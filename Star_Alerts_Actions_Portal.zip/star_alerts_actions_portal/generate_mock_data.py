from pathlib import Path
import pandas as pd
import numpy as np

OUT = Path(__file__).parent / 'data'
OUT.mkdir(exist_ok=True)

alert_cols=['Alert ID','Alert Type','Description','Business Area','Product','State','Severity','Triggered On','Metric Impact','Financial Impact','Owner','Days Open','Status']
alerts = pd.DataFrame([
    ['ALT-2025-000178','Loss Ratio','Loss ratio deteriorated by 6.5 pp vs PY','Product','Star Senior Citizens','Maharashtra','Critical','2025-01-29',6.5,85.3,'Anil Kumar',2,'New'],
    ['ALT-2025-000175','Hospital Severity','Average claim severity 18% above benchmark','Hospital','All Products','Karnataka','Critical','2025-01-28',1.8,42.7,'Neha Singh',3,'New'],
    ['ALT-2025-000165','Claims Leakage','High tariff variance >15% in 12 hospitals','Claims','All Products','Tamil Nadu','High','2025-01-27',1.2,23.6,'Rakesh Nair',4,'In Progress'],
    ['ALT-2025-000162','Expense Ratio','Acquisition expense ratio > target by 3 pp','Distribution','Star Health Assure','West Bengal','High','2025-01-26',3.0,18.9,'Sanjay Verma',5,'In Progress'],
    ['ALT-2025-000160','Early Claims','Early claims rate above threshold (14%)','Underwriting','Star Comprehensive','Delhi','High','2025-01-25',1.1,16.4,'Priya Menon',6,'In Progress'],
    ['ALT-2025-000154','Renewal Retention','Renewal retention dropped by 4 pp','Retention','All Products','Kerala','Medium','2025-01-24',0.0,-12.8,'Manoj Iyer',7,'Open'],
    ['ALT-2025-000148','Hospital Turnaround','Cashless TAT >3 days in 8 hospitals','Claims Ops','All Products','Gujarat','Medium','2025-01-23',0.6,8.7,'Neeraj Patel',8,'Open'],
    ['ALT-2025-000141','Fraud Indicator','Potential fraud cases identified','Fraud Control','All Products','Uttar Pradesh','Medium','2025-01-22',0.4,6.3,'Vikram Rao',9,'Under Review'],
], columns=alert_cols)
# Add more rows to make filtering/pagination meaningful
rng = np.random.default_rng(42)
sev = ['Critical','High','Medium','Low']
areas = ['Product','Claims','Hospital','Distribution','Underwriting','Retention','Claims Ops','Fraud Control']
products = ['All Products','Star Comprehensive','Star Health Assure','Senior Citizens Red Carpet','Family Health Optima']
states = ['Maharashtra','Tamil Nadu','Karnataka','Delhi','Gujarat','Kerala','West Bengal','Telangana','Uttar Pradesh']
owners = ['Anil Kumar','Neha Singh','Rakesh Nair','Sanjay Verma','Priya Menon','Manoj Iyer','Neeraj Patel','Vikram Rao']
types = ['Loss Ratio','Claims Leakage','Hospital','Expense Ratio','Early Claims','Retention','Fraud Indicator','Operational SLA']
statuses = ['New','Open','In Progress','Under Review']
base = []
for i in range(191):
    s = rng.choice(sev, p=[0.07,0.20,0.38,0.35])
    idx = 177-i
    base.append([
        f'ALT-2025-{idx:06d}', rng.choice(types), 'Threshold exception detected from monitored metric', rng.choice(areas),
        rng.choice(products), rng.choice(states), s, pd.Timestamp('2025-01-21')-pd.Timedelta(days=int(rng.integers(0,50))),
        round(float(rng.uniform(0.1,4.0)),1), round(float(rng.uniform(-15,55)),1), rng.choice(owners), int(rng.integers(1,35)), rng.choice(statuses)
    ])
alerts = pd.concat([alerts, pd.DataFrame(base, columns=alerts.columns)], ignore_index=True)
alerts['Triggered On'] = pd.to_datetime(alerts['Triggered On']).dt.strftime('%Y-%m-%d')
alerts.to_csv(OUT/'alerts.csv', index=False)

actions = pd.DataFrame([
['ACT-2025-00056','ALT-2025-000178','Re-negotiate tariffs with top 20 hospitals','Anil Kumar','High','2025-02-15','In Progress',60,-28.5],
['ACT-2025-00053','ALT-2025-000175','Implement severity management program','Neha Singh','High','2025-02-20','In Progress',40,-15.0],
['ACT-2025-00051','ALT-2025-000165','Audit and recover overpayments','Rakesh Nair','High','2025-02-28','On Track',70,-18.0],
['ACT-2025-00048','ALT-2025-000162','Optimize acquisition channels and commissions','Sanjay Verma','Medium','2025-02-28','In Progress',35,-12.0],
['ACT-2025-00046','ALT-2025-000160','Strengthen underwriting for early claims','Priya Menon','High','2025-02-15','At Risk',25,-10.5],
])
more=[]
act_status=['In Progress','On Track','At Risk','Completed','Overdue']
for i in range(127):
    more.append([f'ACT-2025-{45-i:05d}', f'ALT-2025-{rng.integers(1,199):06d}', rng.choice([
        'Validate root cause and close control gap','Improve hospital contract compliance','Automate exception review','Revise product threshold','Train operations team','Implement data quality rule']),
        rng.choice(owners),rng.choice(['High','Medium','Low']),
        (pd.Timestamp('2025-02-01')+pd.Timedelta(days=int(rng.integers(1,90)))).strftime('%Y-%m-%d'),
        rng.choice(act_status,p=[.35,.30,.12,.12,.11]),int(rng.integers(5,101)),round(float(rng.uniform(-20,-1)),1)])
actions = pd.concat([actions,pd.DataFrame(more,columns=actions.columns)],ignore_index=True)
actions.to_csv(OUT/'actions.csv',index=False)

trend=[]
weeks=['W50 Dec24','W51 Dec24','W52 Dec24','W01 Jan25','W02 Jan25','W03 Jan25','W04 Jan25','W05 Jan25']
vals={
'Critical':[11,10,10,10,13,14,16,18],
'High':[43,41,35,44,46,48,41,42],
'Medium':[32,29,41,35,38,39,45,76],
'Low':[20,21,22,24,26,31,34,63]
}
for severity,arr in vals.items():
    for w,v in zip(weeks,arr): trend.append([w,severity,v])
pd.DataFrame(trend,columns=['Week','Severity','Count']).to_csv(OUT/'alert_trend.csv',index=False)

notifications = pd.DataFrame([
['Email Alerts Sent',1254],['In-App Notifications',3412],['SMS Alerts Sent',867]
])
notifications.to_csv(OUT/'notifications.csv',index=False)

print('Mock CSV files generated in', OUT)
