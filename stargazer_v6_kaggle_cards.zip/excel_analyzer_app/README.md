# Stargazer

Stargazer is a Streamlit application for joining and analyzing two Excel or CSV files through a simple web interface.

## Capabilities

- Upload Excel (`xlsx`, `xlsm`, `xls`) and CSV files.
- Resilient CSV decoding using UTF-8, UTF-8 BOM, Windows-1252, and Latin-1 fallbacks.
- Automatic delimiter detection for comma, semicolon, tab, and pipe-delimited files.
- Left/VLOOKUP, inner, right, and full outer joins.
- Visible multi-rule AND/OR filters using columns from both files.
- Save and reload filter definitions.
- Drag, group, pivot, hide, filter, and sort columns through AG Grid.
- Detailed quality profiling for source, joined, and filtered data.
- Missing values, duplicate rows and values, outliers, invalid values, data-type consistency, unique values, and top values.
- EDA for numerical and categorical features.
- Daily, weekly, monthly, quarterly, and yearly trend analysis with period-over-period changes.
- Pearson, Spearman, and Kendall correlation analysis.
- IQR and Z-score outlier detection.
- Download outputs, saved filters, audit logs, and complete analysis dumps.

## Run locally

Use Python 3.11 or 3.12.

### Windows PowerShell

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

Open `http://localhost:8501`.

## Docker

```bash
docker build -t stargazer .
docker run --rm -p 8501:8501 stargazer
```

## Notes

- The application skips malformed CSV lines with a warning rather than failing the complete upload.
- CSV encoding fallbacks address common Microsoft/Windows smart-quote characters such as byte `0x92`.
- Excel export column sizing safely handles empty columns, missing values, and float/NaN width results.
- For very large datasets, move processing to DuckDB, Polars, or Databricks SQL.
- Add SSO, malware scanning, retention controls, and row/upload limits before enterprise deployment.

## Single-file analysis mode

Only File 1 is mandatory. After uploading File 1, you can immediately use Filters & Output, Pivot, Charts, Data Profile, EDA, and Audit & Dump. Upload File 2 only when a join or lookup is required. When the uploaded files or selected sheets change, Stargazer clears prior joined/filtered results to prevent stale analysis.
