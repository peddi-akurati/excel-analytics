# V126 Out-of-range datetime fix

- All uploaded/query datetime values are normalized to Asia/Kolkata.
- Values outside the safe pandas datetime64[ns] range (1678-01-01 through 2262-04-11) are coerced to null.
- Date/time-named columns are normalized when at least one valid timestamp exists, even when most source values are invalid.
- Scalar conversion and profile summaries no longer call Python datetime conversion for unsupported timestamps.
