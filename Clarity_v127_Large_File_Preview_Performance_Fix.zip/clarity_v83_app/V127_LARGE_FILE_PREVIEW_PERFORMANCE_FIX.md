# V127 Large File Preview Performance Fix

## Root causes corrected

1. CSV ingestion used `sep=None` with pandas' Python parser for every upload. This is substantially slower than the C parser for large regular CSV files.
2. Every candidate datetime value was converted in a Python list comprehension, calling `pd.to_datetime` once per cell.
3. Streamlit reruns reread the uploaded file, repeated datetime normalization, and copied the full dataframe even when only a Preview control changed.
4. The entire upload was SHA-256 hashed repeatedly to establish source identity.

## Changes

- Fast C-engine CSV parsing with delimiter sniffing from the first 64 KB; Python parser retained only as fallback.
- Vectorized mixed timezone parsing. Aware values preserve their instant and are converted to Asia/Kolkata; naive values are localized as Asia/Kolkata.
- Lightweight file fingerprint based on size plus first/last 1 MB.
- Source signature resolved before loading. The session-backed normalized dataframe is reused on Streamlit reruns.
- Removed unconditional full dataframe copies before page rendering.
- Datetime detection still occurs immediately after a new source is loaded.

## Validation

- Python compilation passed.
- Included startup validation passed.
- One million mixed-timezone timestamps normalized in approximately two seconds in the validation environment.
- A 68.7 MB, 350,000-row, 31-column synthetic CSV loaded with the C parser in approximately 1.6 seconds in the validation environment. Actual laptop performance depends on storage, CPU, memory and antivirus scanning.
