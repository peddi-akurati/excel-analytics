
import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import streamlit.components.v1 as components
from pathlib import Path
import html as html_lib

st.set_page_config(
    page_title="Claims Process Mining",
    page_icon="⛏️",
    layout="wide",
    initial_sidebar_state="collapsed",
)

st.markdown("""
<style>
.block-container {
    padding-top: 1.0rem;
    padding-bottom: 1.4rem;
    max-width: 100%;
}
[data-testid="stMetric"] {
    background: var(--secondary-background-color);
    border: 1px solid rgba(128,128,128,.18);
    padding: .72rem .85rem;
    border-radius: .8rem;
}
.event-card {
    border: 1px solid rgba(128,128,128,.20);
    border-radius: 12px;
    padding: 10px 12px;
    margin: 0 0 8px 0;
    background: var(--secondary-background-color);
}
.event-name {
    font-weight: 700;
    font-size: .92rem;
    margin-bottom: 4px;
}
.event-value {
    font-size: 1.32rem;
    font-weight: 800;
    line-height: 1.1;
}
.event-sub {
    font-size: .73rem;
    opacity: .72;
    margin-top: 4px;
}
.section-title {
    font-weight: 800;
    font-size: 1.05rem;
    margin: .3rem 0 .7rem 0;
}
.small-note {
    font-size: .77rem;
    opacity: .72;
}
</style>
""", unsafe_allow_html=True)

METRICS = {
    "Average": "mean",
    "Median": "median",
    "50th percentile": "p50",
    "60th percentile": "p60",
    "70th percentile": "p70",
    "80th percentile": "p80",
    "90th percentile": "p90",
    "95th percentile": "p95",
    "99th percentile": "p99",
}

METRIC_QUANTILES = {
    "p50": 0.50,
    "p60": 0.60,
    "p70": 0.70,
    "p80": 0.80,
    "p90": 0.90,
    "p95": 0.95,
    "p99": 0.99,
}

def selected_metric_value(series, metric_key):
    s = pd.Series(series).dropna()
    if s.empty:
        return np.nan
    if metric_key == "mean":
        return s.mean()
    if metric_key == "median":
        return s.median()
    if metric_key in METRIC_QUANTILES:
        return s.quantile(METRIC_QUANTILES[metric_key])
    return np.nan

def fmt_duration(hours):
    if pd.isna(hours):
        return "—"
    hours = float(hours)
    if hours < 1:
        return f"{hours * 60:.0f} min"
    if hours < 48:
        return f"{hours:.1f} h"
    return f"{hours / 24:.1f} d"

@st.cache_data
def load_default():
    here = Path(__file__).resolve().parent
    return pd.read_csv(here / "claims_event_log_timestamp_sample.csv")

def prepare_data(raw):
    """
    Timestamp-only event-log logic.

    Required:
      case_id
      event_name
      eventTimestamp

    Derived:
      event_sequence   = order of events after sorting by eventTimestamp
      previous_event   = preceding event in the same case
      next_event       = following event in the same case
      time_from_previous_hours = current timestamp - previous timestamp
      time_to_next_hours       = next timestamp - current timestamp
      cycle_hours              = last timestamp - first timestamp
    """
    d = raw.copy()

    required = {"case_id", "event_name", "eventTimestamp"}
    missing = required - set(d.columns)
    if missing:
        raise ValueError(
            "Missing required columns: " + ", ".join(sorted(missing))
        )

    d["eventTimestamp"] = pd.to_datetime(
        d["eventTimestamp"], errors="coerce"
    )
    d = d.dropna(subset=["case_id", "event_name", "eventTimestamp"]).copy()

    # If duplicate timestamps exist within one case, preserve original row order
    # as a deterministic tie-breaker.
    d["_row_order"] = np.arange(len(d))
    d = d.sort_values(
        ["case_id", "eventTimestamp", "_row_order"]
    ).reset_index(drop=True)

    d["event_sequence"] = d.groupby("case_id").cumcount() + 1

    d["previous_event"] = d.groupby("case_id")["event_name"].shift(1)
    d["previous_timestamp"] = d.groupby("case_id")["eventTimestamp"].shift(1)

    d["next_event"] = d.groupby("case_id")["event_name"].shift(-1)
    d["next_timestamp"] = d.groupby("case_id")["eventTimestamp"].shift(-1)

    d["time_from_previous_hours"] = (
        d["eventTimestamp"] - d["previous_timestamp"]
    ).dt.total_seconds() / 3600

    d["time_to_next_hours"] = (
        d["next_timestamp"] - d["eventTimestamp"]
    ).dt.total_seconds() / 3600

    # Defensive cleanup for malformed source logs.
    d.loc[d["time_from_previous_hours"] < 0, "time_from_previous_hours"] = np.nan
    d.loc[d["time_to_next_hours"] < 0, "time_to_next_hours"] = np.nan

    cases = (
        d.groupby("case_id")
         .agg(
             case_start=("eventTimestamp", "min"),
             case_end=("eventTimestamp", "max"),
             events=("event_name", "size")
         )
         .reset_index()
    )
    cases["cycle_hours"] = (
        cases["case_end"] - cases["case_start"]
    ).dt.total_seconds() / 3600

    return d.drop(columns=["_row_order"]), cases

def rebuild_after_filters(d):
    """
    Rebuild sequencing and elapsed times after case-level filters.
    """
    cols_to_drop = [
        "event_sequence", "previous_event", "previous_timestamp",
        "next_event", "next_timestamp",
        "time_from_previous_hours", "time_to_next_hours"
    ]
    base = d.drop(columns=[c for c in cols_to_drop if c in d.columns]).copy()
    return prepare_data(base)

def percentile_frame(series):
    s = pd.Series(series).dropna()
    if s.empty:
        return {
            "count": 0,
            "mean": np.nan,
            "median": np.nan,
            "p50": np.nan,
            "p60": np.nan,
            "p70": np.nan,
            "p80": np.nan,
            "p90": np.nan,
            "p95": np.nan,
            "p99": np.nan,
        }
    return {
        "count": int(s.count()),
        "mean": s.mean(),
        "median": s.median(),
        "p50": s.quantile(.50),
        "p60": s.quantile(.60),
        "p70": s.quantile(.70),
        "p80": s.quantile(.80),
        "p90": s.quantile(.90),
        "p95": s.quantile(.95),
        "p99": s.quantile(.99),
    }

def event_stats(d):
    """
    Event scorecard timing:
    time from this event occurrence until the next event occurrence.
    Final events therefore have no time-to-next value.
    """
    records = []
    for event_name, grp in d.groupby("event_name", sort=False):
        x = percentile_frame(grp["time_to_next_hours"])
        x["event_name"] = event_name
        x["executions"] = len(grp)
        records.append(x)
    return pd.DataFrame(records)

def transition_stats(d):
    t = d.dropna(
        subset=["next_event", "time_to_next_hours"]
    ).copy()

    records = []
    for (source, target), grp in t.groupby(
        ["event_name", "next_event"], sort=False
    ):
        x = percentile_frame(grp["time_to_next_hours"])
        x["event_name"] = source
        x["next_event"] = target
        x["cases"] = len(grp)
        records.append(x)

    if not records:
        return pd.DataFrame(columns=[
            "event_name", "next_event", "cases",
            "mean", "median", "p50", "p60", "p70", "p80",
            "p90", "p95", "p99"
        ])
    return pd.DataFrame(records)


def case_variant_analysis(d, cases):
    """Build one end-to-end path per case and classify self/rework loops."""
    case_metrics = cases.set_index("case_id")["cycle_hours"].to_dict()
    records = []
    ordered = d.sort_values(["case_id", "event_sequence", "eventTimestamp"])

    for case_id, grp in ordered.groupby("case_id", sort=False):
        seq = grp["event_name"].astype(str).tolist()
        self_edges, rework_edges, rework_events = [], [], []
        seen = set()

        for i, evt in enumerate(seq):
            if i > 0:
                prev = seq[i - 1]
                if evt == prev:
                    self_edges.append((prev, evt))
                elif evt in seen:
                    rework_edges.append((prev, evt))
                    rework_events.append(evt)
            seen.add(evt)

        records.append({
            "case_id": case_id,
            "path_tuple": tuple(seq),
            "process_variant": " → ".join(seq),
            "event_count": len(seq),
            "cycle_hours": case_metrics.get(case_id, np.nan),
            "has_self_loop": bool(self_edges),
            "has_rework_loop": bool(rework_edges),
            "self_loop_count": len(self_edges),
            "rework_return_count": len(rework_edges),
            "self_loop_edges": tuple(self_edges),
            "rework_edges": tuple(rework_edges),
            "rework_events": tuple(sorted(set(rework_events))),
        })
    return pd.DataFrame(records)


def variant_summary(d, cases):
    case_v = case_variant_analysis(d, cases)
    if case_v.empty:
        return case_v, pd.DataFrame()

    total_cases = max(len(case_v), 1)
    grouped = []
    for path_tuple, grp in case_v.groupby("path_tuple", sort=False):
        cycle = grp["cycle_hours"].dropna()
        grouped.append({
            "process_variant": " → ".join(path_tuple),
            "path_tuple": path_tuple,
            "claims": len(grp),
            "share_pct": len(grp) / total_cases * 100,
            "events_in_path": len(path_tuple),
            "avg_e2e_hours": cycle.mean() if not cycle.empty else np.nan,
            "median_e2e_hours": cycle.median() if not cycle.empty else np.nan,
            "p95_e2e_hours": cycle.quantile(.95) if not cycle.empty else np.nan,
            "has_self_loop": bool(grp["has_self_loop"].any()),
            "has_rework_loop": bool(grp["has_rework_loop"].any()),
            "self_loop_cases": int(grp["has_self_loop"].sum()),
            "rework_loop_cases": int(grp["has_rework_loop"].sum()),
            "self_loop_count": int(grp["self_loop_count"].sum()),
            "rework_return_count": int(grp["rework_return_count"].sum()),
        })

    summary = pd.DataFrame(grouped).sort_values(
        ["claims", "process_variant"], ascending=[False, True]
    ).reset_index(drop=True)
    summary.insert(0, "variant_rank", np.arange(1, len(summary) + 1))
    return case_v, summary


def filter_process_map_data(d, case_v, variant_summary_df, highlight_mode, selected_variant_rank=None):
    """
    Restrict the process-map dataset to only the cases represented by the
    active variant-highlighting selection. Unrelated paths, nodes, counts and
    timing statistics are therefore removed from the visual entirely.
    """
    if highlight_mode == "None":
        return d.copy(), "All process paths"

    selected_case_ids = []
    description = highlight_mode

    if highlight_mode == "Selected top variant" and selected_variant_rank:
        row = variant_summary_df[
            variant_summary_df["variant_rank"] == selected_variant_rank
        ]
        if not row.empty:
            path_tuple = row.iloc[0]["path_tuple"]
            selected_case_ids = case_v.loc[
                case_v["path_tuple"] == path_tuple, "case_id"
            ].tolist()
            description = f"Top variant #{selected_variant_rank}"

    elif highlight_mode == "Self-loop variants":
        selected_case_ids = case_v.loc[
            case_v["has_self_loop"], "case_id"
        ].tolist()
        description = "Self-loop variants only"

    elif highlight_mode == "Rework-loop variants":
        selected_case_ids = case_v.loc[
            case_v["has_rework_loop"], "case_id"
        ].tolist()
        description = "Rework-loop variants only"

    elif highlight_mode == "All loop variants":
        selected_case_ids = case_v.loc[
            case_v["has_self_loop"] | case_v["has_rework_loop"], "case_id"
        ].tolist()
        description = "All loop variants only"

    filtered = d[d["case_id"].isin(selected_case_ids)].copy()
    return filtered, description


def selected_highlight(case_v, variant_summary_df, highlight_mode, selected_variant_rank=None):
    edge_types, node_types = {}, {}
    precedence = {"path": 1, "rework": 2, "self": 3}

    def add_edge(edge, kind):
        current = edge_types.get(edge)
        if current is None or precedence[kind] > precedence[current]:
            edge_types[edge] = kind

    def add_node(node, kind):
        current = node_types.get(node)
        if current is None or precedence[kind] > precedence[current]:
            node_types[node] = kind

    if highlight_mode == "Selected top variant" and selected_variant_rank:
        row = variant_summary_df[
            variant_summary_df["variant_rank"] == selected_variant_rank
        ]
        if not row.empty:
            seq = list(row.iloc[0]["path_tuple"])
            seen = set()
            for i, evt in enumerate(seq):
                add_node(evt, "path")
                if i > 0:
                    prev = seq[i - 1]
                    kind = "path"
                    if evt == prev:
                        kind = "self"
                    elif evt in seen:
                        kind = "rework"
                    add_edge((prev, evt), kind)
                    if kind in ("self", "rework"):
                        add_node(prev, kind)
                        add_node(evt, kind)
                seen.add(evt)

    elif highlight_mode in ("Self-loop variants", "Rework-loop variants", "All loop variants"):
        if highlight_mode == "Self-loop variants":
            subset = case_v[case_v["has_self_loop"]]
        elif highlight_mode == "Rework-loop variants":
            subset = case_v[case_v["has_rework_loop"]]
        else:
            subset = case_v[case_v["has_self_loop"] | case_v["has_rework_loop"]]

        for _, r in subset.iterrows():
            seq = list(r["path_tuple"])
            for a, b in zip(seq[:-1], seq[1:]):
                add_edge((a, b), "path")
            if highlight_mode in ("Self-loop variants", "All loop variants"):
                for edge in r["self_loop_edges"]:
                    add_edge(edge, "self")
                    add_node(edge[0], "self")
            if highlight_mode in ("Rework-loop variants", "All loop variants"):
                for edge in r["rework_edges"]:
                    add_edge(edge, "rework")
                    add_node(edge[0], "rework")
                    add_node(edge[1], "rework")

    return edge_types, node_types


def process_map_html(d, metric_key, canvas_height=820, highlight_edges=None, highlight_nodes=None):
    """Render a Power Automate Process Mining-inspired directed process map."""
    highlight_edges = highlight_edges or {}
    highlight_nodes = highlight_nodes or {}
    edge_palette = {"path": "#0f6cbd", "rework": "#f59e0b", "self": "#d13438"}
    node_palette = {"path": "#0f6cbd", "rework": "#f59e0b", "self": "#d13438"}

    t_stats = transition_stats(d).copy()
    e_stats = event_stats(d).set_index("event_name")
    node_order = (d.groupby("event_name")["event_sequence"].median().sort_values(kind="stable").index.tolist())
    if not node_order:
        return "<div style='padding:24px'>No process events available.</div>"

    width = 1160
    top = 92
    bottom = 82
    usable_h = max(canvas_height - top - bottom, 420)
    gap = usable_h / max(len(node_order) - 1, 1)
    center_x = 555
    offsets = [0, -115, 90, -70, 120, -35, 80, -95, 35, 105, -120]
    positions = {name: (center_x + offsets[i % len(offsets)], top + i * gap) for i, name in enumerate(node_order)}

    metric_vals = [float(e_stats.loc[n, metric_key]) for n in node_order if n in e_stats.index and pd.notna(e_stats.loc[n, metric_key])]
    max_metric = max(metric_vals) if metric_vals else 1.0
    trans_max = max(t_stats["cases"].max(), 1) if not t_stats.empty else 1

    ordered = d.sort_values(["case_id", "event_sequence"])
    first_events = ordered.groupby("case_id", as_index=False).first()["event_name"].value_counts()
    last_events = ordered.groupby("case_id", as_index=False).last()["event_name"].value_counts()
    total_cases = max(d["case_id"].nunique(), 1)

    def esc(v):
        return html_lib.escape(str(v))

    svg = []
    svg.append(f'''<svg viewBox="0 0 {width} {canvas_height}" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" style="font-family:Segoe UI,Arial,sans-serif;background:#ffffff;">
      <defs>
        <marker id="arrow" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto" markerUnits="strokeWidth"><path d="M0,0 L9,4.5 L0,9 z" fill="#6b7280"/></marker>
        <marker id="arrow-path" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto" markerUnits="strokeWidth"><path d="M0,0 L9,4.5 L0,9 z" fill="#0f6cbd"/></marker>
        <marker id="arrow-rework" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto" markerUnits="strokeWidth"><path d="M0,0 L9,4.5 L0,9 z" fill="#f59e0b"/></marker>
        <marker id="arrow-self" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto" markerUnits="strokeWidth"><path d="M0,0 L9,4.5 L0,9 z" fill="#d13438"/></marker>
        <filter id="halo" x="-100%" y="-100%" width="300%" height="300%"><feGaussianBlur stdDeviation="10"/></filter>
      </defs>''')

    start_x, start_y = center_x, 32
    end_x, end_y = center_x, canvas_height - 32
    svg.append(f'<circle cx="{start_x}" cy="{start_y}" r="22" fill="#2f2f2f"/>')
    svg.append(f'<text x="{start_x}" y="{start_y+4}" text-anchor="middle" fill="white" font-size="10" font-weight="600">Start</text>')
    svg.append(f'<circle cx="{end_x}" cy="{end_y}" r="22" fill="#2f2f2f"/>')
    svg.append(f'<text x="{end_x}" y="{end_y+4}" text-anchor="middle" fill="white" font-size="10" font-weight="600">End</text>')

    for evt, count in first_events.items():
        if evt not in positions: continue
        x, y = positions[evt]
        sw = 1.2 + 4.5 * (float(count) / total_cases)
        path = f'M {start_x} {start_y+22} C {start_x} {start_y+50}, {x} {y-58}, {x} {y-25}'
        svg.append(f'<path d="{path}" fill="none" stroke="#9ca3af" stroke-width="{sw:.2f}" opacity="0.82" marker-end="url(#arrow)"/>')
        svg.append(f'<text x="{(start_x+x)/2:.1f}" y="{(start_y+y)/2-8:.1f}" text-anchor="middle" fill="#6b7280" font-size="10">{int(count):,}</text>')

    for _, r in t_stats.iterrows():
        source, target = r["event_name"], r["next_event"]
        if source not in positions or target not in positions: continue
        x1, y1 = positions[source]; x2, y2 = positions[target]
        count = float(r["cases"])
        sw = 1.0 + 5.2 * (count / trans_max) ** 0.72
        metric_text = fmt_duration(r[metric_key])
        if target == source or y2 <= y1:
            loop_x = max(x1, x2) + 265
            path = f'M {x1+112} {y1} C {loop_x} {y1}, {loop_x} {y2}, {x2+112} {y2}'
            label_x = loop_x - 5; label_y = (y1+y2)/2
        else:
            c1y = y1 + (y2-y1)*0.42; c2y = y1 + (y2-y1)*0.58
            path = f'M {x1} {y1+25} C {x1} {c1y}, {x2} {c2y}, {x2} {y2-25}'
            label_x = (x1+x2)/2 + (18 if x2 >= x1 else -18); label_y = (y1+y2)/2
        edge_kind = highlight_edges.get((source, target))
        stroke = edge_palette.get(edge_kind, "#6b7280")
        marker = {"path": "arrow-path", "rework": "arrow-rework", "self": "arrow-self"}.get(edge_kind, "arrow")
        opacity = 0.98 if edge_kind else 0.40
        if edge_kind:
            sw = max(sw, 4.2 if edge_kind == "path" else 5.4)

        svg.append(f'<path d="{path}" fill="none" stroke="{stroke}" stroke-width="{sw:.2f}" opacity="{opacity:.2f}" marker-end="url(#{marker})"/>')
        label = f'{int(count):,}  ·  {esc(metric_text)}'
        if edge_kind == "self":
            label += "  · SELF LOOP"
        elif edge_kind == "rework":
            label += "  · REWORK"
        label_w = max(74, min(225, 7.0*len(label)+14))
        label_border = stroke if edge_kind else "#ffffff"
        label_text = stroke if edge_kind else "#6b7280"
        svg.append(f'<rect x="{label_x-label_w/2:.1f}" y="{label_y-11:.1f}" width="{label_w:.1f}" height="20" rx="10" fill="white" fill-opacity="0.96" stroke="{label_border}" stroke-width="{1.2 if edge_kind else 0}"/>')
        svg.append(f'<text x="{label_x:.1f}" y="{label_y+3:.1f}" text-anchor="middle" fill="{label_text}" font-size="10" font-weight="{600 if edge_kind else 400}">{label}</text>')

    for evt, count in last_events.items():
        if evt not in positions: continue
        x, y = positions[evt]
        sw = 1.2 + 4.5*(float(count)/total_cases)
        path = f'M {x} {y+25} C {x} {y+58}, {end_x} {end_y-50}, {end_x} {end_y-22}'
        svg.append(f'<path d="{path}" fill="none" stroke="#9ca3af" stroke-width="{sw:.2f}" opacity="0.82" marker-end="url(#arrow)"/>')
        svg.append(f'<text x="{(x+end_x)/2:.1f}" y="{(y+end_y)/2+5:.1f}" text-anchor="middle" fill="#6b7280" font-size="10">{int(count):,}</text>')

    for idx, name in enumerate(node_order, start=1):
        x, y = positions[name]
        r = e_stats.loc[name] if name in e_stats.index else None
        executions = int(r["executions"]) if r is not None else 0
        metric_val = float(r[metric_key]) if r is not None and pd.notna(r[metric_key]) else np.nan
        metric_text = fmt_duration(metric_val)
        strength = 0 if pd.isna(metric_val) else min(max(metric_val/max_metric, 0.08), 1.0)
        halo_r = 30 + 29*strength; halo_opacity = 0.10 + 0.20*strength
        svg.append(f'<circle cx="{x-102}" cy="{y}" r="{halo_r:.1f}" fill="#1683ff" opacity="{halo_opacity:.2f}" filter="url(#halo)"/>')
        node_kind = highlight_nodes.get(name)
        node_stroke = node_palette.get(node_kind, "#c9cdd3")
        node_sw = 2.6 if node_kind else 1.2
        if node_kind:
            svg.append(f'<circle cx="{x}" cy="{y}" r="38" fill="{node_stroke}" opacity="0.10"/>')
        svg.append(f'<rect x="{x-108}" y="{y-24}" width="226" height="48" rx="24" fill="#ffffff" stroke="{node_stroke}" stroke-width="{node_sw}"/>')
        svg.append(f'<circle cx="{x-103}" cy="{y}" r="17" fill="{node_palette.get(node_kind, "#303030")}"/>')
        svg.append(f'<text x="{x-103}" y="{y+4}" text-anchor="middle" fill="white" font-size="10" font-weight="700">{idx}</text>')
        svg.append(f'<text x="{x-78}" y="{y-3}" fill="#242424" font-size="12" font-weight="600">{esc(name)}</text>')
        svg.append(f'<text x="{x-78}" y="{y+13}" fill="#737373" font-size="10">{executions:,} events · {esc(metric_text)}</text>')
        accent = '#0f6cbd' if not pd.isna(metric_val) else '#c9cdd3'
        svg.append(f'<path d="M {x+99} {y-11} A 13 13 0 0 1 {x+99} {y+11}" fill="none" stroke="{accent}" stroke-width="3" stroke-linecap="round"/>')

    svg.append('</svg>')
    legend_metric = {"mean":"Average","median":"Median","p90":"P90","p95":"P95","p99":"P99"}.get(metric_key, metric_key.upper())
    return f'''<!doctype html><html><head><meta charset="utf-8"><style>
html,body{{margin:0;background:#fff;overflow:hidden}} .wrap{{position:relative;width:100%;height:{canvas_height}px;border:1px solid #edebe9;border-radius:8px;background:white}} .legend{{position:absolute;left:14px;bottom:10px;display:flex;gap:18px;align-items:center;padding:7px 10px;background:rgba(255,255,255,.94);border:1px solid #edebe9;border-radius:5px;font:11px Segoe UI,Arial,sans-serif;color:#605e5c}} .legend .line{{width:36px;height:0;border-top:4px solid #6b7280;display:inline-block;margin-right:6px}} .legend .halo{{width:17px;height:17px;border-radius:50%;background:rgba(22,131,255,.25);box-shadow:0 0 10px rgba(22,131,255,.55);display:inline-block;margin-right:6px}}
</style></head><body><div class="wrap">{''.join(svg)}<div class="legend"><span><span class="line"></span>Path frequency</span><span><span class="halo"></span>{esc(legend_metric)} elapsed time</span><span style="color:#0f6cbd;font-weight:600">● Selected path</span><span style="color:#f59e0b;font-weight:600">● Rework</span><span style="color:#d13438;font-weight:600">● Self-loop</span></div></div></body></html>'''

# ------------------------------------------------------------------
# Header / data
# ------------------------------------------------------------------
st.title("Claims Process Mining")
st.caption(
    "Timestamp-only process mining: sequence, transitions and cycle times "
    "are derived from eventTimestamp."
)

with st.expander("Data source & event-log rules", expanded=False):
    c1, c2 = st.columns([1, 2])
    with c1:
        uploaded = st.file_uploader(
            "Upload event log CSV",
            type=["csv"]
        )
    with c2:
        st.markdown(
            "**Required columns:** `case_id`, `event_name`, `eventTimestamp`  \n"
            "**No start/end timestamps are required.** Events are ordered "
            "within each claim using `eventTimestamp`.  \n\n"
            "Derived elapsed time = timestamp of next event − timestamp of "
            "current event. End-to-end cycle = last event timestamp − first "
            "event timestamp."
        )

raw = pd.read_csv(uploaded) if uploaded is not None else load_default()

try:
    data, cases = prepare_data(raw)
except Exception as exc:
    st.error(str(exc))
    st.stop()

# ------------------------------------------------------------------
# Optional business filters
# ------------------------------------------------------------------
filter_cols = [
    c for c in ["claim_type", "product", "region"]
    if c in data.columns
]

if filter_cols:
    with st.expander("Business filters", expanded=False):
        filtered = data.copy()
        for col in filter_cols:
            options = sorted(filtered[col].dropna().unique().tolist())
            selected = st.multiselect(
                col.replace("_", " ").title(),
                options,
                default=options
            )
            if selected:
                filtered = filtered[filtered[col].isin(selected)]

        try:
            data, cases = rebuild_after_filters(filtered)
        except Exception as exc:
            st.error(str(exc))
            st.stop()

analysis_base_data = data.copy()

# ------------------------------------------------------------------
# Timing lens
# ------------------------------------------------------------------
st.markdown('<div class="section-title">Timing lens</div>', unsafe_allow_html=True)
metric_label = st.segmented_control(
    "Timing lens",
    options=list(METRICS.keys()),
    default="Average",
    label_visibility="collapsed",
)
metric_key = METRICS[metric_label]

# Initial summary cards; the selected E2E lens follows the timing selector.
selected_e2e_value = selected_metric_value(cases["cycle_hours"], metric_key)
m1, m2, m3, m4 = st.columns(4)
m1.metric("Claims", f"{cases['case_id'].nunique():,}")
m2.metric("Events", f"{len(data):,}")
m3.metric("Median E2E cycle", fmt_duration(cases["cycle_hours"].median()))
m4.metric(f"{metric_label} E2E cycle", fmt_duration(selected_e2e_value))

st.divider()

# ------------------------------------------------------------------
# Maximize/minimize
# ------------------------------------------------------------------
control1, control2 = st.columns(2)
with control1:
    if st.button("⛶ Maximize flow", use_container_width=True):
        st.session_state["flow_expanded"] = True
with control2:
    if st.button("⇲ Minimize flow", use_container_width=True):
        st.session_state["flow_expanded"] = False

expanded = st.session_state.get("flow_expanded", False)

# ------------------------------------------------------------------
# Main analysis layout
# ------------------------------------------------------------------
left, right = st.columns([1, 3.2], gap="large")

with left:
    st.markdown(
        '<div class="section-title">Analysis filters</div>',
        unsafe_allow_html=True
    )

    all_events = (
        analysis_base_data.groupby("event_name")["event_sequence"]
        .median()
        .sort_values()
        .index
        .tolist()
    )
    selected_events = st.multiselect(
        "Events required for analysis",
        options=all_events,
        default=all_events,
        help=(
            "Only selected activities are retained. Sequence and elapsed "
            "times are rebuilt from eventTimestamp after filtering."
        ),
    )

    all_case_ids = sorted(
        analysis_base_data["case_id"].astype(str).dropna().unique().tolist()
    )
    selected_case_ids = st.multiselect(
        "Case ID",
        options=all_case_ids,
        default=[],
        placeholder="All case IDs",
        help="Leave empty to include every case ID.",
    )

    if not selected_events:
        st.warning("Select at least one event.")
        st.stop()

    filtered_analysis = analysis_base_data[
        analysis_base_data["event_name"].isin(selected_events)
    ].copy()

    if selected_case_ids:
        filtered_analysis = filtered_analysis[
            filtered_analysis["case_id"].astype(str).isin(selected_case_ids)
        ].copy()

    if filtered_analysis.empty:
        st.warning("No records match the selected event/case filters.")
        st.stop()

    data, cases = rebuild_after_filters(filtered_analysis)
    stats = event_stats(data)
    case_variants, variants = variant_summary(data, cases)

    st.caption(
        f"**{data['case_id'].nunique():,} claims** · "
        f"**{len(data):,} events** · "
        f"**{data['event_name'].nunique():,} activities**"
    )

    st.markdown("#### Variant highlighting")
    highlight_mode = st.selectbox(
        "Variant filter",
        [
            "None",
            "Selected top variant",
            "Self-loop variants",
            "Rework-loop variants",
            "All loop variants",
        ],
        index=0,
    )

    max_rank = max(min(len(variants), 20), 1)
    selected_variant_rank = st.selectbox(
        "Top repeating path",
        options=list(range(1, max_rank + 1)),
        format_func=lambda r: (
            f"#{r} · {int(variants.iloc[r-1]['claims']):,} claims · "
            f"{variants.iloc[r-1]['share_pct']:.1f}%"
        ) if len(variants) >= r else f"#{r}",
        disabled=(highlight_mode != "Selected top variant"),
    )

map_data, map_filter_description = filter_process_map_data(
    data, case_variants, variants, highlight_mode, selected_variant_rank
)
highlight_edges, highlight_nodes = selected_highlight(
    case_variants, variants, highlight_mode, selected_variant_rank
)

# Metrics shown below are based on the final process-map population.
_, map_cases = rebuild_after_filters(map_data)
selected_e2e_value = selected_metric_value(map_cases["cycle_hours"], metric_key)

with left:
    st.markdown("#### Selected E2E metric")
    st.metric(
        f"{metric_label} E2E cycle",
        fmt_duration(selected_e2e_value)
    )
    if highlight_mode != "None":
        st.caption(
            f"Variant population: **{map_filter_description}** · "
            f"{map_data['case_id'].nunique():,} claims · "
            f"{len(map_data):,} events"
        )

with right:
    st.markdown(
        '<div class="section-title">End-to-end process flow</div>',
        unsafe_allow_html=True
    )

    map_height = 900 if expanded else 760
    components.html(
        process_map_html(
            map_data,
            metric_key,
            canvas_height=map_height,
            highlight_edges=highlight_edges,
            highlight_nodes=highlight_nodes,
        ),
        height=map_height + 10,
        scrolling=False,
    )


st.divider()

# ------------------------------------------------------------------
# Supporting analysis tabs
# ------------------------------------------------------------------
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "E2E cycle time",
    "Event-to-next timing",
    "Transitions",
    "Top path variants",
    "Loop intelligence",
])

with tab1:
    q = pd.DataFrame({
        "Statistic": [
            "Average", "Median", "P50", "P60", "P70", "P80",
            "P90", "P95", "P99"
        ],
        "End-to-end hours": [
            cases["cycle_hours"].mean(),
            cases["cycle_hours"].median(),
            cases["cycle_hours"].quantile(.50),
            cases["cycle_hours"].quantile(.60),
            cases["cycle_hours"].quantile(.70),
            cases["cycle_hours"].quantile(.80),
            cases["cycle_hours"].quantile(.90),
            cases["cycle_hours"].quantile(.95),
            cases["cycle_hours"].quantile(.99),
        ]
    })
    q["Readable"] = q["End-to-end hours"].map(fmt_duration)
    st.dataframe(q, use_container_width=True, hide_index=True)

with tab2:
    show = stats[
        ["event_name", "executions", "mean", "median",
         "p50", "p60", "p70", "p80", "p90", "p95", "p99"]
    ].copy()

    for col in [
        "mean", "median", "p50", "p60", "p70", "p80",
        "p90", "p95", "p99"
    ]:
        show[col] = show[col].map(fmt_duration)

    show.columns = [
        "Event", "Executions", "Average to next", "Median to next",
        "P50 to next", "P60 to next", "P70 to next", "P80 to next",
        "P90 to next", "P95 to next", "P99 to next"
    ]

    st.dataframe(show, use_container_width=True, hide_index=True)

with tab3:
    t = transition_stats(data).copy()

    if t.empty:
        st.info("No event-to-event transitions are available.")
    else:
        for col in [
            "mean", "median", "p50", "p60", "p70", "p80",
            "p90", "p95", "p99"
        ]:
            t[col] = t[col].map(fmt_duration)

        t = t[[
            "event_name", "next_event", "cases",
            "mean", "median", "p50", "p60", "p70", "p80",
            "p90", "p95", "p99"
        ]]

        t.columns = [
            "From event", "To event", "Transitions",
            "Average", "Median", "P50", "P60", "P70", "P80",
            "P90", "P95", "P99"
        ]

        st.dataframe(t, use_container_width=True, hide_index=True)

with tab4:
    st.markdown("#### Top end-to-end repeating paths")
    if variants.empty:
        st.info("No complete process variants are available.")
    else:
        max_top = max(5, min(50, len(variants)))
        default_top = min(15, max_top)
        top_n = st.slider("Number of top variants", 5, max_top, default_top, 1)

        vshow = variants.head(top_n).copy()
        vshow["Loop type"] = np.select(
            [
                vshow["has_self_loop"] & vshow["has_rework_loop"],
                vshow["has_self_loop"],
                vshow["has_rework_loop"],
            ],
            ["🔴 Self + 🟠 Rework", "🔴 Self-loop", "🟠 Rework loop"],
            default="Normal",
        )
        vshow["Average E2E"] = vshow["avg_e2e_hours"].map(fmt_duration)
        vshow["Median E2E"] = vshow["median_e2e_hours"].map(fmt_duration)
        vshow["P95 E2E"] = vshow["p95_e2e_hours"].map(fmt_duration)
        vshow["Share %"] = vshow["share_pct"].round(2)

        st.dataframe(
            vshow[[
                "variant_rank", "process_variant", "claims", "Share %",
                "events_in_path", "Loop type",
                "Average E2E", "Median E2E", "P95 E2E",
            ]].rename(columns={
                "variant_rank": "Rank",
                "process_variant": "End-to-end path",
                "claims": "Claims",
                "events_in_path": "Events",
            }),
            use_container_width=True,
            hide_index=True,
            column_config={"End-to-end path": st.column_config.TextColumn(width="large")},
        )

with tab5:
    st.markdown("#### Loop intelligence")
    st.caption(
        "Self-loop = the same activity repeats immediately. "
        "Rework loop = the process returns to an activity already visited earlier."
    )

    self_cases_df = case_variants[case_variants["has_self_loop"]]
    rework_cases_df = case_variants[case_variants["has_rework_loop"]]

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Self-loop claims", f"{len(self_cases_df):,}")
    c2.metric("Self-loop rate", f"{len(self_cases_df)/max(len(case_variants),1)*100:.1f}%")
    c3.metric("Rework claims", f"{len(rework_cases_df):,}")
    c4.metric("Rework rate", f"{len(rework_cases_df)/max(len(case_variants),1)*100:.1f}%")

    loop_rows = []
    for _, r in case_variants.iterrows():
        for edge in r["self_loop_edges"]:
            loop_rows.append({"case_id": r["case_id"], "loop_type": "Self-loop", "from_event": edge[0], "to_event": edge[1]})
        for edge in r["rework_edges"]:
            loop_rows.append({"case_id": r["case_id"], "loop_type": "Rework", "from_event": edge[0], "to_event": edge[1]})

    loop_df = pd.DataFrame(loop_rows)

    if loop_df.empty:
        st.success("No self-loops or rework loops are present in the current filter.")
    else:
        loop_summary = (
            loop_df.groupby(["loop_type", "from_event", "to_event"])
                   .agg(Occurrences=("case_id", "size"), Claims=("case_id", "nunique"))
                   .reset_index()
                   .sort_values(["loop_type", "Occurrences"], ascending=[True, False])
        )
        loop_summary["Highlight"] = loop_summary["loop_type"].map(
            {"Self-loop": "🔴 Self-loop", "Rework": "🟠 Rework"}
        )
        st.dataframe(
            loop_summary[["Highlight", "from_event", "to_event", "Occurrences", "Claims"]]
                .rename(columns={"from_event": "From event", "to_event": "To event"}),
            use_container_width=True,
            hide_index=True,
        )

        st.markdown("##### Loop-affected end-to-end variants")
        affected = variants[variants["has_self_loop"] | variants["has_rework_loop"]].copy()
        affected["Loop type"] = np.select(
            [
                affected["has_self_loop"] & affected["has_rework_loop"],
                affected["has_self_loop"],
                affected["has_rework_loop"],
            ],
            ["🔴 Self + 🟠 Rework", "🔴 Self-loop", "🟠 Rework loop"],
            default="Normal",
        )
        affected["Share %"] = affected["share_pct"].round(2)

        st.dataframe(
            affected[[
                "variant_rank", "process_variant", "claims", "Share %",
                "Loop type", "self_loop_count", "rework_return_count",
            ]].rename(columns={
                "variant_rank": "Rank",
                "process_variant": "End-to-end path",
                "claims": "Claims",
                "self_loop_count": "Self-loop occurrences",
                "rework_return_count": "Rework returns",
            }),
            use_container_width=True,
            hide_index=True,
        )

# ------------------------------------------------------------------
# Detailed records - selected timing lens
# ------------------------------------------------------------------
st.divider()
st.markdown("### Detailed records")

# Use the final map population, which already reflects:
# business filters -> event filters -> case filters -> variant selection.
detail_threshold = selected_metric_value(map_cases["cycle_hours"], metric_key)

if pd.notna(detail_threshold):
    detail_cases = map_cases[
        map_cases["cycle_hours"] >= detail_threshold
    ].copy()
else:
    detail_cases = map_cases.iloc[0:0].copy()

# Rebuild variant path from the final map population so the displayed
# path exactly matches the process-flow visual.
map_case_variants, _ = variant_summary(map_data, map_cases)
variant_lookup = (
    map_case_variants.set_index("case_id")["process_variant"].to_dict()
    if not map_case_variants.empty else {}
)

detail_cases["Required variant path traversed"] = (
    detail_cases["case_id"].map(variant_lookup)
)
detail_cases["E2E elapsed hours"] = detail_cases["cycle_hours"]
detail_cases["E2E elapsed"] = detail_cases["cycle_hours"].map(fmt_duration)
detail_cases["Selected timing lens"] = metric_label
detail_cases["Selected threshold"] = fmt_duration(detail_threshold)

# Pull useful case-level business attributes when present.
attr_cols = [
    c for c in ["claim_type", "product", "region", "amount"]
    if c in map_data.columns
]
if attr_cols:
    case_attrs = (
        map_data.sort_values(["case_id", "eventTimestamp"])
        .groupby("case_id")[attr_cols]
        .first()
        .reset_index()
    )
    detail_cases = detail_cases.merge(
        case_attrs,
        on="case_id",
        how="left"
    )

# Highest E2E elapsed time first.
detail_cases = detail_cases.sort_values(
    "E2E elapsed hours",
    ascending=False
)

st.caption(
    f"Showing **{len(detail_cases):,} cases** at or above the current "
    f"**{metric_label}** E2E threshold of "
    f"**{fmt_duration(detail_threshold)}**, sorted by highest E2E elapsed time."
)

display_cols = [
    "case_id",
    "case_start",
    "case_end",
    "events",
    "E2E elapsed",
    "E2E elapsed hours",
    "Selected timing lens",
    "Selected threshold",
    "Required variant path traversed",
] + attr_cols

st.dataframe(
    detail_cases[display_cols],
    use_container_width=True,
    hide_index=True,
    column_config={
        "case_id": st.column_config.TextColumn("Case ID"),
        "case_start": st.column_config.DatetimeColumn("Case start"),
        "case_end": st.column_config.DatetimeColumn("Case end"),
        "events": st.column_config.NumberColumn("Event count"),
        "E2E elapsed": st.column_config.TextColumn("E2E elapsed"),
        "E2E elapsed hours": st.column_config.NumberColumn(
            "E2E elapsed hours",
            format="%.2f"
        ),
        "Required variant path traversed": st.column_config.TextColumn(
            "Required variant path traversed",
            width="large"
        ),
    },
)

st.caption(
    "Important: a single event timestamp cannot reveal the true duration "
    "of an activity. This app therefore measures inter-event elapsed time "
    "and case throughput time, which are directly derivable from the log."
)
