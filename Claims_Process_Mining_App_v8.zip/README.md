# Claims Process Mining — Timestamp-only Event Log

This version assumes each event contains only one timestamp.

## Required columns

- `case_id`
- `event_name`
- `eventTimestamp`

No event start/end timestamps are required.

## Derived logic

Within each `case_id`, events are sorted by `eventTimestamp`.

- `event_sequence` = sorted order within the claim
- `next_event` = following event
- `time_to_next_hours` = next event timestamp - current event timestamp
- `time_from_previous_hours` = current event timestamp - previous event timestamp
- `cycle_hours` = last event timestamp - first event timestamp

Because a single timestamp cannot reveal true activity duration, the app
does not pretend that `time_to_next_hours` is processing duration. It is
displayed as inter-event elapsed time.

## Features

- Event-wise scorecards
- Microsoft Power Automate Process Mining-style directed process map
- Average / Median / P90 / P95 / P99 timing lenses
- Maximize / minimize process map
- E2E claim cycle-time analysis
- Event-to-next timing statistics
- Transition-level timing statistics
- Process variants and rework loops
- CSV upload
- Claim type / product / region filters

## Run

```bash
pip install -r requirements.txt
streamlit run app.py
```


## Process map visual
The process map uses Start/End boundary nodes, activity pills, blue performance halos, directed curved edges, frequency-based edge thickness, and transition timing labels. Rework/backward transitions are routed as visible loops.


## Variant intelligence added

- Ranked top end-to-end repeating event paths
- Claim count and share per variant
- Average / median / P95 E2E time by variant
- Self-loop detection (`A -> A`)
- Rework-loop detection (`A -> B -> ... -> A`)
- Loop transition frequency and affected-claim counts
- Map highlighting for selected top variant, self-loop variants, rework-loop variants, or all loop variants
- Blue = selected path, orange = rework, red = self-loop


## Event/case filters and expanded timing lenses

- Left pane beside the process map now contains event and case-ID filters.
- Event scorecards were removed.
- Event filtering rebuilds sequence and elapsed time from `eventTimestamp`.
- Timing lenses: Average, Median, P50, P60, P70, P80, P90, P95, P99.
- The E2E KPI is generic and follows the selected timing lens.
- Detailed case records appear directly below the process flow.
- Detailed cases are those at or above the selected E2E timing threshold.
- Event-level records for those cases are available in an expander.


## v7 layout update

- The selected E2E metric card now appears in the left pane below Variant Highlighting.
- The process-flow area no longer shows the metric card above the graph.
- Percentile selection no longer opens or refreshes a detailed records table.
- Average / Median / P50 / P60 / P70 / P80 / P90 / P95 / P99 now update only the process-map timing lens and selected E2E metric.


## v8 detailed records

- Added a detailed records table at the bottom of the page.
- The table follows the final filtered process-map population.
- It is driven by the selected timing lens: Average, Median, P50, P60, P70, P80, P90, P95 or P99.
- Cases at or above the selected E2E threshold are displayed.
- The exact traversed process variant is included for every case.
- Records are sorted by highest E2E elapsed time first.
