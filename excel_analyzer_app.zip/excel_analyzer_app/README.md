# Excel Data Analyzer

A Streamlit application for uploading two Excel/CSV files, joining them, building visible AND/OR filters across both files, analyzing the result, and exporting a complete auditable dump.

## Main capabilities

- Upload two Excel or CSV files and select sheets
- Prefix columns as `File1.<column>` and `File2.<column>`
- Left/VLOOKUP, inner, right, and full outer joins
- Visual multi-condition filter builder
- Sequential `AND` and `OR` conditions
- Every filter remains visible and can be reordered or removed
- Save filters as JSON and import them later
- Select/reorder output columns, sort, and remove duplicates
- Interactive grid, pivot tables, charts, profiling, and correlations
- Audit log for explicit user actions
- Download a complete ZIP dump containing:
  - `output.xlsx`
  - `output.csv`
  - `filters.json`
  - `audit_log.csv`
  - `audit_log.json`
  - `session_metadata.json`

## Run locally

### Windows PowerShell

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```

### macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

Open `http://localhost:8501`.

## Filter logic

Rules are evaluated from top to bottom. For example:

```text
WHERE File1.State equals Tamil Nadu
AND File2.Premium greater than 25000
OR File2.Product equals Senior Citizen
```

This is evaluated sequentially as:

```text
(State = Tamil Nadu AND Premium > 25000) OR Product = Senior Citizen
```

For advanced nested expressions such as `(A OR B) AND (C OR D)`, a future enhancement can introduce filter groups and parentheses.

## Audit design

The audit trail records explicit actions such as:

- Join executed
- Filter added, removed, reordered, imported, cleared, and applied
- Pivot or chart created
- Output/filter/dump downloaded

Uploaded source data is not copied into the audit log. The metadata includes file names, selected sheets, row counts, and a shortened SHA-256 fingerprint.

## Production recommendations

- Put the app behind enterprise SSO
- Add authorization by business role
- Store audit events in a database rather than only session memory
- Store saved filter templates in PostgreSQL or a governed Delta table
- Add an analysis/session ID and user identity to each event
- Add malware scanning and file-size/row-count limits
- Use DuckDB, Polars, or Databricks SQL for very large files
