from __future__ import annotations

from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
from typing import Any
import hashlib
import json
import zipfile

import pandas as pd
import plotly.express as px
import streamlit as st
from st_aggrid import AgGrid, GridOptionsBuilder, DataReturnMode, GridUpdateMode

st.set_page_config(page_title="Excel Data Analyzer", page_icon="📊", layout="wide")
st.title("📊 Excel Data Analyzer")
st.caption(
    "Upload two files, join them, create visible AND/OR filters, analyze the result, "
    "save filter definitions, and download a complete auditable analysis package."
)

OPERATORS = [
    "equals", "not equals", "contains", "does not contain", "starts with", "ends with",
    "greater than", "greater than or equal", "less than", "less than or equal",
    "between", "in list", "not in list", "is blank", "is not blank",
]


def init_state() -> None:
    defaults: dict[str, Any] = {
        "filters": [],
        "audit_log": [],
        "joined_data": None,
        "filtered_data": None,
        "join_config": {},
        "last_filter_config": {},
        "analysis_name": "excel_analysis",
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def utc_now() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def audit(action: str, details: dict[str, Any] | None = None) -> None:
    st.session_state.audit_log.append({
        "timestamp": utc_now(),
        "action": action,
        "details": json.dumps(details or {}, ensure_ascii=False, default=str),
    })


def file_fingerprint(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()[:16]


@st.cache_data(show_spinner=False)
def get_sheet_names(file_bytes: bytes, filename: str) -> list[str]:
    if filename.lower().endswith(".csv"):
        return ["CSV"]
    return pd.ExcelFile(BytesIO(file_bytes)).sheet_names


@st.cache_data(show_spinner=False)
def load_table(file_bytes: bytes, filename: str, sheet_name: str | None) -> pd.DataFrame:
    stream = BytesIO(file_bytes)
    if filename.lower().endswith(".csv"):
        return pd.read_csv(stream, low_memory=False)
    return pd.read_excel(stream, sheet_name=sheet_name)


def make_unique_columns(df: pd.DataFrame, source: str) -> pd.DataFrame:
    result = df.copy()
    counts: dict[str, int] = {}
    columns: list[str] = []
    for raw in result.columns:
        col = str(raw).strip() or "Unnamed"
        counts[col] = counts.get(col, 0) + 1
        unique = col if counts[col] == 1 else f"{col}_{counts[col]}"
        columns.append(f"{source}.{unique}")
    result.columns = columns
    return result


def normalize_key(series: pd.Series, trim: bool, lower: bool) -> pd.Series:
    result = series.astype("string")
    if trim:
        result = result.str.strip()
    if lower:
        result = result.str.lower()
    return result


def json_bytes(value: Any) -> bytes:
    return json.dumps(value, indent=2, ensure_ascii=False, default=str).encode("utf-8")


def to_excel_bytes(sheets: dict[str, pd.DataFrame]) -> bytes:
    output = BytesIO()
    with pd.ExcelWriter(output, engine="xlsxwriter") as writer:
        for sheet_name, df in sheets.items():
            safe_name = sheet_name[:31]
            df.to_excel(writer, index=False, sheet_name=safe_name)
            worksheet = writer.sheets[safe_name]
            for index, column in enumerate(df.columns):
                sample_width = df[column].astype(str).head(500).map(len).max() if not df.empty else 0
                worksheet.set_column(index, index, min(max(sample_width, len(str(column))) + 2, 50))
    return output.getvalue()


def render_grid(df: pd.DataFrame, key: str) -> pd.DataFrame:
    gb = GridOptionsBuilder.from_dataframe(df)
    gb.configure_default_column(
        sortable=True, filter=True, resizable=True, editable=False,
        enableRowGroup=True, enablePivot=True, enableValue=True,
    )
    gb.configure_grid_options(sideBar=True, rowSelection="multiple", animateRows=True)
    response = AgGrid(
        df, gridOptions=gb.build(), height=480, fit_columns_on_grid_load=False,
        data_return_mode=DataReturnMode.FILTERED_AND_SORTED,
        update_mode=GridUpdateMode.NO_UPDATE, allow_unsafe_jscode=False,
        theme="streamlit", key=key,
    )
    return pd.DataFrame(response.get("data", df))


def condition_mask(df: pd.DataFrame, rule: dict[str, Any]) -> pd.Series:
    column = rule["column"]
    operator = rule["operator"]
    value = str(rule.get("value", ""))
    value2 = str(rule.get("value2", ""))
    case_sensitive = bool(rule.get("case_sensitive", False))
    series = df[column]
    text = series.astype("string")
    left = text if case_sensitive else text.str.lower()
    right = value if case_sensitive else value.lower()

    if operator == "equals": return left == right
    if operator == "not equals": return left != right
    if operator == "contains": return left.str.contains(right, na=False, regex=False)
    if operator == "does not contain": return ~left.str.contains(right, na=False, regex=False)
    if operator == "starts with": return left.str.startswith(right, na=False)
    if operator == "ends with": return left.str.endswith(right, na=False)
    if operator == "is blank": return series.isna() | text.str.strip().eq("")
    if operator == "is not blank": return series.notna() & ~text.str.strip().eq("")
    if operator in {"in list", "not in list"}:
        values = [item.strip() for item in value.split(",") if item.strip()]
        if not case_sensitive:
            values = [item.lower() for item in values]
        mask = left.isin(values)
        return ~mask if operator == "not in list" else mask

    numeric = pd.to_numeric(series, errors="coerce")
    try:
        number = float(value)
    except ValueError as exc:
        raise ValueError(f"'{value}' is not numeric for {column}") from exc
    if operator == "greater than": return numeric > number
    if operator == "greater than or equal": return numeric >= number
    if operator == "less than": return numeric < number
    if operator == "less than or equal": return numeric <= number
    if operator == "between":
        try:
            number2 = float(value2)
        except ValueError as exc:
            raise ValueError(f"'{value2}' is not numeric for the upper bound") from exc
        return numeric.between(min(number, number2), max(number, number2), inclusive="both")
    raise ValueError(f"Unsupported operator: {operator}")


def apply_filter_rules(df: pd.DataFrame, rules: list[dict[str, Any]]) -> pd.DataFrame:
    if not rules:
        return df.copy()
    combined: pd.Series | None = None
    for index, rule in enumerate(rules):
        mask = condition_mask(df, rule).fillna(False)
        if index == 0:
            combined = mask
        elif rule.get("connector", "AND") == "OR":
            combined = combined | mask  # type: ignore[operator]
        else:
            combined = combined & mask  # type: ignore[operator]
    return df[combined].copy() if combined is not None else df.copy()


def filter_summary(rule: dict[str, Any], index: int) -> str:
    prefix = "WHERE" if index == 0 else rule.get("connector", "AND")
    operator = rule["operator"]
    if operator in {"is blank", "is not blank"}:
        return f"{prefix} {rule['column']} {operator}"
    if operator == "between":
        return f"{prefix} {rule['column']} between {rule.get('value', '')} and {rule.get('value2', '')}"
    return f"{prefix} {rule['column']} {operator} {rule.get('value', '')}"


def build_dump(output_df: pd.DataFrame, filters: list[dict[str, Any]], metadata: dict[str, Any]) -> bytes:
    memory = BytesIO()
    audit_df = pd.DataFrame(st.session_state.audit_log)
    with zipfile.ZipFile(memory, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("output.xlsx", to_excel_bytes({"Analysis_Output": output_df, "Audit_Log": audit_df}))
        archive.writestr("output.csv", output_df.to_csv(index=False).encode("utf-8"))
        archive.writestr("filters.json", json_bytes({"version": 1, "filters": filters}))
        archive.writestr("audit_log.json", json_bytes(st.session_state.audit_log))
        archive.writestr("audit_log.csv", audit_df.to_csv(index=False).encode("utf-8"))
        archive.writestr("session_metadata.json", json_bytes(metadata))
    return memory.getvalue()


def basic_profile(df: pd.DataFrame) -> pd.DataFrame:
    return pd.DataFrame({
        "column": df.columns,
        "data_type": [str(df[c].dtype) for c in df.columns],
        "non_null": [int(df[c].notna().sum()) for c in df.columns],
        "nulls": [int(df[c].isna().sum()) for c in df.columns],
        "null_pct": [round(float(df[c].isna().mean() * 100), 2) for c in df.columns],
        "distinct": [int(df[c].nunique(dropna=True)) for c in df.columns],
    })


init_state()

with st.sidebar:
    st.header("1. Upload files")
    file_1 = st.file_uploader("File 1", type=["xlsx", "xlsm", "xls", "csv"], key="file_1")
    file_2 = st.file_uploader("File 2", type=["xlsx", "xlsm", "xls", "csv"], key="file_2")
    st.session_state.analysis_name = st.text_input("Analysis name", st.session_state.analysis_name)

if not file_1 or not file_2:
    st.info("Upload both files to begin.")
    st.stop()

try:
    bytes_1, bytes_2 = file_1.getvalue(), file_2.getvalue()
    sheets_1, sheets_2 = get_sheet_names(bytes_1, file_1.name), get_sheet_names(bytes_2, file_2.name)
    with st.sidebar:
        sheet_1 = st.selectbox("File 1 sheet", sheets_1)
        sheet_2 = st.selectbox("File 2 sheet", sheets_2)
    raw1 = load_table(bytes_1, file_1.name, None if sheet_1 == "CSV" else sheet_1)
    raw2 = load_table(bytes_2, file_2.name, None if sheet_2 == "CSV" else sheet_2)
    df1, df2 = make_unique_columns(raw1, "File1"), make_unique_columns(raw2, "File2")
except Exception as exc:
    st.error(f"Could not read the files: {exc}")
    st.stop()

m1, m2, m3, m4 = st.columns(4)
m1.metric("File 1 rows", f"{len(df1):,}")
m2.metric("File 1 columns", len(df1.columns))
m3.metric("File 2 rows", f"{len(df2):,}")
m4.metric("File 2 columns", len(df2.columns))

tab_join, tab_filter, tab_pivot, tab_chart, tab_profile, tab_audit = st.tabs(
    ["Join / Lookup", "Filters & Output", "Pivot", "Charts", "Data Profile", "Audit & Dump"]
)

with tab_join:
    st.subheader("Join or lookup the two files")
    c1, c2, c3 = st.columns(3)
    left_key = c1.selectbox("File 1 lookup key", df1.columns)
    right_key = c2.selectbox("File 2 lookup key", df2.columns)
    join_type = c3.selectbox("Join type", ["left", "inner", "right", "outer"], format_func=lambda x: {
        "left": "Left lookup (VLOOKUP style)", "inner": "Inner join",
        "right": "Right join", "outer": "Full outer join"}[x])
    c4, c5, c6 = st.columns(3)
    trim_keys = c4.checkbox("Trim spaces in keys", True)
    case_insensitive = c5.checkbox("Case-insensitive keys", True)
    add_match_status = c6.checkbox("Add match status", True)
    selected_right = st.multiselect(
        "Columns to bring from File 2", [c for c in df2.columns if c != right_key],
        default=[c for c in df2.columns if c != right_key][:10],
    )

    if st.button("Run join / lookup", type="primary"):
        left_work = df1.copy()
        right_work = df2[[right_key] + selected_right].copy()
        key = "__lookup_key__"
        left_work[key] = normalize_key(left_work[left_key], trim_keys, case_insensitive)
        right_work[key] = normalize_key(right_work[right_key], trim_keys, case_insensitive)
        duplicates = int(right_work[key].duplicated(keep=False).sum())
        merged = left_work.merge(
            right_work, how=join_type, on=key, suffixes=("_file1", "_file2"),
            indicator=add_match_status,
        ).drop(columns=[key])
        if add_match_status:
            merged["_merge"] = merged["_merge"].astype(str).map({
                "left_only": "Only in File 1", "right_only": "Only in File 2", "both": "Matched"})
        st.session_state.joined_data = merged
        st.session_state.filtered_data = None
        st.session_state.join_config = {
            "left_key": left_key, "right_key": right_key, "join_type": join_type,
            "trim_keys": trim_keys, "case_insensitive": case_insensitive,
            "selected_file2_columns": selected_right, "duplicate_file2_key_rows": duplicates,
        }
        audit("JOIN_EXECUTED", {**st.session_state.join_config, "output_rows": len(merged)})
        st.success(f"Join created {len(merged):,} rows and {len(merged.columns):,} columns.")

    if st.session_state.joined_data is not None:
        st.caption("Columns are prefixed with File1. or File2. so filters can clearly use fields from either source.")
        render_grid(st.session_state.joined_data, "joined_grid")
    else:
        st.info("Configure and run the join before creating cross-file filters.")

with tab_filter:
    st.subheader("Visible AND/OR filter builder")
    source_options = {"Joined data": st.session_state.joined_data, "File 1": df1, "File 2": df2}
    available = [name for name, frame in source_options.items() if frame is not None]
    source_name = st.radio("Filter data source", available, horizontal=True)
    source_df = source_options[source_name].copy()

    load_col, clear_col = st.columns(2)
    uploaded_filters = load_col.file_uploader("Load saved filters", type=["json"], key="filter_upload")
    if uploaded_filters and load_col.button("Import filter file"):
        try:
            payload = json.loads(uploaded_filters.getvalue().decode("utf-8"))
            imported = payload.get("filters", payload)
            if not isinstance(imported, list):
                raise ValueError("The file does not contain a filter list.")
            valid = [r for r in imported if r.get("column") in source_df.columns]
            st.session_state.filters = valid
            audit("FILTER_SET_IMPORTED", {"imported": len(valid), "ignored": len(imported) - len(valid)})
            st.rerun()
        except Exception as exc:
            st.error(f"Could not import filters: {exc}")
    if clear_col.button("Clear all filters"):
        count = len(st.session_state.filters)
        st.session_state.filters = []
        st.session_state.filtered_data = None
        audit("FILTERS_CLEARED", {"count": count})
        st.rerun()

    st.markdown("#### Add condition")
    a, b, c, d = st.columns([1, 2.2, 1.8, 2])
    connector = a.selectbox("Connector", ["AND", "OR"], disabled=len(st.session_state.filters) == 0)
    column = b.selectbox("Column", source_df.columns)
    operator = c.selectbox("Operator", OPERATORS)
    value_disabled = operator in {"is blank", "is not blank"}
    value = d.text_input("Value", disabled=value_disabled, help="For 'in list', use comma-separated values.")
    e, f, g = st.columns([2, 1, 1])
    value2 = e.text_input("Upper value", disabled=operator != "between")
    case_sensitive = f.checkbox("Case-sensitive", False)
    if g.button("Add filter", type="primary"):
        rule = {
            "connector": "AND" if not st.session_state.filters else connector,
            "column": column, "operator": operator, "value": value,
            "value2": value2, "case_sensitive": case_sensitive,
        }
        st.session_state.filters.append(rule)
        audit("FILTER_ADDED", rule)
        st.rerun()

    st.markdown("#### Applied filter definition")
    if not st.session_state.filters:
        st.info("No conditions added. Add conditions above; every condition remains visible here.")
    else:
        for index, rule in enumerate(st.session_state.filters):
            with st.container(border=True):
                x1, x2, x3 = st.columns([7, 1, 1])
                x1.code(filter_summary(rule, index), language=None)
                if x2.button("↑", key=f"up_{index}", disabled=index == 0):
                    rules = st.session_state.filters
                    rules[index - 1], rules[index] = rules[index], rules[index - 1]
                    audit("FILTER_REORDERED", {"from": index, "to": index - 1})
                    st.rerun()
                if x3.button("Remove", key=f"remove_{index}"):
                    removed = st.session_state.filters.pop(index)
                    audit("FILTER_REMOVED", removed)
                    st.rerun()

    csel, csort, cascn = st.columns([3, 2, 1])
    selected_columns = csel.multiselect("Output columns and order", source_df.columns, default=list(source_df.columns))
    sort_columns = csort.multiselect("Sort by", selected_columns)
    ascending = cascn.checkbox("Ascending", True)
    remove_duplicates = st.checkbox("Remove duplicate output rows")

    apply_col, save_col = st.columns(2)
    if apply_col.button("Apply filters", type="primary"):
        try:
            filtered = apply_filter_rules(source_df, st.session_state.filters)
            if selected_columns:
                filtered = filtered[selected_columns]
            if sort_columns:
                filtered = filtered.sort_values(sort_columns, ascending=ascending, na_position="last")
            if remove_duplicates:
                filtered = filtered.drop_duplicates()
            st.session_state.filtered_data = filtered
            st.session_state.last_filter_config = {
                "source": source_name, "filters": st.session_state.filters,
                "selected_columns": selected_columns, "sort_columns": sort_columns,
                "ascending": ascending, "remove_duplicates": remove_duplicates,
            }
            audit("FILTERS_APPLIED", {
                "source": source_name, "conditions": len(st.session_state.filters),
                "input_rows": len(source_df), "output_rows": len(filtered),
                "sort_columns": sort_columns, "remove_duplicates": remove_duplicates,
            })
            st.success(f"Filters returned {len(filtered):,} of {len(source_df):,} rows.")
        except Exception as exc:
            st.error(f"Could not apply filters: {exc}")

    filter_payload = {"version": 1, "source": source_name, "filters": st.session_state.filters}
    save_col.download_button(
        "Save filter definition", json_bytes(filter_payload),
        file_name=f"{st.session_state.analysis_name}_filters.json", mime="application/json",
        on_click=lambda: audit("FILTER_SET_DOWNLOADED", {"conditions": len(st.session_state.filters)}),
    )

    if st.session_state.filtered_data is not None:
        st.markdown("#### Filtered output")
        visible_output = render_grid(st.session_state.filtered_data, "filtered_grid")
        st.download_button(
            "Download output Excel", to_excel_bytes({"Filtered_Output": visible_output}),
            file_name=f"{st.session_state.analysis_name}_output.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            on_click=lambda: audit("OUTPUT_EXCEL_DOWNLOADED", {"rows": len(visible_output)}),
        )

with tab_pivot:
    st.subheader("Pivot table")
    pivot_source = st.session_state.filtered_data if st.session_state.filtered_data is not None else st.session_state.joined_data
    if pivot_source is None or pivot_source.empty:
        st.info("Run a join and apply filters first.")
    else:
        p1, p2 = st.columns(2)
        index_columns = p1.multiselect("Rows", pivot_source.columns)
        pivot_columns = p2.multiselect("Columns", pivot_source.columns)
        numeric = list(pivot_source.select_dtypes(include="number").columns)
        values = st.multiselect("Values", pivot_source.columns, default=numeric[:1])
        aggregation = st.selectbox("Aggregation", ["sum", "mean", "count", "min", "max", "median", "nunique"])
        if st.button("Create pivot") and index_columns and values:
            pivot_df = pd.pivot_table(
                pivot_source, index=index_columns, columns=pivot_columns or None,
                values=values, aggfunc=aggregation, fill_value=0, dropna=False).reset_index()
            pivot_df.columns = [" | ".join(str(x) for x in col if str(x)) if isinstance(col, tuple) else str(col) for col in pivot_df.columns]
            audit("PIVOT_CREATED", {"rows": index_columns, "columns": pivot_columns, "values": values, "aggregation": aggregation})
            render_grid(pivot_df, "pivot_grid")

with tab_chart:
    st.subheader("Interactive charts")
    chart_df = st.session_state.filtered_data if st.session_state.filtered_data is not None else st.session_state.joined_data
    if chart_df is None or chart_df.empty:
        st.info("Run a join and apply filters first.")
    else:
        chart_type = st.selectbox("Chart type", ["Bar", "Line", "Scatter", "Histogram", "Box", "Pie"])
        columns, numeric = list(chart_df.columns), list(chart_df.select_dtypes(include="number").columns)
        x_col = st.selectbox("X axis / category", columns)
        y_options = columns if chart_type in {"Histogram", "Pie"} else numeric
        y_col = st.selectbox("Y axis / value", y_options) if y_options else None
        color_col = st.selectbox("Color / group", ["None"] + columns)
        if st.button("Create chart"):
            color = None if color_col == "None" else color_col
            funcs = {
                "Bar": lambda: px.bar(chart_df, x=x_col, y=y_col, color=color),
                "Line": lambda: px.line(chart_df, x=x_col, y=y_col, color=color),
                "Scatter": lambda: px.scatter(chart_df, x=x_col, y=y_col, color=color),
                "Histogram": lambda: px.histogram(chart_df, x=x_col, color=color),
                "Box": lambda: px.box(chart_df, x=x_col, y=y_col, color=color),
                "Pie": lambda: px.pie(chart_df, names=x_col, values=y_col),
            }
            st.plotly_chart(funcs[chart_type](), use_container_width=True)
            audit("CHART_CREATED", {"type": chart_type, "x": x_col, "y": y_col, "color": color_col})

with tab_profile:
    st.subheader("Data quality profile")
    options = {"File 1": df1, "File 2": df2}
    if st.session_state.joined_data is not None: options["Joined data"] = st.session_state.joined_data
    if st.session_state.filtered_data is not None: options["Filtered output"] = st.session_state.filtered_data
    profile_name = st.radio("Profile source", options.keys(), horizontal=True)
    profile = options[profile_name]
    p1, p2, p3 = st.columns(3)
    p1.metric("Rows", f"{len(profile):,}")
    p2.metric("Duplicate rows", f"{profile.duplicated().sum():,}")
    p3.metric("Missing cells", f"{profile.isna().sum().sum():,}")
    st.dataframe(basic_profile(profile), use_container_width=True, hide_index=True)
    numeric = profile.select_dtypes(include="number")
    if numeric.shape[1] >= 2:
        st.subheader("Correlation matrix")
        st.dataframe(numeric.corr(), use_container_width=True)

with tab_audit:
    st.subheader("Audit trail and complete analysis dump")
    audit_df = pd.DataFrame(st.session_state.audit_log)
    if audit_df.empty:
        st.info("Audit entries appear after you run joins, add/apply filters, create pivots/charts, or download outputs.")
    else:
        st.dataframe(audit_df, use_container_width=True, hide_index=True)

    output_df = st.session_state.filtered_data
    if output_df is None:
        output_df = st.session_state.joined_data
    if output_df is None:
        output_df = pd.DataFrame()

    metadata = {
        "analysis_name": st.session_state.analysis_name,
        "created_at": utc_now(),
        "file_1": {"name": file_1.name, "sheet": sheet_1, "sha256_prefix": file_fingerprint(bytes_1), "rows": len(df1)},
        "file_2": {"name": file_2.name, "sheet": sheet_2, "sha256_prefix": file_fingerprint(bytes_2), "rows": len(df2)},
        "join_config": st.session_state.join_config,
        "filter_config": st.session_state.last_filter_config,
        "output_rows": len(output_df),
        "output_columns": list(output_df.columns),
    }
    dump = build_dump(output_df, st.session_state.filters, metadata)
    st.download_button(
        "Download complete analysis dump (.zip)", dump,
        file_name=f"{st.session_state.analysis_name}_dump.zip", mime="application/zip",
        on_click=lambda: audit("ANALYSIS_DUMP_DOWNLOADED", {"rows": len(output_df), "audit_entries": len(st.session_state.audit_log)}),
        disabled=output_df.empty,
    )
    st.caption("The dump contains output.xlsx, output.csv, filters.json, audit_log.csv/json, and session_metadata.json.")
