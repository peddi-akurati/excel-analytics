# Stargazer

Stargazer is a Streamlit-based data analysis application for uploaded Excel/CSV files and database query results.

## Supported data sources

Each dataset can independently come from:

- Excel or CSV upload
- PostgreSQL custom SQL query
- Databricks SQL Warehouse custom SQL query

Dataset 2 is optional and is needed only for join/lookup analysis. Query results work throughout filters, pivots, charts, profiling, EDA, exports, and audit packages.

## Database connection fields

### PostgreSQL

Provide host, port, database, user, password, SSL mode, and a read-only SQL query.

### Databricks

Provide server hostname, SQL Warehouse HTTP path, personal/service-principal access token, optional catalog/schema, and a read-only SQL query.

Stargazer accepts one result-returning statement at a time: `SELECT`, `WITH`, `SHOW`, `DESCRIBE`, or `EXPLAIN`. Credentials are not written to audit logs or exported analysis metadata.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

## Docker

```bash
docker build -t stargazer .
docker run --rm -p 8501:8501 stargazer
```

Open `http://localhost:8501`.

## Databricks notes

Use the hostname and HTTP path shown in the SQL Warehouse connection details. The token must have permission to use the warehouse and read the queried objects.

## PostgreSQL notes

Use a database account with read-only privileges. Network routes, firewall rules, SSL certificates, and allowlists must permit the machine running Stargazer to reach PostgreSQL.
