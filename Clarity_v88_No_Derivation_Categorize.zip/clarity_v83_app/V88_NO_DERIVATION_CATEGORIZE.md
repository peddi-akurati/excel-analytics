# V88 No Derivation Categorization

- Added a **No Derivation** checkbox to the Create Column section.
- When selected, formula name, operator, second operand, and Create column action are disabled.
- The selected first/source column can be categorized directly with the existing Categorize dialog.
- Direct categorization validates that the selected column contains numeric values.
- Categorized output can be published as Filtered output for downstream Clarity pages.
- Existing formula-derived categorization remains unchanged.
