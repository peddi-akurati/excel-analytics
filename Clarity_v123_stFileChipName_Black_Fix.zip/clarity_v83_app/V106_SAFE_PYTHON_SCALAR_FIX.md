# Clarity v106 – safe_python_scalar fix

- Restored the missing `safe_python_scalar` module-level helper.
- Converts NumPy scalars to native Python values.
- Converts pandas timestamps/timedeltas to native Python objects.
- Converts null, NaT, NaN, and infinite float values to `None`.
- Verified all called `safe_*` helpers are now defined.
- Passed Python compilation and startup validation.
