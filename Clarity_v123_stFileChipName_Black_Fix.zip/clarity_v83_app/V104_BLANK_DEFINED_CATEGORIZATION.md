# Clarity v104 — Blank / Defined Categorization

## Change
The Filter/Create page's **Categorize Calculated Column** dialog now supports two methods:

1. Minimum / Maximum ranges (existing behavior)
2. Is blank / Is defined (new)

Blank includes null values, empty strings, and whitespace-only strings. Users can provide separate labels for blank and defined rows. The generated `<column>_Cat` column follows the existing Modified Dataset publication flow.

## Sanity validation
- Numeric range categorization remains available.
- Blank/defined categorization works for numeric, text, and date-like columns.
- Null, empty, and whitespace-only values are categorized as blank.
- Defined values are categorized separately.
- Duplicate category labels and empty labels are rejected.
- Python compilation passed.
- Application startup validation passed.
