# Clarity v83 – Pivot Visualization Update

## Changes

- Moved the Pivot table section to the top of the Visualize page.
- Moved the general Charts section below the Pivot section with a divider between them.
- Added a Visualize button beside the Pivot Excel and CSV download buttons.
- Pivot visualization supports Bar, Line, Pie and Heatmap charts.
- Users can choose the category/X axis, numeric value/Y axis and an optional grouping series.
- Pivot visualization state resets when the source or pivot definition changes.
