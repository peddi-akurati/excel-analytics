# V119 — Top Navigation Selected Text Fix

- Scoped selected-state correction to the right-side/top page navigation only.
- Selected navigation text and nested labels now remain dark navy (`#0b3569`).
- Selected navigation background now uses light blue for accessible contrast.
- Normal action, submit, download, and content buttons retain their prior styling.
