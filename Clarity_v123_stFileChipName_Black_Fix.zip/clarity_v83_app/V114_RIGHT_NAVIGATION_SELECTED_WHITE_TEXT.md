# V114 — Right Navigation Selected Text

- Added a high-specificity CSS override for the selected (`primary`) button in the top/right navigation strip.
- Forces the button and nested Streamlit label elements to white text.
- Unselected, hover, and disabled navigation states remain unchanged.
