# V117 Left Sidebar Scroll Fix

- Converted the expanded sidebar shell to a fixed-height flex column.
- Kept the logo/header in a non-scrolling region.
- Limited vertical scrolling to `stSidebarUserContent` below the logo.
- Prevented navigation content from moving behind the logo.
- Preserved existing sidebar width, logo sizing, colors, and collapse behavior.
