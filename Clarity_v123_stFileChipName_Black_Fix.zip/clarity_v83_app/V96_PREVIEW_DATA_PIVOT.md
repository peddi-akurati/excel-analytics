# Clarity v96 - Preview Data Pivot

- Added a **Data Pivot** section below Data Preview.
- Users select static grouping columns and transpose columns.
- Repeated records are spread horizontally using numbered names such as `Metric_1`, `Metric_2`.
- Submit generates an on-page pivot preview with horizontal scrolling.
- Confirm Dataset publishes the result as **Modified Dataset**.
- The existing revision-based source activation makes the confirmed pivot the default on downstream pages.
