# Clarity v111 – Preview button text correction

Targeted UI correction:

- Selected **Preview** navigation button keeps white text, including nested Streamlit label elements.
- Primary **Submit** button in the Preview page Data Pivot section keeps white text, including nested Streamlit label elements.
- No global button-state rules were changed.
- All application functionality and the v110 theme remain unchanged.
