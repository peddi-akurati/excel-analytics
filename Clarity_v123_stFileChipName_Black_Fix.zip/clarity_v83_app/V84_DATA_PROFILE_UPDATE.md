# Clarity v84 – Data Profile Update

- Detailed is now the only data-card view.
- No card columns are selected by default.
- Numerical cards display skewness in the statistics and chart title.
- Numerical corrections: Drop nulls, Fill with median, Drop outliers.
- Corrections update the active reusable dataset and invalidate stale downstream outputs.
- Profile results include a checkbox beside every column; all are selected by default.
- Confirm final dataset publishes selected columns as Modified Dataset for subsequent analysis.
