# Clarity v89 - Explain Target

Added an **Explain Target** tab in Machine Learning → Model comparison, positioned between **Experiments** and **Export**.

The feature:
- Ranks the top target drivers using permutation importance when available.
- Falls back to native model importance or mean absolute SHAP.
- Adds observed direction using Spearman correlation for numeric regression features.
- Adds category-level target ranges for categorical regression features.
- Generates a plain-language target summary and factor-by-factor interpretations.
- Provides CSV and text downloads.
- Prevents explanations from a previous training run being shown against a newer model.
