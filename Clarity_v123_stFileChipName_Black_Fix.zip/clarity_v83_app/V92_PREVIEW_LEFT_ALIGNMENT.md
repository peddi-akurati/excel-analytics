# Clarity v92 — Preview Grid Left Alignment

- Preview page column headers are left aligned.
- All Preview page cell values, including numeric and date values, are left aligned.
- The change is limited to the Preview grid and does not alter dataset values or downstream analysis.
