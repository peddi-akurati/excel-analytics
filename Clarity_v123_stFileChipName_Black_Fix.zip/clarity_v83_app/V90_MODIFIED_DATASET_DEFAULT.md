# Clarity v90 — Modified Dataset Default

## Changes

- Renamed every user-facing **Filtered Output** reference to **Modified Dataset**.
- When a Modified Dataset is created or republished, it becomes the default source for:
  - Preview
  - Create Column
  - Filter
  - Pivot
  - Charts
  - Data Profile
  - Machine Learning
  - Data Mining
- Users may manually switch back to an original or joined dataset after the automatic selection.
- A new publication activates Modified Dataset again across downstream pages.
- Excel output sheet naming now uses `Modified_Dataset`.

## Compatibility

The existing internal `filtered_data` session slot is retained to avoid breaking older saved sessions and dependent logic. Only the user-facing terminology and source-selection behavior were changed.
