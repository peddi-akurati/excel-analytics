# V113 Global Selected Button Text Fix

- Extended the V111 white-label treatment from Preview-only controls to all selected/primary buttons throughout the application.
- Covers Streamlit standard buttons, form submit buttons, download buttons, navigation buttons, aria-pressed/aria-selected controls, and active button states.
- Applies the override to nested label elements (`p`, `span`, and other descendants), preventing component-level text styles from reverting labels to black.
- Normal, unselected and disabled button styling remains controlled by the existing theme.
