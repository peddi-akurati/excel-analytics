# Clarity v102 — Remove Database Preview Rows Control

- Removed the **Preview rows** number input shown in the left pane after PostgreSQL or Databricks query execution.
- Database query results continue to show a compact preview of the first 50 rows.
- The full query result remains stored and available to the application as Dataset 1 or Dataset 2.
- The Preview page's independent row-count selector remains unchanged.
