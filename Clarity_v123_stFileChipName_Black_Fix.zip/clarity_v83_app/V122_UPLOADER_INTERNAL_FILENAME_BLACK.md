# v122 – Uploader Internal Filename Visibility Fix

- Rolled back the separately rendered custom uploaded-filename element introduced in v121.
- Restored the original `Loaded: <filename>` caption behavior.
- Applied black text only to the filename displayed inside Streamlit's file-uploader file row in the left sidebar.
- Upload button text/icon and other sidebar content remain unchanged.
