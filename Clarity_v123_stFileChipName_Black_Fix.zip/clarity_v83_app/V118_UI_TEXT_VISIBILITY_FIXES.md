# Clarity v118 – UI Text Visibility Fixes

## Changes

- Made the left-sidebar **1. Data sources** heading white.
- Made the **Primary file** uploader button text and icon black.
- Made entered text in the **Analysis name** input black on a white field.
- Made the **Selected filter summary** heading and highlighted summary text white.
- Replaced the top header text with:
  - “Add the data, conduct analysis, and uncover insights to facilitate clear, data-driven decisions”
- Added a shorter responsive header phrase for narrow screens.

## Validation

- Python compilation
- AST parsing
- Application startup validation
- Targeted CSS and header-copy sanity checks
- ZIP integrity test
