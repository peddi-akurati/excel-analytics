# Clarity v85 Data Profile Standardization

- Places **Standardize Data** first and **Confirm Dataset** beside it below the profile results grid.
- Standardize Data opens a target-column selection dialog for the columns checked in the grid.
- For a selected numerical target, rows with missing/non-numeric target values are removed.
- For other selected numerical columns, missing values are filled with the median and IQR outlier rows are removed.
- Standardization is staged until **Confirm Dataset** is clicked.
- Confirmation publishes the finalized dataset to downstream analysis and refreshes the profile grid and detailed cards.
