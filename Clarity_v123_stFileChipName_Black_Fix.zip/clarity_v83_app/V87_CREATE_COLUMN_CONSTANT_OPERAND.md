# V87 Create Column Constant Operand

- Updated the second formula operand to accept an existing dataset column or numeric constant `0` or `1`.
- Formula preview, calculation, audit details, and saved configuration now distinguish column and constant operands.
- Division by constant zero uses the existing safe divide behavior and produces missing values with a warning.
