# Clarity v86 – Temporal Standardization

Data Profile standardization now handles selected date, datetime, and verified date-like text columns automatically.

- Date values are normalized to `YYYY-MM-DD`.
- Timestamp values are normalized to `YYYY-MM-DD HH:MM:SS`.
- Blank, invalid, and missing temporal values are stored as nulls.
- Every detected temporal column creates three analysis columns by default:
  - `<column>_year`
  - `<column>_month`
  - `<column>_weekday`
- Derived names are made collision-safe when an existing column already uses the requested name.
- Temporal processing occurs before target-aware numerical standardization.
- The standardized result remains staged until **Confirm Dataset** is selected.
