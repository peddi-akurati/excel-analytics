# V121 Upload Filename Visibility Fix

- Replaced sidebar upload filename captions with an explicitly styled HTML element.
- Forced uploaded filename text to black (`#000000`) with high-specificity sidebar CSS.
- Escaped uploaded filenames before HTML rendering.
- Applied to both Primary file and Second file uploaders.
