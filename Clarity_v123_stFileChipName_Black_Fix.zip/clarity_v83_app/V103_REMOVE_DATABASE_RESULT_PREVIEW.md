# Clarity v103 — Remove Database Result Preview from Left Pane

- Removed the database result caption and preview grid from the left navigation pane.
- Retained full database query results in session state and as the loaded dataset.
- Query success messages still show returned row and column counts.
- Updated the left-pane expansion help text to remove the reference to query previews.
