# Clarity v80 Categorize sanity checks

- Create Column retains the calculated numeric column.
- The action is labelled Categorize.
- Categorize creates `<calculated_column>_Cat`.
- Dialog shows source minimum and maximum values.
- Published calculated data is refreshed for downstream pages after categorization.
- Category ranges retain overlap and boundary validation.
