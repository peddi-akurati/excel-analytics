# Clarity v91 - Modified Dataset Auto-Selection Fix

- Replaced object-identity based activation with a persistent publication revision.
- Every new or republished Modified Dataset increments the revision.
- Preview, Create Column, Filter, Pivot, Charts, Data Profile, Machine Learning, and Data Mining automatically select Modified Dataset once for each revision.
- Users may manually switch sources after the automatic selection until another Modified Dataset is published.
- Clearing the Modified Dataset resets selection tracking safely.
