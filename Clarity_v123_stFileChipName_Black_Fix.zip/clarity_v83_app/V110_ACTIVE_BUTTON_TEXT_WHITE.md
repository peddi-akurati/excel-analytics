# Clarity v110 — Active/Pressed Button Text

- Removed the broad v109 CSS override that forced white text on every button state.
- Retained the existing theme colors for normal, hover, focus, and disabled states.
- Applied white text only to actively pressed (`:active`) or explicitly selected (`aria-pressed="true"`) buttons.
- Applied white text to the selected top navigation button represented by Streamlit's primary button state.
