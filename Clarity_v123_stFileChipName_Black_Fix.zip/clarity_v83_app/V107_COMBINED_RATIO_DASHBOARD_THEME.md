# v107 Combined Ratio Dashboard Theme

- Applied the dark navy enterprise sidebar used in the Combined Ratio dashboard mockups.
- Reworked the main canvas, header, navigation, metrics, forms, tables, AG Grid and Plotly containers.
- Added a dark-sidebar-compatible Clarity logo.
- Standardized chart colours to blue, green, amber, purple and red.
- Preserved all existing data preparation, analytics, AutoML and export functionality.
