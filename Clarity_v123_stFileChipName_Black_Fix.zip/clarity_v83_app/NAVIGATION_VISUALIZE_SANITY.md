# Clarity v81 navigation and Visualize sanity checks

- [x] Filter navigation label is Filter/Create.
- [x] Explore navigation label is Data Mining.
- [x] Pivot and Charts are removed as separate navigation pages.
- [x] Visualize contains Charts as the first section.
- [x] Visualize contains a divider before Pivot table.
- [x] Existing Filter, Pivot, Charts and Explore session values migrate to the new page names.
- [x] Selected and primary button hover styling stays within a blue gradient.
- [x] Python compilation and startup validation pass.
