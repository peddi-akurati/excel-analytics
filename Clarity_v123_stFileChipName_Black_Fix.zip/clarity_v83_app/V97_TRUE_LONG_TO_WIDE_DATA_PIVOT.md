# Clarity v97 - True Long-to-Wide Data Pivot

- Reworked Preview > Data Pivot so distinct row values become output column names.
- Static columns retain the row identity.
- Column values to become headers selects the field such as Test.
- Values column selects the field such as Result.
- Added duplicate handling: First, Last, Sum, Mean, Minimum, Maximum, Count.
- Confirm Dataset publishes the generated wide dataset as Modified Dataset and activates it downstream.
- Sanity checked Customer/Test/Result -> Customer/BP/HbA1C/Basophils.
