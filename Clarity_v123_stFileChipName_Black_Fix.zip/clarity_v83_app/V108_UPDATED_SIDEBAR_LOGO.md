# V108 Updated Sidebar Logo

- Replaced the v107 sidebar logo artwork with the user-provided CLARITY – Analyze & Discover logo.
- Normalized the logo asset to the same 1536 × 832 transparent canvas used in v106.
- Preserved the existing `st.logo(..., size="large")` configuration and v106 CSS scale (`1.25`).
- No application logic, dependencies, navigation, or dashboard theme code was changed.
