# Clarity v98

- Join/Lookup result headers are rendered on one line.
- Join/Lookup results use stable column widths and horizontal scrolling.
- Preview explicitly includes Dataset 2 whenever it is loaded, including the session-backed Dataset 2 after reruns.
- Dataset 1, Dataset 2, Joined dataset, and Modified Dataset remain selectable from Preview source.
