# Filter Create Column Sanity Check

Validated in Clarity v78:

- Create Column is positioned above Visible AND/OR filter builder.
- New column name is mandatory and duplicate names are rejected.
- Both formula terms are selected from the current source columns.
- Add, Minus, Multiply and Divide operations are available.
- Non-numeric values are coerced safely to missing values.
- Divide-by-zero rows become missing and produce a warning.
- Calculated results can remain as a local preview.
- Selecting the final-dataset option publishes the result as Filtered output.
- Filtered output remains available to Preview, Data Profile, Pivot, Charts, Explore and Machine Learning.
- Existing calculated output can be selected as a Filter source for continued refinement.
- Divider lines separate Create Column, filter source/import, condition builder, applied definition, output configuration and output preview.
- Python compilation and Clarity startup validation passed.
