# Filter Buckets and Output Grid Sanity Check

Validated in Clarity v79:

- Buckets button is available after a calculated column is created.
- Bucket configuration opens in a large dialog.
- Supports 2–10 buckets with name, minimum and maximum inputs.
- Rejects blank or duplicate names, invalid ranges and overlapping ranges.
- Minimum is inclusive; maximum is exclusive except for the final bucket.
- Missing calculated values remain missing.
- Values outside all bucket ranges receive a configurable fallback label.
- Bucket labels replace the calculated numeric column.
- Published calculated data updates Filtered output for downstream pages.
- Filtered Output uses a horizontally scrollable Streamlit dataframe.
- Display row limits do not truncate the downloaded Excel output.
- Python compilation and Clarity startup validation passed.
