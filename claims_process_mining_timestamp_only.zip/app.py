
import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from pathlib import Path

st.set_page_config(
    page_title="Claims Process Mining",
    page_icon="⛏️",
    layout="wide",
    initial_sidebar_state="collapsed",
)

st.markdown("""
<style>
.block-container {
    padding-top: 1.0rem;
    padding-bottom: 1.4rem;
    max-width: 100%;
}
[data-testid="stMetric"] {
    background: var(--secondary-background-color);
    border: 1px solid rgba(128,128,128,.18);
    padding: .72rem .85rem;
    border-radius: .8rem;
}
.event-card {
    border: 1px solid rgba(128,128,128,.20);
    border-radius: 12px;
    padding: 10px 12px;
    margin: 0 0 8px 0;
    background: var(--secondary-background-color);
}
.event-name {
    font-weight: 700;
    font-size: .92rem;
    margin-bottom: 4px;
}
.event-value {
    font-size: 1.32rem;
    font-weight: 800;
    line-height: 1.1;
}
.event-sub {
    font-size: .73rem;
    opacity: .72;
    margin-top: 4px;
}
.section-title {
    font-weight: 800;
    font-size: 1.05rem;
    margin: .3rem 0 .7rem 0;
}
.small-note {
    font-size: .77rem;
    opacity: .72;
}
</style>
""", unsafe_allow_html=True)

METRICS = {
    "Average": "mean",
    "Median": "median",
    "90th percentile": "p90",
    "95th percentile": "p95",
    "99th percentile": "p99",
}

def fmt_duration(hours):
    if pd.isna(hours):
        return "—"
    hours = float(hours)
    if hours < 1:
        return f"{hours * 60:.0f} min"
    if hours < 48:
        return f"{hours:.1f} h"
    return f"{hours / 24:.1f} d"

@st.cache_data
def load_default():
    here = Path(__file__).resolve().parent
    return pd.read_csv(here / "claims_event_log_timestamp_sample.csv")

def prepare_data(raw):
    """
    Timestamp-only event-log logic.

    Required:
      case_id
      event_name
      eventTimestamp

    Derived:
      event_sequence   = order of events after sorting by eventTimestamp
      previous_event   = preceding event in the same case
      next_event       = following event in the same case
      time_from_previous_hours = current timestamp - previous timestamp
      time_to_next_hours       = next timestamp - current timestamp
      cycle_hours              = last timestamp - first timestamp
    """
    d = raw.copy()

    required = {"case_id", "event_name", "eventTimestamp"}
    missing = required - set(d.columns)
    if missing:
        raise ValueError(
            "Missing required columns: " + ", ".join(sorted(missing))
        )

    d["eventTimestamp"] = pd.to_datetime(
        d["eventTimestamp"], errors="coerce"
    )
    d = d.dropna(subset=["case_id", "event_name", "eventTimestamp"]).copy()

    # If duplicate timestamps exist within one case, preserve original row order
    # as a deterministic tie-breaker.
    d["_row_order"] = np.arange(len(d))
    d = d.sort_values(
        ["case_id", "eventTimestamp", "_row_order"]
    ).reset_index(drop=True)

    d["event_sequence"] = d.groupby("case_id").cumcount() + 1

    d["previous_event"] = d.groupby("case_id")["event_name"].shift(1)
    d["previous_timestamp"] = d.groupby("case_id")["eventTimestamp"].shift(1)

    d["next_event"] = d.groupby("case_id")["event_name"].shift(-1)
    d["next_timestamp"] = d.groupby("case_id")["eventTimestamp"].shift(-1)

    d["time_from_previous_hours"] = (
        d["eventTimestamp"] - d["previous_timestamp"]
    ).dt.total_seconds() / 3600

    d["time_to_next_hours"] = (
        d["next_timestamp"] - d["eventTimestamp"]
    ).dt.total_seconds() / 3600

    # Defensive cleanup for malformed source logs.
    d.loc[d["time_from_previous_hours"] < 0, "time_from_previous_hours"] = np.nan
    d.loc[d["time_to_next_hours"] < 0, "time_to_next_hours"] = np.nan

    cases = (
        d.groupby("case_id")
         .agg(
             case_start=("eventTimestamp", "min"),
             case_end=("eventTimestamp", "max"),
             events=("event_name", "size")
         )
         .reset_index()
    )
    cases["cycle_hours"] = (
        cases["case_end"] - cases["case_start"]
    ).dt.total_seconds() / 3600

    return d.drop(columns=["_row_order"]), cases

def rebuild_after_filters(d):
    """
    Rebuild sequencing and elapsed times after case-level filters.
    """
    cols_to_drop = [
        "event_sequence", "previous_event", "previous_timestamp",
        "next_event", "next_timestamp",
        "time_from_previous_hours", "time_to_next_hours"
    ]
    base = d.drop(columns=[c for c in cols_to_drop if c in d.columns]).copy()
    return prepare_data(base)

def percentile_frame(series):
    s = pd.Series(series).dropna()
    if s.empty:
        return {
            "count": 0,
            "mean": np.nan,
            "median": np.nan,
            "p90": np.nan,
            "p95": np.nan,
            "p99": np.nan,
        }
    return {
        "count": int(s.count()),
        "mean": s.mean(),
        "median": s.median(),
        "p90": s.quantile(.90),
        "p95": s.quantile(.95),
        "p99": s.quantile(.99),
    }

def event_stats(d):
    """
    Event scorecard timing:
    time from this event occurrence until the next event occurrence.
    Final events therefore have no time-to-next value.
    """
    records = []
    for event_name, grp in d.groupby("event_name", sort=False):
        x = percentile_frame(grp["time_to_next_hours"])
        x["event_name"] = event_name
        x["executions"] = len(grp)
        records.append(x)
    return pd.DataFrame(records)

def transition_stats(d):
    t = d.dropna(
        subset=["next_event", "time_to_next_hours"]
    ).copy()

    records = []
    for (source, target), grp in t.groupby(
        ["event_name", "next_event"], sort=False
    ):
        x = percentile_frame(grp["time_to_next_hours"])
        x["event_name"] = source
        x["next_event"] = target
        x["cases"] = len(grp)
        records.append(x)

    if not records:
        return pd.DataFrame(columns=[
            "event_name", "next_event", "cases",
            "mean", "median", "p90", "p95", "p99"
        ])
    return pd.DataFrame(records)

def sankey_figure(d, metric_key):
    t_stats = transition_stats(d)

    node_order = (
        d.groupby("event_name")["event_sequence"]
         .median()
         .sort_values()
         .index
         .tolist()
    )
    node_idx = {name: i for i, name in enumerate(node_order)}

    event_s = event_stats(d).set_index("event_name")

    sources = []
    targets = []
    values = []
    hover = []

    for _, r in t_stats.iterrows():
        source = r["event_name"]
        target = r["next_event"]

        if source not in node_idx or target not in node_idx:
            continue

        sources.append(node_idx[source])
        targets.append(node_idx[target])
        values.append(max(float(r["cases"]), 1.0))

        hover.append(
            f"{source} → {target}<br>"
            f"Transitions: {int(r['cases']):,}<br>"
            f"{metric_key.upper()} elapsed time: {fmt_duration(r[metric_key])}"
        )

    node_labels = []
    for name in node_order:
        if name in event_s.index:
            r = event_s.loc[name]
            val = r[metric_key]
            executions = int(r["executions"])
        else:
            val = np.nan
            executions = 0

        node_labels.append(
            f"{name}<br>"
            f"To next: {fmt_duration(val)}<br>"
            f"{executions:,} events"
        )

    fig = go.Figure(
        go.Sankey(
            arrangement="snap",
            node=dict(
                pad=24,
                thickness=24,
                line=dict(width=.5),
                label=node_labels,
                hovertemplate="%{label}<extra></extra>",
            ),
            link=dict(
                source=sources,
                target=targets,
                value=values,
                customdata=hover,
                hovertemplate="%{customdata}<extra></extra>",
            ),
        )
    )

    fig.update_layout(
        title=f"Claims process map — {metric_key.upper()} inter-event time",
        height=690,
        margin=dict(l=10, r=10, t=55, b=10),
        font=dict(size=12),
    )
    return fig

# ------------------------------------------------------------------
# Header / data
# ------------------------------------------------------------------
st.title("Claims Process Mining")
st.caption(
    "Timestamp-only process mining: sequence, transitions and cycle times "
    "are derived from eventTimestamp."
)

with st.expander("Data source & event-log rules", expanded=False):
    c1, c2 = st.columns([1, 2])
    with c1:
        uploaded = st.file_uploader(
            "Upload event log CSV",
            type=["csv"]
        )
    with c2:
        st.markdown(
            "**Required columns:** `case_id`, `event_name`, `eventTimestamp`  \n"
            "**No start/end timestamps are required.** Events are ordered "
            "within each claim using `eventTimestamp`.  \n\n"
            "Derived elapsed time = timestamp of next event − timestamp of "
            "current event. End-to-end cycle = last event timestamp − first "
            "event timestamp."
        )

raw = pd.read_csv(uploaded) if uploaded is not None else load_default()

try:
    data, cases = prepare_data(raw)
except Exception as exc:
    st.error(str(exc))
    st.stop()

# ------------------------------------------------------------------
# Filters
# ------------------------------------------------------------------
filter_cols = [
    c for c in ["claim_type", "product", "region"]
    if c in data.columns
]

if filter_cols:
    with st.expander("Business filters", expanded=False):
        filtered = data.copy()

        for col in filter_cols:
            options = sorted(filtered[col].dropna().unique().tolist())
            selected = st.multiselect(
                col.replace("_", " ").title(),
                options,
                default=options
            )
            if selected:
                filtered = filtered[filtered[col].isin(selected)]

        try:
            data, cases = rebuild_after_filters(filtered)
        except Exception as exc:
            st.error(str(exc))
            st.stop()

# ------------------------------------------------------------------
# Top metrics
# ------------------------------------------------------------------
m1, m2, m3, m4 = st.columns(4)
m1.metric("Claims", f"{cases['case_id'].nunique():,}")
m2.metric("Events", f"{len(data):,}")
m3.metric(
    "Median E2E cycle",
    fmt_duration(cases["cycle_hours"].median())
)
m4.metric(
    "P95 E2E cycle",
    fmt_duration(cases["cycle_hours"].quantile(.95))
)

st.divider()

# ------------------------------------------------------------------
# Timing lens and maximize/minimize
# ------------------------------------------------------------------
control1, control2, control3 = st.columns([2.2, 1, 1])

with control1:
    metric_label = st.segmented_control(
        "Timing lens",
        options=list(METRICS.keys()),
        default="Average",
        label_visibility="collapsed",
    )

metric_key = METRICS[metric_label]

with control2:
    if st.button("⛶ Maximize flow", use_container_width=True):
        st.session_state["flow_expanded"] = True

with control3:
    if st.button("⇲ Minimize flow", use_container_width=True):
        st.session_state["flow_expanded"] = False

expanded = st.session_state.get("flow_expanded", False)
stats = event_stats(data)

def render_event_cards():
    st.markdown(
        '<div class="section-title">Event scorecards</div>',
        unsafe_allow_html=True
    )
    st.markdown(
        f'<div class="small-note">'
        f'{metric_label} elapsed time from each event to its next event.'
        f'</div>',
        unsafe_allow_html=True
    )

    order = (
        data.groupby("event_name")["event_sequence"]
            .median()
            .sort_values()
            .index
            .tolist()
    )

    s = stats.set_index("event_name")

    for event_name in order:
        r = s.loc[event_name]
        st.markdown(
            f"""
            <div class="event-card">
                <div class="event-name">{event_name}</div>
                <div class="event-value">{fmt_duration(r[metric_key])}</div>
                <div class="event-sub">
                    {int(r['executions']):,} executions ·
                    P95 to next {fmt_duration(r['p95'])}
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

if expanded:
    st.info(
        "Process map is maximized. Use **Minimize flow** to restore "
        "the event scorecards."
    )
    st.plotly_chart(
        sankey_figure(data, metric_key),
        use_container_width=True,
        config={"displaylogo": False},
    )
else:
    left, right = st.columns([1, 3.2], gap="large")

    with left:
        render_event_cards()

    with right:
        st.markdown(
            '<div class="section-title">End-to-end process flow</div>',
            unsafe_allow_html=True
        )
        st.plotly_chart(
            sankey_figure(data, metric_key),
            use_container_width=True,
            config={"displaylogo": False},
        )

st.divider()

# ------------------------------------------------------------------
# Supporting analysis tabs
# ------------------------------------------------------------------
tab1, tab2, tab3, tab4 = st.tabs([
    "E2E cycle time",
    "Event-to-next timing",
    "Transitions",
    "Process variants",
])

with tab1:
    q = pd.DataFrame({
        "Statistic": [
            "Average", "Median", "P90", "P95", "P99"
        ],
        "End-to-end hours": [
            cases["cycle_hours"].mean(),
            cases["cycle_hours"].median(),
            cases["cycle_hours"].quantile(.90),
            cases["cycle_hours"].quantile(.95),
            cases["cycle_hours"].quantile(.99),
        ]
    })
    q["Readable"] = q["End-to-end hours"].map(fmt_duration)
    st.dataframe(q, use_container_width=True, hide_index=True)

with tab2:
    show = stats[
        ["event_name", "executions", "mean", "median", "p90", "p95", "p99"]
    ].copy()

    for col in ["mean", "median", "p90", "p95", "p99"]:
        show[col] = show[col].map(fmt_duration)

    show.columns = [
        "Event", "Executions", "Average to next", "Median to next",
        "P90 to next", "P95 to next", "P99 to next"
    ]

    st.dataframe(show, use_container_width=True, hide_index=True)

with tab3:
    t = transition_stats(data).copy()

    if t.empty:
        st.info("No event-to-event transitions are available.")
    else:
        for col in ["mean", "median", "p90", "p95", "p99"]:
            t[col] = t[col].map(fmt_duration)

        t = t[[
            "event_name", "next_event", "cases",
            "mean", "median", "p90", "p95", "p99"
        ]]

        t.columns = [
            "From event", "To event", "Transitions",
            "Average", "Median", "P90", "P95", "P99"
        ]

        st.dataframe(t, use_container_width=True, hide_index=True)

with tab4:
    variants = (
        data.sort_values(["case_id", "event_sequence"])
            .groupby("case_id")["event_name"]
            .apply(lambda x: " → ".join(x))
            .value_counts()
            .rename_axis("Process variant")
            .reset_index(name="Claims")
    )

    variants["Share %"] = (
        variants["Claims"] / variants["Claims"].sum() * 100
    ).round(2)

    st.dataframe(
        variants.head(20),
        use_container_width=True,
        hide_index=True
    )

st.caption(
    "Important: a single event timestamp cannot reveal the true duration "
    "of an activity. This app therefore measures inter-event elapsed time "
    "and case throughput time, which are directly derivable from the log."
)
