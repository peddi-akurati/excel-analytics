# Claims Process Mining — Timestamp-only Event Log

This version assumes each event contains only one timestamp.

## Required columns

- `case_id`
- `event_name`
- `eventTimestamp`

No event start/end timestamps are required.

## Derived logic

Within each `case_id`, events are sorted by `eventTimestamp`.

- `event_sequence` = sorted order within the claim
- `next_event` = following event
- `time_to_next_hours` = next event timestamp - current event timestamp
- `time_from_previous_hours` = current event timestamp - previous event timestamp
- `cycle_hours` = last event timestamp - first event timestamp

Because a single timestamp cannot reveal true activity duration, the app
does not pretend that `time_to_next_hours` is processing duration. It is
displayed as inter-event elapsed time.

## Features

- Event-wise scorecards
- End-to-end Sankey process map
- Average / Median / P90 / P95 / P99 timing lenses
- Maximize / minimize process map
- E2E claim cycle-time analysis
- Event-to-next timing statistics
- Transition-level timing statistics
- Process variants and rework loops
- CSV upload
- Claim type / product / region filters

## Run

```bash
pip install -r requirements.txt
streamlit run app.py
```
