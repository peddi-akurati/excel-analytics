
import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from pathlib import Path

st.set_page_config(
    page_title="Claims Process Mining",
    page_icon="⛏️",
    layout="wide",
    initial_sidebar_state="collapsed",
)

st.markdown("""
<style>
    .block-container {padding-top: 1.2rem; padding-bottom: 1.5rem; max-width: 100%;}
    [data-testid="stMetric"] {
        background: var(--secondary-background-color);
        border: 1px solid rgba(128,128,128,.18);
        padding: 0.7rem 0.85rem;
        border-radius: 0.8rem;
    }
    .event-card {
        border: 1px solid rgba(128,128,128,.20);
        border-radius: 12px;
        padding: 10px 12px;
        margin: 0 0 8px 0;
        background: var(--secondary-background-color);
    }
    .event-name {font-weight: 700; font-size: 0.92rem; margin-bottom: 4px;}
    .event-value {font-size: 1.35rem; font-weight: 800; line-height:1.1;}
    .event-sub {font-size: 0.74rem; opacity:0.72; margin-top:4px;}
    .section-title {font-weight:800; font-size:1.05rem; margin:0.3rem 0 0.7rem 0;}
    .small-note {font-size:0.77rem; opacity:.7;}
</style>
""", unsafe_allow_html=True)

METRICS = {
    "Average": "mean",
    "Median": "median",
    "90th percentile": "p90",
    "95th percentile": "p95",
    "99th percentile": "p99",
}

def fmt_duration(hours):
    if pd.isna(hours):
        return "—"
    hours = float(hours)
    if hours < 1:
        return f"{hours*60:.0f} min"
    if hours < 48:
        return f"{hours:.1f} h"
    return f"{hours/24:.1f} d"

@st.cache_data
def load_default():
    here = Path(__file__).resolve().parent
    return pd.read_csv(here / "claims_event_log_sample.csv")

def prepare_data(raw):
    d = raw.copy()
    required = {"case_id","event_sequence","event_name","start_time","end_time"}
    missing = required - set(d.columns)
    if missing:
        raise ValueError("Missing required columns: " + ", ".join(sorted(missing)))
    d["start_time"] = pd.to_datetime(d["start_time"], errors="coerce")
    d["end_time"] = pd.to_datetime(d["end_time"], errors="coerce")
    d = d.dropna(subset=["start_time","end_time"])
    d["duration_hours"] = (d["end_time"] - d["start_time"]).dt.total_seconds() / 3600
    d = d[d["duration_hours"] >= 0].copy()
    d = d.sort_values(["case_id","event_sequence","start_time"])

    # Case end-to-end time
    case_summary = (
        d.groupby("case_id")
         .agg(case_start=("start_time","min"), case_end=("end_time","max"), events=("event_name","size"))
         .reset_index()
    )
    case_summary["cycle_hours"] = (case_summary["case_end"] - case_summary["case_start"]).dt.total_seconds()/3600

    # Waiting/transition time to next event
    d["next_event"] = d.groupby("case_id")["event_name"].shift(-1)
    d["next_start"] = d.groupby("case_id")["start_time"].shift(-1)
    d["transition_hours"] = (d["next_start"] - d["end_time"]).dt.total_seconds()/3600
    return d, case_summary

def aggregate_metric(s, key):
    s = pd.Series(s).dropna()
    if len(s) == 0:
        return np.nan
    if key == "mean": return s.mean()
    if key == "median": return s.median()
    if key == "p90": return s.quantile(.90)
    if key == "p95": return s.quantile(.95)
    if key == "p99": return s.quantile(.99)
    return s.mean()

def event_stats(d):
    g = d.groupby("event_name")["duration_hours"]
    stats = g.agg(["count","mean","median"]).reset_index()
    stats["p90"] = g.quantile(.90).values
    stats["p95"] = g.quantile(.95).values
    stats["p99"] = g.quantile(.99).values
    return stats

def transition_stats(d):
    t = d.dropna(subset=["next_event","transition_hours"]).copy()
    t = t[t["transition_hours"] >= 0]
    if t.empty:
        return pd.DataFrame(columns=["event_name","next_event","cases","mean","median","p90","p95","p99"])
    g = t.groupby(["event_name","next_event"])["transition_hours"]
    x = g.agg(["count","mean","median"]).reset_index().rename(columns={"count":"cases"})
    x["p90"] = g.quantile(.90).values
    x["p95"] = g.quantile(.95).values
    x["p99"] = g.quantile(.99).values
    return x

def sankey_figure(d, metric_key):
    e_stats = event_stats(d).set_index("event_name")
    t_stats = transition_stats(d)

    # deterministic node order based on median sequence
    node_order = (
        d.groupby("event_name")["event_sequence"].median()
         .sort_values()
         .index.tolist()
    )
    node_idx = {n:i for i,n in enumerate(node_order)}

    sources, targets, values, labels = [], [], [], []
    for _, r in t_stats.iterrows():
        s, t = r["event_name"], r["next_event"]
        if s not in node_idx or t not in node_idx:
            continue
        sources.append(node_idx[s])
        targets.append(node_idx[t])
        values.append(max(float(r["cases"]), 1.0))
        labels.append(
            f"{s} → {t}<br>"
            f"Cases: {int(r['cases']):,}<br>"
            f"{metric_key.upper()} wait: {fmt_duration(r[metric_key])}"
        )

    node_labels = []
    for n in node_order:
        val = e_stats.loc[n, metric_key] if n in e_stats.index else np.nan
        count = int(e_stats.loc[n, "count"]) if n in e_stats.index else 0
        node_labels.append(f"{n}<br>{fmt_duration(val)}<br>{count:,} events")

    fig = go.Figure(go.Sankey(
        arrangement="snap",
        node=dict(
            pad=24,
            thickness=24,
            line=dict(width=0.5),
            label=node_labels,
            hovertemplate="%{label}<extra></extra>",
        ),
        link=dict(
            source=sources,
            target=targets,
            value=values,
            customdata=labels,
            hovertemplate="%{customdata}<extra></extra>",
        ),
    ))
    fig.update_layout(
        title=f"Claims Process Flow — {metric_key.upper()} timing lens",
        height=680,
        margin=dict(l=10,r=10,t=55,b=10),
        font=dict(size=12),
    )
    return fig

st.title("Claims Process Mining")
st.caption("End-to-end claims journey, event processing time, waiting time and percentile-based bottleneck analysis.")

with st.expander("Data source & filters", expanded=False):
    c1, c2 = st.columns([1,2])
    with c1:
        uploaded = st.file_uploader("Upload event log CSV", type=["csv"])
    with c2:
        st.markdown(
            "**Required columns:** `case_id`, `event_sequence`, `event_name`, `start_time`, `end_time`. "
            "The bundled sample also includes claim type, product, region and amount."
        )

raw = pd.read_csv(uploaded) if uploaded is not None else load_default()

try:
    data, cases = prepare_data(raw)
except Exception as e:
    st.error(str(e))
    st.stop()

# Optional filters
filter_cols = [c for c in ["claim_type","product","region"] if c in data.columns]
if filter_cols:
    with st.expander("Business filters", expanded=False):
        filtered = data.copy()
        for c in filter_cols:
            options = sorted([x for x in filtered[c].dropna().unique().tolist()])
            selected = st.multiselect(c.replace("_"," ").title(), options, default=options)
            if selected:
                filtered = filtered[filtered[c].isin(selected)]
        data = filtered
        cases = (
            data.groupby("case_id")
                .agg(case_start=("start_time","min"), case_end=("end_time","max"), events=("event_name","size"))
                .reset_index()
        )
        cases["cycle_hours"] = (cases["case_end"] - cases["case_start"]).dt.total_seconds()/3600

m1, m2, m3, m4 = st.columns(4)
m1.metric("Claims", f"{cases['case_id'].nunique():,}")
m2.metric("Events", f"{len(data):,}")
m3.metric("Median E2E cycle", fmt_duration(cases["cycle_hours"].median()))
m4.metric("P95 E2E cycle", fmt_duration(cases["cycle_hours"].quantile(.95)))

st.divider()

control1, control2, control3 = st.columns([2.2,1,1])
with control1:
    metric_label = st.segmented_control(
        "Timing lens",
        options=list(METRICS.keys()),
        default="Average",
        label_visibility="collapsed",
    )
metric_key = METRICS[metric_label]
with control2:
    if st.button("⛶ Maximize flow", use_container_width=True):
        st.session_state["flow_expanded"] = True
with control3:
    if st.button("⇲ Minimize flow", use_container_width=True):
        st.session_state["flow_expanded"] = False

expanded = st.session_state.get("flow_expanded", False)
stats = event_stats(data)
stats["display_value"] = stats[metric_key]

def render_event_cards():
    st.markdown('<div class="section-title">Event scorecards</div>', unsafe_allow_html=True)
    st.markdown(
        f'<div class="small-note">Showing {metric_label.lower()} processing time for each event.</div>',
        unsafe_allow_html=True
    )
    order = (
        data.groupby("event_name")["event_sequence"].median()
            .sort_values().index.tolist()
    )
    s = stats.set_index("event_name")
    for evt in order:
        r = s.loc[evt]
        st.markdown(
            f"""
            <div class="event-card">
              <div class="event-name">{evt}</div>
              <div class="event-value">{fmt_duration(r[metric_key])}</div>
              <div class="event-sub">{int(r['count']):,} executions · P95 {fmt_duration(r['p95'])}</div>
            </div>
            """,
            unsafe_allow_html=True
        )

if expanded:
    st.info("Flow is maximized. Use **Minimize flow** to restore event scorecards.")
    st.plotly_chart(sankey_figure(data, metric_key), use_container_width=True, config={"displaylogo":False})
else:
    left, right = st.columns([1, 3.2], gap="large")
    with left:
        render_event_cards()
    with right:
        st.markdown('<div class="section-title">End-to-end process flow</div>', unsafe_allow_html=True)
        st.plotly_chart(sankey_figure(data, metric_key), use_container_width=True, config={"displaylogo":False})

st.divider()
tab1, tab2, tab3 = st.tabs(["Cycle-time distribution", "Event statistics", "Variants"])

with tab1:
    q = pd.DataFrame({
        "Statistic": ["Average","Median","P90","P95","P99"],
        "End-to-end hours": [
            cases["cycle_hours"].mean(),
            cases["cycle_hours"].median(),
            cases["cycle_hours"].quantile(.90),
            cases["cycle_hours"].quantile(.95),
            cases["cycle_hours"].quantile(.99),
        ]
    })
    q["Readable"] = q["End-to-end hours"].map(fmt_duration)
    st.dataframe(q, use_container_width=True, hide_index=True)

with tab2:
    show = stats[["event_name","count","mean","median","p90","p95","p99"]].copy()
    for c in ["mean","median","p90","p95","p99"]:
        show[c] = show[c].map(fmt_duration)
    show.columns = ["Event","Executions","Average","Median","P90","P95","P99"]
    st.dataframe(show, use_container_width=True, hide_index=True)

with tab3:
    variants = (
        data.sort_values(["case_id","event_sequence"])
            .groupby("case_id")["event_name"]
            .apply(lambda x: " → ".join(x))
            .value_counts()
            .rename_axis("Process variant")
            .reset_index(name="Claims")
    )
    variants["Share %"] = variants["Claims"] / variants["Claims"].sum() * 100
    st.dataframe(variants.head(20), use_container_width=True, hide_index=True)

st.caption(
    "Processing time = event end − event start. Transition/wait time = next event start − current event end. "
    "End-to-end cycle = first event start to final event end per claim."
)
