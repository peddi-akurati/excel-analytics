# Claims Process Mining Streamlit App

## Run
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Included sample data
`claims_event_log_sample.csv`

Required columns:
- case_id
- event_sequence
- event_name
- start_time
- end_time

The UI provides:
- event-wise scorecards
- end-to-end Sankey process flow
- Average / Median / P90 / P95 / P99 timing lens
- maximize/minimize flow option
- overall cycle-time distribution
- event statistics
- top process variants
- optional CSV upload and business filters
