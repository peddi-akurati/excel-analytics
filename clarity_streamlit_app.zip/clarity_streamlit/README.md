# Clarity Streamlit App

A Streamlit implementation of the supplied **CLARITY – Analyze & Discover** mockup.

## Included functionality

- Excel and CSV upload with sheet selection and configurable header row
- PostgreSQL query input
- Databricks SQL query input
- Optional second data source
- Left, inner, right, and outer joins
- Numeric and categorical filters
- Pivot-table builder
- Interactive Plotly charts
- Data profiling and EDA
- Search, pagination, CSV export, Excel export, and audit-log export
- Numeric fields rendered as text in the preview so every table column is left aligned

## Run

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

## Database examples

PostgreSQL URL:

```text
postgresql+psycopg2://username:password@hostname:5432/database
```

Databricks requires a server hostname, SQL warehouse HTTP path, and personal access token.

## Notes

- Database credentials remain in the current Streamlit session and are not persisted by the app.
- For production, move credentials into Streamlit secrets and add authentication, row limits, query timeouts, and authorization controls.
