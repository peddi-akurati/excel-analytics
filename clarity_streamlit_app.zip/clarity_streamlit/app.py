from __future__ import annotations

import io
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

try:
    from sqlalchemy import create_engine, text
except Exception:  # optional until database mode is used
    create_engine = None
    text = None

APP_DIR = Path(__file__).resolve().parent
LOGO_PATH = APP_DIR / "assets" / "clarity_logo.png"

st.set_page_config(
    page_title="Clarity - Analyze & Discover",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ------------------------------ Styling ------------------------------
st.markdown(
    """
<style>
:root {
  --blue:#0969e8;
  --blue-700:#075bc9;
  --navy:#0b2b55;
  --line:#dfe5ec;
  --muted:#64748b;
  --surface:#ffffff;
  --soft:#f6f9fd;
}
html, body, [class*="css"] { font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; }
.stApp { background:#fff; }
[data-testid="stHeader"] { height:38px; background:#fff; border-bottom:1px solid #e8ebef; }
[data-testid="stToolbar"] { right:0.5rem; }
[data-testid="stSidebar"] { width:318px !important; min-width:318px !important; background:#fbfcfe; border-right:1px solid #dfe5ec; }
[data-testid="stSidebar"] > div:first-child { width:318px !important; padding-top:0.35rem; }
[data-testid="stSidebar"] .block-container { padding:0.25rem 1.15rem 1.2rem; }
[data-testid="stMainBlockContainer"] { max-width:none; padding:1rem 1.2rem 2rem; }

/* Typography */
h1,h2,h3,h4 { color:#0f172a; letter-spacing:-.015em; }
p, label, div { line-height:1.35; }
.small-muted { color:var(--muted); font-size:.82rem; }
.section-label { color:#183c6b; font-weight:750; font-size:.82rem; margin:.35rem 0 .45rem; }
.metric-line { display:flex; gap:18px; font-size:.84rem; color:#111827; margin-top:-4px; margin-bottom:12px; }
.metric-line b { font-weight:650; }

/* Buttons */
.stButton > button, .stDownloadButton > button {
  border-radius:6px; min-height:36px; border:1px solid #d8dee7; font-weight:600; box-shadow:none;
}
.stButton > button:hover, .stDownloadButton > button:hover { border-color:#8ab8f4; color:#075bc9; }
.primary-cta div.stButton > button { background:var(--blue); color:white; border-color:var(--blue); }
.primary-cta div.stButton > button:hover { background:var(--blue-700); color:white; }

/* Inputs */
[data-baseweb="input"] > div, [data-baseweb="select"] > div, [data-baseweb="textarea"] > div {
  border-radius:6px !important; border-color:#d9e0e8 !important; background:white !important;
}
.stFileUploader [data-testid="stFileUploaderDropzone"] {
  border:1px dashed #bdc8d5; border-radius:7px; background:white; min-height:106px; padding:12px;
}
.stFileUploader [data-testid="stFileUploaderDropzone"] button { border:1px solid #cfe0f7; color:#075bc9; background:#fff; }
.stFileUploader small { color:#667085 !important; }

/* Sidebar tabs and expanders */
[data-testid="stSidebar"] .stTabs [data-baseweb="tab-list"] { gap:0; border:1px solid #d7dee8; border-radius:6px; overflow:hidden; }
[data-testid="stSidebar"] .stTabs [data-baseweb="tab"] { flex:1; min-width:0; white-space:nowrap; padding:8px 8px; font-size:.75rem; border-right:1px solid #d7dee8; background:#f8fafc; }
[data-testid="stSidebar"] .stTabs [data-baseweb="tab"]:last-child { border-right:0; }
[data-testid="stSidebar"] .stTabs [aria-selected="true"] { background:white; color:#075bc9; box-shadow:inset 0 0 0 1px #4f94ef; }
[data-testid="stSidebar"] .stTabs [data-baseweb="tab-highlight"] { display:none; }
[data-testid="stSidebar"] details { border-top:1px solid #e3e8ef; border-radius:0; padding:0; background:transparent; }
[data-testid="stSidebar"] details summary { font-weight:700; color:#0d2b53; padding:10px 0; font-size:.83rem; }
[data-testid="stSidebar"] details[open] summary { color:#075bc9; }

/* Dataframe */
[data-testid="stDataFrame"] { border:1px solid #dfe5ec; border-radius:7px; overflow:hidden; }
[data-testid="stDataFrame"] * { font-size:12px !important; }

/* Cards */
.success-strip { border:1px solid #73d7a3; background:#f1fff7; border-radius:6px; padding:11px 14px; color:#183d2b; font-size:.84rem; margin:14px 0; }
.next-card { background:linear-gradient(110deg,#f6f9ff,#fff); border-radius:8px; padding:18px 18px 16px; border:1px solid #edf1f7; }
.next-title { color:#12366a; font-weight:800; font-size:.92rem; margin-bottom:8px; }
.next-grid { display:grid; grid-template-columns:repeat(6,minmax(115px,1fr)); gap:14px; margin-top:16px; }
.next-item { display:grid; grid-template-columns:30px 1fr; gap:8px; align-items:start; }
.next-icon { color:#126fe8; font-size:25px; line-height:1; }
.next-item b { color:#0d2b53; font-size:.82rem; }
.next-item span { color:#344054; font-size:.75rem; display:block; margin-top:4px; }
.file-chip { display:flex; align-items:center; gap:10px; border:1px solid #e0e5eb; border-radius:6px; background:white; padding:9px 10px; margin:8px 0 12px; }
.file-icon { width:31px;height:31px;border-radius:5px;background:#e9fbef;color:#12a150;display:grid;place-items:center;font-weight:900; }
.file-meta { flex:1; font-size:.77rem; }
.file-meta b { font-size:.79rem; }
.logo-wrap { padding:0 18px 3px 18px; }
.logo-wrap img { max-width:220px; }
hr { border-color:#e6ebf1; }

@media (max-width:1100px) {
  .next-grid { grid-template-columns:repeat(3,1fr); }
}
</style>
""",
    unsafe_allow_html=True,
)

# ------------------------------ Helpers ------------------------------
def init_state() -> None:
    defaults = {
        "df1": None,
        "df2": None,
        "name1": "",
        "name2": "",
        "sheet1": "",
        "sheet2": "",
        "first_header1": True,
        "first_header2": True,
        "page": 1,
        "result_df": None,
        "audit": [],
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def log_action(action: str, details: str = "") -> None:
    st.session_state.audit.append(
        {"Timestamp": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S"), "Action": action, "Details": details}
    )


def dataframe_to_excel_bytes(df: pd.DataFrame, sheet_name: str = "Data") -> bytes:
    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name=sheet_name[:31] or "Data")
    output.seek(0)
    return output.getvalue()


def dataframe_to_csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode("utf-8")


def read_uploaded_file(uploaded_file: Any, sheet: str | int | None, first_row_header: bool) -> pd.DataFrame:
    header = 0 if first_row_header else None
    suffix = Path(uploaded_file.name).suffix.lower()
    uploaded_file.seek(0)
    if suffix == ".csv":
        return pd.read_csv(uploaded_file, header=header)
    if suffix in {".xlsx", ".xlsm", ".xls"}:
        return pd.read_excel(uploaded_file, sheet_name=sheet if sheet not in (None, "") else 0, header=header)
    raise ValueError("Unsupported file type. Upload Excel or CSV.")


def get_excel_sheets(uploaded_file: Any) -> list[str]:
    suffix = Path(uploaded_file.name).suffix.lower()
    if suffix not in {".xlsx", ".xlsm", ".xls"}:
        return ["CSV Data"]
    uploaded_file.seek(0)
    with pd.ExcelFile(uploaded_file) as xls:
        return xls.sheet_names


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out.columns = [str(c) if c is not None else f"Column_{i+1}" for i, c in enumerate(out.columns)]
    return out


def load_postgres(url: str, query: str) -> pd.DataFrame:
    if create_engine is None:
        raise RuntimeError("SQLAlchemy is unavailable. Install dependencies from requirements.txt.")
    engine = create_engine(url, pool_pre_ping=True)
    with engine.connect() as conn:
        return pd.read_sql(text(query), conn)


def load_databricks(server_hostname: str, http_path: str, token: str, query: str) -> pd.DataFrame:
    try:
        from databricks import sql as dbsql
    except Exception as exc:
        raise RuntimeError("Install databricks-sql-connector to use Databricks mode.") from exc
    with dbsql.connect(server_hostname=server_hostname, http_path=http_path, access_token=token) as conn:
        with conn.cursor() as cur:
            cur.execute(query)
            rows = cur.fetchall()
            columns = [d[0] for d in cur.description]
    return pd.DataFrame(rows, columns=columns)


def profile_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for col in df.columns:
        s = df[col]
        rows.append(
            {
                "Column": col,
                "Data Type": str(s.dtype),
                "Non-Null": int(s.notna().sum()),
                "Nulls": int(s.isna().sum()),
                "Null %": round(float(s.isna().mean() * 100), 2),
                "Unique": int(s.nunique(dropna=True)),
                "Min": s.min() if pd.api.types.is_numeric_dtype(s) and s.notna().any() else "",
                "Max": s.max() if pd.api.types.is_numeric_dtype(s) and s.notna().any() else "",
                "Mean": round(float(s.mean()), 4) if pd.api.types.is_numeric_dtype(s) and s.notna().any() else "",
            }
        )
    return pd.DataFrame(rows)


def render_file_chip(file_name: str, size: int) -> None:
    st.markdown(
        f"""
<div class="file-chip">
  <div class="file-icon">X</div>
  <div class="file-meta"><b>{file_name}</b><br><span class="small-muted">{size / (1024*1024):.2f} MB</span></div>
  <div>×</div>
</div>
""",
        unsafe_allow_html=True,
    )


def upload_source(source_no: int, required: bool) -> None:
    key = str(source_no)
    st.markdown(
        f'<div class="section-label">Data Source - File {source_no} ({"Required" if required else "Optional"})</div>',
        unsafe_allow_html=True,
    )
    upload_tab, pg_tab, dbx_tab = st.tabs(["Upload File", "PostgreSQL", "Databricks"])

    with upload_tab:
        uploaded = st.file_uploader(
            "Drag & drop your file here",
            type=["xlsx", "xls", "xlsm", "csv"],
            key=f"upload_{key}",
            help="Supports Excel and CSV",
        )
        if uploaded is not None:
            render_file_chip(uploaded.name, uploaded.size)
            try:
                sheets = get_excel_sheets(uploaded)
                selected_sheet = st.selectbox("Sheet", sheets, key=f"sheet_select_{key}")
                first_header = st.checkbox("First row is header", True, key=f"header_{key}")
                preview_rows = st.selectbox("Preview rows", [50, 100, 250, 500, 1000], index=1, key=f"preview_rows_{key}")
                if st.button("Preview Data", key=f"preview_btn_{key}", use_container_width=False):
                    df = normalize_columns(read_uploaded_file(uploaded, selected_sheet if selected_sheet != "CSV Data" else None, first_header))
                    st.session_state[f"df{key}"] = df
                    st.session_state[f"name{key}"] = uploaded.name
                    st.session_state[f"sheet{key}"] = selected_sheet
                    st.session_state[f"first_header{key}"] = first_header
                    st.session_state["page"] = 1
                    if source_no == 1:
                        st.session_state.result_df = df.copy()
                    log_action("Load file", f"Source {source_no}: {uploaded.name}, {len(df):,} rows")
                    st.success(f"Loaded {len(df):,} rows. Preview is limited to {preview_rows:,} rows in the main table.")
            except Exception as exc:
                st.error(f"Unable to inspect file: {exc}")

    with pg_tab:
        pg_url = st.text_input("Connection URL", placeholder="postgresql+psycopg2://user:password@host:5432/db", type="password", key=f"pg_url_{key}")
        pg_query = st.text_area("SQL query", "SELECT * FROM your_table LIMIT 10000", height=90, key=f"pg_query_{key}")
        if st.button("Load PostgreSQL", key=f"pg_load_{key}", use_container_width=True):
            try:
                with st.spinner("Running query..."):
                    df = normalize_columns(load_postgres(pg_url, pg_query))
                st.session_state[f"df{key}"] = df
                st.session_state[f"name{key}"] = "PostgreSQL Query"
                st.session_state[f"sheet{key}"] = "Query Result"
                if source_no == 1:
                    st.session_state.result_df = df.copy()
                log_action("PostgreSQL query", f"Source {source_no}: {len(df):,} rows")
                st.success(f"Loaded {len(df):,} rows.")
            except Exception as exc:
                st.error(f"PostgreSQL load failed: {exc}")

    with dbx_tab:
        host = st.text_input("Server hostname", placeholder="adb-....azuredatabricks.net", key=f"dbx_host_{key}")
        http_path = st.text_input("HTTP path", placeholder="/sql/1.0/warehouses/...", key=f"dbx_path_{key}")
        token = st.text_input("Access token", type="password", key=f"dbx_token_{key}")
        dbx_query = st.text_area("SQL query", "SELECT * FROM catalog.schema.table LIMIT 10000", height=90, key=f"dbx_query_{key}")
        if st.button("Load Databricks", key=f"dbx_load_{key}", use_container_width=True):
            try:
                with st.spinner("Running Databricks SQL..."):
                    df = normalize_columns(load_databricks(host, http_path, token, dbx_query))
                st.session_state[f"df{key}"] = df
                st.session_state[f"name{key}"] = "Databricks Query"
                st.session_state[f"sheet{key}"] = "Query Result"
                if source_no == 1:
                    st.session_state.result_df = df.copy()
                log_action("Databricks query", f"Source {source_no}: {len(df):,} rows")
                st.success(f"Loaded {len(df):,} rows.")
            except Exception as exc:
                st.error(f"Databricks load failed: {exc}")


init_state()

# ------------------------------ Sidebar ------------------------------
with st.sidebar:
    if LOGO_PATH.exists():
        st.markdown('<div class="logo-wrap">', unsafe_allow_html=True)
        st.image(str(LOGO_PATH), use_container_width=False, width=220)
        st.markdown('</div>', unsafe_allow_html=True)
    else:
        st.markdown("## CLARITY\nAnalyze & Discover")

    st.markdown('<div class="section-label">Expand left pane</div>', unsafe_allow_html=True)
    st.checkbox("Expand", key="expand_label", help="The Streamlit sidebar can also be collapsed using the arrow at the top.")

    upload_source(1, required=True)

    with st.expander("Data Source - File 2 (Optional)", expanded=False):
        upload_source(2, required=False)

    with st.expander("Join / Lookup", expanded=False):
        df1, df2 = st.session_state.df1, st.session_state.df2
        if df1 is None or df2 is None:
            st.caption("Load File 1 and File 2 to enable joins.")
        else:
            left_key = st.selectbox("File 1 key", df1.columns.tolist(), key="left_key")
            right_key = st.selectbox("File 2 key", df2.columns.tolist(), key="right_key")
            join_type = st.selectbox("Join type", ["left", "inner", "right", "outer"], key="join_type")
            suffixes = st.text_input("Suffixes", "_file1,_file2", key="join_suffixes")
            if st.button("Apply Join", use_container_width=True):
                try:
                    suffix_pair = tuple(x.strip() for x in suffixes.split(",", 1))
                    if len(suffix_pair) != 2:
                        suffix_pair = ("_file1", "_file2")
                    result = df1.merge(df2, left_on=left_key, right_on=right_key, how=join_type, suffixes=suffix_pair)
                    st.session_state.result_df = result
                    st.session_state.page = 1
                    log_action("Join", f"{join_type} join on {left_key}={right_key}; {len(result):,} rows")
                    st.success(f"Join created {len(result):,} rows.")
                except Exception as exc:
                    st.error(f"Join failed: {exc}")

    with st.expander("Filters & Output", expanded=False):
        base = st.session_state.result_df
        if base is None:
            st.caption("Load data to enable filters.")
        else:
            filter_col = st.selectbox("Column", base.columns.tolist(), key="filter_col")
            series = base[filter_col]
            if pd.api.types.is_numeric_dtype(series):
                clean = pd.to_numeric(series, errors="coerce").dropna()
                if clean.empty:
                    st.caption("No numeric values available.")
                else:
                    min_v, max_v = float(clean.min()), float(clean.max())
                    selected = st.slider("Range", min_v, max_v, (min_v, max_v), key="numeric_range")
                    if st.button("Apply Filter", key="apply_num_filter", use_container_width=True):
                        vals = pd.to_numeric(base[filter_col], errors="coerce")
                        st.session_state.result_df = base[vals.between(selected[0], selected[1])].copy()
                        st.session_state.page = 1
                        log_action("Filter", f"{filter_col} between {selected[0]} and {selected[1]}")
                        st.rerun()
            else:
                values = series.dropna().astype(str).unique().tolist()
                selected_values = st.multiselect("Values", values[:1000], key="category_filter")
                contains = st.text_input("Or contains text", key="contains_filter")
                if st.button("Apply Filter", key="apply_cat_filter", use_container_width=True):
                    mask = pd.Series(True, index=base.index)
                    if selected_values:
                        mask &= base[filter_col].astype(str).isin(selected_values)
                    if contains:
                        mask &= base[filter_col].astype(str).str.contains(contains, case=False, na=False)
                    st.session_state.result_df = base[mask].copy()
                    st.session_state.page = 1
                    log_action("Filter", f"{filter_col}: values/text filter")
                    st.rerun()
            if st.button("Reset to File 1", use_container_width=True):
                st.session_state.result_df = st.session_state.df1.copy()
                st.session_state.page = 1
                log_action("Reset", "Reset output to File 1")
                st.rerun()

    with st.expander("Pivot", expanded=False):
        base = st.session_state.result_df
        if base is None:
            st.caption("Load data to create a pivot table.")
        else:
            index_cols = st.multiselect("Rows", base.columns.tolist(), key="pivot_index")
            column_cols = st.multiselect("Columns", base.columns.tolist(), key="pivot_columns")
            numeric_cols = base.select_dtypes(include=np.number).columns.tolist()
            value_cols = st.multiselect("Values", numeric_cols, key="pivot_values")
            agg = st.selectbox("Aggregation", ["sum", "mean", "count", "min", "max", "median"], key="pivot_agg")
            if st.button("Create Pivot", use_container_width=True):
                try:
                    pivot = pd.pivot_table(
                        base,
                        index=index_cols or None,
                        columns=column_cols or None,
                        values=value_cols or None,
                        aggfunc=agg,
                        fill_value=0,
                    ).reset_index()
                    if isinstance(pivot.columns, pd.MultiIndex):
                        pivot.columns = [" | ".join(str(x) for x in col if str(x) != "") for col in pivot.columns]
                    st.session_state.result_df = pivot
                    st.session_state.page = 1
                    log_action("Pivot", f"Rows={index_cols}; Columns={column_cols}; Values={value_cols}; Agg={agg}")
                    st.success("Pivot created.")
                except Exception as exc:
                    st.error(f"Pivot failed: {exc}")

    with st.expander("Charts", expanded=False):
        base = st.session_state.result_df
        if base is None:
            st.caption("Load data to build charts.")
        else:
            chart_type = st.selectbox("Chart", ["Bar", "Line", "Scatter", "Area", "Histogram", "Box"], key="chart_type")
            x_col = st.selectbox("X axis", base.columns.tolist(), key="chart_x")
            numeric_cols = base.select_dtypes(include=np.number).columns.tolist()
            y_col = st.selectbox("Y axis", numeric_cols or base.columns.tolist(), key="chart_y")
            color_col = st.selectbox("Color / group", ["None"] + base.columns.tolist(), key="chart_color")
            st.session_state.chart_config = {"type": chart_type, "x": x_col, "y": y_col, "color": None if color_col == "None" else color_col}
            st.caption("The chart appears below the preview table.")

    with st.expander("Data Profile", expanded=False):
        base = st.session_state.result_df
        if base is None:
            st.caption("Load data to profile columns.")
        else:
            st.metric("Rows", f"{len(base):,}")
            st.metric("Columns", f"{len(base.columns):,}")
            st.metric("Missing cells", f"{int(base.isna().sum().sum()):,}")
            st.session_state.show_profile = st.checkbox("Show full profile below", value=st.session_state.get("show_profile", False))

    with st.expander("EDA", expanded=False):
        base = st.session_state.result_df
        if base is None:
            st.caption("Load data to run EDA.")
        else:
            st.session_state.show_eda = st.checkbox("Show EDA below", value=st.session_state.get("show_eda", False))
            st.caption("Includes descriptive statistics, missingness, and numeric correlations.")

    with st.expander("Audit & Export", expanded=False):
        base = st.session_state.result_df
        if base is None:
            st.caption("Load data to export.")
        else:
            st.download_button("Download CSV", dataframe_to_csv_bytes(base), "clarity_output.csv", "text/csv", use_container_width=True)
            st.download_button(
                "Download Excel",
                dataframe_to_excel_bytes(base, "ClarityOutput"),
                "clarity_output.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True,
            )
            audit_df = pd.DataFrame(st.session_state.audit)
            st.download_button("Download Audit Log", dataframe_to_csv_bytes(audit_df), "clarity_audit_log.csv", "text/csv", use_container_width=True)

# ------------------------------ Main ------------------------------
base_df = st.session_state.result_df

if base_df is None:
    title = "Preview - Upload a dataset or choose a database query"
    st.markdown(f"### {title}")
    st.caption("Use the options in the left pane to load Excel, CSV, PostgreSQL, or Databricks data.")
    st.markdown(
        """
<div class="next-card" style="margin-top:18px">
  <div class="next-title">Start with your data</div>
  <div class="small-muted">Upload a file in the left pane, select a sheet, and click <b>Preview Data</b>.</div>
</div>
""",
        unsafe_allow_html=True,
    )
    st.stop()

name = st.session_state.name1 or "Dataset"
sheet = st.session_state.sheet1 or "Data"

# Header and actions
head_l, head_r = st.columns([6.4, 3.6], vertical_alignment="center")
with head_l:
    st.markdown(f"### Preview - {name} ({sheet})")
    st.markdown(
        f'<div class="metric-line"><span>Total Rows: <b>{len(base_df):,}</b></span><span>Total Columns: <b>{len(base_df.columns):,}</b></span></div>',
        unsafe_allow_html=True,
    )
with head_r:
    c1, c2, c3 = st.columns([1.1, 1.2, 1])
    with c1:
        if st.button("🗑  Clear Data", use_container_width=True):
            for key in ["df1", "df2", "result_df"]:
                st.session_state[key] = None
            st.session_state.page = 1
            log_action("Clear", "Cleared loaded data")
            st.rerun()
    with c2:
        with st.popover("Download  ⌄", use_container_width=True):
            st.download_button("CSV", dataframe_to_csv_bytes(base_df), "clarity_output.csv", "text/csv", use_container_width=True)
            st.download_button(
                "Excel",
                dataframe_to_excel_bytes(base_df, "ClarityOutput"),
                "clarity_output.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True,
            )
    with c3:
        st.markdown('<div class="primary-cta">', unsafe_allow_html=True)
        if st.button("Proceed  →", type="primary", use_container_width=True):
            st.session_state.show_next = True
            log_action("Proceed", "Opened analysis options")
        st.markdown('</div>', unsafe_allow_html=True)

# Search and pagination controls
search_col, spacer = st.columns([3.1, 6.9])
with spacer:
    search_term = st.text_input("Search", placeholder="Search...", label_visibility="collapsed", key="global_search")

view_df = base_df
if search_term:
    mask = base_df.astype(str).apply(lambda col: col.str.contains(search_term, case=False, na=False)).any(axis=1)
    view_df = base_df[mask]

rows_per_page = st.selectbox("Rows per page", [25, 50, 100, 250, 500], index=2, key="rows_per_page", label_visibility="collapsed")
total_pages = max(1, int(np.ceil(len(view_df) / rows_per_page)))
st.session_state.page = min(max(1, st.session_state.page), total_pages)
start = (st.session_state.page - 1) * rows_per_page
end = min(start + rows_per_page, len(view_df))
page_df = view_df.iloc[start:end]

# All columns are text-aligned left to match the mockup.
display_df = page_df.copy()
for col in display_df.columns:
    display_df[col] = display_df[col].map(lambda x: "" if pd.isna(x) else str(x))

st.dataframe(
    display_df,
    use_container_width=True,
    hide_index=True,
    height=min(540, 38 + max(1, len(display_df)) * 35),
    column_config={c: st.column_config.TextColumn(c) for c in display_df.columns},
)

# Pagination row
p1, p2, p3 = st.columns([1.7, 4.3, 4], vertical_alignment="center")
with p1:
    st.caption(f"Rows per page: {rows_per_page}")
with p2:
    st.caption(f"Showing {start + 1 if len(view_df) else 0:,} to {end:,} of {len(view_df):,} rows")
with p3:
    pc = st.columns([0.7, 0.8, 0.8, 0.8, 0.8, 0.8, 0.7])
    with pc[0]:
        if st.button("‹", disabled=st.session_state.page <= 1, use_container_width=True):
            st.session_state.page -= 1
            st.rerun()
    candidates = sorted(set([1, max(1, st.session_state.page - 1), st.session_state.page, min(total_pages, st.session_state.page + 1), total_pages]))
    for i, page_num in enumerate(candidates[:5], start=1):
        with pc[i]:
            if st.button(str(page_num), key=f"page_{page_num}", type="primary" if page_num == st.session_state.page else "secondary", use_container_width=True):
                st.session_state.page = page_num
                st.rerun()
    with pc[6]:
        if st.button("›", disabled=st.session_state.page >= total_pages, use_container_width=True):
            st.session_state.page += 1
            st.rerun()

st.markdown('<div class="success-strip">✅ &nbsp; File loaded successfully!</div>', unsafe_allow_html=True)

# Optional analytical outputs
chart_cfg = st.session_state.get("chart_config")
if chart_cfg:
    st.markdown("#### Chart")
    chart_data = base_df.head(5000)
    kwargs = {"data_frame": chart_data, "x": chart_cfg["x"], "y": chart_cfg["y"], "color": chart_cfg["color"]}
    try:
        chart_type = chart_cfg["type"]
        if chart_type == "Bar":
            fig = px.bar(**kwargs)
        elif chart_type == "Line":
            fig = px.line(**kwargs)
        elif chart_type == "Scatter":
            fig = px.scatter(**kwargs)
        elif chart_type == "Area":
            fig = px.area(**kwargs)
        elif chart_type == "Histogram":
            fig = px.histogram(data_frame=chart_data, x=chart_cfg["x"], color=chart_cfg["color"])
        else:
            fig = px.box(**kwargs)
        fig.update_layout(margin=dict(l=10, r=10, t=30, b=10), height=430)
        st.plotly_chart(fig, use_container_width=True)
    except Exception as exc:
        st.warning(f"Chart cannot be rendered with the selected fields: {exc}")

if st.session_state.get("show_profile"):
    st.markdown("#### Data Profile")
    st.dataframe(profile_dataframe(base_df), use_container_width=True, hide_index=True)

if st.session_state.get("show_eda"):
    st.markdown("#### Exploratory Data Analysis")
    st.markdown("**Descriptive statistics**")
    try:
        st.dataframe(base_df.describe(include="all").transpose().reset_index(names="Column"), use_container_width=True, hide_index=True)
    except Exception as exc:
        st.info(f"Descriptive statistics are unavailable: {exc}")
    numeric = base_df.select_dtypes(include=np.number)
    if numeric.shape[1] >= 2:
        st.markdown("**Correlation matrix**")
        corr = numeric.corr(numeric_only=True)
        fig = px.imshow(corr, text_auto=".2f", aspect="auto")
        fig.update_layout(height=520, margin=dict(l=10, r=10, t=30, b=10))
        st.plotly_chart(fig, use_container_width=True)

st.markdown(
    """
<div class="next-card">
  <div class="next-title">What's Next?</div>
  <div class="small-muted">You can now clean, join, analyze, and visualize your data using the options in the left menu.</div>
  <div class="next-grid">
    <div class="next-item"><div class="next-icon">⌘</div><div><b>Join / Lookup</b><span>Combine data from two sources</span></div></div>
    <div class="next-item"><div class="next-icon">▽</div><div><b>Filters & Output</b><span>Filter and shape your dataset</span></div></div>
    <div class="next-item"><div class="next-icon">▦</div><div><b>Pivot</b><span>Summarize data in pivot tables</span></div></div>
    <div class="next-item"><div class="next-icon">♮</div><div><b>Charts</b><span>Visualize with interactive charts</span></div></div>
    <div class="next-item"><div class="next-icon">▥</div><div><b>Data Profile</b><span>Understand your data in depth</span></div></div>
    <div class="next-item"><div class="next-icon">▧</div><div><b>EDA</b><span>Explore and discover insights</span></div></div>
  </div>
</div>
""",
    unsafe_allow_html=True,
)
