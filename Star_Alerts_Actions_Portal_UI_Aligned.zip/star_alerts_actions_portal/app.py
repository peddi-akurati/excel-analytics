from pathlib import Path
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

st.set_page_config(page_title='Alerts & Actions', page_icon='🔔', layout='wide', initial_sidebar_state='expanded')
BASE = Path(__file__).parent
DATA = BASE / 'data'

@st.cache_data
def load_data():
    schemas = {
        'alerts.csv': ['Alert ID','Alert Type','Description','Business Area','Product','State','Severity','Triggered On','Metric Impact','Financial Impact','Owner','Days Open','Status'],
        'actions.csv': ['Action ID','Related Alert ID','Action / Initiative','Owner','Priority','Target Date','Status','Progress','Expected Impact'],
        'alert_trend.csv': ['Week','Severity','Count'],
        'notifications.csv': ['Channel','Count'],
    }
    frames = {}
    for filename, required_columns in schemas.items():
        path = DATA / filename
        if not path.is_file():
            raise FileNotFoundError(f'Required data file not found: {path}')
        frame = pd.read_csv(path)
        missing = [column for column in required_columns if column not in frame.columns]
        if missing:
            raise ValueError(f'{filename} is missing required columns: {", ".join(missing)}')
        if frame.empty:
            raise ValueError(f'{filename} contains no data rows')
        frames[filename] = frame

    frames['alerts.csv']['Triggered On'] = pd.to_datetime(frames['alerts.csv']['Triggered On'], errors='raise')
    frames['actions.csv']['Target Date'] = pd.to_datetime(frames['actions.csv']['Target Date'], errors='raise')
    return frames['alerts.csv'], frames['actions.csv'], frames['alert_trend.csv'], frames['notifications.csv']

try:
    alerts, actions, trend, notifications = load_data()
except Exception as exc:
    st.error('Portal startup validation failed.')
    st.code(str(exc))
    st.info('Run preflight_check.py from the project folder, correct the reported CSV issue, and restart the portal.')
    st.stop()

st.markdown('''
<style>
:root { --navy:#062d5d; --blue:#0b5ed7; --ink:#0b2a55; --muted:#62738e; --line:#dfe7f1; --bg:#f4f7fb; }
.stApp {background:#f5f8fc; color:var(--ink);}
[data-testid="stSidebar"] {background:linear-gradient(180deg,#062f63 0%,#001f47 100%); width:248px!important; min-width:248px!important; max-width:248px!important;}
[data-testid="stSidebarContent"] {padding-top:.45rem;}
[data-testid="stHorizontalBlock"] {align-items:stretch;}
[data-testid="column"] {min-width:0;}
[data-testid="stPlotlyChart"] {overflow:hidden;}
[data-testid="stDataFrame"] {width:100%;}
[data-testid="stSidebar"] * {color:white;}
[data-testid="stSidebar"] .stSelectbox label {font-size:11px; font-weight:600; color:#dce8f7;}
[data-testid="stSidebar"] div[data-baseweb="select"] > div {background:#0b3b74; border:1px solid #4c6f9a; color:white; min-height:38px;}
.block-container {padding:0.85rem 1.15rem 1.75rem 1.15rem; max-width:1600px; margin:0 auto;}
@media (max-width:1200px){
  .block-container{padding-left:.8rem;padding-right:.8rem;}
  .page-title{font-size:23px!important;}
  .k-value{font-size:24px!important;}
  .card{padding:12px 13px!important;}
}
@media (max-width:900px){
  [data-testid="stSidebar"]{width:220px!important;min-width:220px!important;max-width:220px!important;}
  .block-container{padding:.65rem .65rem 1.25rem .65rem;}
  .asof{text-align:left!important;margin:.25rem 0 .5rem 0!important;}
}
#MainMenu, footer, header {visibility:hidden;}
.logo {padding:8px 4px 18px 4px; border-bottom:1px solid rgba(255,255,255,.12); margin-bottom:16px;}
.logo .star {font-size:28px;font-weight:800;letter-spacing:1px}.logo small{display:block;font-size:10px;color:#d9e7f8;margin-left:3px}
.navitem{padding:10px 12px;margin:3px 0;border-radius:7px;color:#fff;font-size:14px}.navitem.active{background:#0b65db;font-weight:700}.navitem span{display:inline-block;width:28px}
.page-title{font-size:27px;font-weight:800;color:#0b2a55;margin-bottom:0}.subtitle{color:#657791;margin-top:-2px;font-size:13px}.asof{text-align:right;color:#40536d;font-size:11px;margin-top:6px}
.card{background:#fff;border:1px solid var(--line);border-radius:9px;padding:14px 16px;min-height:104px;height:100%;box-shadow:0 1px 1px rgba(10,42,85,.02);box-sizing:border-box;overflow:hidden}
.k-label{font-size:11px;font-weight:800;color:#184a93}.k-value{font-size:28px;font-weight:800;color:#102c69;margin:4px 0}.k-sub{font-size:11px;color:#62738e}.up{color:#e32929;font-weight:700}.down{color:#159447;font-weight:700}.section{background:#fff;border:1px solid var(--line);border-radius:9px;padding:12px 14px;margin-top:10px}.section-title{font-size:13px;font-weight:800;color:#173d7a;margin:0 0 8px 0}.pill{display:inline-block;padding:3px 8px;border-radius:10px;font-size:10px;font-weight:700}.critical{background:#fff0f0;color:#d72727;border:1px solid #ffcaca}.high{background:#fff7ed;color:#f07b16;border:1px solid #ffd7ad}.medium{background:#fffbe8;color:#c38b00;border:1px solid #f6df87}.low{background:#edf9f0;color:#228b4e;border:1px solid #bee5ca}.status{padding:3px 7px;border-radius:5px;font-size:10px;border:1px solid #cfd9e8;background:#f7f9fc}.table-wrap{overflow-x:auto}.note{font-size:10px;color:#60718a}.quick-title{font-size:12px;font-weight:800;margin-top:18px;margin-bottom:4px;color:#dce8f7}.stDataFrame{border:0!important}.stButton>button{border-radius:6px;border:1px solid #0b5ed7;color:#0b5ed7;background:white}.stButton>button:hover{background:#eef5ff;border-color:#0b5ed7;color:#0b5ed7}
</style>
''', unsafe_allow_html=True)

with st.sidebar:
    st.markdown('<div class="logo"><div class="star">☆ STAR <span style="font-size:11px;font-weight:500">Health<br>Insurance</span></div><small>Personal & Caring</small></div>', unsafe_allow_html=True)
    menu = [('◴','Executive Summary'),('♣','Driver Tree'),('▥','Loss Ratio Analysis'),('◕','Expense Ratio Analysis'),('⌕','Operational Drilldown'),('⌁','Forecast & Simulation'),('♟','Alerts & Actions'),('▤','Reports'),('▣','Definitions'),('◆','Data Quality')]
    for icon,name in menu:
        cls='navitem active' if name=='Alerts & Actions' else 'navitem'
        st.markdown(f'<div class="{cls}"><span>{icon}</span>{name}</div>',unsafe_allow_html=True)
    st.markdown('<div class="quick-title">QUICK FILTERS</div>',unsafe_allow_html=True)
    alert_type = st.selectbox('Alert Type',['All']+sorted(alerts['Alert Type'].unique().tolist()))
    business = st.selectbox('Business Area',['All']+sorted(alerts['Business Area'].unique().tolist()))
    product = st.selectbox('Product',['All']+sorted(alerts['Product'].unique().tolist()))
    state = st.selectbox('State',['All']+sorted(alerts['State'].unique().tolist()))
    severity = st.selectbox('Severity',['All','Critical','High','Medium','Low'])
    owner = st.selectbox('Owner',['All']+sorted(alerts['Owner'].unique().tolist()))
    if st.button('Reset Filters',use_container_width=True):
        st.rerun()

# Header filters
h1,h2,h3,h4 = st.columns([2.4,1.25,1.25,1.25], gap='medium')
with h1:
    st.markdown('<div class="page-title">ALERTS & ACTIONS ⓘ</div><div class="subtitle">Monitor key risks, track actions and drive accountability</div>',unsafe_allow_html=True)
with h2: period=st.selectbox('Time Period',["Apr'24 – Jan'25 (YTD)","FY2024-25","Last 90 Days"],label_visibility='visible')
with h3: top_area=st.selectbox('Business Area',['All']+sorted(alerts['Business Area'].unique().tolist()),key='top_area')
with h4: top_sev=st.selectbox('Alert Severity',['All','Critical','High','Medium','Low'],key='top_sev')
st.markdown('<div class="asof">Data as on: 31 Jan 2025</div>',unsafe_allow_html=True)

f=alerts.copy()
for col,val in [('Alert Type',alert_type),('Business Area',business),('Product',product),('State',state),('Severity',severity),('Owner',owner),('Business Area',top_area),('Severity',top_sev)]:
    if val!='All': f=f[f[col]==val]

# KPI cards
counts=f['Severity'].value_counts()
open_count=len(f)
overdue=int((f['Days Open']>20).sum())
kpis=[('CRITICAL ALERTS',int(counts.get('Critical',0)),'vs PY: 11','▲ 63.6%','critical'),('HIGH ALERTS',int(counts.get('High',0)),'vs PY: 38','▲ 10.5%','high'),('MEDIUM ALERTS',int(counts.get('Medium',0)),'vs PY: 71','▼ 7.0%','medium'),('LOW ALERTS',int(counts.get('Low',0)),'vs PY: 65','▼ 3.1%','low'),('TOTAL OPEN ALERTS',open_count,'vs PY: 185','▲ 7.6%','blue'),('OVERDUE ALERTS',overdue,'vs PY: 19','▲ 42.1%','purple')]
for row in (kpis[:3], kpis[3:]):
    cols=st.columns(3, gap='medium')
    for c,(label,val,sub,delta,kind) in zip(cols,row):
        good='down' if '▼' in delta else 'up'
        with c:
            st.markdown(f'<div class="card"><div class="k-label">{label}</div><div class="k-value">{val}</div><div class="k-sub">{sub}&nbsp;&nbsp; <span class="{good}">{delta}</span></div></div>',unsafe_allow_html=True)

left,right=st.columns([2.5,1],gap='medium')
with left:
    st.markdown('<div class="section-title" style="margin-top:12px">OPEN ALERTS</div>',unsafe_allow_html=True)
    s1,s2=st.columns([3,1])
    with s1: search=st.text_input('Search Alerts...',placeholder='Search Alerts...',label_visibility='collapsed')
    with s2: sort=st.selectbox('Sort By',['Severity','Days Open','Financial Impact'],label_visibility='collapsed')
    ft=f.copy()
    if search:
        mask=ft.astype(str).apply(lambda col: col.str.contains(search,case=False,na=False)).any(axis=1); ft=ft[mask]
    sev_order={'Critical':0,'High':1,'Medium':2,'Low':3}
    if sort=='Severity': ft=ft.assign(_s=ft['Severity'].map(sev_order)).sort_values(['_s','Days Open']).drop(columns='_s')
    elif sort=='Days Open': ft=ft.sort_values('Days Open',ascending=False)
    else: ft=ft.sort_values('Financial Impact',ascending=False)
    show=ft[['Alert ID','Alert Type','Description','Business Area','Product','State','Severity','Triggered On','Metric Impact','Financial Impact','Owner','Days Open','Status']].head(8).copy()
    show['Triggered On']=show['Triggered On'].dt.strftime('%d %b %Y')
    show.rename(columns={'Metric Impact':'Metric Impact (pp)','Financial Impact':'Financial Impact (₹ Cr)'},inplace=True)
    st.dataframe(show,use_container_width=True,hide_index=True,height=330)
    st.caption(f'Showing 1 to {min(8,len(ft))} of {len(ft)} alerts')
with right:
    cat=f['Alert Type'].value_counts().head(7).reset_index(); cat.columns=['Category','Count']
    fig=px.pie(cat,values='Count',names='Category',hole=.58,color_discrete_sequence=['#e42323','#f28e1c','#f1c40f','#2fa66a','#1a9ec4','#5e3db3','#8796aa'])
    fig.update_layout(title='ALERTS BY CATEGORY',height=315,margin=dict(l=8,r=8,t=48,b=8),legend=dict(orientation='h',y=-0.08,x=0,font=dict(size=9)),title_font=dict(size=13))
    fig.update_traces(textinfo='none'); st.plotly_chart(fig,use_container_width=True,config={'displayModeBar':False})
    fig2=px.line(trend,x='Week',y='Count',color='Severity',markers=True,color_discrete_map={'Critical':'#e42323','High':'#f28e1c','Medium':'#d0a000','Low':'#2c9858'})
    fig2.update_layout(title='ALERTS TREND (By Week)',height=265,margin=dict(l=8,r=8,t=50,b=30),legend=dict(orientation='h',y=1.12,x=0,font=dict(size=9)),xaxis_title=None,yaxis_title=None,title_font=dict(size=13))
    st.plotly_chart(fig2,use_container_width=True,config={'displayModeBar':False})

# Action tracker and supporting visuals
st.markdown('<div class="section-title" style="margin-top:10px">ACTIONS TRACKER</div>',unsafe_allow_html=True)
status_counts=actions['Status'].value_counts()
summary=[('TOTAL ACTIONS',len(actions)),('IN PROGRESS',int(status_counts.get('In Progress',0))),('ON TRACK',int(status_counts.get('On Track',0))),('AT RISK',int(status_counts.get('At Risk',0))),('COMPLETED',int(status_counts.get('Completed',0))),('OVERDUE',int(status_counts.get('Overdue',0)))]
for row in (summary[:3], summary[3:]):
    acols=st.columns(3, gap='medium')
    for c,(lab,v) in zip(acols,row):
        with c:
            st.markdown(f'<div class="card" style="min-height:84px;padding:11px 13px"><div class="k-label">{lab}</div><div class="k-value" style="font-size:22px">{v}</div></div>',unsafe_allow_html=True)

b1,b2=st.columns([2.2,1],gap='medium')
with b1:
    a=actions[['Action ID','Related Alert ID','Action / Initiative','Owner','Priority','Target Date','Status','Progress','Expected Impact']].head(8).copy()
    a['Target Date']=a['Target Date'].dt.strftime('%d %b %Y'); a.rename(columns={'Expected Impact':'Expected Impact (₹ Cr)','Progress':'Progress (%)'},inplace=True)
    st.dataframe(a,use_container_width=True,hide_index=True,height=285)
with b2:
    open_impact=max(f['Financial Impact'].clip(lower=0).sum(),1)
    inprog=abs(actions.loc[actions['Status']=='In Progress','Expected Impact'].sum())
    completed=abs(actions.loc[actions['Status']=='Completed','Expected Impact'].sum())
    net=max(open_impact-inprog-completed,0)
    wf=go.Figure(go.Waterfall(x=['Open Alert Impact','Actions In Progress','Completed Actions','Net Impact'],y=[open_impact,-inprog,-completed,net],measure=['absolute','relative','relative','total'],connector={'line':{'color':'#93a4bb'}},decreasing={'marker':{'color':'#22a060'}},increasing={'marker':{'color':'#173c75'}},totals={'marker':{'color':'#173c75'}}))
    wf.update_layout(title='FINANCIAL IMPACT SUMMARY (₹ Cr)',height=310,margin=dict(l=5,r=5,t=45,b=5),showlegend=False)
    st.plotly_chart(wf,use_container_width=True,config={'displayModeBar':False})
st.markdown('<div class="section-title" style="margin-top:10px">NOTIFICATIONS & OWNERS</div>',unsafe_allow_html=True)
b3,b4=st.columns(2,gap='medium')
with b3:
    st.markdown('<div class="section"><div class="section-title">ALERT NOTIFICATION SUMMARY</div>',unsafe_allow_html=True)
    for _,r in notifications.iterrows(): st.markdown(f'<div style="display:flex;justify-content:space-between;padding:10px 2px;border-bottom:1px solid #edf1f6"><span>{r["Channel"]}</span><b>{int(r["Count"]):,}</b></div>',unsafe_allow_html=True)
    st.markdown('</div>',unsafe_allow_html=True)
with b4:
    st.markdown('<div class="section"><div class="section-title">TOP ALERT OWNERS</div>',unsafe_allow_html=True)
    owners=f['Owner'].value_counts().head(5)
    maxo=max(int(owners.max()) if len(owners) else 1,1)
    for n,v in owners.items():
        st.markdown(f'<div style="font-size:11px;margin:8px 0"><div style="display:flex;justify-content:space-between"><span>{n}</span><b>{v}</b></div><div style="height:8px;background:#edf2f8;border-radius:5px"><div style="height:8px;width:{100*v/maxo:.0f}%;background:#0b5ed7;border-radius:5px"></div></div></div>',unsafe_allow_html=True)
    st.markdown('</div>',unsafe_allow_html=True)

st.markdown('<div class="note">Note: Financial impact is indicative and based on best available estimates. &nbsp;&nbsp; pp: Percentage Points &nbsp; | &nbsp; ₹ Cr: Crore Rupees</div>',unsafe_allow_html=True)
