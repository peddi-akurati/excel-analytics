"""Fast startup sanity checks for the local CSV-backed portal."""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"

SCHEMAS = {
    "alerts.csv": [
        "Alert ID", "Alert Type", "Description", "Business Area", "Product",
        "State", "Severity", "Triggered On", "Metric Impact", "Financial Impact",
        "Owner", "Days Open", "Status",
    ],
    "actions.csv": [
        "Action ID", "Related Alert ID", "Action / Initiative", "Owner", "Priority",
        "Target Date", "Status", "Progress", "Expected Impact",
    ],
    "alert_trend.csv": ["Week", "Severity", "Count"],
    "notifications.csv": ["Channel", "Count"],
}

DATE_COLUMNS = {
    "alerts.csv": ["Triggered On"],
    "actions.csv": ["Target Date"],
}

NUMERIC_COLUMNS = {
    "alerts.csv": ["Metric Impact", "Financial Impact", "Days Open"],
    "actions.csv": ["Progress", "Expected Impact"],
    "alert_trend.csv": ["Count"],
    "notifications.csv": ["Count"],
}


def fail(message: str) -> None:
    print(f"[FAIL] {message}")
    raise SystemExit(1)


def main() -> None:
    print(f"[OK] Python {sys.version.split()[0]}")
    if not DATA.is_dir():
        fail(f"Data folder not found: {DATA}")

    frames: dict[str, pd.DataFrame] = {}
    for name, required in SCHEMAS.items():
        path = DATA / name
        if not path.is_file():
            fail(f"Required file is missing: {path}")
        try:
            df = pd.read_csv(path)
        except Exception as exc:
            fail(f"Cannot read {name}: {exc}")
        missing = [column for column in required if column not in df.columns]
        if missing:
            fail(f"{name} is missing columns: {', '.join(missing)}")
        if df.empty:
            fail(f"{name} contains no data rows")
        frames[name] = df
        print(f"[OK] {name}: {len(df):,} rows, {len(df.columns)} columns")

    for name, columns in DATE_COLUMNS.items():
        for column in columns:
            parsed = pd.to_datetime(frames[name][column], errors="coerce")
            bad = int(parsed.isna().sum())
            if bad:
                fail(f"{name}.{column} contains {bad} invalid or blank date values")

    for name, columns in NUMERIC_COLUMNS.items():
        for column in columns:
            parsed = pd.to_numeric(frames[name][column], errors="coerce")
            bad = int(parsed.isna().sum())
            if bad:
                fail(f"{name}.{column} contains {bad} invalid or blank numeric values")

    for name, key in (("alerts.csv", "Alert ID"), ("actions.csv", "Action ID")):
        duplicate_count = int(frames[name][key].astype(str).duplicated().sum())
        if duplicate_count:
            fail(f"{name} contains {duplicate_count} duplicate {key} values")

    alert_ids = set(frames["alerts.csv"]["Alert ID"].astype(str))
    related = frames["actions.csv"]["Related Alert ID"].astype(str)
    orphan_count = int((~related.isin(alert_ids)).sum())
    if orphan_count:
        fail(f"actions.csv contains {orphan_count} action rows linked to alert IDs not present in alerts.csv")

    progress = pd.to_numeric(frames["actions.csv"]["Progress"], errors="coerce")
    invalid_progress = int(((progress < 0) | (progress > 100)).sum())
    if invalid_progress:
        fail(f"actions.csv contains {invalid_progress} Progress values outside 0-100")

    print("[PASS] All startup preflight checks completed successfully.")


if __name__ == "__main__":
    main()
