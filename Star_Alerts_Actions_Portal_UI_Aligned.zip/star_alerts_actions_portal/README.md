# Star Alerts & Actions Portal

A local CSV-backed Streamlit dashboard.

## Requirements

- 64-bit Python 3.11, 3.12, or 3.13
- pip

## Standard installation

Open Command Prompt or PowerShell in this extracted project folder.

```bash
python -m venv .venv
```

Activate the environment on Windows Command Prompt:

```bat
.venv\Scripts\activate
```

Or on PowerShell:

```powershell
.venv\Scripts\Activate.ps1
```

Install dependencies from the standard Python Package Index:

```bash
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

The requirements file explicitly uses `https://pypi.org/simple` so a stale or incomplete pip mirror does not silently replace PyPI.

Run the portal:

```bash
streamlit run app.py
```

You can optionally validate the CSV files first:

```bash
python preflight_check.py
```

## Troubleshooting

If `streamlit` is not recognized despite activating the environment, run:

```bash
python -m streamlit run app.py
```

If an old virtual environment was created with another Python installation, delete the `.venv` folder and recreate it.
