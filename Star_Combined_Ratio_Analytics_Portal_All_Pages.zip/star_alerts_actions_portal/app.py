from pathlib import Path
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

st.set_page_config(page_title='Star Health Combined Ratio Analytics', page_icon='☆', layout='wide', initial_sidebar_state='expanded')
BASE=Path(__file__).parent; DATA=BASE/'data'

@st.cache_data
def csv(name, dates=None):
    p=DATA/name
    if not p.exists(): raise FileNotFoundError(f'Missing required CSV: {name}')
    df=pd.read_csv(p)
    for c in dates or []:
        if c in df: df[c]=pd.to_datetime(df[c],errors='coerce')
    return df

COLORS=['#0b5ed7','#14a3a5','#7147d8','#f59e0b','#e5484d','#2f855a','#64748b']
NAV=['Executive Summary','Driver Tree','Loss Ratio Analysis','Expense Ratio Analysis','Operational Drilldown','Forecast & Simulation','Alerts & Actions','Reports','Definitions','Data Quality']
ICONS=['◴','♣','▥','◕','⌕','⌁','♟','▤','▣','◆']

st.markdown('''<style>
:root{--navy:#062d5d;--blue:#0b5ed7;--ink:#0b2a55;--muted:#62738e;--line:#dfe7f1;--bg:#f4f7fb}
.stApp{background:#f5f8fc;color:var(--ink)} [data-testid="stSidebar"]{background:linear-gradient(180deg,#062f63,#001f47);min-width:245px;max-width:245px}
[data-testid="stSidebar"] *{color:white}.block-container{padding:.7rem 1.25rem 1.5rem;max-width:100%}#MainMenu,footer,header{visibility:hidden}
.logo{padding:8px 4px 18px;border-bottom:1px solid rgba(255,255,255,.12);margin-bottom:12px}.logo .star{font-size:28px;font-weight:800}.logo small{font-size:10px;color:#d9e7f8}
[data-testid="stSidebar"] div[role="radiogroup"] label{padding:8px 10px;border-radius:7px;margin:1px 0}[data-testid="stSidebar"] div[role="radiogroup"] label:has(input:checked){background:#0b65db;font-weight:700}
.page-title{font-size:27px;font-weight:800;color:#0b2a55;margin-bottom:0}.subtitle{color:#657791;margin-top:-2px;font-size:13px}.asof{text-align:right;color:#40536d;font-size:11px}
.card{background:#fff;border:1px solid var(--line);border-radius:9px;padding:14px 16px;min-height:95px;box-shadow:0 1px 1px rgba(10,42,85,.03)}
.k-label{font-size:11px;font-weight:800;color:#184a93}.k-value{font-size:27px;font-weight:800;color:#102c69;margin:4px 0}.k-sub{font-size:11px;color:#62738e}.good{color:#159447;font-weight:700}.bad{color:#e32929;font-weight:700}
.section{background:#fff;border:1px solid var(--line);border-radius:9px;padding:12px 14px;margin-top:10px}.section-title{font-size:13px;font-weight:800;color:#173d7a;margin:2px 0 8px}.note{font-size:10px;color:#60718a;margin-top:8px}
.stButton>button{border-radius:6px;border:1px solid #0b5ed7;color:#0b5ed7;background:white}.stButton>button:hover{background:#eef5ff}.stDataFrame{border:1px solid var(--line);border-radius:8px}
div[data-baseweb="select"]>div,.stTextInput input,.stNumberInput input{border-color:#cfd9e8;background:#fff}.stTabs [data-baseweb="tab-list"]{gap:4px}.stTabs [data-baseweb="tab"]{background:#edf3fa;border-radius:6px 6px 0 0;padding:8px 16px}.stTabs [aria-selected="true"]{background:#0b5ed7;color:white}
</style>''',unsafe_allow_html=True)

with st.sidebar:
    st.markdown('<div class="logo"><div class="star">☆ STAR <span style="font-size:11px;font-weight:500">Health<br>Insurance</span></div><small>Personal & Caring</small></div>',unsafe_allow_html=True)
    page=st.radio('Navigation',[f'{i}  {n}' for i,n in zip(ICONS,NAV)],label_visibility='collapsed')
    page=page.split('  ',1)[1]
    st.markdown('---')
    st.caption('COMBINED RATIO ANALYTICS')
    st.caption('CSV-backed demonstration portal')

def header(title,subtitle):
    a,b=st.columns([4,1])
    with a: st.markdown(f'<div class="page-title">{title} ⓘ</div><div class="subtitle">{subtitle}</div>',unsafe_allow_html=True)
    with b: st.markdown('<div class="asof">Data as on: 31 Jan 2025</div>',unsafe_allow_html=True)

def kpis(items):
    cols=st.columns(len(items))
    for c,item in zip(cols,items):
        label,val,sub,delta=item
        cls='good' if str(delta).startswith(('▼','▲ +','+')) or ('Improved' in str(delta)) else 'bad'
        with c: st.markdown(f'<div class="card"><div class="k-label">{label}</div><div class="k-value">{val}</div><div class="k-sub">{sub} &nbsp; <span class="{cls}">{delta}</span></div></div>',unsafe_allow_html=True)

def chart(fig,height=320):
    fig.update_layout(height=height,margin=dict(l=10,r=10,t=48,b=10),paper_bgcolor='white',plot_bgcolor='white',font=dict(color='#334155',size=11),legend_title_text='')
    st.plotly_chart(fig,use_container_width=True,config={'displayModeBar':False})

def filters(df, cols):
    out=df.copy(); fs=st.columns(len(cols))
    for box,c in zip(fs,cols):
        vals=['All']+sorted(df[c].dropna().astype(str).unique().tolist())
        v=box.selectbox(c,vals,key=f'{page}_{c}')
        if v!='All': out=out[out[c].astype(str)==v]
    return out

if page=='Executive Summary':
    header('EXECUTIVE SUMMARY','Enterprise view of underwriting performance, growth and key business drivers')
    d=csv('executive_kpis.csv'); t=csv('executive_trend.csv'); drv=csv('executive_drivers.csv')
    cards=[]
    for _,r in d.iterrows():
        unit=r.Unit; val=f"₹{r.Current:,.0f} Cr" if unit=='₹ Cr' else (f"{r.Current:.1f}%" if unit=='%' else f"{r.Current:.2f}x")
        prev=f"vs PY: {r.Previous:,.1f}{'%' if unit=='%' else ''}"; delta=f"{'▲' if r.Variance>0 else '▼'} {abs(r.Variance):.1f}{'%' if r.KPI in ['GWP','PAT','Solvency Ratio'] else ' pp'}"
        cards.append((r.KPI.upper(),val,prev,delta))
    kpis(cards)
    c1,c2=st.columns([2,1])
    with c1:
        fig=go.Figure(); fig.add_trace(go.Scatter(x=t.Month,y=t['Combined Ratio'],name='Combined Ratio',mode='lines+markers')); fig.add_trace(go.Scatter(x=t.Month,y=t['Loss Ratio'],name='Loss Ratio',mode='lines+markers')); fig.add_trace(go.Scatter(x=t.Month,y=t['Expense Ratio'],name='Expense Ratio',mode='lines+markers'))
        fig.update_layout(title='RATIO PERFORMANCE TREND',yaxis_title='%'); chart(fig,340)
    with c2:
        fig=px.bar(drv.sort_values('Impact_pp'),x='Impact_pp',y='Driver',orientation='h',color='Direction',color_discrete_map={'Positive':'#159447','Negative':'#e32929'},title='TOP COMBINED RATIO DRIVERS'); chart(fig,340)
    c3,c4=st.columns(2)
    with c3:
        fig=px.line(t,x='Month',y='GWP',markers=True,title='GWP TREND (₹ Cr)'); chart(fig,300)
    with c4:
        fig=px.pie(drv,names='Category',values=drv.Impact_pp.abs(),hole=.6,title='DRIVER CONTRIBUTION'); chart(fig,300)

elif page=='Driver Tree':
    header('COMBINED RATIO DRIVER TREE','Trace combined ratio movement from financial outcomes to operational drivers')
    tree=csv('driver_tree.csv'); var=csv('driver_variance.csv')
    root=tree.iloc[0]; kpis([('COMBINED RATIO',f'{root.Value:.1f}%','vs PY: 101.4%','▼ 4.6 pp'),('LOSS RATIO','64.2%','vs PY: 68.7%','▼ 4.5 pp'),('EXPENSE RATIO','32.6%','vs PY: 32.7%','▼ 0.1 pp'),('UNDERWRITING RESULT','₹493 Cr','vs PY: -₹186 Cr','Improved')])
    c1,c2=st.columns([1.5,1])
    with c1:
        labels=tree.Node.tolist(); parents=[x if pd.notna(x) else '' for x in tree.Parent]; values=tree.Value.tolist()
        fig=go.Figure(go.Sunburst(labels=labels,parents=parents,values=values,branchvalues='total',marker=dict(colors=['#062d5d','#0b5ed7','#14a3a5','#7147d8','#f59e0b','#64748b','#1d8a65','#4f78c4','#9c6ade','#f97316']))); fig.update_layout(title='DRIVER TREE'); chart(fig,460)
    with c2:
        fig=go.Figure(go.Waterfall(x=['Opening']+var.Driver.tolist()+['Closing'],y=[101.4]+var.Impact_pp.tolist()+[96.8],measure=['absolute']+['relative']*len(var)+['total'])); fig.update_layout(title='COMBINED RATIO MOVEMENT (pp)'); chart(fig,460)
    st.markdown('<div class="section-title">DRIVER PERFORMANCE</div>',unsafe_allow_html=True); st.dataframe(var,use_container_width=True,hide_index=True)

elif page=='Loss Ratio Analysis':
    header('LOSS RATIO ANALYSIS','Analyse claim frequency, severity, mix and leakage across products and geographies')
    d=filters(csv('loss_ratio.csv'),['Product','State','Channel']); tr=csv('loss_trend.csv'); wf=csv('loss_waterfall.csv')
    lr=d['Incurred Claims'].sum()/d['Earned Premium'].sum()*100
    kpis([('LOSS RATIO',f'{lr:.1f}%','vs PY: 68.7%','▼ 4.5 pp'),('CLAIM FREQUENCY',f'{d.Frequency.mean():.1f}%','vs PY: 14.2%','▼ 1.1 pp'),('AVG SEVERITY',f'₹{d.Severity.mean()/1000:.1f}K','vs PY: ₹104.3K','▼ 3.6%'),('LARGE CLAIMS',f'{int(d["Large Claims"].sum())}','vs PY: 488','▼ 6.8%')])
    c1,c2=st.columns(2)
    with c1:
        fig=go.Figure(go.Waterfall(x=wf.Driver,y=wf.Impact_pp,measure=['absolute']+['relative']*(len(wf)-2)+['total'])); fig.update_layout(title='LOSS RATIO WATERFALL'); chart(fig)
    with c2:
        agg=d.groupby('Product',as_index=False).agg({'Earned Premium':'sum','Incurred Claims':'sum'}); agg['Loss Ratio']=agg['Incurred Claims']/agg['Earned Premium']*100
        fig=px.bar(agg,x='Product',y='Loss Ratio',title='LOSS RATIO BY PRODUCT'); chart(fig)
    c3,c4=st.columns(2)
    with c3:
        fig=px.line(tr,x='Month',y='Loss Ratio',color='Product',markers=True,title='PRODUCT TREND'); chart(fig)
    with c4:
        s=d.groupby('State',as_index=False).agg({'Earned Premium':'sum','Incurred Claims':'sum'}); s['Loss Ratio']=s['Incurred Claims']/s['Earned Premium']*100
        fig=px.bar(s.sort_values('Loss Ratio'),x='Loss Ratio',y='State',orientation='h',title='STATE PERFORMANCE'); chart(fig)
    st.dataframe(d,use_container_width=True,hide_index=True,height=300)

elif page=='Expense Ratio Analysis':
    header('EXPENSE RATIO ANALYSIS','Track acquisition, employee, branch and technology costs against earned premium')
    d=csv('expense_ratio.csv'); wf=csv('expense_waterfall.csv'); s=csv('expense_state.csv')
    kpis([('EXPENSE RATIO','32.6%','vs PY: 32.7%','▼ 0.1 pp'),('ACQUISITION COST','19.5%','vs PY: 20.3%','▼ 0.8 pp'),('EMPLOYEE COST','6.1%','vs PY: 6.3%','▼ 0.2 pp'),('COST SAVINGS','₹126 Cr','vs Plan: ₹110 Cr','▲ +₹16 Cr')])
    c1,c2=st.columns(2)
    with c1:
        fig=go.Figure(go.Waterfall(x=wf.Driver,y=wf.Impact_pp,measure=['absolute']+['relative']*(len(wf)-2)+['total'])); fig.update_layout(title='EXPENSE RATIO WATERFALL'); chart(fig)
    with c2:
        cat=d.groupby('Expense Category',as_index=False).Amount.sum(); fig=px.pie(cat,names='Expense Category',values='Amount',hole=.55,title='EXPENSE MIX'); chart(fig)
    c3,c4=st.columns(2)
    with c3:
        mt=d.groupby(['Month','Expense Category'],as_index=False).Amount.sum(); fig=px.line(mt,x='Month',y='Amount',color='Expense Category',markers=True,title='MONTHLY EXPENSE TREND'); chart(fig)
    with c4:
        fig=px.scatter(s,x='Expense Ratio',y='Productivity Index',text='State',size='Productivity Index',title='STATE COST VS PRODUCTIVITY'); fig.update_traces(textposition='top center'); chart(fig)
    st.dataframe(d,use_container_width=True,hide_index=True,height=280)

elif page=='Operational Drilldown':
    header('OPERATIONAL DRILLDOWN','Monitor process throughput, automation, turnaround time, backlog and SLA compliance')
    d=csv('operations.csv'); tr=csv('operations_trend.csv')
    kpis([('TOTAL VOLUME',f'{d.Volume.sum():,}','Current period','▲ 8.4%'),('AVG STP RATE',f'{d["STP Rate"].mean():.1f}%','vs PY: 67.2%','▲ +7.8 pp'),('AVG TAT',f'{d["Avg TAT Hours"].mean():.1f} hrs','vs PY: 24.1 hrs','▼ 18.2%'),('SLA BREACH',f'{d["SLA Breach %"].mean():.1f}%','vs PY: 10.8%','▼ 3.1 pp'),('BACKLOG',f'{d.Backlog.sum():,}','vs PY: 7,820','▼ 12.6%')])
    c1,c2=st.columns(2)
    with c1:
        fig=px.bar(d,x='Process',y='STP Rate',color='Status',title='STRAIGHT-THROUGH PROCESSING'); chart(fig)
    with c2:
        fig=px.scatter(d,x='Avg TAT Hours',y='SLA Breach %',size='Volume',text='Process',color='Status',title='TAT VS SLA BREACH'); fig.update_traces(textposition='top center'); chart(fig)
    c3,c4=st.columns(2)
    with c3:
        fig=px.line(tr,x='Month',y='Avg TAT Hours',color='Process',title='TAT TREND'); chart(fig)
    with c4:
        fig=px.area(tr,x='Month',y='Backlog',color='Process',title='BACKLOG TREND'); chart(fig)
    st.dataframe(d,use_container_width=True,hide_index=True)

elif page=='Forecast & Simulation':
    header('FORECAST & SIMULATION','Project combined ratio and evaluate management interventions under multiple scenarios')
    f=csv('forecast.csv'); inp=csv('scenario_inputs.csv'); acts=csv('forecast_actions.csv')
    med=st.sidebar.slider('Medical Inflation %',5.0,15.0,8.5,.5); freq=st.sidebar.slider('Frequency Change %',-10.0,10.0,-3.0,.5); acq=st.sidebar.slider('Acquisition Cost Change %',-10.0,10.0,-2.0,.5)
    impact=(med-8.5)*.18+freq*.12+acq*.10
    base=float(f[f.Type=='Forecast']['Base Scenario'].iloc[-1])+impact
    kpis([('BASE FORECAST',f'{base:.1f}%','Sep-25 projection','Scenario adjusted'),('OPTIMISTIC','92.7%','Sep-25 projection','▼ 4.1 pp'),('STRESS','101.9%','Sep-25 projection','▲ 5.1 pp'),('VALUE AT STAKE','₹286 Cr','Across initiatives','Tracked')])
    c1,c2=st.columns([2,1])
    with c1:
        fig=go.Figure();
        for col in ['Base Scenario','Optimistic','Stress']: fig.add_trace(go.Scatter(x=f.Month,y=f[col],name=col,mode='lines+markers'))
        fig.add_vline(x='Jan-25',line_dash='dash'); fig.update_layout(title='COMBINED RATIO FORECAST'); chart(fig,390)
    with c2:
        fig=px.bar(inp.sort_values('CR_Impact_pp'),x='CR_Impact_pp',y='Assumption',orientation='h',title='SCENARIO DRIVER IMPACT'); chart(fig,390)
    st.markdown('<div class="section-title">ACTION PLAN</div>',unsafe_allow_html=True); st.dataframe(acts,use_container_width=True,hide_index=True)

elif page=='Alerts & Actions':
    header('ALERTS & ACTIONS','Monitor key risks, track actions and drive accountability')
    alerts=csv('alerts.csv',['Triggered On']); actions=csv('actions.csv',['Target Date']); trend=csv('alert_trend.csv'); notes=csv('notifications.csv')
    f=filters(alerts,['Alert Type','Business Area','Product','State','Severity','Owner'])
    counts=f.Severity.value_counts(); overdue=int((f['Days Open']>20).sum())
    kpis([('CRITICAL ALERTS',int(counts.get('Critical',0)),'vs PY: 11','▲ 63.6%'),('HIGH ALERTS',int(counts.get('High',0)),'vs PY: 38','▲ 10.5%'),('MEDIUM ALERTS',int(counts.get('Medium',0)),'vs PY: 71','▼ 7.0%'),('LOW ALERTS',int(counts.get('Low',0)),'vs PY: 65','▼ 3.1%'),('TOTAL OPEN ALERTS',len(f),'vs PY: 185','▲ 7.6%'),('OVERDUE ALERTS',overdue,'vs PY: 19','▲ 42.1%')])
    c1,c2=st.columns([3,1])
    with c1:
        st.markdown('<div class="section-title">OPEN ALERTS</div>',unsafe_allow_html=True); st.dataframe(f,use_container_width=True,hide_index=True,height=390)
    with c2:
        cat=f['Alert Type'].value_counts().reset_index(); cat.columns=['Category','Count']; fig=px.pie(cat,names='Category',values='Count',hole=.58,title='ALERTS BY CATEGORY'); chart(fig,260)
        fig=px.line(trend,x='Week',y='Count',color='Severity',markers=True,title='ALERT TREND'); chart(fig,260)
    st.markdown('<div class="section-title">ACTIONS TRACKER</div>',unsafe_allow_html=True); st.dataframe(actions,use_container_width=True,hide_index=True,height=300)
    c3,c4=st.columns(2)
    with c3:
        sc=actions.Status.value_counts().reset_index(); sc.columns=['Status','Count']; fig=px.bar(sc,x='Status',y='Count',title='ACTION STATUS'); chart(fig,270)
    with c4:
        fig=px.bar(notes,x='Channel',y='Count',title='NOTIFICATION SUMMARY'); chart(fig,270)

elif page=='Reports':
    header('REPORTS','Access governed executive, finance, claims, operations and data-quality reports')
    r=csv('reports.csv'); u=csv('report_usage.csv')
    kpis([('PUBLISHED REPORTS',len(r),'Current catalog','Active'),('MONTHLY REPORTS',int((r.Frequency=='Monthly').sum()),'Scheduled','Current'),('REPORT VIEWS',int(u.Views.sum()),'Last 30 days','▲ 12.4%'),('TOP REPORT',u.iloc[0]['Report Name'],f"{u.iloc[0].Views} views",'Most used')])
    tabs=st.tabs(['Report Catalog','Scheduled Reports','Recently Viewed'])
    with tabs[0]: st.dataframe(r,use_container_width=True,hide_index=True,height=360)
    with tabs[1]: st.dataframe(r[['Report Name','Frequency','Owner','Last Published','Status']],use_container_width=True,hide_index=True)
    with tabs[2]:
        fig=px.bar(u.sort_values('Views'),x='Views',y='Report Name',orientation='h',title='REPORT USAGE'); chart(fig,350)

elif page=='Definitions':
    header('DEFINITIONS & BUSINESS GLOSSARY','Govern KPI formulas, business terminology, ownership and version history')
    d=csv('definitions.csv'); g=csv('glossary.csv')
    kpis([('DEFINED METRICS',len(d),'Governed KPIs','Approved'),('BUSINESS TERMS',len(g),'Glossary entries','Current'),('DOMAINS',d.Domain.nunique(),'Business areas','Covered'),('LATEST VERSION',d.Version.max(),'Definition repository','Published')])
    tabs=st.tabs(['KPI Definitions','Business Glossary','Version & Ownership'])
    with tabs[0]:
        q=st.text_input('Search metric or definition'); x=d if not q else d[d.astype(str).apply(lambda c:c.str.contains(q,case=False,na=False)).any(axis=1)]; st.dataframe(x,use_container_width=True,hide_index=True,height=380)
    with tabs[1]: st.dataframe(g,use_container_width=True,hide_index=True,height=350)
    with tabs[2]: st.dataframe(d[['Metric','Domain','Owner','Status','Version']],use_container_width=True,hide_index=True)

elif page=='Data Quality':
    header('DATA QUALITY','Monitor completeness, accuracy, validity, timeliness and remediation across critical data assets')
    d=csv('data_quality.csv'); tr=csv('dq_trend.csv'); issues=csv('dq_issues.csv')
    score=d[['Completeness','Accuracy','Validity','Timeliness']].mean().mean()
    kpis([('OVERALL DQ SCORE',f'{score:.1f}%','Target: 95.0%',f"{'▲' if score>=95 else '▼'} {abs(score-95):.1f} pp"),('CRITICAL ISSUES',int((issues.Severity=='Critical').sum()),'Target: 0','Needs action'),('OPEN ISSUES',int(d['Open Issues'].sum()),'Across assets','Tracked'),('HEALTHY ASSETS',int((d.Status=='Healthy').sum()),f'of {len(d)} assets','Current')])
    c1,c2=st.columns(2)
    with c1:
        avg=d[['Completeness','Accuracy','Validity','Timeliness']].mean().reset_index(); avg.columns=['Dimension','Score']; fig=px.bar(avg,x='Dimension',y='Score',range_y=[80,100],title='QUALITY DIMENSIONS'); chart(fig)
    with c2:
        fig=px.line(tr,x='Month',y='DQ Score',markers=True,title='DQ SCORE TREND'); chart(fig)
    c3,c4=st.columns(2)
    with c3:
        fig=px.bar(d.sort_values('Open Issues'),x='Open Issues',y='Data Asset',orientation='h',color='Status',title='ISSUES BY DATA ASSET'); chart(fig)
    with c4:
        fig=px.line(tr,x='Month',y=['New Issues','Resolved Issues','Critical Issues'],markers=True,title='ISSUE MOVEMENT'); chart(fig)
    st.markdown('<div class="section-title">REMEDIATION TRACKER</div>',unsafe_allow_html=True); st.dataframe(issues,use_container_width=True,hide_index=True)

st.markdown('<div class="note">All visuals and tables in this demonstration portal are populated from static CSV files in the data folder. ₹ Cr: Crore Rupees; pp: percentage points.</div>',unsafe_allow_html=True)
