#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 preflight_check.py
python3 -m streamlit run app.py
