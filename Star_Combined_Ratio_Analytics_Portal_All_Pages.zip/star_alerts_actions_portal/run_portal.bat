@echo off
cd /d "%~dp0"
python preflight_check.py
if errorlevel 1 pause & exit /b 1
python -m streamlit run app.py
pause
