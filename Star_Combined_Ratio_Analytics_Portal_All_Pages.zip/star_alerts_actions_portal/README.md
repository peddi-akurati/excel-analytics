# Star Health Combined Ratio Analytics Portal

A complete ten-page Streamlit demonstration portal based on the Combined Ratio dashboard mockups. All business data is read from static CSV files under `data/`; no page-level business values are sourced from a database or API.

## Pages

1. Executive Summary
2. Driver Tree
3. Loss Ratio Analysis
4. Expense Ratio Analysis
5. Operational Drilldown
6. Forecast & Simulation
7. Alerts & Actions
8. Reports
9. Definitions
10. Data Quality

## Windows setup

Install 64-bit Python 3.11 or 3.12, extract the ZIP, open Command Prompt in the project folder, and run:

```bat
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python preflight_check.py
python -m streamlit run app.py
```

You can also double-click `run_portal.bat` after dependencies are installed.

Open `http://localhost:8501` if the browser does not open automatically.

## macOS/Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
python preflight_check.py
python -m streamlit run app.py
```

## Updating data

Edit the relevant CSV under `data/` and restart Streamlit or use **Rerun**. Column names must remain unchanged. Run `python preflight_check.py` after structural changes.

## Important files

- `app.py`: complete multi-page portal
- `data/*.csv`: all underlying static mock data
- `preflight_check.py`: validates every required CSV and schema
- `requirements.txt`: runtime dependencies
- `run_portal.bat`: standard Windows launcher
- `run_portal.sh`: standard macOS/Linux launcher
