from pathlib import Path
import sys
import pandas as pd

BASE=Path(__file__).parent; DATA=BASE/'data'
required={
'executive_kpis.csv':['KPI','Current','Previous','Variance','Unit'],
'executive_trend.csv':['Month','Combined Ratio','Loss Ratio','Expense Ratio','GWP'],
'executive_drivers.csv':['Driver','Impact_pp','Category','Direction'],
'driver_tree.csv':['Node','Value','Parent','Level'],'driver_variance.csv':['Driver','Previous','Current','Impact_pp'],
'loss_ratio.csv':['Product','State','Channel','Earned Premium','Incurred Claims','Loss Ratio','Frequency','Severity','Large Claims'],
'loss_trend.csv':['Month','Product','Loss Ratio','Frequency','Severity'],'loss_waterfall.csv':['Driver','Impact_pp'],
'expense_ratio.csv':['Month','Expense Category','Expense Ratio','Amount','Channel'],'expense_waterfall.csv':['Driver','Impact_pp'],'expense_state.csv':['State','Expense Ratio','Productivity Index'],
'operations.csv':['Process','Volume','STP Rate','Avg TAT Hours','Backlog','SLA Breach %','First Time Right %','Status'],'operations_trend.csv':['Month','Process','Avg TAT Hours','SLA Breach %','Backlog'],
'forecast.csv':['Month','Type','Base Scenario','Optimistic','Stress'],'scenario_inputs.csv':['Assumption','Input_Value','CR_Impact_pp'],'forecast_actions.csv':['Initiative','Owner','Target','Impact_pp','Value_₹Cr','Status'],
'alerts.csv':['Alert ID','Alert Type','Description','Business Area','Product','State','Severity','Triggered On','Metric Impact','Financial Impact','Owner','Days Open','Status'],
'actions.csv':['Action ID','Related Alert ID','Action / Initiative','Owner','Priority','Target Date','Status','Progress','Expected Impact'],'alert_trend.csv':['Week','Severity','Count'],'notifications.csv':['Channel','Count'],
'reports.csv':['Report ID','Report Name','Category','Frequency','Owner','Last Published','Status'],'report_usage.csv':['Report Name','Views'],
'definitions.csv':['Metric','Definition','Domain','Frequency','Owner','Status','Version'],'glossary.csv':['Term','Meaning','Domain'],
'data_quality.csv':['Data Asset','Completeness','Accuracy','Validity','Timeliness','Open Issues','Status'],'dq_trend.csv':['Month','DQ Score','New Issues','Resolved Issues','Critical Issues'],'dq_issues.csv':['Issue ID','Data Asset','Issue','Severity','Owner','Target Date','Status']}
print(f'[OK] Python {sys.version.split()[0]}')
failed=False
for name,cols in required.items():
 p=DATA/name
 if not p.exists(): print(f'[FAIL] Missing {name}'); failed=True; continue
 try: df=pd.read_csv(p)
 except Exception as e: print(f'[FAIL] {name}: {e}'); failed=True; continue
 miss=[c for c in cols if c not in df.columns]
 if miss: print(f'[FAIL] {name}: missing {miss}'); failed=True
 elif df.empty: print(f'[FAIL] {name}: no rows'); failed=True
 else: print(f'[OK] {name}: {len(df)} rows, {len(df.columns)} columns')
if failed: raise SystemExit(1)
print('[PASS] All portal CSV files passed validation.')
