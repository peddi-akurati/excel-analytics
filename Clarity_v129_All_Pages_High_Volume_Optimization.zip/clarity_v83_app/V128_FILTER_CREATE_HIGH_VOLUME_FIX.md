# Clarity v128 – Filter/Create High-Volume Performance Fix

## Scope
Validated and optimized the Filter/Create page for large datasets such as a 150 MB file with approximately 31 columns.

## Changes
- Removed unconditional full DataFrame copies when the page renders or widgets rerun.
- Deferred string conversion until a text filter operator is actually used.
- Kept numeric comparisons on native numeric Series.
- Avoided a full copy when no filter rules are defined.
- Changed full Excel output generation from eager page-render behavior to an explicit Prepare Excel download action.
- Invalidated prepared export bytes whenever Modified Dataset changes.

## Expected behavior
- Opening the page, changing selectors, adding/removing filter definitions, and changing preview row counts do not duplicate the full dataset.
- Full-data work occurs only when the user explicitly creates a column, applies filters, sorts, deduplicates, or prepares an export.

## Synthetic validation
500,000 rows × 31 columns, approximately 294 MB in-memory:
- Page source binding: effectively immediate
- Numeric filter: approximately 0.3 seconds
- Text equality filter: approximately 0.2 seconds
- Calculated-column creation: approximately 0.2 seconds
- 100-row preview extraction: effectively immediate

Actual performance depends on hardware, selected operations, output row count, and column datatypes.
