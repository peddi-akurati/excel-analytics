# V129 All Pages High-Volume Review

Baseline: v128.

Optimizations:
- Join/Lookup: full join remains user-triggered; rendered grid is capped at 1,000 rows.
- Data Profile: opens on deterministic 100,000-row diagnostic sample; full profiling is explicit and cached in session state.
- Visualize/Pivot: pivot creation remains explicit; Excel serialization is explicit through Prepare Pivot Excel.
- Machine Learning: UI-only type classification and target-cardinality checks use a deterministic sample; training retains its configured full/sample execution.
- Data Mining: expensive mining/correlation operations remain behind Evaluate controls and existing row caps.
- Audit: complete CSV/Excel ZIP generation is explicit through Prepare Complete Analysis Dump.
- Preview and Filter/Create retain v127/v128 optimizations.

No analytical transformation was changed from full-data to sample without a visible scope label or explicit execution control.
