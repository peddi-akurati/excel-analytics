# Clarity v124 — Metric Labels and Preview Copy

## Changes

- Strengthened the Streamlit `stMetricLabel` styling so the uploaded dataset metric labels, including **ROWS** and **COLUMNS**, render in bold across nested label elements.
- Enabled AG Grid cell text selection and clipboard copy for the Preview grid.
- Added DOM ordering and explicit text-selection CSS so users can select cell content and copy it with Ctrl+C / Cmd+C without entering edit mode.

## Grid options

- `enableCellTextSelection=True`
- `ensureDomOrder=True`
- `suppressClipboardPaste=False`
