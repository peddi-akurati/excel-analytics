# Clarity v125 – IST datetime ingestion standardization

- Fixed `ValueError: Mixed timezones detected` in `safe_datetime_series`.
- Every detected datetime column is normalized immediately after file or database ingestion.
- Canonical internal timezone is the IANA zone `Asia/Kolkata`.
- Timezone-aware source values preserve their actual instant and are converted to IST.
- Timezone-naive source values are interpreted as IST.
- A single column may safely contain naive values, UTC `Z` values, explicit offsets, and timezone-aware Python/pandas values.
- Invalid datetime values are coerced to null and recorded in the input audit metadata.
- Numeric fields are not automatically treated as dates, protecting IDs and measures.
- Excel downloads preserve IST wall-clock values while removing timezone metadata only for Excel compatibility.
- Python compilation, included startup validation, mixed-timezone tests, ingestion detection tests, and Excel export tests passed.
