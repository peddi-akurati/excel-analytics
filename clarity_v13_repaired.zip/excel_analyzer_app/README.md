# Stargazer

Stargazer is a Streamlit-based data analysis application for uploaded Excel/CSV files and database query results.

## Supported data sources

Each dataset can independently come from:

- Excel or CSV upload
- PostgreSQL custom SQL query
- Databricks SQL Warehouse custom SQL query

Dataset 2 is optional and is needed only for join/lookup analysis. Query results work throughout filters, pivots, charts, profiling, EDA, exports, and audit packages.

## Database connection fields

### PostgreSQL

Provide host, port, database, user, password, SSL mode, and a read-only SQL query.

### Databricks

Provide server hostname, SQL Warehouse HTTP path, personal/service-principal access token, optional catalog/schema, and a read-only SQL query.

Stargazer accepts one result-returning statement at a time: `SELECT`, `WITH`, `SHOW`, `DESCRIBE`, or `EXPLAIN`. Credentials are not written to audit logs or exported analysis metadata.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

## Docker

```bash
docker build -t stargazer .
docker run --rm -p 8501:8501 stargazer
```

Open `http://localhost:8501`.

## Databricks notes

Use the hostname and HTTP path shown in the SQL Warehouse connection details. The token must have permission to use the warehouse and read the queried objects.

## PostgreSQL notes

Use a database account with read-only privileges. Network routes, firewall rules, SSL certificates, and allowlists must permit the machine running Stargazer to reach PostgreSQL.


## Version 8 interface updates

- Expandable wide left pane for database query controls and larger result previews.
- Pivot output retains expanded/wrapped headings and can be downloaded as Excel or CSV.
- Data Profile no longer duplicates column-level exploration or correlation analysis.
- EDA correlation analysis selects all columns by default and supports Pearson, Spearman, and Kendall algorithms.
- Streamlit Deploy control is hidden.
- Plotly charts apply visible data labels by default where the chart type supports labels.

## Version 9 reliability update

- Fixed the startup `NameError: name 'font' is not defined` caused by CSS braces inside a Python f-string.
- Global Verdana styling and dynamic sidebar width are now rendered through a safe CSS builder.
- Added `validate_startup.py` to compile the application, validate package files, and prevent CSS f-string regressions.

Run validation before deployment:

```bash
python validate_startup.py
streamlit run app.py
```

## v11 dashboard UI

This version introduces the Clarity dashboard layout approved in the reference design:

- Clarity logo at the top-left of the sidebar
- Expandable data-source workspace
- File, PostgreSQL, and Databricks source choices
- Preview title, row and column totals, action buttons, and full-width grid
- File-loaded success banner
- What's Next workflow cards
- Existing join, filtering, pivot, charting, profiling, EDA, audit, and export capabilities
- Left-aligned headers and values in all data grids
