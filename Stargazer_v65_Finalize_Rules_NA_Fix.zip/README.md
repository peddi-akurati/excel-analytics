# Stargazer

Stargazer is a Streamlit-based data analysis application for uploaded Excel/CSV files and database query results.

## Supported data sources

Each dataset can independently come from:

- Excel or CSV upload
- PostgreSQL custom SQL query
- Databricks SQL Warehouse custom SQL query

Dataset 2 is optional and is needed only for join/lookup analysis. Query results work throughout filters, pivots, charts, profiling, EDA, exports, and audit packages.

## Database connection fields

### PostgreSQL

Provide host, port, database, user, password, SSL mode, and a read-only SQL query.

### Databricks

Provide server hostname, SQL Warehouse HTTP path, personal/service-principal access token, optional catalog/schema, and a read-only SQL query.

Stargazer accepts one result-returning statement at a time: `SELECT`, `WITH`, `SHOW`, `DESCRIBE`, or `EXPLAIN`. Credentials are not written to audit logs or exported analysis metadata.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

## Docker

```bash
docker build -t stargazer .
docker run --rm -p 8501:8501 stargazer
```

Open `http://localhost:8501`.

## Databricks notes

Use the hostname and HTTP path shown in the SQL Warehouse connection details. The token must have permission to use the warehouse and read the queried objects.

## PostgreSQL notes

Use a database account with read-only privileges. Network routes, firewall rules, SSL certificates, and allowlists must permit the machine running Stargazer to reach PostgreSQL.


## Version 8 interface updates

- Expandable wide left pane for database query controls and larger result previews.
- Pivot output retains expanded/wrapped headings and can be downloaded as Excel or CSV.
- Data Profile no longer duplicates column-level exploration or correlation analysis.
- EDA correlation analysis selects all columns by default and supports Pearson, Spearman, and Kendall algorithms.
- Streamlit Deploy control is hidden.
- Plotly charts apply visible data labels by default where the chart type supports labels.

## Version 9 reliability update

- Fixed the startup `NameError: name 'font' is not defined` caused by CSS braces inside a Python f-string.
- Global Verdana styling and dynamic sidebar width are now rendered through a safe CSS builder.
- Added `validate_startup.py` to compile the application, validate package files, and prevent CSS f-string regressions.

Run validation before deployment:

```bash
python validate_startup.py
streamlit run app.py
```

## Stable logo build

This build is based on Stargazer stable v9 with the right-side immediate data preview. It adds only the supplied Clarity logo at the top of the left sidebar. The logo is stored as an RGBA PNG with a transparent background in `assets/clarity_logo.png`.

## Stable v12 navigation and layout update

- Preview is now a first-class top navigation tab.
- Removed the interactive-preview expander and fit-columns control.
- Pivot Excel and CSV downloads are positioned side by side.
- All native dataframe and AG Grid cells are left aligned.
- The sidebar logo remains fixed while sidebar content scrolls.
- The main workspace expands when the sidebar is collapsed.

## Stable v14 corrections
- Sidebar header logo is rendered deterministically using the transparent PNG as the native header background, with `st.logo()` retained only as a compatibility fallback.
- Purpose statement is displayed immediately on the right pane, including before a file or database source is loaded.
- Browser favicon uses the minified Clarity star logo.

## v31 fixes
- Stabilized mixed-type Pearson, Spearman, and Kendall association matrices so displayed cells are numeric rather than NaN.
- Added native Streamlit interactive cell grids below correlation and Deep Dive cross-tab heatmaps.
- Clicking a cell applies its exact filter, stores the result as Filtered output, and opens the matching dataset in a popup.

## v38 Filter layout alignment
- Reorganized the Filter page into consistent form rows.
- Normalized selectbox, text input, multiselect, button, download button and checkbox heights.
- Added compact styling for the saved-filter uploader.
- Balanced column widths for filter conditions, output settings and actions.
- Kept the styling scoped to the Filter page.

## Version 39
- Added a Profile source selector to Pivot, Charts, and Explore.
- Available sources match Data Profile: File 1, File 2, Joined data, and Filtered output when available.
- Pivot output is cleared when the source changes to avoid showing results from a previous dataset.


## v41 update
- Deep Dive heatmap tables now support horizontal scrolling for wide matrices.
- Vertical scrolling from v40 is retained.
- Value columns keep readable minimum widths instead of being compressed to fit the page.
- Cell-click popup and saved-filter behavior are unchanged.

## Saved database connection profiles

PostgreSQL and Databricks connection details can be saved from the source intake panel. The app stores named profiles in `connection_profiles.json` in the project directory and lets either dataset load or delete them later. Because saved profiles include passwords or access tokens, the file is excluded through `.gitignore`; keep it private and restrict project-folder access. A template is provided as `connection_profiles.example.json`.

## Combination Mining

The Explore page now includes notebook-aligned exhaustive combination mining after Control Selection and Categorical Analysis. It prepares categorical features with `UNKNOWN`/`OTHER`, quantile-bins numeric features, evaluates combinations up to the configured rule length, applies support/positive-count/confidence/lift thresholds, computes Wilson 95% confidence intervals and rule scores, and supports CSV rule export.

## Association Mining

The Explore page includes notebook-equivalent FP-Growth association mining after Combination Mining. It prepares categorical and numeric-bin transaction items, appends `TARGET_POSITIVE`, mines frequent itemsets, and retains rules whose consequent is the positive target. Configurable thresholds include minimum support, confidence, lift, maximum itemset length, top categories, and numeric bins. Results include support, confidence, lift, leverage, conviction, summary metrics, bin metadata, and CSV download.


## Finalize Rules

The Explore page combines notebook sections 10-12 into a Finalize Rules workflow after Association Mining. It trains an imputed/encoded balanced decision tree, extracts readable tree leaves, reports holdout classification metrics, ROC-AUC, PR-AUC and confusion matrix, validates up to 500 combination rules on a stratified holdout set, creates model-score risk bands, assigns recommended business actions, and exports CSV and Excel outputs. Validation explicitly handles missing targets, invalid numeric positive classes, insufficient class counts, empty feature sets, infinite numeric values, missing/blank categorical values, collapsed score quantiles, malformed rules, absent columns, and pandas scalar/array missing-value ambiguity.

### v65 nullable-value hardening
Finalize Rules now converts nullable Boolean, String, category and object model inputs to plain Python strings or `numpy.nan` before scikit-learn imputation. It also validates persisted Combination Mining settings and avoids truth-testing non-dictionary state, preventing `boolean value of NA is ambiguous` failures.
