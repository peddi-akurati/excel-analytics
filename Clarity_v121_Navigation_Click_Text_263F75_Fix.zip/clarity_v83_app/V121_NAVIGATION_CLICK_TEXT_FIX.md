# V121 Navigation Click Text Fix

- Scoped navigation styling to Streamlit widget-key wrappers (`st-key-nav_button_*`).
- Forces navigation label and nested elements to `#263f75` for normal, hover, focus, active, and selected/primary states.
- Prevents the global selected-button white text rule from affecting page navigation.
- Does not alter content, form, upload, download, or action buttons.
