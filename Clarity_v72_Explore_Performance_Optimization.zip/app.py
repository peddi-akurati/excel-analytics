from __future__ import annotations
LEFT_ALIGN_CSS="""<style>.ag-header-cell-label{justify-content:flex-start!important}.ag-cell,.ag-right-aligned-cell{text-align:left!important;justify-content:flex-start!important}</style>"""


from datetime import datetime, timezone
from io import BytesIO
from itertools import combinations
from pathlib import Path
from typing import Any
import hashlib
import json
import math
import zipfile
import re
import html
import os
import tempfile
from urllib.parse import quote

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from PIL import Image
from st_aggrid import AgGrid, GridOptionsBuilder, DataReturnMode, GridUpdateMode, JsCode
from mlxtend.frequent_patterns import fpgrowth, association_rules as mlxtend_association_rules
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import average_precision_score, classification_report, confusion_matrix, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, label_binarize
from sklearn.tree import DecisionTreeClassifier, _tree, export_text

BASE_DIR = Path(__file__).resolve().parent
LOGO_PATH = BASE_DIR / "assets" / "clarity_logo.png"
FAVICON_PATH = BASE_DIR / "assets" / "clarity_favicon.png"
CONNECTION_CONFIG_PATH = BASE_DIR / "connection_profiles.json"

page_icon = str(FAVICON_PATH) if FAVICON_PATH.exists() else "C"
st.set_page_config(page_title="Clarity", page_icon=page_icon, layout="wide")
st.markdown(LEFT_ALIGN_CSS, unsafe_allow_html=True)
st.markdown('<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" rel="stylesheet">', unsafe_allow_html=True)

# Render the transparent Clarity brand inside Streamlit's native sidebar header.
if LOGO_PATH.exists():
    st.logo(
        str(LOGO_PATH),
        icon_image=str(FAVICON_PATH) if FAVICON_PATH.exists() else None,
        size="large",
    )
    # Logo rendered large; CSS below scales it by 1.25.


def render_global_styles() -> None:
    """Apply stable app, sidebar, header, dataframe and grid styling."""
    sidebar_width = "27rem" if st.session_state.get("wide_sidebar", False) else "15.75rem"
    css = """
    <style>

    /* Increase logo render size within same header area */
    [data-testid="stLogo"] img, [data-testid="stSidebarHeader"] img{
        transform: scale(1.25);
        transform-origin:center;
    }

    html, body, [class*="css"], [data-testid="stAppViewContainer"],
    [data-testid="stSidebar"], button, input, textarea, select {
        font-family: Verdana, Geneva, sans-serif !important;
    }
    [data-testid="stAppDeployButton"], [data-testid="stDeployButton"] {
        display: none !important;
    }
    section[data-testid="stSidebar"][aria-expanded="true"] {
        width: __SIDEBAR_WIDTH__ !important;
        min-width: __SIDEBAR_WIDTH__ !important;
    }
    section[data-testid="stSidebar"][aria-expanded="true"] > div {
        width: __SIDEBAR_WIDTH__ !important;
    }
    section[data-testid="stSidebar"][aria-expanded="false"] {
        width: 0 !important;
        min-width: 0 !important;
    }
    /* Hide the sidebar brand completely while the pane is collapsed. */
    section[data-testid="stSidebar"][aria-expanded="false"] [data-testid="stSidebarHeader"],
    section[data-testid="stSidebar"][aria-expanded="false"] [data-testid="stLogo"],
    section[data-testid="stSidebar"][aria-expanded="false"] [data-testid="stSidebarHeader"] img {
        visibility: hidden !important;
        opacity: 0 !important;
        pointer-events: none !important;
    }
    [data-testid="collapsedControl"] {
        z-index: 10050 !important;
        top: .55rem !important;
        left: .6rem !important;
        width: 3.35rem !important;
        height: 3.35rem !important;
        border-radius: .75rem !important;
        background: #f3f6fb !important;
        border: 1px solid #dce4f0 !important;
        box-shadow: 0 2px 10px rgba(15, 23, 42, .10) !important;
    }
    [data-testid="collapsedControl"] img,
    [data-testid="collapsedControl"] svg {
        width: 2.35rem !important;
        height: 2.35rem !important;
    }
    section[data-testid="stSidebar"] [data-testid="stSidebarHeader"] {
        position: sticky !important;
        top: 0 !important;
        z-index: 10000 !important;
        min-height: 6.2rem !important;
        padding: .35rem .7rem !important;
        border-bottom: 1px solid #e8edf5 !important;
        background: #f3f6fb !important;
        backdrop-filter: none !important;
        overflow: hidden !important;
    }
    section[data-testid="stSidebar"] [data-testid="stSidebarHeader"] img {
        width: 12.25rem !important;
        min-width: 12.25rem !important;
        max-width: 12.25rem !important;
        height: 4.75rem !important;
        min-height: 4.75rem !important;
        max-height: 4.75rem !important;
        object-fit: contain !important;
        object-position: left center !important;
        opacity: 1 !important;
        background: transparent !important;
        flex: 0 0 12.25rem !important;
    }
    section[data-testid="stSidebar"] {
        background: #f3f6fb !important;
        border-right: 1px solid #dce4f0 !important;
    }
    section[data-testid="stSidebar"] div[data-testid="stSidebarUserContent"] {
        padding-top: .85rem !important;
        position: relative !important;
        z-index: 1 !important;
        background: #f3f6fb !important;
    }
    section[data-testid="stSidebar"] > div:first-child {
        background: #f3f6fb !important;
    }
    /* Header statement rendered in the right-pane stAppHeader. */
    [data-testid="stHeader"]::after,
    [data-testid="stAppHeader"]::after {
        content: "Add the data, conduct analysis, and uncover insights to facilitate clear, data-driven decisions";
        position: absolute;
        left: 5.35rem;
        top: 50%;
        transform: translateY(-50%);
        width: calc(100% - 6.35rem);
        max-width: none;
        padding: .58rem 1rem .58rem 1.15rem;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        color: #002060;
        font-size: .86rem;
        font-weight: 600;
        letter-spacing: .005em;
        line-height: 1.2;
        border: 1px solid #cbd8ec;
        border-left: 4px solid #002060;
        border-radius: .65rem;
        background: linear-gradient(90deg, #edf3ff 0%, #f8fbff 72%, #ffffff 100%);
        box-shadow: 0 3px 12px rgba(0, 32, 96, .08);
        pointer-events: none;
        box-sizing: border-box;
    }
    /* Left-align all native dataframe headers and values; keep headers sticky. */
    [data-testid="stDataFrame"] th, [data-testid="stDataFrame"] td,
    [data-testid="stDataEditor"] th, [data-testid="stDataEditor"] td {
        text-align: left !important;
        justify-content: flex-start !important;
    }
    [data-testid="stDataFrame"] thead th,
    [data-testid="stDataEditor"] thead th {
        position: sticky !important;
        top: 0 !important;
        z-index: 5 !important;
        background: #f8fafc !important;
    }
    /* Material 3 documentation-style navigation tabs. */
    div[data-testid="stHorizontalBlock"]:has(.modern-nav-anchor) {
        display: none !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] {
        display: grid !important;
        grid-template-columns: repeat(7, minmax(max-content, 1fr)) !important;
        align-items: end !important;
        padding: 0 .25rem;
        margin: .2rem 0 1.15rem 0;
        border: 0 !important;
        border-bottom: 1px solid #d7dee8 !important;
        border-radius: 0 !important;
        background: transparent !important;
        box-shadow: none !important;
        gap: .15rem !important;
        overflow-x: auto !important;
        scrollbar-width: thin;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] > div {
        width: 100% !important;
        min-width: max-content !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"],
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] > div {
        width: 100% !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button {
        position: relative !important;
        width: 100% !important;
        height: 3rem !important;
        min-height: 3rem !important;
        padding: .55rem .75rem .65rem !important;
        border: 0 !important;
        border-radius: .5rem .5rem 0 0 !important;
        background: transparent !important;
        color: #475569 !important;
        font-size: .79rem !important;
        font-weight: 600 !important;
        line-height: 1.1 !important;
        letter-spacing: .01em !important;
        white-space: nowrap !important;
        box-shadow: none !important;
        transition: background-color .16s ease, color .16s ease !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button::after {
        content: "" !important;
        position: absolute !important;
        left: 50% !important;
        bottom: 0 !important;
        width: 0 !important;
        height: 3px !important;
        border-radius: 3px 3px 0 0 !important;
        background: #002060 !important;
        transform: translateX(-50%) !important;
        transition: width .18s ease !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button:hover {
        transform: none !important;
        background: #f2f6fc !important;
        color: #002060 !important;
        box-shadow: none !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button:focus-visible {
        outline: 2px solid #5477b7 !important;
        outline-offset: -2px !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button[kind="primary"] {
        background: #edf3ff !important;
        color: #002060 !important;
        font-weight: 700 !important;
        box-shadow: none !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button[kind="primary"]::after {
        width: calc(100% - 1.25rem) !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button[kind="primary"]:hover {
        background: #e4edfc !important;
        color: #002060 !important;
    }
    @media (max-width: 920px) {
        .modern-nav-anchor + div[data-testid="stHorizontalBlock"] {
            grid-template-columns: repeat(8, minmax(8rem, 1fr)) !important;
        }
    }
    

    /* Filter page: consistent form widths, heights and baseline alignment. */
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) div[data-testid="stHorizontalBlock"] {
        align-items: end !important;
    }
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stSelectbox"] > div,
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stTextInput"] > div,
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stMultiSelect"] > div {
        width: 100% !important;
    }
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-baseweb="select"] > div,
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stTextInput"] input {
        min-height: 2.65rem !important;
        height: 2.65rem !important;
        box-sizing: border-box !important;
    }
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stButton"] button,
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stDownloadButton"] button {
        min-height: 2.65rem !important;
        height: 2.65rem !important;
        width: 100% !important;
        padding-top: .45rem !important;
        padding-bottom: .45rem !important;
    }
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stFileUploader"] section {
        min-height: 2.65rem !important;
        padding: .35rem .55rem !important;
    }
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stFileUploader"] section > div:first-child,
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stFileUploader"] small {
        display: none !important;
    }
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stFileUploader"] section button {
        min-height: 2rem !important;
        height: 2rem !important;
        width: auto !important;
        margin: 0 !important;
    }
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stCheckbox"] {
        min-height: 2.65rem !important;
        display: flex !important;
        align-items: center !important;
        padding-top: 1.25rem !important;
        box-sizing: border-box !important;
    }
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stCheckbox"] label {
        margin: 0 !important;
    }
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stWidgetLabel"] {
        min-height: 1.35rem !important;
        margin-bottom: .25rem !important;
    }
</style>
    """.replace("__SIDEBAR_WIDTH__", sidebar_width)
    st.markdown(css, unsafe_allow_html=True)


render_global_styles()


OPERATORS = [
    "equals", "not equals", "contains", "does not contain", "starts with", "ends with",
    "greater than", "greater than or equal", "less than", "less than or equal",
    "between", "in list", "not in list", "is blank", "is not blank",
]


def init_state() -> None:
    defaults: dict[str, Any] = {
        "filters": [],
        "audit_log": [],
        "joined_data": None,
        "filtered_data": None,
        "join_config": {},
        "last_filter_config": {},
        "analysis_name": "excel_analysis",
        "input_signature": None,
        "db_data_1": None,
        "db_data_2": None,
        "db_meta_1": {},
        "db_meta_2": {},
        "base_data_1": None,
        "base_data_2": None,
        "profile_revision_1": 0,
        "profile_revision_2": 0,
        "pivot_data": None,
        "wide_sidebar": False,
        "saved_deep_dive_filters": {},
        "deep_dive_popup_event_id": 0,
        "deep_dive_popup_shown_event_id": 0,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def utc_now() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def audit(action: str, details: dict[str, Any] | None = None) -> None:
    st.session_state.audit_log.append({
        "timestamp": utc_now(),
        "action": action,
        "details": json.dumps(details or {}, ensure_ascii=False, default=str),
    })


def file_fingerprint(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()[:16]


def dataframe_signature(df: pd.DataFrame) -> str:
    """Create a lightweight, stable signature without hashing every cell on every rerun."""
    sample = df.head(128)
    payload = f"{len(df)}|{len(df.columns)}|{'|'.join(map(str, df.columns))}|{sample.to_csv(index=False)}"
    return hashlib.sha256(payload.encode("utf-8", errors="ignore")).hexdigest()[:16]


@st.cache_data(show_spinner=False, max_entries=12)
def sampled_explore_frame(df: pd.DataFrame, max_rows: int, seed: int, signature: str) -> pd.DataFrame:
    del signature
    if max_rows <= 0 or len(df) <= max_rows:
        return df
    return df.sample(n=int(max_rows), random_state=int(seed)).sort_index()


def candidate_combination_count(feature_count: int, max_len: int) -> int:
    return int(sum(math.comb(feature_count, k) for k in range(1, min(max_len, feature_count) + 1)))


@st.cache_data(show_spinner=False)
def get_sheet_names(file_bytes: bytes, filename: str) -> list[str]:
    if filename.lower().endswith(".csv"):
        return ["CSV"]
    return pd.ExcelFile(BytesIO(file_bytes)).sheet_names


@st.cache_data(show_spinner=False)
def load_table(file_bytes: bytes, filename: str, sheet_name: str | None) -> pd.DataFrame:
    """Read Excel or CSV files with resilient CSV encoding/delimiter handling."""
    stream = BytesIO(file_bytes)
    if filename.lower().endswith(".csv"):
        encodings = ["utf-8-sig", "utf-8", "cp1252", "latin-1"]
        last_error: Exception | None = None
        for encoding in encodings:
            try:
                stream.seek(0)
                # sep=None lets pandas detect comma, semicolon, tab, or pipe-delimited files.
                return pd.read_csv(
                    stream, encoding=encoding, sep=None, engine="python",
                    on_bad_lines="warn"
                )
            except (UnicodeDecodeError, UnicodeError, pd.errors.ParserError) as exc:
                last_error = exc
        raise ValueError(
            "CSV could not be decoded using UTF-8, Windows-1252, or Latin-1. "
            f"Last error: {last_error}"
        )
    return pd.read_excel(stream, sheet_name=sheet_name)


def validate_read_only_sql(query: str) -> str:
    """Allow result-returning SQL while blocking obvious write or multi-statement commands."""
    cleaned = query.strip().rstrip(";").strip()
    if not cleaned:
        raise ValueError("Enter a SQL query.")
    # Reject multiple statements. A trailing semicolon is accepted.
    if ";" in cleaned:
        raise ValueError("Run one SQL statement at a time.")
    first = re.match(r"^\s*([A-Za-z]+)", cleaned)
    command = first.group(1).lower() if first else ""
    allowed = {"select", "with", "show", "describe", "desc", "explain"}
    if command not in allowed:
        raise ValueError("Only read-only SELECT, WITH, SHOW, DESCRIBE, or EXPLAIN queries are allowed.")
    return cleaned


def run_postgres_query(
    host: str, port: int, database: str, user: str, password: str,
    query: str, sslmode: str = "prefer",
) -> pd.DataFrame:
    import psycopg2

    sql_text = validate_read_only_sql(query)
    connection = psycopg2.connect(
        host=host, port=int(port), dbname=database, user=user, password=password,
        sslmode=sslmode, connect_timeout=20,
    )
    try:
        connection.set_session(readonly=True, autocommit=False)
        return pd.read_sql_query(sql_text, connection)
    finally:
        connection.close()


def run_databricks_query(
    server_hostname: str, http_path: str, access_token: str, query: str,
    catalog: str | None = None, schema: str | None = None,
) -> pd.DataFrame:
    from databricks import sql as dbsql

    sql_text = validate_read_only_sql(query)
    kwargs: dict[str, Any] = {
        "server_hostname": server_hostname,
        "http_path": http_path,
        "access_token": access_token,
    }
    if catalog:
        kwargs["catalog"] = catalog
    if schema:
        kwargs["schema"] = schema
    connection = dbsql.connect(**kwargs)
    try:
        cursor = connection.cursor()
        try:
            cursor.execute(sql_text)
            rows = cursor.fetchall()
            columns = [item[0] for item in cursor.description] if cursor.description else []
            return pd.DataFrame(rows, columns=columns)
        finally:
            cursor.close()
    finally:
        connection.close()


def load_connection_profiles() -> dict[str, dict[str, dict[str, Any]]]:
    """Load saved database profiles from the project folder."""
    empty = {"PostgreSQL": {}, "Databricks": {}}
    if not CONNECTION_CONFIG_PATH.exists():
        return empty
    try:
        payload = json.loads(CONNECTION_CONFIG_PATH.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            return empty
        for db_type in empty:
            value = payload.get(db_type, {})
            empty[db_type] = value if isinstance(value, dict) else {}
        return empty
    except Exception:
        return empty


def save_connection_profiles(profiles: dict[str, dict[str, dict[str, Any]]]) -> None:
    """Persist profiles atomically in the project folder with owner-only permissions where supported."""
    CONNECTION_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix="connection_profiles_", suffix=".json", dir=str(CONNECTION_CONFIG_PATH.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(profiles, handle, indent=2, ensure_ascii=False)
        try:
            os.chmod(tmp_name, 0o600)
        except OSError:
            pass
        os.replace(tmp_name, CONNECTION_CONFIG_PATH)
        try:
            os.chmod(CONNECTION_CONFIG_PATH, 0o600)
        except OSError:
            pass
    finally:
        if os.path.exists(tmp_name):
            os.unlink(tmp_name)


def apply_connection_profile(dataset_number: int, db_type: str, profile: dict[str, Any]) -> None:
    """Populate source-specific Streamlit widget state from a saved profile."""
    if db_type == "PostgreSQL":
        mapping = {
            f"pg_host_{dataset_number}": profile.get("host", ""),
            f"pg_port_{dataset_number}": int(profile.get("port", 5432)),
            f"pg_database_{dataset_number}": profile.get("database", ""),
            f"pg_user_{dataset_number}": profile.get("user", ""),
            f"pg_password_{dataset_number}": profile.get("password", ""),
            f"pg_sslmode_{dataset_number}": profile.get("sslmode", "prefer"),
        }
    else:
        mapping = {
            f"dbx_host_{dataset_number}": profile.get("server_hostname", ""),
            f"dbx_http_path_{dataset_number}": profile.get("http_path", ""),
            f"dbx_token_{dataset_number}": profile.get("access_token", ""),
            f"dbx_catalog_{dataset_number}": profile.get("catalog", ""),
            f"dbx_schema_{dataset_number}": profile.get("schema", ""),
        }
    for key, value in mapping.items():
        st.session_state[key] = value


def render_connection_profile_manager(dataset_number: int, db_type: str) -> None:
    """Render load/save/delete controls for persistent project-level connection profiles."""
    profiles = load_connection_profiles()
    type_profiles = profiles.get(db_type, {})
    profile_names = sorted(type_profiles)
    db_slug = db_type.lower().replace(" ", "_")

    st.markdown("**Saved connection profiles**")
    selected = st.selectbox(
        "Saved profile", ["— Select —"] + profile_names,
        key=f"saved_profile_{dataset_number}_{db_slug}", label_visibility="collapsed",
    )

    # Keep profile actions below the selector in a responsive two-button row.
    # Container-width buttons shrink and grow with the sidebar without overlapping.
    with st.container(key=f"profile_actions_{dataset_number}_{db_slug}"):
        load_col, delete_col = st.columns([1, 1], gap="small")
        load_clicked = load_col.button(
            "Load", key=f"load_profile_{dataset_number}_{db_slug}", use_container_width=True
        )
        delete_clicked = delete_col.button(
            "Delete", key=f"delete_profile_{dataset_number}_{db_slug}", use_container_width=True
        )

    if load_clicked:
        if selected == "— Select —":
            st.warning("Select a saved profile first.")
        else:
            apply_connection_profile(dataset_number, db_type, type_profiles[selected])
            st.session_state[f"profile_name_{dataset_number}_{db_slug}"] = selected
            audit("CONNECTION_PROFILE_LOADED", {"dataset": dataset_number, "database_type": db_type, "profile": selected})
            st.rerun()
    if delete_clicked:
        if selected == "— Select —":
            st.warning("Select a saved profile first.")
        else:
            del profiles[db_type][selected]
            save_connection_profiles(profiles)
            audit("CONNECTION_PROFILE_DELETED", {"dataset": dataset_number, "database_type": db_type, "profile": selected})
            st.success(f"Deleted profile '{selected}'.")
            st.rerun()


def render_database_source(dataset_number: int, db_type: str) -> tuple[pd.DataFrame | None, dict[str, Any]]:
    """Render controls for one explicit database source and return its persisted query result."""
    db_slug = db_type.lower().replace(" ", "_")
    state_key = f"db_data_{dataset_number}_{db_slug}"
    meta_key = f"db_meta_{dataset_number}_{db_slug}"
    with st.expander(f"{db_type} connection details", expanded=True):
        render_connection_profile_manager(dataset_number, db_type)
        st.divider()
        if db_type == "PostgreSQL":
            c1, c2 = st.columns([3, 1])
            host = c1.text_input("Host", key=f"pg_host_{dataset_number}")
            port = c2.number_input("Port", 1, 65535, 5432, key=f"pg_port_{dataset_number}")
            database = st.text_input("Database", key=f"pg_database_{dataset_number}")
            user = st.text_input("User", key=f"pg_user_{dataset_number}")
            password = st.text_input("Password", type="password", key=f"pg_password_{dataset_number}")
            sslmode = st.selectbox(
                "SSL mode", ["prefer", "require", "verify-ca", "verify-full", "disable"],
                key=f"pg_sslmode_{dataset_number}",
            )
        else:
            server_hostname = st.text_input(
                "Server hostname", placeholder="dbc-xxxxxxxx.cloud.databricks.com",
                key=f"dbx_host_{dataset_number}",
            )
            http_path = st.text_input(
                "HTTP path", placeholder="/sql/1.0/warehouses/xxxxxxxx",
                key=f"dbx_http_path_{dataset_number}",
            )
            access_token = st.text_input("Access token", type="password", key=f"dbx_token_{dataset_number}")
            c1, c2 = st.columns(2)
            catalog = c1.text_input("Catalog (optional)", key=f"dbx_catalog_{dataset_number}")
            schema = c2.text_input("Schema (optional)", key=f"dbx_schema_{dataset_number}")

        st.markdown("**Save this connection**")
        profile_name = st.text_input(
            "Profile name", placeholder="e.g. Production warehouse",
            key=f"profile_name_{dataset_number}_{db_slug}", label_visibility="collapsed",
        )
        save_actions_key = f"save_actions_{dataset_number}_{db_slug}"
        save_actions_css = """
            <style>
            .st-key-__SAVE_ACTIONS_KEY__ div[data-testid="stButton"] button {
                width: 120px !important;
                min-width: 120px !important;
                max-width: 120px !important;
            }
            </style>
        """.replace("__SAVE_ACTIONS_KEY__", save_actions_key)
        st.markdown(save_actions_css, unsafe_allow_html=True)
        with st.container(key=save_actions_key):
            save_clicked = st.button(
                "Save config", key=f"save_profile_{dataset_number}_{db_slug}", use_container_width=False
            )
        if save_clicked:
            clean_profile_name = profile_name.strip()
            if not clean_profile_name:
                st.warning("Enter a profile name before saving.")
            else:
                profiles = load_connection_profiles()
                if db_type == "PostgreSQL":
                    profile_payload = {
                        "host": host, "port": int(port), "database": database, "user": user,
                        "password": password, "sslmode": sslmode,
                    }
                else:
                    profile_payload = {
                        "server_hostname": server_hostname, "http_path": http_path,
                        "access_token": access_token, "catalog": catalog, "schema": schema,
                    }
                profiles.setdefault(db_type, {})[clean_profile_name] = profile_payload
                save_connection_profiles(profiles)
                audit("CONNECTION_PROFILE_SAVED", {
                    "dataset": dataset_number, "database_type": db_type, "profile": clean_profile_name,
                    "config_file": CONNECTION_CONFIG_PATH.name,
                })
                st.success(f"Saved profile '{clean_profile_name}' to {CONNECTION_CONFIG_PATH.name}.")
                st.rerun()
        st.caption(
            f"Profiles are stored in `{CONNECTION_CONFIG_PATH.name}` inside the project folder. "
            "Passwords and access tokens are saved because the profile is intended for reuse; keep this file private and exclude it from source control."
        )

        query = st.text_area(
            "Custom SQL query", height=150, placeholder="SELECT * FROM schema.table LIMIT 1000",
            key=f"db_query_{dataset_number}_{db_slug}",
        )
        query_actions_key = f"query_actions_{dataset_number}_{db_slug}"
        # Responsive action row: both buttons share the available pane width.
        # A wider ratio is reserved for the longer clear label.
        with st.container(key=query_actions_key):
            run_col, clear_col = st.columns([1, 1.55], gap="small")
            run_query_clicked = run_col.button(
                "Run", type="primary", key=f"run_db_query_{dataset_number}_{db_slug}",
                use_container_width=True,
            )
            clear_query_clicked = clear_col.button(
                "Clear", key=f"clear_db_query_{dataset_number}_{db_slug}",
                use_container_width=True,
            )

        if run_query_clicked:
            try:
                with st.spinner("Running query..."):
                    if db_type == "PostgreSQL":
                        if not all([host, database, user, password]):
                            raise ValueError("Host, database, user, and password are required.")
                        result = run_postgres_query(host, int(port), database, user, password, query, sslmode)
                        safe_meta = {"database_type": db_type, "host": host, "database": database, "query": query}
                    else:
                        if not all([server_hostname, http_path, access_token]):
                            raise ValueError("Server hostname, HTTP path, and access token are required.")
                        result = run_databricks_query(server_hostname, http_path, access_token, query, catalog or None, schema or None)
                        safe_meta = {
                            "database_type": db_type, "server_hostname": server_hostname,
                            "http_path": http_path, "catalog": catalog, "schema": schema, "query": query,
                        }
                st.session_state[state_key] = result
                st.session_state[meta_key] = safe_meta
                audit("DATABASE_QUERY_EXECUTED", {
                    "dataset": dataset_number, "database_type": db_type,
                    "rows": len(result), "columns": len(result.columns),
                    "query_hash": hashlib.sha256(query.encode("utf-8")).hexdigest()[:16],
                })
                st.success(f"Query returned {len(result):,} rows and {len(result.columns):,} columns.")
                st.rerun()
            except Exception as exc:
                audit("DATABASE_QUERY_FAILED", {"dataset": dataset_number, "database_type": db_type, "error": str(exc)})
                st.error(f"Could not run query: {exc}")
        if clear_query_clicked:
            st.session_state[state_key] = None
            st.session_state[meta_key] = {}
            st.rerun()

    result = st.session_state.get(state_key)
    meta = st.session_state.get(meta_key, {})
    if result is not None:
        st.caption(f"Current query result: {len(result):,} rows × {len(result.columns):,} columns")
        preview_rows = st.number_input(
            "Preview rows", min_value=5, max_value=500, value=50, step=5,
            key=f"db_preview_rows_{dataset_number}_{db_slug}"
        )
        st.dataframe(result.head(int(preview_rows)), use_container_width=True, height=420 if st.session_state.get("wide_sidebar") else 260)
    return result, meta


def make_unique_columns(df: pd.DataFrame, source: str) -> pd.DataFrame:
    result = df.copy()
    counts: dict[str, int] = {}
    columns: list[str] = []
    for raw in result.columns:
        col = str(raw).strip() or "Unnamed"
        counts[col] = counts.get(col, 0) + 1
        unique = col if counts[col] == 1 else f"{col}_{counts[col]}"
        columns.append(f"{source}.{unique}")
    result.columns = columns
    return result


def normalize_key(series: pd.Series, trim: bool, lower: bool) -> pd.Series:
    result = series.astype("string")
    if trim:
        result = result.str.strip()
    if lower:
        result = result.str.lower()
    return result


def json_bytes(value: Any) -> bytes:
    return json.dumps(value, indent=2, ensure_ascii=False, default=str).encode("utf-8")


def to_excel_bytes(sheets: dict[str, pd.DataFrame]) -> bytes:
    output = BytesIO()
    with pd.ExcelWriter(output, engine="xlsxwriter") as writer:
        for sheet_name, df in sheets.items():
            safe_name = sheet_name[:31]
            df.to_excel(writer, index=False, sheet_name=safe_name)
            worksheet = writer.sheets[safe_name]
            for index, column in enumerate(df.columns):
                if df.empty:
                    sample_width = 0
                else:
                    lengths = df[column].head(500).map(
                        lambda value: len(str(value)) if pd.notna(value) else 0
                    )
                    max_width = lengths.max()
                    sample_width = int(max_width) if pd.notna(max_width) else 0
                header_width = len(str(column))
                worksheet.set_column(index, index, min(max(sample_width, header_width) + 2, 50))
    return output.getvalue()


def render_grid(df: pd.DataFrame, key: str, fit_columns: bool = False) -> pd.DataFrame:
    gb = GridOptionsBuilder.from_dataframe(df)
    gb.configure_default_column(
        sortable=True, filter=True, resizable=True, editable=False,
        enableRowGroup=True, enablePivot=True, enableValue=True,
        wrapHeaderText=True, autoHeaderHeight=True,
        headerClass="ag-left-aligned-header",
        cellStyle={"textAlign": "left", "justifyContent": "flex-start"},
    )
    gb.configure_pagination(enabled=True, paginationAutoPageSize=False, paginationPageSize=50)
    gb.configure_grid_options(
        sideBar=True,
        rowSelection="multiple",
        animateRows=True,
        domLayout="normal",
        suppressPaginationPanel=False,
    )
    grid_css = {
        ".ag-header": {"position": "sticky", "top": "0", "z-index": "10"},
        ".ag-header-cell-label": {"justify-content": "flex-start"},
        ".ag-cell": {"text-align": "left", "justify-content": "flex-start"},
    }
    response = AgGrid(
        df, gridOptions=gb.build(), height=480, fit_columns_on_grid_load=fit_columns,
        data_return_mode=DataReturnMode.FILTERED_AND_SORTED,
        update_mode=GridUpdateMode.NO_UPDATE, allow_unsafe_jscode=False,
        theme="streamlit", key=key, custom_css=grid_css,
    )
    return pd.DataFrame(response.get("data", df))


def safe_numeric_series(series: pd.Series) -> pd.Series:
    """Convert values to float-compatible numbers while treating pd.NA safely."""
    cleaned = series.astype("string").str.replace(",", "", regex=False).str.strip()
    cleaned = cleaned.mask(cleaned.isin(["", "<NA>", "NA", "N/A", "None", "null", "NULL"]))
    return pd.to_numeric(cleaned, errors="coerce").astype("float64")



def safe_datetime_series(
    series: pd.Series, *, utc: bool = False, dayfirst: bool = False
) -> pd.Series:
    """Parse datetimes without pandas format-inference warnings."""
    if pd.api.types.is_datetime64_any_dtype(series):
        return pd.to_datetime(series, errors="coerce", utc=utc)
    if pd.api.types.is_numeric_dtype(series):
        return pd.to_datetime(series, errors="coerce", utc=utc)
    return pd.to_datetime(
        series.astype("string"),
        errors="coerce",
        format="mixed",
        dayfirst=dayfirst,
        utc=utc,
    )

def safe_python_scalar(value: Any) -> Any:
    """Convert pandas/numpy scalar values to UI/JSON-safe Python values."""
    if value is pd.NA or value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(value, np.generic):
        return value.item()
    return value


def condition_mask(df: pd.DataFrame, rule: dict[str, Any]) -> pd.Series:
    column = rule["column"]
    operator = rule["operator"]
    value = str(rule.get("value", ""))
    value2 = str(rule.get("value2", ""))
    case_sensitive = bool(rule.get("case_sensitive", False))
    series = df[column]
    text = series.astype("string")
    left = text if case_sensitive else text.str.lower()
    right = value if case_sensitive else value.lower()

    if operator == "equals": return left == right
    if operator == "not equals": return left != right
    if operator == "contains": return left.str.contains(right, na=False, regex=False)
    if operator == "does not contain": return ~left.str.contains(right, na=False, regex=False)
    if operator == "starts with": return left.str.startswith(right, na=False)
    if operator == "ends with": return left.str.endswith(right, na=False)
    if operator == "is blank": return series.isna() | text.str.strip().eq("")
    if operator == "is not blank": return series.notna() & ~text.str.strip().eq("")
    if operator in {"in list", "not in list"}:
        values = [item.strip() for item in value.split(",") if item.strip()]
        if not case_sensitive:
            values = [item.lower() for item in values]
        mask = left.isin(values)
        return ~mask if operator == "not in list" else mask

    numeric = safe_numeric_series(series)
    try:
        number = float(value)
    except ValueError as exc:
        raise ValueError(f"'{value}' is not numeric for {column}") from exc
    if operator == "greater than": return numeric > number
    if operator == "greater than or equal": return numeric >= number
    if operator == "less than": return numeric < number
    if operator == "less than or equal": return numeric <= number
    if operator == "between":
        try:
            number2 = float(value2)
        except ValueError as exc:
            raise ValueError(f"'{value2}' is not numeric for the upper bound") from exc
        return numeric.between(min(number, number2), max(number, number2), inclusive="both")
    raise ValueError(f"Unsupported operator: {operator}")


def apply_filter_rules(df: pd.DataFrame, rules: list[dict[str, Any]]) -> pd.DataFrame:
    if not rules:
        return df.copy()
    combined: pd.Series | None = None
    for index, rule in enumerate(rules):
        mask = condition_mask(df, rule).fillna(False)
        if index == 0:
            combined = mask
        elif rule.get("connector", "AND") == "OR":
            combined = combined | mask  # type: ignore[operator]
        else:
            combined = combined & mask  # type: ignore[operator]
    return df[combined].copy() if combined is not None else df.copy()


def filter_summary(rule: dict[str, Any], index: int) -> str:
    prefix = "WHERE" if index == 0 else rule.get("connector", "AND")
    operator = rule["operator"]
    if operator in {"is blank", "is not blank"}:
        return f"{prefix} {rule['column']} {operator}"
    if operator == "between":
        return f"{prefix} {rule['column']} between {rule.get('value', '')} and {rule.get('value2', '')}"
    return f"{prefix} {rule['column']} {operator} {rule.get('value', '')}"


def build_dump(output_df: pd.DataFrame, filters: list[dict[str, Any]], metadata: dict[str, Any]) -> bytes:
    memory = BytesIO()
    audit_df = pd.DataFrame(st.session_state.audit_log)
    with zipfile.ZipFile(memory, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("output.xlsx", to_excel_bytes({"Analysis_Output": output_df, "Audit_Log": audit_df}))
        archive.writestr("output.csv", output_df.to_csv(index=False).encode("utf-8"))
        archive.writestr("filters.json", json_bytes({"version": 1, "filters": filters}))
        archive.writestr("audit_log.json", json_bytes(st.session_state.audit_log))
        archive.writestr("audit_log.csv", audit_df.to_csv(index=False).encode("utf-8"))
        archive.writestr("session_metadata.json", json_bytes(metadata))
    return memory.getvalue()



def infer_semantic_type(series: pd.Series) -> str:
    non_null = series.dropna()
    if non_null.empty:
        return "empty"
    if pd.api.types.is_bool_dtype(series):
        return "boolean"
    if pd.api.types.is_numeric_dtype(series):
        return "numerical"
    if pd.api.types.is_datetime64_any_dtype(series):
        return "datetime"
    text = non_null.astype(str).str.strip()
    numeric_ratio = pd.to_numeric(text.str.replace(",", "", regex=False), errors="coerce").notna().mean()
    date_ratio = safe_datetime_series(text, dayfirst=False).notna().mean()
    if numeric_ratio >= 0.9:
        return "numeric-like text"
    if date_ratio >= 0.9:
        return "date-like text"
    unique_ratio = text.nunique(dropna=True) / max(len(text), 1)
    return "identifier/text" if unique_ratio > 0.8 else "categorical"


def outlier_mask_iqr(series: pd.Series) -> pd.Series:
    numeric = safe_numeric_series(series)
    valid = numeric.dropna()
    if len(valid) < 4:
        return pd.Series(False, index=series.index)
    q1, q3 = valid.quantile([0.25, 0.75])
    iqr = q3 - q1
    if pd.isna(iqr) or iqr == 0:
        return pd.Series(False, index=series.index)
    return (numeric < q1 - 1.5 * iqr) | (numeric > q3 + 1.5 * iqr)


def detailed_profile(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    total = len(df)
    for column in df.columns:
        series = df[column]
        non_null = series.dropna()
        semantic = infer_semantic_type(series)
        blank_count = int(series.astype("string").str.strip().eq("").fillna(False).sum())
        outliers = int(outlier_mask_iqr(series).sum()) if semantic in {"numerical", "numeric-like text"} else 0
        invalid = 0
        consistency = 100.0
        if semantic == "numeric-like text":
            converted = safe_numeric_series(non_null)
            invalid = int(converted.isna().sum())
            consistency = round((1 - invalid / max(len(non_null), 1)) * 100, 2)
        elif semantic == "date-like text":
            converted = safe_datetime_series(non_null)
            invalid = int(converted.isna().sum())
            consistency = round((1 - invalid / max(len(non_null), 1)) * 100, 2)
        top_values = non_null.astype(str).value_counts().head(5)
        top_text = "; ".join(f"{k} ({v})" for k, v in top_values.items())
        rows.append({
            "column": column, "physical_type": str(series.dtype), "semantic_type": semantic,
            "rows": total, "non_null": int(series.notna().sum()), "missing": int(series.isna().sum()),
            "missing_pct": round(float(series.isna().mean() * 100), 2) if total else 0.0,
            "blank_strings": blank_count, "unique_values": int(series.nunique(dropna=True)),
            "duplicate_values": int(non_null.duplicated(keep=False).sum()),
            "outliers_iqr": outliers, "invalid_values": invalid,
            "type_consistency_pct": consistency, "top_values": top_text,
        })
    return pd.DataFrame(rows)


def quality_summary(df: pd.DataFrame) -> dict[str, int | float]:
    profile = detailed_profile(df)
    return {
        "rows": len(df), "columns": len(df.columns),
        "duplicate_rows": int(df.duplicated().sum()),
        "missing_cells": int(df.isna().sum().sum()),
        "outliers": int(profile["outliers_iqr"].sum()) if not profile.empty else 0,
        "invalid_values": int(profile["invalid_values"].sum()) if not profile.empty else 0,
    }


def detect_datetime_candidates(df: pd.DataFrame) -> list[str]:
    candidates = []
    for column in df.columns:
        series = df[column]
        if pd.api.types.is_datetime64_any_dtype(series):
            candidates.append(column)
            continue
        non_null = series.dropna().head(1000)
        if non_null.empty or pd.api.types.is_numeric_dtype(series):
            continue
        parsed = safe_datetime_series(non_null)
        if parsed.notna().mean() >= 0.8:
            candidates.append(column)
    return candidates


def basic_profile(df: pd.DataFrame) -> pd.DataFrame:
    return pd.DataFrame({
        "column": df.columns,
        "data_type": [str(df[c].dtype) for c in df.columns],
        "non_null": [int(df[c].notna().sum()) for c in df.columns],
        "nulls": [int(df[c].isna().sum()) for c in df.columns],
        "null_pct": [round(float(df[c].isna().mean() * 100), 2) for c in df.columns],
        "distinct": [int(df[c].nunique(dropna=True)) for c in df.columns],
    })


def classify_columns(df: pd.DataFrame) -> dict[str, list[str]]:
    result = {"numeric": [], "categorical": [], "datetime": [], "boolean": [], "empty": []}
    for column in df.columns:
        semantic = infer_semantic_type(df[column])
        if semantic in {"numerical", "numeric-like text"}:
            result["numeric"].append(column)
        elif semantic in {"datetime", "date-like text"}:
            result["datetime"].append(column)
        elif semantic == "boolean":
            result["boolean"].append(column)
        elif semantic == "empty":
            result["empty"].append(column)
        else:
            result["categorical"].append(column)
    return result


def all_column_descriptive_summary(df: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for column in df.columns:
        series = df[column]
        semantic = infer_semantic_type(series)
        non_null = series.dropna()
        row: dict[str, Any] = {
            "column": column,
            "semantic_type": semantic,
            "rows": len(series),
            "non_null": int(series.notna().sum()),
            "missing": int(series.isna().sum()),
            "unique": int(series.nunique(dropna=True)),
            "most_frequent": None,
            "frequency": 0,
            "min": None,
            "max": None,
            "mean": None,
            "median": None,
        }
        if not non_null.empty:
            counts = non_null.astype(str).value_counts()
            row["most_frequent"] = counts.index[0] if not counts.empty else None
            row["frequency"] = int(counts.iloc[0]) if not counts.empty else 0
        if semantic in {"numerical", "numeric-like text"}:
            numeric = safe_numeric_series(non_null)
            row.update({
                "min": safe_python_scalar(numeric.min()), "max": safe_python_scalar(numeric.max()),
                "mean": safe_python_scalar(numeric.mean()), "median": safe_python_scalar(numeric.median()),
            })
        elif semantic in {"datetime", "date-like text"}:
            dates = safe_datetime_series(non_null)
            row["min"], row["max"] = safe_python_scalar(dates.min()), safe_python_scalar(dates.max())
        rows.append(row)
    return pd.DataFrame(rows)


def encoded_association(df: pd.DataFrame, columns: list[str], method: str = "spearman") -> pd.DataFrame:
    """Create a stable numeric association matrix for mixed data types.

    Unsupported, constant, or insufficient pairs are displayed as 0.00 instead of
    NaN so the Explore page always shows numeric values. Valid diagonals are 1.00.
    """
    encoded = pd.DataFrame(index=df.index)
    for column in columns:
        series = df[column]
        semantic = infer_semantic_type(series)
        if semantic in {"numerical", "numeric-like text"}:
            values = safe_numeric_series(series)
        elif semantic in {"datetime", "date-like text"}:
            dates = safe_datetime_series(series, utc=True)
            values = pd.Series(np.nan, index=df.index, dtype="float64")
            valid = dates.notna()
            if valid.any():
                values.loc[valid] = dates.loc[valid].astype("int64") / 1_000_000_000
        else:
            text = series.astype("string")
            valid = text.notna() & ~text.isin(["", "<NA>"])
            values = pd.Series(np.nan, index=df.index, dtype="float64")
            if valid.any():
                codes, _ = pd.factorize(text.loc[valid], sort=True)
                values.loc[valid] = codes.astype("float64")
        encoded[str(column)] = pd.to_numeric(values, errors="coerce").replace([np.inf, -np.inf], np.nan)

    matrix = encoded.corr(method=method, min_periods=2)
    matrix = matrix.reindex(index=columns, columns=columns).astype("float64")
    matrix = matrix.replace([np.inf, -np.inf], np.nan).fillna(0.0)
    for column in columns:
        valid = encoded[str(column)].dropna()
        matrix.loc[column, column] = 1.0 if valid.nunique() > 1 else 0.0
    return matrix.clip(-1.0, 1.0)


def association_pairs_by_strength(
    matrices: dict[str, pd.DataFrame],
    medium_threshold: float = 0.40,
    high_threshold: float = 0.70,
) -> list[dict[str, Any]]:
    """Return unique medium/high association pairs, retaining the strongest algorithm result."""
    strongest: dict[tuple[str, str], dict[str, Any]] = {}
    for algorithm, matrix in matrices.items():
        columns = list(matrix.columns)
        for index, left in enumerate(columns):
            for right in columns[index + 1:]:
                value = matrix.loc[left, right]
                if pd.isna(value) or abs(float(value)) < medium_threshold:
                    continue
                key = tuple(sorted((str(left), str(right))))
                candidate = {
                    "left": str(left),
                    "right": str(right),
                    "association": float(value),
                    "algorithm": algorithm,
                    "strength": "High" if abs(float(value)) >= high_threshold else "Medium",
                }
                if key not in strongest or abs(candidate["association"]) > abs(strongest[key]["association"]):
                    strongest[key] = candidate
    return sorted(strongest.values(), key=lambda item: abs(item["association"]), reverse=True)


def grouped_deep_dive_aggregations(
    df: pd.DataFrame, categorical_column: str, numeric_column: str
) -> pd.DataFrame:
    """Aggregate a numeric feature by every category using the requested five measures."""
    work = pd.DataFrame({
        categorical_column: df[categorical_column].astype("string").fillna("<Missing>"),
        "__numeric__": safe_numeric_series(df[numeric_column]),
    })

    def first_mode(series: pd.Series):
        modes = series.dropna().mode()
        return safe_python_scalar(modes.iloc[0]) if not modes.empty else None

    result = (
        work.groupby(categorical_column, dropna=False)["__numeric__"]
        .agg(
            sum="sum",
            count="count",
            mean="mean",
            median="median",
            mode=first_mode,
        )
        .reset_index()
    )
    return result


def deep_dive_crosstab(
    df: pd.DataFrame, left: str, right: str, max_levels: int = 50
) -> tuple[pd.DataFrame, str | None]:
    """Build a readable cross-tab, binning numeric fields and limiting very wide cardinality."""
    prepared: dict[str, pd.Series] = {}
    notes: list[str] = []
    for column in (left, right):
        semantic = infer_semantic_type(df[column])
        if semantic in {"numerical", "numeric-like text"}:
            numeric = safe_numeric_series(df[column])
            unique_count = int(numeric.nunique(dropna=True))
            if unique_count > max_levels:
                try:
                    prepared[column] = pd.qcut(
                        numeric, q=min(10, unique_count), duplicates="drop"
                    ).astype("string").fillna("<Missing>")
                    notes.append(f"{column} was grouped into quantile bands for readability")
                except (ValueError, TypeError):
                    prepared[column] = numeric.astype("string").fillna("<Missing>")
            else:
                prepared[column] = numeric.astype("string").fillna("<Missing>")
        else:
            values = df[column].astype("string").fillna("<Missing>")
            top_values = values.value_counts(dropna=False).head(max_levels).index
            if values.nunique(dropna=False) > max_levels:
                prepared[column] = values.where(values.isin(top_values), "<Other>")
                notes.append(f"{column} was limited to its top {max_levels} values; remaining values are shown as <Other>")
            else:
                prepared[column] = values
    table = pd.crosstab(prepared[left], prepared[right], dropna=False)
    return table, "; ".join(notes) if notes else None


def deep_dive_prepared_series(
    df: pd.DataFrame, column: str, max_levels: int = 50
) -> tuple[pd.Series, str | None]:
    """Prepare one feature exactly as it is displayed in a Deep Dive cross-tab."""
    semantic = infer_semantic_type(df[column])
    note = None
    if semantic in {"numerical", "numeric-like text"}:
        numeric = safe_numeric_series(df[column])
        unique_count = int(numeric.nunique(dropna=True))
        if unique_count > max_levels:
            try:
                prepared = pd.qcut(
                    numeric, q=min(10, unique_count), duplicates="drop"
                ).astype("string").fillna("<Missing>")
                note = f"{column} was grouped into quantile bands for readability"
                return prepared, note
            except (ValueError, TypeError):
                pass
        return numeric.astype("string").fillna("<Missing>"), note

    values = df[column].astype("string").fillna("<Missing>")
    top_values = values.value_counts(dropna=False).head(max_levels).index
    if values.nunique(dropna=False) > max_levels:
        note = f"{column} was limited to its top {max_levels} values; remaining values are shown as <Other>"
        return values.where(values.isin(top_values), "<Other>"), note
    return values, note



def selectable_heatmap_figure(
    matrix: pd.DataFrame, title: str, x_title: str, y_title: str, color_title: str
) -> go.Figure:
    """Render a heatmap-like grid using selectable scatter points.

    Streamlit does not consistently emit point-selection events for Plotly Heatmap
    traces. Square scatter markers preserve the heatmap appearance while making
    every cell a real selectable point.
    """
    x_labels = [str(v) for v in matrix.columns]
    y_labels = [str(v) for v in matrix.index]
    x_values: list[str] = []
    y_values: list[str] = []
    z_values: list[float] = []
    cell_text: list[str] = []
    custom_data: list[list[str]] = []
    for row_label, row in matrix.iterrows():
        for column_label, value in row.items():
            numeric_value = float(value) if pd.notna(value) else 0.0
            x_values.append(str(column_label))
            y_values.append(str(row_label))
            z_values.append(numeric_value)
            cell_text.append(f"{numeric_value:.2f}" if isinstance(value, (float, np.floating)) else f"{int(numeric_value):,}")
            custom_data.append([str(row_label), str(column_label)])

    cell_count = max(len(x_labels), len(y_labels), 1)
    marker_size = max(18, min(58, int(620 / cell_count)))
    figure = go.Figure(
        go.Scatter(
            x=x_values,
            y=y_values,
            mode="markers+text",
            text=cell_text,
            textposition="middle center",
            customdata=custom_data,
            hovertemplate=(
                f"{y_title}: %{{customdata[0]}}<br>"
                f"{x_title}: %{{customdata[1]}}<br>"
                f"{color_title}: %{{marker.color}}<extra></extra>"
            ),
            marker={
                "symbol": "square",
                "size": marker_size,
                "color": z_values,
                "colorscale": "RdBu" if any(v < 0 for v in z_values) else "Blues",
                "cmid": 0 if any(v < 0 for v in z_values) else None,
                "showscale": True,
                "colorbar": {"title": color_title},
                "line": {"width": 1, "color": "rgba(255,255,255,0.55)"},
            },
            selected={"marker": {"opacity": 1}},
            unselected={"marker": {"opacity": 0.88}},
        )
    )
    figure.update_layout(
        title=title,
        xaxis={"title": x_title, "type": "category", "categoryorder": "array", "categoryarray": x_labels},
        yaxis={"title": y_title, "type": "category", "categoryorder": "array", "categoryarray": list(reversed(y_labels))},
        dragmode="select",
        clickmode="event+select",
        margin={"l": 80, "r": 40, "t": 70, "b": 80},
        height=max(420, min(850, 130 + len(y_labels) * marker_size)),
    )
    return figure



def clickable_heatmap_table(
    matrix: pd.DataFrame,
    key_prefix: str,
    value_format: str = ".2f",
    disable_diagonal: bool = False,
) -> tuple[str | None, str | None]:
    """Render a scrollable AG Grid heatmap and return a newly clicked value cell.

    Cell clicks are captured through hidden data fields rather than row selection.
    This keeps the heatmap visible while the dialog opens and prevents retained
    selection state from retriggering the previous popup on unrelated reruns.
    """
    if matrix.empty:
        return None, None

    numeric_matrix = matrix.apply(pd.to_numeric, errors="coerce").fillna(0.0)
    is_count = value_format == "count"
    max_value = float(np.nanmax(np.abs(numeric_matrix.to_numpy(dtype=float)))) if numeric_matrix.size else 0.0

    display = numeric_matrix.copy()
    display.insert(0, "Feature", [str(value) for value in numeric_matrix.index])
    display["__row_label"] = [str(value) for value in numeric_matrix.index]
    display["__clicked_col"] = ""
    display["__click_nonce"] = ""

    gb = GridOptionsBuilder.from_dataframe(display)
    gb.configure_default_column(
        sortable=False, filter=False, resizable=False, editable=False,
        suppressMovable=True, suppressSizeToFit=True, flex=0,
        wrapHeaderText=True, autoHeaderHeight=True,
        headerClass="ag-left-aligned-header",
        cellStyle={"textAlign": "left", "justifyContent": "flex-start", "fontWeight": "700", "padding": "0 2px"},
    )
    gb.configure_column(
        "Feature", pinned="left", lockPinned=True, suppressSizeToFit=True,
        width=150, minWidth=150, maxWidth=150,
        cellStyle={"backgroundColor": "#f5f7fb", "color": "#25324a", "fontWeight": "700", "textAlign": "left"},
    )
    gb.configure_column("__row_label", hide=True)
    gb.configure_column("__clicked_col", hide=True)
    gb.configure_column("__click_nonce", hide=True)

    for column in numeric_matrix.columns:
        column_text = str(column)
        style_js = JsCode(f"""
        function(params) {{
            const value = Number(params.value || 0);
            const maxValue = {max_value!r};
            const isCount = {str(is_count).lower()};
            const disabled = {str(disable_diagonal).lower()} && String(params.data.__row_label) === {json.dumps(column_text)};
            let strength = isCount ? (maxValue <= 0 ? 0 : Math.min(Math.abs(value) / maxValue, 1)) : Math.min(Math.abs(value), 1);
            let lightness = 97 - (58 * strength);
            let hue = isCount ? 211 : (value >= 0 ? 211 : 8);
            return {{
                backgroundColor: `hsl(${{hue}}, 78%, ${{lightness}}%)`,
                color: strength >= 0.58 ? '#ffffff' : '#162033',
                fontWeight: '700', textAlign: 'left', justifyContent: 'flex-start',
                cursor: disabled ? 'not-allowed' : 'pointer',
                opacity: disabled ? 0.72 : 1, padding: '0 2px'
            }};
        }}
        """)
        formatter_js = JsCode("""
        function(params) {
            const value = Number(params.value || 0);
            return %s ? Math.round(value).toLocaleString() : value.toFixed(2);
        }
        """ % str(is_count).lower())
        gb.configure_column(
            column, width=120, minWidth=120, maxWidth=120, flex=0,
            suppressSizeToFit=True, cellStyle=style_js, valueFormatter=formatter_js,
        )

    click_js = JsCode(f"""
    function(params) {{
        if (!params.colDef || !params.colDef.field || params.colDef.field === 'Feature') return;
        if (params.colDef.field.startsWith('__')) return;
        const disabled = {str(disable_diagonal).lower()} && String(params.data.__row_label) === String(params.colDef.field);
        if (disabled) return;
        params.node.setDataValue('__clicked_col', String(params.colDef.field));
        params.node.setDataValue('__click_nonce', String(Date.now()) + '-' + String(Math.random()));
    }}
    """)
    visible_rows = min(len(display), 16)
    # Include room for AG Grid's horizontal scrollbar. The Feature column stays
    # pinned; only the centre value-column viewport scrolls horizontally.
    grid_height = 42 + (visible_rows * 34) + 24
    needs_vertical_scroll = len(display) > visible_rows

    gb.configure_grid_options(
        onCellClicked=click_js, domLayout="normal",
        suppressHorizontalScroll=False, alwaysShowHorizontalScroll=True,
        alwaysShowVerticalScroll=needs_vertical_scroll, ensureDomOrder=True,
        suppressScrollOnNewData=True, suppressColumnVirtualisation=True,
        headerHeight=42, rowHeight=34,
    )

    response = AgGrid(
        display, gridOptions=gb.build(), height=grid_height, fit_columns_on_grid_load=False,
        data_return_mode=DataReturnMode.FILTERED_AND_SORTED,
        update_mode=GridUpdateMode.VALUE_CHANGED,
        allow_unsafe_jscode=True, theme="streamlit", key=key_prefix,
        custom_css={
            # Do not override AG Grid viewport widths/overflow here. Native AG Grid
            # scrolling is driven by fixed, non-flex value columns above. Overriding
            # centre viewport/container sizing can suppress the scrollbar in some
            # streamlit-aggrid / AG Grid versions.
            ".ag-root-wrapper": {"border-radius": "10px", "max-width": "100% !important"},
            ".ag-body-horizontal-scroll": {"display": "flex !important", "visibility": "visible !important", "min-height": "18px !important", "height": "18px !important"},
            ".ag-body-horizontal-scroll-viewport": {"overflow-x": "scroll !important", "min-height": "18px !important"},
            ".ag-header-cell-label": {"justify-content": "flex-start", "font-size": "11px", "line-height": "1.1"},
            ".ag-cell": {"font-size": "11px", "line-height": "34px", "text-align": "left", "justify-content": "flex-start"},
        },
    )

    returned = response.get("data")
    if returned is None:
        return None, None
    returned_df = returned if isinstance(returned, pd.DataFrame) else pd.DataFrame(returned)
    if returned_df.empty or "__click_nonce" not in returned_df.columns:
        return None, None
    clicked = returned_df[returned_df["__click_nonce"].astype("string").fillna("").str.len() > 0]
    if clicked.empty:
        return None, None
    selected = clicked.iloc[-1].to_dict()
    row_label = selected.get("__row_label")
    column_label = selected.get("__clicked_col")
    click_nonce = selected.get("__click_nonce")
    if not row_label or not column_label or not click_nonce:
        return None, None

    signature = f"{row_label}|{column_label}|{click_nonce}"
    state_key = f"__processed_heatmap_click_{key_prefix}"
    if st.session_state.get(state_key) == signature:
        return None, None
    st.session_state[state_key] = signature
    return str(row_label), str(column_label)


def selected_cell_labels(point: dict[str, Any]) -> tuple[str | None, str | None]:
    """Read row/column labels from a selectable heatmap scatter point."""
    custom = point.get("customdata")
    if isinstance(custom, (list, tuple)) and len(custom) >= 2:
        return str(custom[0]), str(custom[1])
    x_value = point.get("x")
    y_value = point.get("y")
    return (str(y_value), str(x_value)) if x_value is not None and y_value is not None else (None, None)

def selected_plotly_point(event: Any) -> dict[str, Any] | None:
    """Return the first selected Plotly point across Streamlit state formats."""
    if event is None:
        return None
    try:
        selection = event.selection
        points = selection.points
    except Exception:
        try:
            points = event.get("selection", {}).get("points", [])
        except Exception:
            points = []
    return points[0] if points else None


def heatmap_point_labels(
    point: dict[str, Any], row_labels: list[Any], column_labels: list[Any]
) -> tuple[str | None, str | None]:
    """Resolve heatmap cell labels across Plotly/Streamlit event payload formats."""
    x_value = point.get("x")
    y_value = point.get("y")
    if x_value is not None and y_value is not None:
        return str(y_value), str(x_value)

    point_number = point.get("point_number", point.get("pointNumber"))
    if isinstance(point_number, (list, tuple)) and len(point_number) >= 2:
        row_index, column_index = int(point_number[0]), int(point_number[1])
        if 0 <= row_index < len(row_labels) and 0 <= column_index < len(column_labels):
            return str(row_labels[row_index]), str(column_labels[column_index])
    return None, None


def register_deep_dive_popup(
    filtered: pd.DataFrame, title: str, filter_text: str, audit_details: dict[str, Any],
    filter_spec: dict[str, Any] | None = None,
) -> None:
    """Apply a Deep Dive cell filter and stage its records for an in-page dialog."""
    # Keep the user on Explore. The selected records are staged only for the
    # in-place dialog; no Preview navigation or Preview-source state is changed.
    st.session_state.nav_page = "Explore"
    # Do not overwrite filtered_data here. Explore uses filtered_data as its
    # analysis source, so changing it during a cell click causes the heatmap to
    # be rebuilt from the selected subset and makes the clicked visual vanish.
    st.session_state.deep_dive_popup = {
        "title": title,
        "filter_text": filter_text,
        "records": filtered.copy(),
        "filter_spec": filter_spec or {},
    }
    st.session_state.deep_dive_popup_event_id = int(
        st.session_state.get("deep_dive_popup_event_id", 0)
    ) + 1
    audit("EDA_DEEP_DIVE_DRILLTHROUGH", {**audit_details, "output_rows": len(filtered)})


@st.dialog("Deep Dive records", width="large")
def show_deep_dive_popup() -> None:
    """Display records matching the selected heatmap-table cell in place."""
    popup = st.session_state.get("deep_dive_popup")
    if not popup:
        st.info("Select a Deep Dive heatmap cell to view its records.")
        return
    records = popup["records"]
    st.markdown(f"### {popup['title']}")
    st.caption(popup["filter_text"])
    st.metric("Matching records", f"{len(records):,}")
    if records.empty:
        st.warning("No records match the selected cell.")
    else:
        st.dataframe(records, use_container_width=True, hide_index=True, height=430)

    st.markdown("#### Save this filter")
    save_name = st.text_input(
        "Filter name",
        value=popup["title"][:80],
        key="deep_dive_filter_save_name",
        help="Saved filters remain available during this analysis session and can be reused from the Filter page.",
    )
    save_col, download_col = st.columns(2)
    if save_col.button("Save filter", type="primary", use_container_width=True, key="deep_dive_popup_save_filter"):
        clean_name = save_name.strip()
        if not clean_name:
            st.warning("Enter a filter name before saving.")
        else:
            st.session_state.saved_deep_dive_filters[clean_name] = {
                "name": clean_name,
                "title": popup["title"],
                "filter_text": popup["filter_text"],
                "filter_spec": popup.get("filter_spec", {}),
                "saved_at": utc_now(),
            }
            audit("EDA_DEEP_DIVE_FILTER_SAVED", {"name": clean_name, "filter_spec": popup.get("filter_spec", {})})
            st.success(f"Saved filter: {clean_name}")

    payload = {
        "version": 1,
        "name": save_name.strip() or popup["title"],
        "filter_text": popup["filter_text"],
        "filter_spec": popup.get("filter_spec", {}),
    }
    download_col.download_button(
        "Download filter JSON",
        json_bytes(payload),
        file_name=f"{re.sub(r'[^A-Za-z0-9_-]+', '_', payload['name']).strip('_') or 'deep_dive_filter'}.json",
        mime="application/json",
        use_container_width=True,
        key="deep_dive_popup_download_filter",
    )
    use_col, _ = st.columns([1, 1])
    if use_col.button(
        "Use records as filtered output",
        use_container_width=True,
        key="deep_dive_popup_use_filtered_output",
    ):
        st.session_state.filtered_data = records.copy()
        audit("EDA_DEEP_DIVE_OUTPUT_APPLIED", {"rows": len(records), "filter_spec": popup.get("filter_spec", {})})
        st.success("Selected records are now available as Filtered output. The Explore heatmap remains unchanged until you leave or refresh the analysis source.")

    st.caption("Cell selection only opens this popup. It does not replace the Explore analysis dataset or change the active page.")

def apply_saved_deep_dive_filter(df: pd.DataFrame, spec: dict[str, Any]) -> pd.DataFrame:
    """Reapply a saved Deep Dive filter definition to the current dataset."""
    filter_type = spec.get("type")
    if filter_type == "non_missing_pair":
        left, right = spec.get("left"), spec.get("right")
        if left in df.columns and right in df.columns:
            return df[df[left].notna() & df[right].notna()].copy()
    if filter_type == "prepared_pair":
        left, right = spec.get("left"), spec.get("right")
        if left in df.columns and right in df.columns:
            prepared_left, _ = deep_dive_prepared_series(df, left)
            prepared_right, _ = deep_dive_prepared_series(df, right)
            mask = (
                prepared_left.astype("string") == str(spec.get("left_value"))
            ) & (
                prepared_right.astype("string") == str(spec.get("right_value"))
            )
            return df[mask].copy()
    return df.iloc[0:0].copy()

def build_chart_data(
    df: pd.DataFrame, x_col: str, y_col: str | None, aggregation: str,
    chart_type: str, top_n: int,
) -> tuple[pd.DataFrame, str | None]:
    work = df.copy()
    if chart_type in {"Histogram", "Box", "Scatter"}:
        return work, y_col
    if aggregation == "Row count":
        result = work.groupby(x_col, dropna=False).size().rename("__value__").reset_index()
        return result.nlargest(top_n, "__value__"), "__value__"
    if y_col is None:
        return work, None
    if aggregation == "Distinct count":
        result = work.groupby(x_col, dropna=False)[y_col].nunique(dropna=True).rename("__value__").reset_index()
        return result.nlargest(top_n, "__value__"), "__value__"
    numeric = safe_numeric_series(work[y_col])
    work = work.assign(__numeric_value__=numeric)
    agg_map = {"Sum": "sum", "Average": "mean", "Median": "median", "Minimum": "min", "Maximum": "max"}
    result = work.groupby(x_col, dropna=False)["__numeric_value__"].agg(agg_map[aggregation]).rename("__value__").reset_index()
    return result.nlargest(top_n, "__value__"), "__value__"


def correlation_summary_text(matrix: pd.DataFrame) -> str:
    """Create a concise strength summary from a symmetric correlation/association matrix."""
    pairs: list[tuple[str, str, float]] = []
    cols = list(matrix.columns)
    for i, left in enumerate(cols):
        for right in cols[i + 1:]:
            value = matrix.loc[left, right]
            if pd.notna(value):
                pairs.append((str(left), str(right), float(value)))

    bands = {"High": [], "Medium": [], "Low": []}
    for left, right, value in sorted(pairs, key=lambda x: abs(x[2]), reverse=True):
        strength = abs(value)
        item = f"{left} ↔ {right} ({value:+.2f})"
        if strength >= 0.70:
            bands["High"].append(item)
        elif strength >= 0.40:
            bands["Medium"].append(item)
        elif strength >= 0.10:
            bands["Low"].append(item)

    lines = []
    for label in ("High", "Medium", "Low"):
        values = bands[label]
        if values:
            shown = "; ".join(values[:8])
            remainder = len(values) - 8
            suffix = f"; and {remainder} more" if remainder > 0 else ""
            lines.append(f"**{label} correlation:** {shown}{suffix}.")
        else:
            lines.append(f"**{label} correlation:** No feature pairs detected in this range.")
    lines.append("Positive values move in the same direction; negative values move in opposite directions. Association does not imply causation.")
    return "\n\n".join(lines)


def apply_default_data_labels(fig):
    """Apply readable value labels to Plotly charts by default."""
    try:
        for trace in fig.data:
            trace_type = getattr(trace, "type", "")
            if trace_type == "bar":
                orientation = getattr(trace, "orientation", None)
                template = "%{x:,.2f}" if orientation == "h" else "%{y:,.2f}"
                trace.update(texttemplate=template, textposition="auto", cliponaxis=False)
            elif trace_type == "pie":
                trace.update(textinfo="label+percent+value", textposition="auto")
            elif trace_type in {"scatter", "scattergl"}:
                mode = getattr(trace, "mode", "") or ""
                if "lines" in mode:
                    trace.update(mode="lines+markers+text", texttemplate="%{y:,.2f}", textposition="top center")
                else:
                    trace.update(mode="markers+text", texttemplate="%{y:,.2f}", textposition="top center")
            elif trace_type in {"histogram"}:
                trace.update(texttemplate="%{y}", textposition="auto")
    except Exception:
        pass
    return fig


def plot_chart(fig, *args, **kwargs):
    return st.plotly_chart(apply_default_data_labels(fig), *args, **kwargs)


def impute_base_column(dataset_name: str, column: str, semantic_type: str) -> tuple[int, Any]:
    """Impute one base-data column and invalidate stale downstream outputs."""
    state_key = "base_data_1" if dataset_name == "File 1" else "base_data_2"
    base = st.session_state.get(state_key)
    if base is None or column not in base.columns:
        raise ValueError(f"{dataset_name} is not available or no longer contains '{column}'.")

    corrected = base.copy()
    series = corrected[column]
    blank_mask = series.astype("string").str.strip().eq("").fillna(False)
    missing_mask = series.isna() | blank_mask
    missing_count = int(missing_mask.sum())
    if missing_count == 0:
        return 0, None

    if semantic_type in {"numerical", "numeric-like text"}:
        numeric = safe_numeric_series(series)
        median_value = numeric[~missing_mask].median()
        if pd.isna(median_value):
            raise ValueError("Median cannot be calculated because the column has no valid numerical values.")
        corrected.loc[missing_mask, column] = median_value
        strategy = "median"
        replacement_value = safe_python_scalar(median_value)
    else:
        corrected.loc[missing_mask, column] = "Unknown"
        strategy = "unknown_category"
        replacement_value = "Unknown"

    st.session_state[state_key] = corrected
    st.session_state.joined_data = None
    st.session_state.filtered_data = None
    st.session_state.pivot_data = None
    st.session_state.join_config = {}
    st.session_state.last_filter_config = {}
    st.session_state.filters = []
    audit("MISSING_VALUES_IMPUTED", {
        "dataset": dataset_name,
        "column": column,
        "semantic_type": semantic_type,
        "strategy": strategy,
        "replacement_value": replacement_value,
        "updated_rows": missing_count,
    })
    return missing_count, replacement_value


def auto_expand_database_source(source_key: str) -> None:
    """Widen the source pane when a database source is selected."""
    if st.session_state.get(source_key) in {"Databricks", "PostgreSQL"}:
        st.session_state["wide_sidebar"] = True


init_state()

with st.sidebar:
    st.checkbox(
        "Expand left pane", key="wide_sidebar",
        help="Use a wider sidebar for SQL connection details and query previews."
    )
    st.header("1. Data sources")
    st.caption("Use an uploaded file or a database query for each dataset.")

    source_type_1 = st.radio(
        "Dataset 1 source", ["Upload file", "Databricks", "PostgreSQL"], horizontal=True,
        key="source_type_1", on_change=auto_expand_database_source, args=("source_type_1",),
    )
    file_1 = None
    db_raw_1 = None
    db_meta_1: dict[str, Any] = {}
    if source_type_1 == "Upload file":
        file_1 = st.file_uploader("File 1", type=["xlsx", "xlsm", "xls", "csv"], key="file_1")
    else:
        db_raw_1, db_meta_1 = render_database_source(1, source_type_1)

    enable_dataset_2 = st.checkbox("Add Dataset 2 for join / lookup", value=False, key="enable_dataset_2")
    source_type_2 = None
    file_2 = None
    db_raw_2 = None
    db_meta_2: dict[str, Any] = {}
    if enable_dataset_2:
        source_type_2 = st.radio(
            "Dataset 2 source", ["Upload file", "Databricks", "PostgreSQL"], horizontal=True,
            key="source_type_2", on_change=auto_expand_database_source, args=("source_type_2",),
        )
        if source_type_2 == "Upload file":
            file_2 = st.file_uploader("File 2", type=["xlsx", "xlsm", "xls", "csv"], key="file_2")
        else:
            db_raw_2, db_meta_2 = render_database_source(2, source_type_2)

    st.session_state.analysis_name = st.text_input("Analysis name", st.session_state.analysis_name)
    st.divider()
    st.subheader("Selected filter summary")
    filter_summary_placeholder = st.empty()
    if st.session_state.filters:
        filter_summary_placeholder.markdown("\n".join(
            f"**{i + 1}.** `{filter_summary(rule, i)}`"
            for i, rule in enumerate(st.session_state.filters)
        ))
    else:
        filter_summary_placeholder.info("No filters selected yet.")

    st.divider()
    st.button(
        "Audit",
        key="sidebar_audit_button",
        type="primary" if st.session_state.get("nav_page") == "Audit" else "secondary",
        use_container_width=True,
        on_click=lambda: st.session_state.__setitem__("nav_page", "Audit"),
    )

# Resolve Dataset 1.
if source_type_1 == "Upload file" and not file_1:
    st.info("Upload Dataset 1 or choose Database query and run a query to begin.")
    st.stop()
if source_type_1 in {"Databricks", "PostgreSQL"} and db_raw_1 is None:
    st.info(f"Configure the Dataset 1 {source_type_1} connection and run a query to begin.")
    st.stop()

try:
    bytes_1 = None
    bytes_2 = None
    sheet_1 = None
    sheet_2 = None

    if source_type_1 == "Upload file":
        bytes_1 = file_1.getvalue()
        sheets_1 = get_sheet_names(bytes_1, file_1.name)
        with st.sidebar:
            sheet_1 = st.selectbox("File 1 sheet", sheets_1)
        raw1 = load_table(bytes_1, file_1.name, None if sheet_1 == "CSV" else sheet_1)
        source_label_1 = file_1.name
        signature_1 = ("file", file_fingerprint(bytes_1), sheet_1)
    else:
        raw1 = db_raw_1.copy()
        source_label_1 = f"{db_meta_1.get('database_type', 'Database')} query"
        signature_1 = (
            "database", db_meta_1.get("database_type"),
            hashlib.sha256(db_meta_1.get("query", "").encode("utf-8")).hexdigest()[:16],
            len(raw1), tuple(map(str, raw1.columns)),
        )
    df1 = make_unique_columns(raw1, "File1")

    df2 = None
    source_label_2 = None
    signature_2 = None
    if enable_dataset_2:
        if source_type_2 == "Upload file":
            if file_2 is not None:
                bytes_2 = file_2.getvalue()
                sheets_2 = get_sheet_names(bytes_2, file_2.name)
                with st.sidebar:
                    sheet_2 = st.selectbox("File 2 sheet", sheets_2)
                raw2 = load_table(bytes_2, file_2.name, None if sheet_2 == "CSV" else sheet_2)
                df2 = make_unique_columns(raw2, "File2")
                source_label_2 = file_2.name
                signature_2 = ("file", file_fingerprint(bytes_2), sheet_2)
        elif db_raw_2 is not None:
            raw2 = db_raw_2.copy()
            df2 = make_unique_columns(raw2, "File2")
            source_label_2 = f"{db_meta_2.get('database_type', 'Database')} query"
            signature_2 = (
                "database", db_meta_2.get("database_type"),
                hashlib.sha256(db_meta_2.get("query", "").encode("utf-8")).hexdigest()[:16],
                len(raw2), tuple(map(str, raw2.columns)),
            )
except Exception as exc:
    st.error(f"Could not load the selected data sources: {exc}")
    st.stop()

input_signature = (signature_1, signature_2)
if st.session_state.input_signature != input_signature:
    st.session_state.input_signature = input_signature
    st.session_state.base_data_1 = df1.copy()
    st.session_state.base_data_2 = df2.copy() if df2 is not None else None
    st.session_state.profile_revision_1 = 0
    st.session_state.profile_revision_2 = 0
    st.session_state.joined_data = None
    st.session_state.filtered_data = None
    st.session_state.pivot_data = None
    st.session_state.join_config = {}
    st.session_state.last_filter_config = {}
    st.session_state.filters = []
    audit("INPUT_SOURCES_CHANGED", {
        "dataset_1": source_label_1,
        "dataset_2": source_label_2,
        "dataset_1_source_type": source_type_1,
        "dataset_2_source_type": source_type_2 if enable_dataset_2 else None,
        "single_dataset_mode": df2 is None,
    })

# Use session-backed base datasets so data-quality corrections survive Streamlit reruns
# and are automatically consumed by every downstream module.
df1 = st.session_state.base_data_1.copy()
df2 = st.session_state.base_data_2.copy() if st.session_state.base_data_2 is not None else None

if df2 is None:
    m1, m2 = st.columns(2)
    m1.metric("Dataset 1 rows", f"{len(df1):,}")
    m2.metric("Dataset 1 columns", len(df1.columns))
    st.caption("Single-dataset analysis mode is active. Add Dataset 2 only when a join or lookup is required.")
else:
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Dataset 1 rows", f"{len(df1):,}")
    m2.metric("Dataset 1 columns", len(df1.columns))
    m3.metric("File 2 rows", f"{len(df2):,}")
    m4.metric("File 2 columns", len(df2.columns))

# Modern top-level navigation. Button cards avoid radio indicators and support
# programmatic navigation from actions such as the filtered-output Preview button.
NAV_ITEMS = [
    "Preview",
    "Join/Lookup",
    "Filter",
    "Data Profile",
    "Pivot",
    "Charts",
    "Explore",
]
if "nav_page" not in st.session_state or st.session_state.nav_page not in set(NAV_ITEMS + ["Audit"]):
    st.session_state.nav_page = "Preview"


def clean_name(value: Any) -> str:
    """Standardize a column name using the notebook's clean_name logic."""
    return re.sub(r"[^a-z0-9]+", "_", str(value).strip().lower()).strip("_")


def standardize_object_dtypes(data: pd.DataFrame, null_patterns: list[str]) -> tuple[pd.DataFrame, int]:
    """Apply the notebook object-dtype cleanup and return changed-cell count."""
    cleaned = data.copy()
    object_columns = list(cleaned.select_dtypes(include=["object", "string"]).columns)
    changed_cells = 0

    for column in object_columns:
        before = cleaned[column].copy()
        # Notebook behavior: normalize object values to pandas string, trim
        # surrounding whitespace, and convert blank values to missing.
        normalized = cleaned[column].astype("string").str.strip().replace({"": pd.NA})
        # Reapply null patterns after trimming so padded patterns such as
        # " ? " and " NULL " are also standardized.
        normalized = normalized.replace(null_patterns, pd.NA)
        cleaned[column] = normalized

        before_cmp = before.astype("string").fillna("<NA>")
        after_cmp = normalized.astype("string").fillna("<NA>")
        changed_cells += int((before_cmp != after_cmp).sum())

    return cleaned, changed_cells


def standardize_base_data(dataset_name: str) -> tuple[int, int, int, int]:
    """Apply notebook column-name, null-pattern, and object-dtype standardization."""
    if dataset_name not in {"File 1", "File 2"}:
        raise ValueError("Select File 1 or File 2 to standardize reusable base data.")

    state_key = "base_data_1" if dataset_name == "File 1" else "base_data_2"
    base = st.session_state.get(state_key)
    if base is None:
        raise ValueError(f"{dataset_name} is not available.")

    standardized = base.copy()
    original_columns = list(standardized.columns)
    cleaned_columns = [clean_name(column) for column in original_columns]

    # Preserve every column even when multiple original names normalize identically.
    seen: dict[str, int] = {}
    unique_columns: list[str] = []
    for cleaned in cleaned_columns:
        base_name = cleaned or "unnamed"
        seen[base_name] = seen.get(base_name, 0) + 1
        unique_columns.append(base_name if seen[base_name] == 1 else f"{base_name}_{seen[base_name]}")
    standardized.columns = unique_columns

    missing_before = int(standardized.isna().sum().sum())
    null_patterns = ["?", "", "NA", "N/A", "NULL", "null", "None", "none", "-", "--"]
    standardized = standardized.replace(null_patterns, np.nan)
    standardized, object_values_cleaned = standardize_object_dtypes(standardized, null_patterns)
    missing_after = int(standardized.isna().sum().sum())

    renamed_columns = sum(str(old) != str(new) for old, new in zip(original_columns, unique_columns))
    converted_to_null = max(0, missing_after - missing_before)

    st.session_state[state_key] = standardized

    # Force all column-dependent Data Profile widgets to rebuild from the
    # standardized schema. File 1 and File 2 use independent revisions.
    revision_key = "profile_revision_1" if dataset_name == "File 1" else "profile_revision_2"
    st.session_state[revision_key] = int(st.session_state.get(revision_key, 0)) + 1

    st.session_state.joined_data = None
    st.session_state.filtered_data = None
    st.session_state.pivot_data = None
    st.session_state.join_config = {}
    st.session_state.last_filter_config = {}
    st.session_state.filters = []
    audit("DATA_STANDARDIZED", {
        "dataset": dataset_name,
        "rows": len(standardized),
        "columns": len(standardized.columns),
        "renamed_columns": renamed_columns,
        "values_converted_to_null": converted_to_null,
        "object_values_cleaned": object_values_cleaned,
        "functions": ["clean_name", "df.replace null patterns", "object dtype handling"],
    })
    return renamed_columns, converted_to_null, len(standardized.columns), object_values_cleaned

def set_navigation(page: str) -> None:
    st.session_state.nav_page = page

def render_navigation() -> str:
    st.markdown('<div class="modern-nav-anchor"></div>', unsafe_allow_html=True)
    nav_columns = st.columns(len(NAV_ITEMS), gap="small")
    current_page = st.session_state.nav_page
    for column, page in zip(nav_columns, NAV_ITEMS):
        column.button(
            page,
            key=f"nav_button_{page.lower().replace(' ', '_').replace('/', '_').replace('&', 'and')}",
            type="primary" if current_page == page else "secondary",
            use_container_width=True,
            on_click=set_navigation,
            args=(page,),
        )
    return st.session_state.nav_page

active_page = render_navigation()

def navigate_to_preview() -> None:
    set_navigation("Preview")

if active_page == "Preview":
    st.subheader("Data preview")
    preview_sources: dict[str, pd.DataFrame] = {"Dataset 1": df1}
    if df2 is not None:
        preview_sources["Dataset 2"] = df2
    if st.session_state.joined_data is not None:
        preview_sources["Joined dataset"] = st.session_state.joined_data
    if st.session_state.filtered_data is not None:
        preview_sources["Filtered output"] = st.session_state.filtered_data

    preview_controls = st.columns([3, 1])
    preview_names = list(preview_sources.keys())
    if st.session_state.filtered_data is not None and st.session_state.get("main_preview_source") not in preview_names:
        st.session_state.main_preview_source = "Filtered output"
    preview_source_name = preview_controls[0].selectbox(
        "Preview source", preview_names, key="main_preview_source"
    )
    preview_row_limit = preview_controls[1].selectbox(
        "Preview rows", [25, 50, 100, 250, 500], index=2, key="main_preview_rows"
    )
    preview_df = preview_sources[preview_source_name]
    st.caption(
        f"Showing up to {min(preview_row_limit, len(preview_df)):,} of "
        f"{len(preview_df):,} rows and {len(preview_df.columns):,} columns."
    )
    preview_slice = preview_df.head(int(preview_row_limit)).copy()
    st.dataframe(
        preview_slice,
        use_container_width=True,
        height=min(620, max(260, 38 + 35 * min(len(preview_slice), 15))),
        hide_index=True,
    )

if active_page == "Join/Lookup":
    if df2 is None:
        st.info("Add and load Dataset 2 to enable join/lookup. All other analysis pages can use Dataset 1 directly.")
    else:
        st.subheader("Join or lookup the two datasets")
        c1, c2, c3 = st.columns(3)
        left_key = c1.selectbox("File 1 lookup key", df1.columns)
        right_key = c2.selectbox("File 2 lookup key", df2.columns)
        join_type = c3.selectbox("Join type", ["left", "inner", "right", "outer"], format_func=lambda x: {
            "left": "Left lookup (VLOOKUP style)", "inner": "Inner join",
            "right": "Right join", "outer": "Full outer join"}[x])
        c4, c5, c6 = st.columns(3)
        trim_keys = c4.checkbox("Trim spaces in keys", True)
        case_insensitive = c5.checkbox("Case-insensitive keys", True)
        add_match_status = c6.checkbox("Add match status", True)
        selected_right = st.multiselect(
            "Columns to bring from File 2", [c for c in df2.columns if c != right_key],
            default=[c for c in df2.columns if c != right_key][:10],
        )
    
        if st.button("Run join / lookup", type="primary"):
            left_work = df1.copy()
            right_work = df2[[right_key] + selected_right].copy()
            key = "__lookup_key__"
            left_work[key] = normalize_key(left_work[left_key], trim_keys, case_insensitive)
            right_work[key] = normalize_key(right_work[right_key], trim_keys, case_insensitive)
            duplicates = int(right_work[key].duplicated(keep=False).sum())
            merged = left_work.merge(
                right_work, how=join_type, on=key, suffixes=("_file1", "_file2"),
                indicator=True,
            ).drop(columns=[key])
    
            file1_key_count = int(left_work[left_key].notna().sum())
            file2_key_count = int(right_work[right_key].notna().sum())
            joined_match_count = int(merged["_merge"].eq("both").sum())
            missing_not_joined_count = int(merged["_merge"].ne("both").sum())
    
            if add_match_status:
                merged["_merge"] = merged["_merge"].astype(str).map({
                    "left_only": "Only in File 1", "right_only": "Only in File 2", "both": "Matched"})
            else:
                merged = merged.drop(columns=["_merge"])
            st.session_state.joined_data = merged
            st.session_state.filtered_data = None
            st.session_state.join_config = {
                "left_key": left_key, "right_key": right_key, "join_type": join_type,
                "trim_keys": trim_keys, "case_insensitive": case_insensitive,
                "selected_file2_columns": selected_right, "duplicate_file2_key_rows": duplicates,
            }
            st.session_state.join_config.update({
                "file1_key_record_count": file1_key_count,
                "file2_key_record_count": file2_key_count,
                "joined_match_count": joined_match_count,
                "missing_not_joined_count": missing_not_joined_count,
            })
            audit("JOIN_EXECUTED", {**st.session_state.join_config, "output_rows": len(merged)})
            st.success(
                f"Total records of file1 ({left_key} count): {file1_key_count:,} | "
                f"Total records of file2 ({right_key} count): {file2_key_count:,} | "
                f"Joined dataset count (key column match): {joined_match_count:,} | "
                f"Missing or not joined count (key column non-match): {missing_not_joined_count:,}"
            )
    
        if st.session_state.joined_data is not None:
            st.caption("Columns are prefixed with File1. or File2. so filters can clearly use fields from either source.")
            render_grid(st.session_state.joined_data, "joined_grid")
        else:
            st.info("Configure and run the join before creating cross-file filters.")
if active_page == "Filter":
    st.markdown('<span class="filter-page-anchor"></span>', unsafe_allow_html=True)
    st.subheader("Visible AND/OR filter builder")
    source_options = {"File 1": df1}
    if df2 is not None:
        source_options["File 2"] = df2
    if st.session_state.joined_data is not None:
        source_options = {"Joined data": st.session_state.joined_data, **source_options}
    available = list(source_options.keys())
    source_col, upload_col = st.columns([1, 1], vertical_alignment="bottom")
    source_name = source_col.selectbox("Filter data source", available, key="filter_source")
    uploaded_filters = upload_col.file_uploader(
        "Load saved filters", type=["json"], key="filter_upload",
        help="Select a previously saved filter-definition JSON file.",
    )
    source_df = source_options[source_name].copy()

    saved_deep_dive = st.session_state.get("saved_deep_dive_filters", {})
    if saved_deep_dive:
        st.markdown("#### Saved Deep Dive filters")
        preset_col, apply_preset_col, delete_preset_col = st.columns([3, 1, 1], vertical_alignment="bottom")
        preset_name = preset_col.selectbox("Saved filter", list(saved_deep_dive.keys()), key="saved_deep_dive_filter_choice")
        if apply_preset_col.button("Apply saved", type="primary", use_container_width=True):
            preset = saved_deep_dive[preset_name]
            reapplied = apply_saved_deep_dive_filter(source_df, preset.get("filter_spec", {}))
            st.session_state.filtered_data = reapplied
            st.session_state.main_preview_source = "Filtered output"
            audit("EDA_DEEP_DIVE_FILTER_REAPPLIED", {"name": preset_name, "output_rows": len(reapplied)})
            st.success(f"Applied '{preset_name}' to {len(reapplied):,} matching records.")
        if delete_preset_col.button("Delete", use_container_width=True):
            del st.session_state.saved_deep_dive_filters[preset_name]
            audit("EDA_DEEP_DIVE_FILTER_DELETED", {"name": preset_name})
            st.rerun()

    import_col, clear_col, spacer_col = st.columns([1, 1, 2], vertical_alignment="bottom")
    if import_col.button(
        "Import filter file", use_container_width=True, disabled=uploaded_filters is None
    ):
        try:
            payload = json.loads(uploaded_filters.getvalue().decode("utf-8"))
            imported = payload.get("filters", payload)
            if not isinstance(imported, list):
                raise ValueError("The file does not contain a filter list.")
            valid = [r for r in imported if r.get("column") in source_df.columns]
            st.session_state.filters = valid
            audit("FILTER_SET_IMPORTED", {"imported": len(valid), "ignored": len(imported) - len(valid)})
            st.rerun()
        except Exception as exc:
            st.error(f"Could not import filters: {exc}")
    if clear_col.button("Clear all filters", use_container_width=True):
        count = len(st.session_state.filters)
        st.session_state.filters = []
        st.session_state.filtered_data = None
        audit("FILTERS_CLEARED", {"count": count})
        st.rerun()

    st.markdown("#### Add condition")
    a, b, c, d = st.columns([1, 1.6, 1.4, 1.6], vertical_alignment="bottom")
    connector = a.selectbox("Connector", ["AND", "OR"], disabled=len(st.session_state.filters) == 0)
    column = b.selectbox("Column", source_df.columns)
    operator = c.selectbox("Operator", OPERATORS)
    value_disabled = operator in {"is blank", "is not blank"}
    value = d.text_input("Value", disabled=value_disabled, help="For 'in list', use comma-separated values.")
    e, f, g = st.columns([2, 1, 1], vertical_alignment="bottom")
    value2 = e.text_input("Upper value", disabled=operator != "between")
    case_sensitive = f.checkbox("Case-sensitive", False)
    if g.button("Add filter", type="primary", use_container_width=True):
        rule = {
            "connector": "AND" if not st.session_state.filters else connector,
            "column": column, "operator": operator, "value": value,
            "value2": value2, "case_sensitive": case_sensitive,
        }
        st.session_state.filters.append(rule)
        audit("FILTER_ADDED", rule)
        st.rerun()

    st.markdown("#### Applied filter definition")
    if not st.session_state.filters:
        st.info("No conditions added. Add conditions above; every condition remains visible here.")
    else:
        for index, rule in enumerate(st.session_state.filters):
            with st.container(border=True):
                x1, x2, x3 = st.columns([7, 1, 1])
                x1.code(filter_summary(rule, index), language=None)
                if x2.button("↑", key=f"up_{index}", disabled=index == 0):
                    rules = st.session_state.filters
                    rules[index - 1], rules[index] = rules[index], rules[index - 1]
                    audit("FILTER_REORDERED", {"from": index, "to": index - 1})
                    st.rerun()
                if x3.button("Remove", key=f"remove_{index}"):
                    removed = st.session_state.filters.pop(index)
                    audit("FILTER_REMOVED", removed)
                    st.rerun()

    csel, csort, cascn = st.columns([2.2, 1.6, 1], vertical_alignment="bottom")
    selected_columns = csel.multiselect("Output columns and order", source_df.columns, default=list(source_df.columns))
    sort_columns = csort.multiselect("Sort by", selected_columns)
    ascending = cascn.checkbox("Ascending", True)
    dedupe_col, dedupe_spacer = st.columns([1, 3], vertical_alignment="bottom")
    remove_duplicates = dedupe_col.checkbox("Remove duplicate output rows")

    apply_col, save_col = st.columns(2, vertical_alignment="bottom")
    if apply_col.button("Apply filters", type="primary", use_container_width=True):
        try:
            filtered = apply_filter_rules(source_df, st.session_state.filters)
            if selected_columns:
                filtered = filtered[selected_columns]
            if sort_columns:
                filtered = filtered.sort_values(sort_columns, ascending=ascending, na_position="last")
            if remove_duplicates:
                filtered = filtered.drop_duplicates()
            st.session_state.filtered_data = filtered
            st.session_state.last_filter_config = {
                "source": source_name, "filters": st.session_state.filters,
                "selected_columns": selected_columns, "sort_columns": sort_columns,
                "ascending": ascending, "remove_duplicates": remove_duplicates,
            }
            audit("FILTERS_APPLIED", {
                "source": source_name, "conditions": len(st.session_state.filters),
                "input_rows": len(source_df), "output_rows": len(filtered),
                "sort_columns": sort_columns, "remove_duplicates": remove_duplicates,
            })
            st.session_state.main_preview_source = "Filtered output"
            set_navigation("Preview")
            st.rerun()
        except Exception as exc:
            st.error(f"Could not apply filters: {exc}")

    filter_payload = {"version": 1, "source": source_name, "filters": st.session_state.filters}
    save_col.download_button(
        "Save filter definition", json_bytes(filter_payload),
        file_name=f"{st.session_state.analysis_name}_filters.json", mime="application/json",
        on_click=lambda: audit("FILTER_SET_DOWNLOADED", {"conditions": len(st.session_state.filters)}),
        use_container_width=True,
    )
    if st.session_state.filtered_data is not None:
        st.markdown("#### Filtered output")
        visible_output = render_grid(st.session_state.filtered_data, "filtered_grid")
        st.download_button(
            "Download output Excel", to_excel_bytes({"Filtered_Output": visible_output}),
            file_name=f"{st.session_state.analysis_name}_output.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            on_click=lambda: audit("OUTPUT_EXCEL_DOWNLOADED", {"rows": len(visible_output)}),
        )

if active_page == "Pivot":
    st.subheader("Pivot table")
    pivot_options = {"File 1": df1}
    if df2 is not None:
        pivot_options["File 2"] = df2
    if st.session_state.joined_data is not None:
        pivot_options["Joined data"] = st.session_state.joined_data
    if st.session_state.filtered_data is not None:
        pivot_options["Filtered output"] = st.session_state.filtered_data
    pivot_source_name = st.radio("Profile source", pivot_options.keys(), horizontal=True, key="pivot_profile_source")
    if st.session_state.get("pivot_last_profile_source") != pivot_source_name:
        st.session_state.pivot_data = None
        st.session_state.pivot_last_profile_source = pivot_source_name
    pivot_source = pivot_options[pivot_source_name]
    if pivot_source is None or pivot_source.empty:
        st.info("No analysis data is available.")
    else:
        p1, p2 = st.columns(2)
        index_columns = p1.multiselect("Rows", pivot_source.columns)
        pivot_columns = p2.multiselect("Columns", pivot_source.columns)
        numeric = list(pivot_source.select_dtypes(include="number").columns)
        values = st.multiselect("Values", pivot_source.columns, default=numeric[:1])
        aggregation = st.selectbox("Aggregation", ["sum", "mean", "count", "min", "max", "median", "nunique"])
        if st.button("Create pivot") and index_columns and values:
            pivot_df = pd.pivot_table(
                pivot_source, index=index_columns, columns=pivot_columns or None,
                values=values, aggfunc=aggregation, fill_value=0, dropna=False).reset_index()
            pivot_df.columns = [" | ".join(str(x) for x in col if str(x)) if isinstance(col, tuple) else str(col) for col in pivot_df.columns]
            st.session_state.pivot_data = pivot_df
            audit("PIVOT_CREATED", {"rows": index_columns, "columns": pivot_columns, "values": values, "aggregation": aggregation})

        pivot_df = st.session_state.get("pivot_data")
        if pivot_df is not None:
            st.caption("Column headings are automatically expanded for readability.")
            visible_pivot = render_grid(pivot_df, "pivot_grid", fit_columns=True)
            d1, d2, _pivot_spacer = st.columns([1, 1, 4])
            d1.download_button(
                "Download pivot Excel", to_excel_bytes({"Pivot_Output": visible_pivot}),
                file_name=f"{st.session_state.analysis_name}_pivot.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                on_click=lambda: audit("PIVOT_EXCEL_DOWNLOADED", {"rows": len(visible_pivot)}),
            )
            d2.download_button(
                "Download pivot CSV", visible_pivot.to_csv(index=False).encode("utf-8-sig"),
                file_name=f"{st.session_state.analysis_name}_pivot.csv", mime="text/csv",
                on_click=lambda: audit("PIVOT_CSV_DOWNLOADED", {"rows": len(visible_pivot)}),
            )

if active_page == "Charts":
    st.subheader("Interactive charts for all column types")
    chart_options = {"File 1": df1}
    if df2 is not None:
        chart_options["File 2"] = df2
    if st.session_state.joined_data is not None:
        chart_options["Joined data"] = st.session_state.joined_data
    if st.session_state.filtered_data is not None:
        chart_options["Filtered output"] = st.session_state.filtered_data
    chart_source_name = st.radio("Profile source", chart_options.keys(), horizontal=True, key="charts_profile_source")
    chart_df = chart_options[chart_source_name]
    if chart_df is None or chart_df.empty:
        st.info("No analysis data is available.")
    else:
        chart_type = st.selectbox("Chart type", ["Bar", "Line", "Scatter", "Histogram", "Box", "Pie", "Heatmap (cross tab)"])
        columns = list(chart_df.columns)

        if chart_type == "Heatmap (cross tab)":
            h1, h2 = st.columns(2)
            row_col = h1.selectbox("Cross-tab rows", columns, key="heatmap_rows")
            col_col = h2.selectbox("Cross-tab columns", columns, index=min(1, len(columns)-1), key="heatmap_cols")
            value_cols = st.multiselect("Value columns (optional)", columns, key="heatmap_values")
            heatmap_agg = st.selectbox("Aggregation", ["Row count", "Distinct count", "Sum", "Average", "Median", "Minimum", "Maximum"], key="heatmap_agg")
            normalize = st.selectbox("Normalize", ["None", "By row (%)", "By column (%)", "Overall (%)"], key="heatmap_normalize")
            max_categories = st.slider("Maximum categories per axis", 5, 50, 20, key="heatmap_max_categories")
            if st.button("Create heatmap", type="primary"):
                try:
                    work = chart_df.copy()
                    top_rows = work[row_col].astype("string").fillna("<Missing>").value_counts().head(max_categories).index
                    top_cols = work[col_col].astype("string").fillna("<Missing>").value_counts().head(max_categories).index
                    work["__row__"] = work[row_col].astype("string").fillna("<Missing>")
                    work["__col__"] = work[col_col].astype("string").fillna("<Missing>")
                    work = work[work["__row__"].isin(top_rows) & work["__col__"].isin(top_cols)]

                    if heatmap_agg == "Row count" or not value_cols:
                        cross = pd.crosstab(work["__row__"], work["__col__"])
                    else:
                        frames = []
                        for value_col in value_cols:
                            if heatmap_agg == "Distinct count":
                                pivot = pd.pivot_table(work, index="__row__", columns="__col__", values=value_col, aggfunc=pd.Series.nunique, fill_value=0)
                            else:
                                work["__heat_value__"] = safe_numeric_series(work[value_col])
                                agg_map = {"Sum":"sum", "Average":"mean", "Median":"median", "Minimum":"min", "Maximum":"max"}
                                pivot = pd.pivot_table(work, index="__row__", columns="__col__", values="__heat_value__", aggfunc=agg_map[heatmap_agg], fill_value=0)
                            if len(value_cols) > 1:
                                pivot.columns = [f"{value_col} | {c}" for c in pivot.columns]
                            frames.append(pivot)
                        cross = pd.concat(frames, axis=1)

                    if normalize == "By row (%)":
                        cross = cross.div(cross.sum(axis=1).replace(0, np.nan), axis=0) * 100
                    elif normalize == "By column (%)":
                        cross = cross.div(cross.sum(axis=0).replace(0, np.nan), axis=1) * 100
                    elif normalize == "Overall (%)":
                        total = cross.to_numpy().sum()
                        cross = cross / total * 100 if total else cross

                    fig = px.imshow(cross, text_auto=".2f", aspect="auto", labels={"x": col_col, "y": row_col, "color": heatmap_agg}, title=f"Cross-tab heatmap: {row_col} × {col_col}")
                    plot_chart(fig, use_container_width=True)
                    st.dataframe(cross, use_container_width=True)
                    audit("HEATMAP_CREATED", {"rows": row_col, "columns": col_col, "values": value_cols, "aggregation": heatmap_agg, "normalize": normalize})
                except Exception as exc:
                    st.error(f"Could not create heatmap: {exc}")
        else:
            x_columns = st.multiselect("X axis / category columns", columns, default=[columns[0]], max_selections=3)
            y_columns = st.multiselect("Y axis / value columns", columns, default=[])
            aggregation = st.selectbox(
                "Aggregation",
                ["Row count", "Distinct count", "Sum", "Average", "Median", "Minimum", "Maximum"],
                help="Select multiple columns to generate multiple series. Row count works without a Y column.",
            )
            color_col = st.selectbox("Color / group", ["None"] + columns)
            top_n = st.slider("Maximum categories", 5, 100, 30)
            if st.button("Create chart"):
                try:
                    if not x_columns:
                        raise ValueError("Select at least one X-axis/category column.")
                    color = None if color_col == "None" else color_col
                    x_col = x_columns[0] if len(x_columns) == 1 else " | ".join(x_columns)
                    work = chart_df.copy()
                    if len(x_columns) > 1:
                        work[x_col] = work[x_columns].astype("string").fillna("<Missing>").agg(" | ".join, axis=1)

                    if chart_type in {"Scatter", "Box"} and not y_columns:
                        raise ValueError(f"Select at least one Y-axis column for a {chart_type.lower()} chart.")

                    if chart_type == "Histogram":
                        melted = work.melt(value_vars=x_columns, var_name="column", value_name="value")
                        fig = px.histogram(melted, x="value", color="column", barmode="overlay")
                    elif chart_type == "Scatter":
                        scatter_y = y_columns[:5]
                        melted = work.melt(id_vars=[x_col] + ([color] if color and color != x_col else []), value_vars=scatter_y, var_name="series", value_name="value")
                        melted["value"] = safe_numeric_series(melted["value"])
                        fig = px.scatter(melted, x=x_col, y="value", color="series", symbol=color if color and color in melted.columns else None)
                    elif chart_type == "Box":
                        melted = work.melt(id_vars=[x_col], value_vars=y_columns, var_name="series", value_name="value")
                        melted["value"] = safe_numeric_series(melted["value"])
                        fig = px.box(melted, x=x_col, y="value", color="series", points="outliers")
                    else:
                        series_cols = y_columns or [None]
                        frames = []
                        for y_col in series_cols:
                            plot_df, plot_y = build_chart_data(work, x_col, y_col, aggregation, chart_type, top_n)
                            plot_df = plot_df.copy()
                            plot_df["series"] = y_col or aggregation
                            plot_df["value"] = plot_df[plot_y]
                            frames.append(plot_df[[x_col, "series", "value"]])
                        combined = pd.concat(frames, ignore_index=True)
                        if chart_type == "Bar":
                            fig = px.bar(combined, x=x_col, y="value", color="series", barmode="group")
                        elif chart_type == "Line":
                            fig = px.line(combined, x=x_col, y="value", color="series", markers=True)
                        elif chart_type == "Pie":
                            if len(series_cols) > 1:
                                raise ValueError("Pie charts support one selected value column at a time.")
                            fig = px.pie(combined, names=x_col, values="value")
                        else:
                            raise ValueError("Unsupported chart configuration.")
                    plot_chart(fig, use_container_width=True)
                    audit("CHART_CREATED", {"type": chart_type, "x": x_columns, "y": y_columns, "aggregation": aggregation, "color": color_col})
                except Exception as exc:
                    st.error(f"Could not create chart: {exc}")

if active_page == "Data Profile":
    st.subheader("Detailed data quality profile")
    options = {"File 1": df1}
    if df2 is not None:
        options["File 2"] = df2
    if st.session_state.joined_data is not None:
        options["Joined data"] = st.session_state.joined_data
    if st.session_state.filtered_data is not None:
        options["Filtered output"] = st.session_state.filtered_data
    profile_name = st.radio(
        "Profile source", options.keys(), horizontal=True, key="data_profile_source"
    )
    profile = options[profile_name]
    summary = quality_summary(profile)
    q1, q2, q3, q4, q5, q6 = st.columns(6)
    q1.metric("Rows", f"{summary['rows']:,}")
    q2.metric("Columns", f"{summary['columns']:,}")
    q3.metric("Duplicate rows", f"{summary['duplicate_rows']:,}")
    q4.metric("Missing cells", f"{summary['missing_cells']:,}")
    q5.metric("IQR outliers", f"{summary['outliers']:,}")
    q6.metric("Invalid values", f"{summary['invalid_values']:,}")

    profile_df = detailed_profile(profile)
    if profile_name == "File 1":
        profile_revision = int(st.session_state.get("profile_revision_1", 0))
    elif profile_name == "File 2":
        profile_revision = int(st.session_state.get("profile_revision_2", 0))
    else:
        profile_revision = 0
    st.dataframe(
        profile_df,
        use_container_width=True,
        hide_index=True,
        key=f"data_profile_grid_{profile_name}_{profile_revision}",
    )
    if profile_name in {"File 1", "File 2"}:
        if st.button("Standardize Data", key=f"standardize_data_{profile_name}", type="primary"):
            try:
                renamed_count, null_count, column_count, object_cleaned_count = standardize_base_data(profile_name)
                st.success(
                    f"Standardized {profile_name}: {renamed_count:,} column names cleaned, "
                    f"{null_count:,} values converted to missing, and {object_cleaned_count:,} "
                    f"object/string values normalized across {column_count:,} columns."
                )
                st.rerun()
            except Exception as exc:
                st.error(f"Could not standardize data: {exc}")
    else:
        st.button(
            "Standardize Data",
            key=f"standardize_data_{profile_name}",
            disabled=True,
            help="Select File 1 or File 2 to update reusable base data.",
        )
    st.caption("Invalid values identify failed conversions in columns that are predominantly numeric-like or date-like. Outliers use the 1.5×IQR rule.")

    st.subheader("Data cards")
    card_controls_1, card_controls_2 = st.columns([1, 3])
    card_view = card_controls_1.radio(
        "Card view", ["Compact", "Detailed"], horizontal=True,
        key=f"profile_card_view_{profile_name}"
    )
    selected_card_columns = card_controls_2.multiselect(
        "Columns to display",
        list(profile.columns),
        default=list(profile.columns[:min(8, len(profile.columns))]),
        key=f"profile_card_columns_{profile_name}_{profile_revision}",
        placeholder="Select one or more columns",
    )

    if not selected_card_columns:
        st.info("Select at least one column to display its data card.")
    else:
        cards_per_row = 3 if card_view == "Compact" else 2
        for start in range(0, len(selected_card_columns), cards_per_row):
            card_row = st.columns(cards_per_row)
            for position, column in enumerate(selected_card_columns[start:start + cards_per_row]):
                series = profile[column]
                row = profile_df.loc[profile_df["column"] == column].iloc[0]
                with card_row[position]:
                    with st.container(border=True):
                        st.markdown(f"**{column}**")
                        st.caption(f"{row['semantic_type']} · {row['physical_type']}")
                        m1, m2, m3 = st.columns(3)
                        m1.metric("Valid", f"{int(row['non_null']):,}")
                        m2.metric("Missing", f"{int(row['missing']):,}", f"{float(row['missing_pct']):.1f}%")
                        m3.metric("Unique", f"{int(row['unique_values']):,}")

                        if card_view == "Compact" and int(row["missing"]) > 0:
                            semantic = str(row["semantic_type"])
                            if profile_name in {"File 1", "File 2"}:
                                if semantic in {"numerical", "numeric-like text"}:
                                    action_label = "Fill missing with median"
                                    action_help = "Replace null and blank values with this column's median."
                                elif semantic in {"datetime", "date-like text"}:
                                    action_label = None
                                    action_help = None
                                    st.caption("Date missing-value imputation is not enabled.")
                                else:
                                    action_label = 'Fill missing with "Unknown"'
                                    action_help = 'Replace null and blank values with the category "Unknown".'

                                if action_label and st.button(
                                    action_label,
                                    key=f"impute_{profile_name}_{column}",
                                    help=action_help,
                                    use_container_width=True,
                                ):
                                    try:
                                        updated_rows, replacement = impute_base_column(profile_name, column, semantic)
                                        st.success(f"Updated {updated_rows:,} rows in {profile_name}. Replacement: {replacement}")
                                        st.rerun()
                                    except Exception as exc:
                                        st.error(f"Could not handle missing values: {exc}")
                            else:
                                st.caption("Select File 1 or File 2 to update the reusable base data.")

                        if card_view == "Detailed":
                            d1, d2, d3 = st.columns(3)
                            d1.metric("Duplicates", f"{int(row['duplicate_values']):,}")
                            d2.metric("Invalid", f"{int(row['invalid_values']):,}")
                            d3.metric("Consistency", f"{float(row['type_consistency_pct']):.1f}%")

                            semantic = str(row["semantic_type"])
                            if semantic in {"numerical", "numeric-like text"}:
                                numeric = safe_numeric_series(series).dropna()
                                if not numeric.empty:
                                    stats = pd.DataFrame({
                                        "Metric": ["Mean", "Median", "Minimum", "Maximum", "Std. deviation", "IQR outliers"],
                                        "Value": [
                                            numeric.mean(), numeric.median(), numeric.min(), numeric.max(),
                                            numeric.std(), int(row["outliers_iqr"]),
                                        ],
                                    })
                                    stats["Value"] = stats["Value"].map(
                                        lambda value: f"{value:,.2f}" if isinstance(value, (int, float, np.integer, np.floating)) and not pd.isna(value) else str(value)
                                    )
                                    st.dataframe(stats, use_container_width=True, hide_index=True)
                                    plot_chart(
                                        px.histogram(numeric, nbins=20, labels={"value": column}),
                                        use_container_width=True, key=f"profile_card_hist_{start}_{position}_{column}"
                                    )
                            elif semantic in {"datetime", "date-like text"}:
                                dates = safe_datetime_series(series).dropna()
                                if not dates.empty:
                                    date_stats = pd.DataFrame({
                                        "Metric": ["Earliest", "Latest", "Distinct dates"],
                                        "Value": [str(dates.min()), str(dates.max()), f"{dates.nunique():,}"],
                                    })
                                    st.dataframe(date_stats, use_container_width=True, hide_index=True)
                                    monthly = dates.dt.to_period("M").astype(str).value_counts().sort_index().tail(24).reset_index()
                                    monthly.columns = ["Period", "Count"]
                                    plot_chart(
                                        px.bar(monthly, x="Period", y="Count"),
                                        use_container_width=True, key=f"profile_card_date_{start}_{position}_{column}"
                                    )
                            else:
                                top_values = series.astype("string").fillna("<Missing>").value_counts(dropna=False).head(10).reset_index()
                                top_values.columns = ["Value", "Count"]
                                st.dataframe(top_values, use_container_width=True, hide_index=True)
                                plot_chart(
                                    px.bar(top_values, x="Count", y="Value", orientation="h"),
                                    use_container_width=True, key=f"profile_card_cat_{start}_{position}_{column}"
                                )
                        else:
                            top_values = series.astype("string").fillna("<Missing>").value_counts(dropna=False).head(3)
                            if not top_values.empty:
                                st.caption("Top values")
                                for value, count in top_values.items():
                                    label = str(value)
                                    if len(label) > 36:
                                        label = label[:33] + "..."
                                    st.write(f"{label}: **{int(count):,}**")

    st.markdown("#### Outlier and anomaly detection")
    profile_columns = list(profile.columns)
    if not profile_columns:
        st.info("No columns are available for anomaly detection.")
    else:
        anomaly_col = st.selectbox(
            "Column of any type", profile_columns,
            key=f"profile_anomaly_col_{profile_name}_{profile_revision}"
        )
        anomaly_semantic = infer_semantic_type(profile[anomaly_col])
        if anomaly_semantic in {"numerical", "numeric-like text"}:
            numeric_series = safe_numeric_series(profile[anomaly_col])
            method = st.radio(
                "Method", ["IQR", "Z-score"], horizontal=True,
                key=f"profile_outlier_method_{profile_name}_{profile_revision}"
            )
            if method == "IQR":
                mask = outlier_mask_iqr(numeric_series)
                detail = "Outside Q1 − 1.5×IQR or Q3 + 1.5×IQR"
            else:
                std = numeric_series.std(ddof=0)
                z = (numeric_series - numeric_series.mean()) / std if pd.notna(std) and std != 0 else pd.Series(0, index=numeric_series.index)
                mask = z.abs() > 3
                detail = "Absolute Z-score greater than 3"
            st.metric("Outlier rows", f"{int(mask.sum()):,}")
            st.caption(detail)
            plot_chart(px.box(y=numeric_series, points="outliers", title=f"Outliers: {anomaly_col}"), use_container_width=True)
            st.dataframe(profile.loc[mask].head(1000), use_container_width=True, hide_index=True)
        elif anomaly_semantic in {"datetime", "date-like text"}:
            parsed = safe_datetime_series(profile[anomaly_col])
            invalid = parsed.isna() & profile[anomaly_col].notna()
            st.metric("Invalid date values", f"{int(invalid.sum()):,}")
            st.dataframe(profile.loc[invalid].head(1000), use_container_width=True, hide_index=True)
        else:
            frequency = profile[anomaly_col].astype("string").fillna("<Missing>").value_counts(dropna=False)
            threshold = st.slider(
                "Rare-value threshold", 1, 100, 5,
                key=f"profile_rare_threshold_{profile_name}_{profile_revision}",
                help="Values occurring at or below this count are treated as rare anomalies."
            )
            rare_values = frequency[frequency <= threshold].index
            mask = profile[anomaly_col].astype("string").fillna("<Missing>").isin(rare_values)
            st.metric("Rare/anomalous rows", f"{int(mask.sum()):,}")
            st.dataframe(frequency.rename("count").reset_index().rename(columns={"index":"value"}), use_container_width=True, hide_index=True)
            st.dataframe(profile.loc[mask].head(1000), use_container_width=True, hide_index=True)


def wilson_interval(successes: int, total: int) -> tuple[float, float]:
    """Return the notebook-equivalent 95% Wilson score interval."""
    if total == 0:
        return np.nan, np.nan
    z = 1.959963984540054
    p = successes / total
    denominator = 1 + (z * z / total)
    center = (p + z * z / (2 * total)) / denominator
    margin = (
        z
        * math.sqrt((p * (1 - p) + z * z / (4 * total)) / total)
        / denominator
    )
    return center - margin, center + margin



def normalize_target_text(value: Any) -> str:
    if _safe_scalar_missing(value):
        return ""
    return str(value).strip()


def parse_ordinal_mapping(mapping_text: str) -> dict[str, float]:
    mapping: dict[str, float] = {}
    for item in str(mapping_text or "").split(","):
        item = item.strip()
        if not item:
            continue
        if ":" not in item:
            raise ValueError(f"Invalid ordinal mapping '{item}'. Use Class:order, for example Low:1, Medium:2, High:3.")
        label, order = item.split(":", 1)
        label = label.strip()
        if not label:
            raise ValueError("Ordinal class labels cannot be blank.")
        try:
            numeric_order = float(order.strip())
        except Exception as exc:
            raise ValueError(f"Ordinal order for '{label}' must be numeric.") from exc
        if not np.isfinite(numeric_order):
            raise ValueError(f"Ordinal order for '{label}' must be finite.")
        mapping[label.casefold()] = numeric_order
    if len(mapping) < 2:
        raise ValueError("Ordinal analysis requires mappings for at least two classes.")
    return mapping


def prepare_target_analysis(
    source_data: pd.DataFrame,
    target_column: str,
    target_mode: str,
    positive_class: str = "",
    focus_class: str = "",
    target_classes: list[str] | None = None,
    ordinal_mapping_text: str = "",
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Create validated binary, one-vs-rest, multiclass, or ordinal targets."""
    if source_data is None or source_data.empty:
        raise ValueError("The selected source has no rows.")
    if target_column not in source_data.columns:
        raise ValueError("The selected target column is not present in the source.")
    valid = source_data[target_column].notna().fillna(False)
    work = source_data.loc[valid].copy()
    if work.empty:
        raise ValueError("No non-null target rows are available.")
    raw = work[target_column]
    mode = str(target_mode).strip().lower().replace("-", "_").replace(" ", "_")
    if mode in {"binary", "one_vs_rest"}:
        chosen = positive_class if mode == "binary" else focus_class
        if not str(chosen).strip():
            raise ValueError("Provide a positive/focus class value.")
        if pd.api.types.is_numeric_dtype(raw):
            try:
                chosen_value = pd.to_numeric(pd.Series([chosen]), errors="raise").iloc[0]
            except Exception as exc:
                raise ValueError("The selected class cannot be converted to the numeric target type.") from exc
            flag = raw.eq(chosen_value).fillna(False).astype(int)
        else:
            flag = raw.astype("string").fillna("").str.strip().str.casefold().eq(str(chosen).strip().casefold()).fillna(False).astype(int)
        if flag.nunique() < 2:
            raise ValueError("The selected class must have both matching and non-matching rows.")
        work["target_flag"] = flag.to_numpy()
        label = str(chosen).strip()
        info = {"mode": mode, "class_label": label, "classes": [label], "target_column": target_column}
    else:
        class_series = raw.map(normalize_target_text).astype(object)
        available = [x for x in pd.unique(class_series) if str(x).strip()]
        if mode == "multiclass":
            selected = [str(x).strip() for x in (target_classes or available) if str(x).strip()]
            if len(selected) < 2:
                raise ValueError("Multiclass analysis requires at least two selected classes.")
            selected_lookup = {x.casefold(): x for x in selected}
            canonical = class_series.map(lambda x: selected_lookup.get(str(x).casefold(), np.nan))
            keep = canonical.notna().fillna(False)
            work = work.loc[keep].copy()
            canonical = canonical.loc[keep]
            if canonical.nunique() < 2:
                raise ValueError("Fewer than two selected classes are present in the source.")
            work["target_class"] = canonical.to_numpy()
            classes = [x for x in selected if x in set(canonical)]
            info = {"mode": mode, "classes": classes, "target_column": target_column}
        elif mode == "ordinal":
            mapping = parse_ordinal_mapping(ordinal_mapping_text)
            canonical_labels = {key: normalize_target_text(label) for key, label in [(k, k) for k in mapping]}
            order = class_series.map(lambda x: mapping.get(str(x).casefold(), np.nan))
            keep = order.notna().fillna(False)
            work = work.loc[keep].copy()
            class_kept = class_series.loc[keep]
            order = order.loc[keep].astype(float)
            if class_kept.nunique() < 2:
                raise ValueError("Ordinal analysis requires at least two mapped classes present in the source.")
            work["target_class"] = class_kept.to_numpy()
            work["target_ordinal"] = order.to_numpy()
            ordered_pairs = sorted(((label, value) for label, value in zip(class_kept, order)), key=lambda x: x[1])
            classes = list(dict.fromkeys(label for label, _ in ordered_pairs))
            info = {"mode": mode, "classes": classes, "ordinal_mapping": mapping, "target_column": target_column}
        else:
            raise ValueError("Unsupported target mode.")
    return work, info


def target_distribution(work: pd.DataFrame, target_info: dict[str, Any]) -> pd.DataFrame:
    if target_info["mode"] in {"binary", "one_vs_rest"}:
        positives = int(work["target_flag"].sum())
        total = int(len(work))
        return pd.DataFrame([{"target_class": target_info["class_label"], "class_count": positives, "records": total, "class_rate": positives / total if total else np.nan}])
    counts = work["target_class"].value_counts(dropna=False).rename("class_count").reset_index().rename(columns={"index": "target_class"})
    counts["target_class"] = counts["target_class"].map(normalize_target_text)
    counts["records"] = len(work)
    counts["class_rate"] = counts["class_count"] / max(len(work), 1)
    return counts


def categorical_lift_summary(data: pd.DataFrame, feature: str, target_info: dict[str, Any]) -> pd.DataFrame:
    temp = pd.DataFrame({feature: data[feature].astype("string").fillna("UNKNOWN")}, index=data.index)
    if target_info["mode"] in {"binary", "one_vs_rest"}:
        temp["target_flag"] = data["target_flag"].astype(int).to_numpy()
        out = temp.groupby(feature, dropna=False)["target_flag"].agg(records="count", class_count="sum").reset_index()
        out["target_class"] = target_info["class_label"]
        out["global_class_rate"] = float(data["target_flag"].mean())
    else:
        temp["target_class"] = data["target_class"].map(normalize_target_text).to_numpy()
        out = temp.groupby([feature, "target_class"], dropna=False).size().rename("class_count").reset_index()
        support = temp.groupby(feature, dropna=False).size().rename("records").reset_index()
        out = out.merge(support, on=feature, how="left")
        rates = temp["target_class"].value_counts(normalize=True).to_dict()
        out["global_class_rate"] = out["target_class"].map(rates)
    out["class_rate"] = out["class_count"] / out["records"]
    out["lift"] = out["class_rate"] / out["global_class_rate"].clip(lower=1e-9)
    intervals = out.apply(lambda row: wilson_interval(int(row["class_count"]), int(row["records"])), axis=1)
    out["ci_low"] = [x[0] for x in intervals]
    out["ci_high"] = [x[1] for x in intervals]
    out["feature"] = feature
    out["value"] = out[feature].astype(str)
    return out[["feature", "value", "target_class", "records", "class_count", "class_rate", "global_class_rate", "lift", "ci_low", "ci_high"]]


def discretize_rule_numeric_features(data: pd.DataFrame, columns: list[str], max_bins: int = 5) -> tuple[pd.DataFrame, pd.DataFrame]:
    output = pd.DataFrame(index=data.index); metadata=[]
    for column in columns:
        series = pd.to_numeric(data[column], errors="coerce").replace([np.inf, -np.inf], np.nan)
        unique_count = int(series.nunique(dropna=True))
        if unique_count < 2: continue
        try:
            binned, edges = pd.qcut(series, q=min(max_bins, unique_count), duplicates="drop", retbins=True)
            output[f"{column}__bin"] = binned.astype("string").fillna("UNKNOWN")
            metadata.append({"feature": column, "binning": "quantile", "bins": int(len(edges)-1), "edges": edges.tolist()})
        except Exception:
            binned = pd.cut(series, bins=max_bins, duplicates="drop")
            output[f"{column}__bin"] = binned.astype("string").fillna("UNKNOWN")
            metadata.append({"feature": column, "binning": "equal_width_fallback", "bins": int(output[f"{column}__bin"].nunique()), "edges": None})
    return output, pd.DataFrame(metadata)


def prepare_combination_rule_frame(data: pd.DataFrame, target_info: dict[str, Any], numeric_columns: list[str], categorical_columns: list[str], top_n_categories: int = 20, max_numeric_bins: int = 5) -> tuple[pd.DataFrame, pd.DataFrame]:
    numeric_binned, meta = discretize_rule_numeric_features(data, numeric_columns, max_numeric_bins)
    frame = pd.DataFrame(index=data.index)
    for column in categorical_columns:
        values = data[column].astype("string").fillna("UNKNOWN")
        if values.nunique(dropna=True) > top_n_categories:
            top = values.value_counts().head(top_n_categories).index
            values = values.where(values.isin(top), "OTHER")
        frame[column] = values
    frame = pd.concat([frame, numeric_binned], axis=1)
    if target_info["mode"] in {"binary", "one_vs_rest"}:
        frame["target_flag"] = data["target_flag"].astype(int).to_numpy()
    else:
        frame["target_class"] = data["target_class"].map(normalize_target_text).to_numpy()
        if target_info["mode"] == "ordinal": frame["target_ordinal"] = pd.to_numeric(data["target_ordinal"], errors="coerce").to_numpy()
    return frame, meta


def mine_exhaustive_combinations(data: pd.DataFrame, target_info: dict[str, Any], max_len: int = 3, min_support: int = 20, min_pos: int = 5, min_confidence: float = .35, min_lift: float = 1.3) -> pd.DataFrame:
    excluded={"target_flag","target_class","target_ordinal"}; features=[c for c in data.columns if c not in excluded]; results=[]
    if target_info["mode"] in {"binary", "one_vs_rest"}:
        global_rates={target_info["class_label"]: float(data["target_flag"].mean())}
    else:
        global_rates=data["target_class"].value_counts(normalize=True).to_dict()
    for length in range(1, max_len+1):
        for cols in combinations(features, length):
            if target_info["mode"] in {"binary", "one_vs_rest"}:
                grouped=data.groupby(list(cols),dropna=False)["target_flag"].agg(records="count",class_count="sum").reset_index()
                grouped["target_class"]=target_info["class_label"]; grouped["global_class_rate"]=list(global_rates.values())[0]
            else:
                grouped=data.groupby(list(cols),dropna=False)["target_class"].value_counts().rename("class_count").reset_index()
                support=data.groupby(list(cols),dropna=False).size().rename("records").reset_index(); grouped=grouped.merge(support,on=list(cols)); grouped["global_class_rate"]=grouped["target_class"].map(global_rates)
            grouped["class_rate"]=grouped["class_count"]/grouped["records"]; grouped["lift"]=grouped["class_rate"]/grouped["global_class_rate"].clip(lower=1e-9)
            grouped=grouped[(grouped.records>=min_support)&(grouped.class_count>=min_pos)&(grouped.class_rate>=min_confidence)&(grouped.lift>=min_lift)]
            for _,row in grouped.iterrows():
                lo,hi=wilson_interval(int(row.class_count),int(row.records))
                results.append({"rule_length":length,"rule":" AND ".join(f"{c} = {row[c]}" for c in cols),"features":" | ".join(cols),"target_class":normalize_target_text(row.target_class),"records":int(row.records),"class_count":int(row.class_count),"class_rate":float(row.class_rate),"global_class_rate":float(row.global_class_rate),"lift":float(row.lift),"ci_low":lo,"ci_high":hi})
    cols=["rule_length","rule","features","target_class","records","class_count","class_rate","global_class_rate","lift","ci_low","ci_high","rule_score"]
    if not results:return pd.DataFrame(columns=cols)
    out=pd.DataFrame(results); out["rule_score"]=out.lift*out.class_rate*np.log1p(out.records)*np.sqrt(out.class_count)
    return out.sort_values(["rule_score","lift","records"],ascending=False).reset_index(drop=True)


def mine_fp_growth_associations(rule_frame: pd.DataFrame, target_info: dict[str, Any], min_support: float, min_confidence: float, min_lift: float, max_len: int) -> tuple[pd.DataFrame,pd.DataFrame]:
    excluded={"target_flag","target_class","target_ordinal"}; features=[c for c in rule_frame.columns if c not in excluded]
    output_cols=["rule","target_class","support","confidence","lift","leverage","conviction"]
    if rule_frame.empty or not features:return pd.DataFrame(columns=output_cols),pd.DataFrame()
    parts=[]
    for c in features:
        items=rule_frame[c].astype("string").fillna("UNKNOWN").map(lambda v:f"{c}={v}")
        parts.append(pd.get_dummies(items,prefix="",prefix_sep="").astype(bool))
    basket=pd.concat(parts,axis=1)
    if basket.shape[1] > 500:
        support = basket.mean(axis=0).sort_values(ascending=False)
        keep = support[support >= float(min_support)].head(500).index
        basket = basket.loc[:, keep]
    if basket.shape[1] == 0:
        return pd.DataFrame(columns=output_cols),pd.DataFrame()
    if target_info["mode"] in {"binary","one_vs_rest"}:
        name=f"TARGET={target_info['class_label']}"; basket[name]=rule_frame.target_flag.fillna(0).astype(bool).to_numpy(); target_items={name}
    else:
        td=pd.get_dummies(rule_frame.target_class.astype(str).map(lambda v:f"TARGET={v}"),prefix="",prefix_sep="").astype(bool); basket=pd.concat([basket,td],axis=1); target_items=set(td.columns)
    fi=fpgrowth(basket,min_support=float(min_support),use_colnames=True,max_len=int(max_len))
    if fi.empty:return pd.DataFrame(columns=output_cols),fi
    rules=mlxtend_association_rules(fi,metric="confidence",min_threshold=float(min_confidence))
    if rules.empty:return pd.DataFrame(columns=output_cols),fi
    rules=rules[rules.consequents.apply(lambda x:len(x)==1 and next(iter(x)) in target_items)].copy(); rules=rules[rules.lift>=float(min_lift)].copy()
    if rules.empty:return pd.DataFrame(columns=output_cols),fi
    rules["target_class"]=rules.consequents.apply(lambda x:next(iter(x)).replace("TARGET=","")); rules["rule"]=rules.antecedents.apply(lambda x:" AND ".join(sorted(x)))+" => TARGET="+rules.target_class
    return rules.sort_values(["lift","confidence","support"],ascending=False)[output_cols].reset_index(drop=True),fi


def _safe_scalar_missing(value: Any) -> bool:
    try:
        result=pd.isna(value)
        return bool(result) if isinstance(result,(bool,np.bool_)) else False
    except Exception:return False


def _clean_rule_value(value: Any) -> str:
    if _safe_scalar_missing(value):return "UNKNOWN"
    text=str(value).strip();return text if text else "UNKNOWN"


def apply_equality_rule(data: pd.DataFrame, rule: Any) -> pd.Series:
    mask=pd.Series(True,index=data.index,dtype=bool)
    if _safe_scalar_missing(rule) or not isinstance(rule,str) or not rule.strip():return pd.Series(False,index=data.index,dtype=bool)
    for condition in rule.split(" AND "):
        if " = " not in condition:return pd.Series(False,index=data.index,dtype=bool)
        feature,expected=condition.split(" = ",1);feature=feature.strip()
        if not feature or feature not in data.columns:return pd.Series(False,index=data.index,dtype=bool)
        actual=data[feature].astype("string").fillna("UNKNOWN").str.strip();mask=mask&actual.eq(expected.strip()).fillna(False)
    return mask.fillna(False).astype(bool)


def extract_decision_tree_rules(tree: DecisionTreeClassifier, feature_names: list[str]) -> pd.DataFrame:
    columns=["rule","weighted_records","predicted_target_class","predicted_class_rate","class_distribution"]
    if tree is None or not hasattr(tree,"tree_"):return pd.DataFrame(columns=columns)
    structure=tree.tree_; labels=[normalize_target_text(x) for x in tree.classes_]; output=[]
    def rec(node,conds):
        idx=structure.feature[node]
        if idx!=_tree.TREE_UNDEFINED:
            name=feature_names[idx] if 0<=idx<len(feature_names) else f"feature_{idx}";thr=float(structure.threshold[node]);rec(structure.children_left[node],conds+[f"{name} <= {thr:.4f}"]);rec(structure.children_right[node],conds+[f"{name} > {thr:.4f}"])
        else:
            counts=np.asarray(structure.value[node]).reshape(-1);total=float(np.nansum(counts));best=int(np.nanargmax(counts)) if counts.size else 0
            distribution=" | ".join(f"{labels[i]}:{float(counts[i]):.2f}" for i in range(min(len(labels),len(counts))))
            output.append({"rule":" AND ".join(conds) if conds else "ALL RECORDS","weighted_records":total,"predicted_target_class":labels[best] if labels else "","predicted_class_rate":float(counts[best]/total) if total else 0.0,"class_distribution":distribution})
    rec(0,[])
    return pd.DataFrame(output,columns=columns).sort_values(["predicted_class_rate","weighted_records"],ascending=False).reset_index(drop=True)


def finalize_rules_workflow(source_data: pd.DataFrame, target_config: dict[str,Any], combination_result: dict[str,Any]|None, tree_max_depth:int, tree_min_leaf:int, test_size:float, random_state:int) -> dict[str,Any]:
    warnings=[]; target_column=target_config["target_column"]
    work,target_info=prepare_target_analysis(source_data,target_column,target_config["mode"],target_config.get("positive_class",""),target_config.get("focus_class",""),target_config.get("target_classes"),target_config.get("ordinal_mapping_text",""))
    groups=classify_columns(work); date_cols=set(groups.get("datetime",[])); excluded={target_column,"target_flag","target_class","target_ordinal"}; features=[c for c in work.columns if c not in excluded and c not in date_cols]
    if not features:raise ValueError("No eligible model features remain after excluding target and date/time columns.")
    X=work[features].copy(); numeric=[c for c in features if pd.api.types.is_numeric_dtype(X[c])]; categorical=[c for c in features if c not in numeric]
    for c in numeric:X[c]=pd.to_numeric(X[c],errors="coerce").replace([np.inf,-np.inf],np.nan)
    for c in categorical:
        X[c]=X[c].map(lambda v: np.nan if _safe_scalar_missing(v) or not str(v).strip() else str(v).strip()).astype(object)
    y=work["target_flag"].astype(int) if target_info["mode"] in {"binary","one_vs_rest"} else work["target_class"].map(normalize_target_text)
    counts=y.value_counts(); n_classes=int(counts.size)
    if n_classes<2:raise ValueError("Model validation requires at least two target classes.")
    if int(counts.min())<2:raise ValueError("Each target class requires at least two rows for stratified validation.")
    transformers=[]
    if numeric:transformers.append(("num",Pipeline([("imp",SimpleImputer(strategy="median"))]),numeric))
    if categorical:transformers.append(("cat",Pipeline([("imp",SimpleImputer(strategy="most_frequent")),("enc",OneHotEncoder(handle_unknown="ignore",min_frequency=5))]),categorical))
    prep=ColumnTransformer(transformers,remainder="drop"); model=DecisionTreeClassifier(max_depth=int(tree_max_depth),min_samples_leaf=int(tree_min_leaf),class_weight="balanced",random_state=int(random_state));pipe=Pipeline([("prep",prep),("model",model)])
    X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=float(test_size),stratify=y,random_state=int(random_state));pipe.fit(X_train,y_train);pred=pipe.predict(X_test);proba=pipe.predict_proba(X_test);classes=[normalize_target_text(x) for x in pipe.named_steps["model"].classes_]
    report=pd.DataFrame(classification_report(y_test,pred,output_dict=True,zero_division=0)).T.reset_index(names="class");matrix=confusion_matrix(y_test,pred,labels=pipe.named_steps["model"].classes_);confusion=pd.DataFrame(matrix,index=[f"Actual {c}" for c in classes],columns=[f"Predicted {c}" for c in classes])
    roc_auc=np.nan;pr_auc=np.nan
    try:
        if n_classes==2:
            positive_proba=proba[:,1]; actual_binary=(pd.Series(y_test).reset_index(drop=True)==pipe.named_steps["model"].classes_[1]).astype(int);roc_auc=float(roc_auc_score(actual_binary,positive_proba));pr_auc=float(average_precision_score(actual_binary,positive_proba))
        else:
            y_bin=label_binarize(y_test,classes=pipe.named_steps["model"].classes_);roc_auc=float(roc_auc_score(y_bin,proba,multi_class="ovr",average="weighted"));pr_auc=float(average_precision_score(y_bin,proba,average="weighted"))
    except Exception as exc:warnings.append(f"Aggregate AUC metrics were unavailable: {exc}")
    names=list(pipe.named_steps["prep"].get_feature_names_out());tree_rules=extract_decision_tree_rules(pipe.named_steps["model"],names);tree_text=export_text(pipe.named_steps["model"],feature_names=names,decimals=3)
    if n_classes==2 and target_info["mode"] in {"binary","one_vs_rest"}:
        scored=pd.DataFrame({"actual":pd.Series(y_test).to_numpy(),"score":proba[:,1]});q=max(1,min(10,int(scored.score.nunique()),len(scored)))
        try:scored["risk_band"]=pd.qcut(scored.score,q=q,duplicates="drop").astype(str) if q>=2 else "D1"
        except Exception:scored["risk_band"]="D1"
        risk=scored.groupby("risk_band",dropna=False).agg(records=("actual","size"),class_count=("actual","sum"),average_score=("score","mean")).reset_index();risk["class_rate"]=risk.class_count/risk.records;risk["target_class"]=target_info["class_label"]
    else:
        rows=[];yt=pd.Series(y_test).reset_index(drop=True);pp=pd.Series(pred)
        for i,c in enumerate(classes):
            actual=yt.astype(str).eq(c); predicted=pp.astype(str).eq(c);correct=actual&predicted
            rows.append({"target_class":c,"actual_records":int(actual.sum()),"predicted_records":int(predicted.sum()),"correct_predictions":int(correct.sum()),"class_recall":float(correct.sum()/actual.sum()) if actual.sum() else np.nan,"class_precision":float(correct.sum()/predicted.sum()) if predicted.sum() else np.nan,"average_probability":float(proba[:,i].mean())})
        risk=pd.DataFrame(rows)
    combination_rules=pd.DataFrame();validated=pd.DataFrame()
    if isinstance(combination_result,dict) and isinstance(combination_result.get("rules"),pd.DataFrame):
        combination_rules=combination_result["rules"].copy();settings=combination_result.get("settings",{}) if isinstance(combination_result.get("settings",{}),dict) else {}
        num=[c for c in groups.get("numeric",[]) if c not in excluded];cat=[c for c in groups.get("categorical",[])+groups.get("boolean",[]) if c not in excluded]
        frame,_=prepare_combination_rule_frame(work,target_info,num,cat,int(settings.get("top_n_categories",20) or 20),int(settings.get("max_numeric_bins",5) or 5))
        train_idx,test_idx=train_test_split(frame.index,test_size=float(test_size),stratify=y,random_state=int(random_state));train_frame,test_frame=frame.loc[train_idx],frame.loc[test_idx]
        rows=[]
        for _,r in combination_rules.head(500).iterrows():
            cls=normalize_target_text(r.get("target_class",target_info.get("class_label","")));tm=apply_equality_rule(train_frame,r.get("rule"));em=apply_equality_rule(test_frame,r.get("rule"));trn=int(tm.sum());ten=int(em.sum())
            if target_info["mode"] in {"binary","one_vs_rest"}:ty=train_frame.target_flag.astype(int);ey=test_frame.target_flag.astype(int);tb=max(float(ty.mean()),1e-9);eb=max(float(ey.mean()),1e-9)
            else:ty=train_frame.target_class.astype(str).eq(cls).astype(int);ey=test_frame.target_class.astype(str).eq(cls).astype(int);tb=max(float(ty.mean()),1e-9);eb=max(float(ey.mean()),1e-9)
            trc=int(ty.loc[tm].sum()) if trn else 0;tec=int(ey.loc[em].sum()) if ten else 0;trr=trc/trn if trn else np.nan;ter=tec/ten if ten else np.nan
            rows.append({"rule":_clean_rule_value(r.get("rule")),"target_class":cls,"train_records":trn,"train_class_rate":trr,"train_lift":trr/tb if trn else np.nan,"test_records":ten,"test_class_count":tec,"test_class_rate":ter,"test_lift":ter/eb if ten else np.nan,"rate_drop":trr-ter if trn and ten else np.nan})
        validated=pd.DataFrame(rows).sort_values(["test_lift","test_records"],ascending=False,na_position="last") if rows else pd.DataFrame()
    else:warnings.append("Evaluate Combination Mining before finalization to include holdout-validated business rules.")
    final_rules=combination_rules.copy()
    if not final_rules.empty:
        if not validated.empty:final_rules=final_rules.merge(validated,on=["rule","target_class"],how="left")
        final_rules["recommended_action"]=final_rules["lift"].map(lambda x:"Enhanced validation / specialist review" if pd.notna(x) and x>=2 else ("Additional automated checks" if pd.notna(x) and x>=1.5 else "Monitor"));final_rules.insert(0,"rule_id",[f"R{i:04d}" for i in range(1,len(final_rules)+1)])
    ordinal_summary=pd.DataFrame()
    if target_info["mode"]=="ordinal":
        rows=[];rule_features=[c for c in frame.columns if c not in {"target_flag","target_class","target_ordinal"}] if 'frame' in locals() else [];portfolio=float(work.target_ordinal.mean())
        for length in range(1,min(3,len(rule_features))+1):
            for cols in combinations(rule_features,length):
                g=frame.groupby(list(cols),dropna=False).target_ordinal.agg(records="size",average_severity="mean",median_severity="median").reset_index();g=g[g.records>=20]
                for _,r in g.iterrows():rows.append({"rule_length":length,"rule":" AND ".join(f"{c} = {r[c]}" for c in cols),"records":int(r.records),"average_severity":float(r.average_severity),"median_severity":float(r.median_severity),"severity_index":float(r.average_severity/portfolio) if portfolio else np.nan})
        if rows:ordinal_summary=pd.DataFrame(rows).sort_values(["severity_index","records"],ascending=False)
    output=BytesIO()
    with pd.ExcelWriter(output,engine="openpyxl") as writer:
        tree_rules.to_excel(writer,sheet_name="Tree_Rules",index=False);report.to_excel(writer,sheet_name="Model_Metrics",index=False);confusion.to_excel(writer,sheet_name="Confusion_Matrix");risk.to_excel(writer,sheet_name="Model_Performance",index=False)
        if not validated.empty:validated.to_excel(writer,sheet_name="Validated_Rules",index=False)
        if not final_rules.empty:final_rules.to_excel(writer,sheet_name="Final_Business_Rules",index=False)
        if not ordinal_summary.empty:ordinal_summary.to_excel(writer,sheet_name="Ordinal_Severity_Rules",index=False)
    output.seek(0)
    return {"target_info":target_info,"tree_rules":tree_rules,"tree_text":tree_text,"classification_report":report,"confusion_matrix":confusion,"roc_auc":roc_auc,"pr_auc":pr_auc,"risk_bands":risk,"validated_rules":validated,"final_rules":final_rules,"ordinal_rules":ordinal_summary,"excel":output.getvalue(),"warnings":warnings,"train_rows":len(X_train),"test_rows":len(X_test),"features":len(names)}


if active_page == "Explore":
    st.subheader("Exploratory Data Analysis")
    explore_options = {"File 1": df1}
    if df2 is not None:
        explore_options["File 2"] = df2
    if st.session_state.joined_data is not None:
        explore_options["Joined data"] = st.session_state.joined_data
    if st.session_state.filtered_data is not None:
        explore_options["Filtered output"] = st.session_state.filtered_data
    explore_source_name = st.radio("Profile source", explore_options.keys(), horizontal=True, key="explore_profile_source")
    eda_df = explore_options[explore_source_name]
    perf1, perf2, perf3 = st.columns([1.2, 1.2, 2.6], vertical_alignment="bottom")
    explore_execution_mode = perf1.selectbox("Execution mode", ["Fast", "Full"], key="eda_execution_mode", help="Fast mode uses a representative sample for interactive analysis. Full mode scans all rows.")
    explore_max_rows = perf2.number_input("Fast-mode rows", min_value=10000, max_value=1000000, value=100000, step=10000, key="eda_fast_max_rows", disabled=explore_execution_mode == "Full")
    explore_seed = perf3.number_input("Sampling seed", min_value=0, max_value=999999, value=42, step=1, key="eda_sampling_seed", disabled=explore_execution_mode == "Full")
    if eda_df is not None and not eda_df.empty:
        explore_sig = dataframe_signature(eda_df)
        analysis_df = eda_df if explore_execution_mode == "Full" else sampled_explore_frame(eda_df, int(explore_max_rows), int(explore_seed), explore_sig)
        if len(analysis_df) < len(eda_df):
            st.info(f"Fast mode is analysing {len(analysis_df):,} of {len(eda_df):,} rows. Final rule validation can be rerun in Full mode.")
    else:
        analysis_df = eda_df
    if eda_df is None or eda_df.empty:
        st.info("Run the join first. EDA uses the filtered output when available; otherwise it uses the complete joined data.")
    else:
        groups = classify_columns(analysis_df)
        all_columns = list(eda_df.columns)
        numerical_cols = groups["numeric"]
        categorical_cols = groups["categorical"] + groups["boolean"]
        datetime_cols = groups["datetime"]

        st.markdown("#### Descriptive analysis for all features")
        d1, d2, d3, d4 = st.columns(4)
        d1.metric("All features", len(all_columns))
        d2.metric("Numeric / numeric-like", len(numerical_cols))
        d3.metric("Categorical / boolean", len(categorical_cols))
        d4.metric("Date/time", len(datetime_cols))
        st.dataframe(all_column_descriptive_summary(analysis_df), use_container_width=True, hide_index=True)

        control_result_key = "eda_control_selection_result"

        st.markdown("#### Control Selection")
        mode_labels={"Binary":"binary","One vs Rest":"one_vs_rest","Multiclass":"multiclass","Ordinal":"ordinal"}
        c1,c2,c3=st.columns([1.5,1.2,2.2],vertical_alignment="bottom")
        target_column=c1.selectbox("Target column",all_columns,key="eda_control_target_column")
        target_mode_label=c2.selectbox("Target mode",list(mode_labels),key="eda_control_target_mode")
        target_mode=mode_labels[target_mode_label]
        available_classes=[normalize_target_text(x) for x in eda_df[target_column].dropna().unique() if normalize_target_text(x)]
        positive_class=focus_class="";target_classes=[];ordinal_mapping_text=""
        if target_mode=="binary":positive_class=c3.text_input("Positive class",key="eda_control_positive_class")
        elif target_mode=="one_vs_rest":focus_class=c3.selectbox("Focus class",available_classes,key="eda_control_focus_class") if available_classes else ""
        elif target_mode=="multiclass":target_classes=c3.multiselect("Target classes",available_classes,default=available_classes,key="eda_control_target_classes")
        else:
            default_mapping=", ".join(f"{v}:{i+1}" for i,v in enumerate(available_classes));ordinal_mapping_text=c3.text_input("Ordinal mapping (Class:order)",value=default_mapping,key="eda_control_ordinal_mapping")
        _,eval_col=st.columns([4.5,.7],vertical_alignment="center");evaluate=eval_col.button("Evaluate",key="eda_control_evaluate",use_container_width=True)
        control_result_key="eda_control_selection_result"
        if evaluate:
            try:
                work,target_info=prepare_target_analysis(analysis_df,target_column,target_mode,positive_class,focus_class,target_classes,ordinal_mapping_text)
                config={"source":explore_source_name,"target_column":target_column,"mode":target_mode,"positive_class":positive_class,"focus_class":focus_class,"target_classes":target_classes,"ordinal_mapping_text":ordinal_mapping_text,"target_info":target_info,"distribution":target_distribution(work,target_info),"rows":len(work),"execution_mode":explore_execution_mode,"sample_rows":len(analysis_df),"source_rows":len(eda_df)}
                st.session_state[control_result_key]=config
                for key in ["eda_combination_mining_result","eda_association_mining_result","eda_finalize_rules_result"]:st.session_state.pop(key,None)
            except Exception as exc:st.session_state.pop(control_result_key,None);st.error(f"Control evaluation failed: {exc}")
        control=st.session_state.get(control_result_key)
        if isinstance(control,dict) and control.get("source")==explore_source_name:
            distribution=control["distribution"]
            m1,m2,m3=st.columns(3);m1.metric("Evaluated rows",f"{control['rows']:,}");m2.metric("Classes",f"{len(distribution):,}");m3.metric("Largest class rate",f"{distribution['class_rate'].max():.4f}")
            st.dataframe(distribution,use_container_width=True,hide_index=True,column_config={"class_rate":st.column_config.NumberColumn(format="%.4f")})

        categorical_header,categorical_action=st.columns([4.5,.7],vertical_alignment="center")
        categorical_header.markdown("#### Categorical Analysis")
        execute_categorical=categorical_action.button("Evaluate",key="eda_categorical_execute",use_container_width=True)
        if execute_categorical:
            if not isinstance(control,dict) or control.get("source")!=explore_source_name:
                st.info("Evaluate Control Selection to generate class-aware categorical lift results.")
            else:
                try:
                    work,target_info=prepare_target_analysis(analysis_df,control["target_column"],control["mode"],control.get("positive_class",""),control.get("focus_class",""),control.get("target_classes"),control.get("ordinal_mapping_text",""))
                    g=classify_columns(work);eligible=[c for c in g["categorical"]+g["boolean"] if c!=control["target_column"] and work[c].nunique(dropna=True)<=200]
                    results=pd.concat([categorical_lift_summary(work,c,target_info) for c in eligible],ignore_index=True) if eligible else pd.DataFrame()
                    st.session_state["eda_categorical_analysis_result"]={"source":explore_source_name,"mode":explore_execution_mode,"results":results}
                except Exception as exc:
                    st.session_state.pop("eda_categorical_analysis_result",None);st.error(f"Categorical analysis could not complete: {exc}")
        cat_result=st.session_state.get("eda_categorical_analysis_result")
        if isinstance(cat_result,dict) and cat_result.get("source")==explore_source_name:
            results=cat_result.get("results",pd.DataFrame())
            if results.empty:st.info("No eligible categorical columns were found.")
            else:st.dataframe(results.sort_values(["lift","records"],ascending=False),use_container_width=True,hide_index=True,column_config={"class_rate":st.column_config.NumberColumn(format="%.4f"),"global_class_rate":st.column_config.NumberColumn(format="%.4f"),"lift":st.column_config.NumberColumn(format="%.4f"),"ci_low":st.column_config.NumberColumn(format="%.4f"),"ci_high":st.column_config.NumberColumn(format="%.4f")})
        else:
            st.info("Click Evaluate to run categorical analysis.")

        combination_header,combination_action=st.columns([4.5,.7],vertical_alignment="center");combination_header.markdown("#### Combination Mining");execute_combination=combination_action.button("Evaluate",key="eda_combination_execute",use_container_width=True)
        with st.expander("Combination Mining settings",expanded=False):
            a,b,c,d=st.columns(4);max_len=a.number_input("Maximum rule length",1,3,2,key="eda_combination_max_len");min_support=b.number_input("Minimum support count",1,1000000,20,key="eda_combination_min_support");min_class=c.number_input("Minimum class count",1,1000000,5,key="eda_combination_min_class");min_conf=d.number_input("Minimum confidence",0.0,1.0,.35,.05,key="eda_combination_min_conf")
            e,f,g,h=st.columns(4);min_lift=e.number_input("Minimum lift",0.0,100.0,1.3,.1,key="eda_combination_min_lift");top_n=f.number_input("Top categories per feature",2,100,20,key="eda_combination_top_n");max_bins=g.number_input("Maximum numeric bins",2,10,5,key="eda_combination_bins");max_features=h.number_input("Maximum mining features",2,20,10,key="eda_combination_max_features")
        if execute_combination:
            if not isinstance(control,dict) or control.get("source")!=explore_source_name:st.warning("Evaluate Control Selection before combination mining.")
            else:
                try:
                    work,target_info=prepare_target_analysis(analysis_df,control["target_column"],control["mode"],control.get("positive_class",""),control.get("focus_class",""),control.get("target_classes"),control.get("ordinal_mapping_text",""));g=classify_columns(work);num=[x for x in g["numeric"] if x not in {control["target_column"],"target_ordinal","target_flag"}];cat=[x for x in g["categorical"]+g["boolean"] if x not in {control["target_column"],"target_class"} and work[x].nunique(dropna=True)<=100];selected=(cat+num)[:int(max_features)];cat=[x for x in selected if x in cat];num=[x for x in selected if x in num];estimated=candidate_combination_count(len(selected),int(max_len));
                    if estimated>50000:raise ValueError(f"Estimated candidate combinations ({estimated:,}) exceed the safe limit of 50,000. Reduce maximum mining features or rule length.")
                    frame,meta=prepare_combination_rule_frame(work,target_info,num,cat,int(top_n),int(max_bins));rules=mine_exhaustive_combinations(frame,target_info,int(max_len),int(min_support),int(min_class),float(min_conf),float(min_lift));st.session_state["eda_combination_mining_result"]={"source":explore_source_name,"rules":rules,"frame":frame,"bin_metadata":meta,"target_info":target_info,"settings":{"top_n_categories":int(top_n),"max_numeric_bins":int(max_bins)}}
                except Exception as exc:st.error(f"Combination mining could not complete: {exc}")
        cr=st.session_state.get("eda_combination_mining_result")
        if isinstance(cr,dict) and cr.get("source")==explore_source_name:
            if cr["rules"].empty:st.info("No combinations met the configured thresholds.")
            else:st.dataframe(cr["rules"].head(1000),use_container_width=True,hide_index=True);st.download_button("Download combination rules",cr["rules"].to_csv(index=False).encode(),"combination_rules.csv","text/csv",key="eda_download_combination_rules")

        association_header,association_action=st.columns([4.5,.7],vertical_alignment="center");association_header.markdown("#### Association Mining");execute_association=association_action.button("Evaluate",key="eda_association_execute",use_container_width=True)
        with st.expander("Association Mining settings",expanded=False):
            a,b,c,d=st.columns(4);asup=a.number_input("Minimum support",0.001,1.0,.02,.01,key="eda_assoc_support");aconf=b.number_input("Minimum confidence",0.0,1.0,.35,.05,key="eda_assoc_conf");alift=c.number_input("Minimum lift",0.0,100.0,1.3,.1,key="eda_assoc_lift");alen=d.number_input("Maximum itemset length",2,10,4,key="eda_assoc_len")
        if execute_association:
            if not isinstance(control,dict) or control.get("source")!=explore_source_name:st.warning("Evaluate Control Selection before association mining.")
            else:
                try:
                    cr=st.session_state.get("eda_combination_mining_result")
                    if not isinstance(cr,dict) or cr.get("source")!=explore_source_name:
                        work,target_info=prepare_target_analysis(analysis_df,control["target_column"],control["mode"],control.get("positive_class",""),control.get("focus_class",""),control.get("target_classes"),control.get("ordinal_mapping_text",""));g=classify_columns(work);num=[x for x in g["numeric"] if x not in {control["target_column"],"target_ordinal","target_flag"}];cat=[x for x in g["categorical"]+g["boolean"] if x not in {control["target_column"],"target_class"}];frame,meta=prepare_combination_rule_frame(work,target_info,num,cat,20,5)
                    else:frame=cr["frame"];meta=cr["bin_metadata"];target_info=cr["target_info"]
                    rules,fi=mine_fp_growth_associations(frame,target_info,float(asup),float(aconf),float(alift),int(alen));st.session_state["eda_association_mining_result"]={"source":explore_source_name,"rules":rules,"frequent_itemsets":fi,"bin_metadata":meta,"target_info":target_info}
                except Exception as exc:st.error(f"Association mining could not complete: {exc}")
        ar=st.session_state.get("eda_association_mining_result")
        if isinstance(ar,dict) and ar.get("source")==explore_source_name:
            if ar["rules"].empty:st.info("No class-target association rules met the thresholds.")
            else:st.dataframe(ar["rules"].head(1000),use_container_width=True,hide_index=True);st.download_button("Download association rules",ar["rules"].to_csv(index=False).encode(),"association_rules.csv","text/csv",key="eda_download_association_rules")

        finalize_header,finalize_action=st.columns([4.5,.7],vertical_alignment="center");finalize_header.markdown("#### Finalize Rules");execute_finalize=finalize_action.button("Evaluate",key="eda_finalize_execute",use_container_width=True)
        with st.expander("Finalize Rules settings",expanded=False):
            a,b,c,d=st.columns(4);depth=a.number_input("Tree maximum depth",1,20,5,key="eda_finalize_depth");leaf=b.number_input("Minimum samples per leaf",1,10000,20,key="eda_finalize_leaf");test=c.number_input("Holdout fraction",.10,.50,.25,.05,key="eda_finalize_test_size");seed=d.number_input("Random seed",0,100000,42,key="eda_finalize_seed")
        if execute_finalize:
            if not isinstance(control,dict) or control.get("source")!=explore_source_name:st.warning("Evaluate Control Selection before finalizing rules.")
            else:
                try:
                    with st.spinner("Training class-aware model and validating rules..."):result=finalize_rules_workflow(eda_df,control,st.session_state.get("eda_combination_mining_result"),int(depth),int(leaf),float(test),int(seed))
                    result.update({"source":explore_source_name,"target_column":control["target_column"],"mode":control["mode"]});st.session_state["eda_finalize_rules_result"]=result
                except Exception as exc:st.session_state.pop("eda_finalize_rules_result",None);st.error(f"Finalize Rules could not complete: {exc}")
        fr=st.session_state.get("eda_finalize_rules_result")
        if isinstance(fr,dict) and fr.get("source")==explore_source_name:
            for w in fr.get("warnings",[]):st.warning(w)
            m1,m2,m3,m4,m5=st.columns(5);m1.metric("Encoded features",fr["features"]);m2.metric("Training rows",fr["train_rows"]);m3.metric("Holdout rows",fr["test_rows"]);m4.metric("ROC-AUC","N/A" if pd.isna(fr["roc_auc"]) else f"{fr['roc_auc']:.4f}");m5.metric("PR-AUC","N/A" if pd.isna(fr["pr_auc"]) else f"{fr['pr_auc']:.4f}")
            tabs=st.tabs(["Final business rules","Validated rules","Tree rules","Model performance","Model validation","Ordinal severity"])
            with tabs[0]:
                if not fr["final_rules"].empty:
                    st.dataframe(fr["final_rules"].head(500), use_container_width=True, hide_index=True)
                else:
                    st.info("Evaluate Combination Mining first or relax thresholds.")
            with tabs[1]:
                if not fr["validated_rules"].empty:
                    st.dataframe(fr["validated_rules"].head(500), use_container_width=True, hide_index=True)
                else:
                    st.info("No mined rules were available for holdout validation.")
            with tabs[2]:
                st.dataframe(fr["tree_rules"], use_container_width=True, hide_index=True)
            with tabs[3]:
                st.dataframe(fr["risk_bands"], use_container_width=True, hide_index=True)
            with tabs[4]:
                st.dataframe(fr["classification_report"], use_container_width=True, hide_index=True)
                st.dataframe(fr["confusion_matrix"], use_container_width=True)
            with tabs[5]:
                if not fr["ordinal_rules"].empty:
                    st.dataframe(fr["ordinal_rules"].head(500), use_container_width=True, hide_index=True)
                else:
                    st.info("Ordinal severity rules are generated only in Ordinal mode.")
            st.download_button("Download complete finalized-rules workbook",fr["excel"],"finalized_rules.xlsx","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",key="eda_download_finalize_workbook")

        time_title_col, time_button_col = st.columns([4.5, .7], vertical_alignment="center")
        with time_title_col:
            st.markdown("#### Time-based analysis")
        with time_button_col:
            execute_time_analysis = st.button(
                "Evaluate", key="eda_execute_time_analysis", use_container_width=True
            )

        if not datetime_cols:
            st.info("No date/time column was detected with at least 90% parseable values.")
            st.session_state.pop("eda_time_analysis_result", None)
        else:
            t1, t2, t3 = st.columns(3)
            date_col = t1.selectbox("Date column", datetime_cols, key="eda_date")
            grain = t2.selectbox("Time grain", ["Daily", "Weekly", "Monthly", "Quarterly", "Yearly"], key="eda_grain")
            measure = t3.selectbox("Measure (any column)", ["Row count"] + all_columns, key="eda_measure")
            aggregation_options = ["count", "nunique"] if measure == "Row count" or measure not in numerical_cols else ["sum", "mean", "median", "min", "max", "count", "nunique"]
            aggregation = st.selectbox("Aggregation", aggregation_options, key="eda_agg")

            if execute_time_analysis:
                try:
                    temp = analysis_df.copy()
                    temp["__date__"] = safe_datetime_series(temp[date_col])
                    temp = temp[temp["__date__"].notna()]
                    if temp.empty:
                        raise ValueError("No valid date/time values are available for the selected date column.")
                    freq = {"Daily":"D", "Weekly":"W", "Monthly":"MS", "Quarterly":"QS", "Yearly":"YS"}[grain]
                    if measure == "Row count":
                        trend = temp.set_index("__date__").resample(freq).size().rename("value").reset_index()
                    elif aggregation == "nunique":
                        trend = temp.set_index("__date__")[measure].resample(freq).nunique().rename("value").reset_index()
                    elif aggregation == "count":
                        trend = temp.set_index("__date__")[measure].resample(freq).count().rename("value").reset_index()
                    else:
                        temp["__measure__"] = safe_numeric_series(temp[measure])
                        trend = temp.set_index("__date__")["__measure__"].resample(freq).agg(aggregation).rename("value").reset_index()
                    trend["period_change_pct"] = trend["value"].pct_change() * 100
                    st.session_state.eda_time_analysis_result = {
                        "trend": trend,
                        "grain": grain,
                        "date_col": date_col,
                        "measure": measure,
                        "aggregation": aggregation,
                    }
                except Exception as exc:
                    st.session_state.pop("eda_time_analysis_result", None)
                    st.error(f"Time-based analysis could not complete: {exc}")

            time_result = st.session_state.get("eda_time_analysis_result")
            if time_result:
                trend = time_result["trend"]
                plot_chart(
                    px.line(
                        trend, x="__date__", y="value", markers=True,
                        title=f"{time_result['grain']} trend",
                    ),
                    use_container_width=True,
                )
                st.dataframe(trend.rename(columns={"__date__":"period"}), use_container_width=True, hide_index=True)
                st.caption(
                    f"Last executed for `{time_result['date_col']}` using "
                    f"`{time_result['aggregation']}` on `{time_result['measure']}`."
                )
            else:
                st.info("Select the time-analysis settings and click Evaluate to calculate the trend.")

        corr_title_col, corr_button_col = st.columns([4.5, .7], vertical_alignment="center")
        with corr_title_col:
            st.markdown("#### Correlation and association analysis")
        with corr_button_col:
            execute_correlation_analysis = st.button(
                "Evaluate", key="eda_execute_correlation_analysis", use_container_width=True
            )
        selected_assoc = st.multiselect(
            "Select columns of any type", all_columns, default=all_columns[:15],
            key="eda_assoc", help="All columns are selected by default. Remove columns to narrow the analysis."
        )
        selected_algorithms = st.multiselect(
            "Correlation algorithms", ["Pearson", "Spearman", "Kendall"],
            default=["Spearman"], key="eda_corr_algorithms"
        )
        if execute_correlation_analysis:
            if len(selected_assoc) > 20:
                st.session_state.pop("eda_correlation_analysis_result", None)
                st.warning("Select no more than 20 columns for one correlation run.")
            elif len(selected_assoc) < 2:
                st.session_state.pop("eda_correlation_analysis_result", None)
                st.warning("Select at least two columns before executing correlation and association analysis.")
            elif not selected_algorithms:
                st.session_state.pop("eda_correlation_analysis_result", None)
                st.warning("Select at least one correlation algorithm before executing the analysis.")
            else:
                try:
                    calculated_matrices: dict[str, pd.DataFrame] = {}
                    for algorithm in selected_algorithms:
                        calculated_matrices[algorithm] = encoded_association(
                            analysis_df, selected_assoc, method=algorithm.lower()
                        )
                    st.session_state.eda_correlation_analysis_result = {
                        "matrices": calculated_matrices,
                        "columns": list(selected_assoc),
                        "algorithms": list(selected_algorithms),
                    }
                    st.session_state.eda_deep_dive_enabled = False
                except Exception as exc:
                    st.session_state.pop("eda_correlation_analysis_result", None)
                    st.error(f"Correlation and association analysis could not complete: {exc}")

        correlation_result = st.session_state.get("eda_correlation_analysis_result")
        if correlation_result:
            association_matrices: dict[str, pd.DataFrame] = correlation_result["matrices"]
            for algorithm, assoc in association_matrices.items():
                method = algorithm.lower()
                # Each algorithm gets its own bounded result section. Horizontal
                # movement is handled inside its AG Grid rather than by the full
                # Explore page or the combined analysis division.
                with st.container(border=True):
                    st.markdown(f"##### {algorithm} correlation / association")
                    st.caption("Scroll horizontally inside the result grid to view additional value columns. Select any colored value cell to filter and open its source records.")
                    selected_left, selected_right = clickable_heatmap_table(
                        assoc, key_prefix=f"eda_assoc_cell_{method}", disable_diagonal=True
                    )
                    if selected_left and selected_right:
                        matching = analysis_df[
                            analysis_df[selected_left].notna() & analysis_df[selected_right].notna()
                        ]
                        register_deep_dive_popup(
                            matching,
                            f"{algorithm}: {selected_left} ↔ {selected_right}",
                            f"Filter applied: `{selected_left}` is not missing AND `{selected_right}` is not missing.",
                            {
                                "drill_type": "correlation_cell",
                                "algorithm": algorithm,
                                "left": selected_left,
                                "right": selected_right,
                                "association": safe_python_scalar(assoc.loc[selected_left, selected_right]),
                            },
                            filter_spec={"type": "non_missing_pair", "left": selected_left, "right": selected_right},
                        )
                    st.markdown(f"**{algorithm} summary**")
                    st.markdown(correlation_summary_text(assoc))
            st.caption("Numeric-like fields are converted, dates use timestamps, and categorical values are factor-encoded. Pearson measures linear association, Spearman rank association, and Kendall ordinal concordance.")

            qualifying_pairs = association_pairs_by_strength(association_matrices)
            if st.button("Deep Dive", type="primary", key="eda_deep_dive_button"):
                st.session_state.eda_deep_dive_enabled = True

            if st.session_state.get("eda_deep_dive_enabled", False):
                st.markdown("#### Deep Dive: medium and high associations")
                if not qualifying_pairs:
                    st.info("No medium or high associations were found using the selected columns and algorithms.")
                else:
                    st.caption(
                        f"Analysing {len(qualifying_pairs):,} unique feature pairs with an absolute association of 0.40 or above. "
                        "Pairs detected by more than one algorithm are shown once using their strongest result."
                    )
                    for pair_number, pair in enumerate(qualifying_pairs, start=1):
                        left = pair["left"]
                        right = pair["right"]
                        left_semantic = infer_semantic_type(eda_df[left])
                        right_semantic = infer_semantic_type(eda_df[right])
                        left_numeric = left_semantic in {"numerical", "numeric-like text"}
                        right_numeric = right_semantic in {"numerical", "numeric-like text"}
                        title = (
                            f'{pair_number}. {left} ↔ {right} — {pair["strength"]} '
                            f'({pair["association"]:+.2f}, {pair["algorithm"]})'
                        )
                        with st.expander(title, expanded=True):
                            if left_numeric != right_numeric:
                                numeric_column = left if left_numeric else right
                                categorical_column = right if left_numeric else left
                                aggregation_table = grouped_deep_dive_aggregations(
                                    eda_df, categorical_column, numeric_column
                                )
                                st.markdown(
                                    f"**Numeric feature:** `{numeric_column}`  ·  "
                                    f"**Categorical feature:** `{categorical_column}`"
                                )
                                st.dataframe(aggregation_table, use_container_width=True, hide_index=True)
                            else:
                                cross_tab, cross_tab_note = deep_dive_crosstab(eda_df, left, right)
                                pair_type = "numeric–numeric" if left_numeric else "categorical–categorical"
                                st.markdown(f"**Pair type:** {pair_type}")
                                if cross_tab_note:
                                    st.caption(cross_tab_note + ".")
                                st.caption("Select any colored count cell to apply that exact combination and open its records.")
                                selected_left_value, selected_right_value = clickable_heatmap_table(
                                    cross_tab,
                                    key_prefix=f"eda_deep_dive_cell_{pair_number}",
                                    value_format="count",
                                )
                                if selected_left_value is not None and selected_right_value is not None:
                                    prepared_left, _ = deep_dive_prepared_series(eda_df, left)
                                    prepared_right, _ = deep_dive_prepared_series(eda_df, right)
                                    matching_mask = (
                                        prepared_left.astype("string") == selected_left_value
                                    ) & (
                                        prepared_right.astype("string") == selected_right_value
                                    )
                                    matching = eda_df[matching_mask]
                                    register_deep_dive_popup(
                                        matching,
                                        f"{left} = {selected_left_value} · {right} = {selected_right_value}",
                                        f"Filter applied: `{left}` = `{selected_left_value}` AND `{right}` = `{selected_right_value}`.",
                                        {
                                            "drill_type": "cross_tab_cell",
                                            "left": left,
                                            "right": right,
                                            "left_value": selected_left_value,
                                            "right_value": selected_right_value,
                                            "pair_strength": pair["strength"],
                                            "association": pair["association"],
                                            "algorithm": pair["algorithm"],
                                        },
                                        filter_spec={
                                            "type": "prepared_pair",
                                            "left": left,
                                            "right": right,
                                            "left_value": selected_left_value,
                                            "right_value": selected_right_value,
                                        },
                                    )

        else:
            st.info("Select columns and algorithms, then click Evaluate to calculate correlation and association results.")

    popup_event_id = int(st.session_state.get("deep_dive_popup_event_id", 0))
    shown_event_id = int(st.session_state.get("deep_dive_popup_shown_event_id", 0))
    if st.session_state.get("deep_dive_popup") and popup_event_id > shown_event_id:
        # Mark consumed before opening. Any later full-app rerun (sidebar,
        # navigation, expanders, etc.) will not reopen this same dialog.
        st.session_state.deep_dive_popup_shown_event_id = popup_event_id
        show_deep_dive_popup()


if active_page == "Audit":
    st.subheader("Audit trail and complete analysis dump")
    audit_df = pd.DataFrame(st.session_state.audit_log)
    if audit_df.empty:
        st.info("Audit entries appear after you run joins, add/apply filters, create pivots/charts, or download outputs.")
    else:
        st.dataframe(audit_df, use_container_width=True, hide_index=True)

    output_df = st.session_state.filtered_data
    if output_df is None:
        output_df = st.session_state.joined_data
    if output_df is None:
        output_df = df1

    metadata = {
        "analysis_name": st.session_state.analysis_name,
        "created_at": utc_now(),
        "dataset_1": ({
            "source_type": "upload", "name": file_1.name, "sheet": sheet_1,
            "sha256_prefix": file_fingerprint(bytes_1), "rows": len(df1),
        } if source_type_1 == "Upload file" else {
            "source_type": "database_query", "database_type": db_meta_1.get("database_type"),
            "endpoint": db_meta_1.get("host") or db_meta_1.get("server_hostname"),
            "database": db_meta_1.get("database"), "catalog": db_meta_1.get("catalog"),
            "schema": db_meta_1.get("schema"),
            "query_hash": hashlib.sha256(db_meta_1.get("query", "").encode("utf-8")).hexdigest()[:16],
            "rows": len(df1),
        }),
        "dataset_2": (({
            "source_type": "upload", "name": file_2.name, "sheet": sheet_2,
            "sha256_prefix": file_fingerprint(bytes_2), "rows": len(df2),
        } if source_type_2 == "Upload file" else {
            "source_type": "database_query", "database_type": db_meta_2.get("database_type"),
            "endpoint": db_meta_2.get("host") or db_meta_2.get("server_hostname"),
            "database": db_meta_2.get("database"), "catalog": db_meta_2.get("catalog"),
            "schema": db_meta_2.get("schema"),
            "query_hash": hashlib.sha256(db_meta_2.get("query", "").encode("utf-8")).hexdigest()[:16],
            "rows": len(df2),
        }) if df2 is not None else None),
        "join_config": st.session_state.join_config,
        "filter_config": st.session_state.last_filter_config,
        "output_rows": len(output_df),
        "output_columns": list(output_df.columns),
    }
    dump = build_dump(output_df, st.session_state.filters, metadata)
    st.download_button(
        "Download complete analysis dump (.zip)", dump,
        file_name=f"{st.session_state.analysis_name}_dump.zip", mime="application/zip",
        on_click=lambda: audit("ANALYSIS_DUMP_DOWNLOADED", {"rows": len(output_df), "audit_entries": len(st.session_state.audit_log)}),
        disabled=output_df.empty,
    )
    st.caption("The dump contains output.xlsx, output.csv, filters.json, audit_log.csv/json, and session_metadata.json.")
