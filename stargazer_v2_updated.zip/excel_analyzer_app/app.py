from __future__ import annotations

from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
from typing import Any
import hashlib
import json
import zipfile

import pandas as pd
import plotly.express as px
import streamlit as st
from st_aggrid import AgGrid, GridOptionsBuilder, DataReturnMode, GridUpdateMode

st.set_page_config(page_title="Stargazer", layout="wide")

st.markdown(
    """
    <style>
    html, body, [class*="css"], [data-testid="stAppViewContainer"],
    [data-testid="stSidebar"], button, input, textarea, select {
        font-family: Verdana, Geneva, sans-serif !important;
    }
    [data-testid="stHeader"]::before {
        content: "Stargazer";
        position: absolute;
        left: 4rem;
        top: 0.70rem;
        z-index: 1001;
        font-family: Verdana, Geneva, sans-serif;
        font-size: 1.05rem;
        font-weight: 700;
        color: var(--text-color);
    }
    [data-testid="stHeader"] {
        background: color-mix(in srgb, var(--background-color) 94%, transparent);
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.caption(
    "Upload two files, join them, create visible AND/OR filters, explore the joined result, "
    "save filter definitions, and download a complete auditable analysis package."
)

OPERATORS = [
    "equals", "not equals", "contains", "does not contain", "starts with", "ends with",
    "greater than", "greater than or equal", "less than", "less than or equal",
    "between", "in list", "not in list", "is blank", "is not blank",
]


def init_state() -> None:
    defaults: dict[str, Any] = {
        "filters": [],
        "audit_log": [],
        "joined_data": None,
        "filtered_data": None,
        "join_config": {},
        "last_filter_config": {},
        "analysis_name": "excel_analysis",
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def utc_now() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def audit(action: str, details: dict[str, Any] | None = None) -> None:
    st.session_state.audit_log.append({
        "timestamp": utc_now(),
        "action": action,
        "details": json.dumps(details or {}, ensure_ascii=False, default=str),
    })


def file_fingerprint(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()[:16]


@st.cache_data(show_spinner=False)
def get_sheet_names(file_bytes: bytes, filename: str) -> list[str]:
    if filename.lower().endswith(".csv"):
        return ["CSV"]
    return pd.ExcelFile(BytesIO(file_bytes)).sheet_names


@st.cache_data(show_spinner=False)
def load_table(file_bytes: bytes, filename: str, sheet_name: str | None) -> pd.DataFrame:
    """Read Excel or CSV files with resilient CSV encoding/delimiter handling."""
    stream = BytesIO(file_bytes)
    if filename.lower().endswith(".csv"):
        encodings = ["utf-8-sig", "utf-8", "cp1252", "latin-1"]
        last_error: Exception | None = None
        for encoding in encodings:
            try:
                stream.seek(0)
                # sep=None lets pandas detect comma, semicolon, tab, or pipe-delimited files.
                return pd.read_csv(
                    stream, encoding=encoding, sep=None, engine="python",
                    on_bad_lines="warn"
                )
            except (UnicodeDecodeError, UnicodeError, pd.errors.ParserError) as exc:
                last_error = exc
        raise ValueError(
            "CSV could not be decoded using UTF-8, Windows-1252, or Latin-1. "
            f"Last error: {last_error}"
        )
    return pd.read_excel(stream, sheet_name=sheet_name)


def make_unique_columns(df: pd.DataFrame, source: str) -> pd.DataFrame:
    result = df.copy()
    counts: dict[str, int] = {}
    columns: list[str] = []
    for raw in result.columns:
        col = str(raw).strip() or "Unnamed"
        counts[col] = counts.get(col, 0) + 1
        unique = col if counts[col] == 1 else f"{col}_{counts[col]}"
        columns.append(f"{source}.{unique}")
    result.columns = columns
    return result


def normalize_key(series: pd.Series, trim: bool, lower: bool) -> pd.Series:
    result = series.astype("string")
    if trim:
        result = result.str.strip()
    if lower:
        result = result.str.lower()
    return result


def json_bytes(value: Any) -> bytes:
    return json.dumps(value, indent=2, ensure_ascii=False, default=str).encode("utf-8")


def to_excel_bytes(sheets: dict[str, pd.DataFrame]) -> bytes:
    output = BytesIO()
    with pd.ExcelWriter(output, engine="xlsxwriter") as writer:
        for sheet_name, df in sheets.items():
            safe_name = sheet_name[:31]
            df.to_excel(writer, index=False, sheet_name=safe_name)
            worksheet = writer.sheets[safe_name]
            for index, column in enumerate(df.columns):
                if df.empty:
                    sample_width = 0
                else:
                    lengths = df[column].head(500).map(
                        lambda value: len(str(value)) if pd.notna(value) else 0
                    )
                    max_width = lengths.max()
                    sample_width = int(max_width) if pd.notna(max_width) else 0
                header_width = len(str(column))
                worksheet.set_column(index, index, min(max(sample_width, header_width) + 2, 50))
    return output.getvalue()


def render_grid(df: pd.DataFrame, key: str) -> pd.DataFrame:
    gb = GridOptionsBuilder.from_dataframe(df)
    gb.configure_default_column(
        sortable=True, filter=True, resizable=True, editable=False,
        enableRowGroup=True, enablePivot=True, enableValue=True,
    )
    gb.configure_grid_options(sideBar=True, rowSelection="multiple", animateRows=True)
    response = AgGrid(
        df, gridOptions=gb.build(), height=480, fit_columns_on_grid_load=False,
        data_return_mode=DataReturnMode.FILTERED_AND_SORTED,
        update_mode=GridUpdateMode.NO_UPDATE, allow_unsafe_jscode=False,
        theme="streamlit", key=key,
    )
    return pd.DataFrame(response.get("data", df))


def condition_mask(df: pd.DataFrame, rule: dict[str, Any]) -> pd.Series:
    column = rule["column"]
    operator = rule["operator"]
    value = str(rule.get("value", ""))
    value2 = str(rule.get("value2", ""))
    case_sensitive = bool(rule.get("case_sensitive", False))
    series = df[column]
    text = series.astype("string")
    left = text if case_sensitive else text.str.lower()
    right = value if case_sensitive else value.lower()

    if operator == "equals": return left == right
    if operator == "not equals": return left != right
    if operator == "contains": return left.str.contains(right, na=False, regex=False)
    if operator == "does not contain": return ~left.str.contains(right, na=False, regex=False)
    if operator == "starts with": return left.str.startswith(right, na=False)
    if operator == "ends with": return left.str.endswith(right, na=False)
    if operator == "is blank": return series.isna() | text.str.strip().eq("")
    if operator == "is not blank": return series.notna() & ~text.str.strip().eq("")
    if operator in {"in list", "not in list"}:
        values = [item.strip() for item in value.split(",") if item.strip()]
        if not case_sensitive:
            values = [item.lower() for item in values]
        mask = left.isin(values)
        return ~mask if operator == "not in list" else mask

    numeric = pd.to_numeric(series, errors="coerce")
    try:
        number = float(value)
    except ValueError as exc:
        raise ValueError(f"'{value}' is not numeric for {column}") from exc
    if operator == "greater than": return numeric > number
    if operator == "greater than or equal": return numeric >= number
    if operator == "less than": return numeric < number
    if operator == "less than or equal": return numeric <= number
    if operator == "between":
        try:
            number2 = float(value2)
        except ValueError as exc:
            raise ValueError(f"'{value2}' is not numeric for the upper bound") from exc
        return numeric.between(min(number, number2), max(number, number2), inclusive="both")
    raise ValueError(f"Unsupported operator: {operator}")


def apply_filter_rules(df: pd.DataFrame, rules: list[dict[str, Any]]) -> pd.DataFrame:
    if not rules:
        return df.copy()
    combined: pd.Series | None = None
    for index, rule in enumerate(rules):
        mask = condition_mask(df, rule).fillna(False)
        if index == 0:
            combined = mask
        elif rule.get("connector", "AND") == "OR":
            combined = combined | mask  # type: ignore[operator]
        else:
            combined = combined & mask  # type: ignore[operator]
    return df[combined].copy() if combined is not None else df.copy()


def filter_summary(rule: dict[str, Any], index: int) -> str:
    prefix = "WHERE" if index == 0 else rule.get("connector", "AND")
    operator = rule["operator"]
    if operator in {"is blank", "is not blank"}:
        return f"{prefix} {rule['column']} {operator}"
    if operator == "between":
        return f"{prefix} {rule['column']} between {rule.get('value', '')} and {rule.get('value2', '')}"
    return f"{prefix} {rule['column']} {operator} {rule.get('value', '')}"


def build_dump(output_df: pd.DataFrame, filters: list[dict[str, Any]], metadata: dict[str, Any]) -> bytes:
    memory = BytesIO()
    audit_df = pd.DataFrame(st.session_state.audit_log)
    with zipfile.ZipFile(memory, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("output.xlsx", to_excel_bytes({"Analysis_Output": output_df, "Audit_Log": audit_df}))
        archive.writestr("output.csv", output_df.to_csv(index=False).encode("utf-8"))
        archive.writestr("filters.json", json_bytes({"version": 1, "filters": filters}))
        archive.writestr("audit_log.json", json_bytes(st.session_state.audit_log))
        archive.writestr("audit_log.csv", audit_df.to_csv(index=False).encode("utf-8"))
        archive.writestr("session_metadata.json", json_bytes(metadata))
    return memory.getvalue()



def infer_semantic_type(series: pd.Series) -> str:
    non_null = series.dropna()
    if non_null.empty:
        return "empty"
    if pd.api.types.is_bool_dtype(series):
        return "boolean"
    if pd.api.types.is_numeric_dtype(series):
        return "numerical"
    if pd.api.types.is_datetime64_any_dtype(series):
        return "datetime"
    text = non_null.astype(str).str.strip()
    numeric_ratio = pd.to_numeric(text.str.replace(",", "", regex=False), errors="coerce").notna().mean()
    date_ratio = pd.to_datetime(text, errors="coerce", dayfirst=False).notna().mean()
    if numeric_ratio >= 0.9:
        return "numeric-like text"
    if date_ratio >= 0.9:
        return "date-like text"
    unique_ratio = text.nunique(dropna=True) / max(len(text), 1)
    return "identifier/text" if unique_ratio > 0.8 else "categorical"


def outlier_mask_iqr(series: pd.Series) -> pd.Series:
    numeric = pd.to_numeric(series, errors="coerce")
    valid = numeric.dropna()
    if len(valid) < 4:
        return pd.Series(False, index=series.index)
    q1, q3 = valid.quantile([0.25, 0.75])
    iqr = q3 - q1
    if pd.isna(iqr) or iqr == 0:
        return pd.Series(False, index=series.index)
    return (numeric < q1 - 1.5 * iqr) | (numeric > q3 + 1.5 * iqr)


def detailed_profile(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    total = len(df)
    for column in df.columns:
        series = df[column]
        non_null = series.dropna()
        semantic = infer_semantic_type(series)
        blank_count = int(series.astype("string").str.strip().eq("").fillna(False).sum())
        outliers = int(outlier_mask_iqr(series).sum()) if semantic in {"numerical", "numeric-like text"} else 0
        invalid = 0
        consistency = 100.0
        if semantic == "numeric-like text":
            converted = pd.to_numeric(non_null.astype(str).str.replace(",", "", regex=False), errors="coerce")
            invalid = int(converted.isna().sum())
            consistency = round((1 - invalid / max(len(non_null), 1)) * 100, 2)
        elif semantic == "date-like text":
            converted = pd.to_datetime(non_null.astype(str), errors="coerce")
            invalid = int(converted.isna().sum())
            consistency = round((1 - invalid / max(len(non_null), 1)) * 100, 2)
        top_values = non_null.astype(str).value_counts().head(5)
        top_text = "; ".join(f"{k} ({v})" for k, v in top_values.items())
        rows.append({
            "column": column, "physical_type": str(series.dtype), "semantic_type": semantic,
            "rows": total, "non_null": int(series.notna().sum()), "missing": int(series.isna().sum()),
            "missing_pct": round(float(series.isna().mean() * 100), 2) if total else 0.0,
            "blank_strings": blank_count, "unique_values": int(series.nunique(dropna=True)),
            "duplicate_values": int(non_null.duplicated(keep=False).sum()),
            "outliers_iqr": outliers, "invalid_values": invalid,
            "type_consistency_pct": consistency, "top_values": top_text,
        })
    return pd.DataFrame(rows)


def quality_summary(df: pd.DataFrame) -> dict[str, int | float]:
    profile = detailed_profile(df)
    return {
        "rows": len(df), "columns": len(df.columns),
        "duplicate_rows": int(df.duplicated().sum()),
        "missing_cells": int(df.isna().sum().sum()),
        "outliers": int(profile["outliers_iqr"].sum()) if not profile.empty else 0,
        "invalid_values": int(profile["invalid_values"].sum()) if not profile.empty else 0,
    }


def detect_datetime_candidates(df: pd.DataFrame) -> list[str]:
    candidates = []
    for column in df.columns:
        series = df[column]
        if pd.api.types.is_datetime64_any_dtype(series):
            candidates.append(column)
            continue
        non_null = series.dropna().head(1000)
        if non_null.empty or pd.api.types.is_numeric_dtype(series):
            continue
        parsed = pd.to_datetime(non_null.astype(str), errors="coerce")
        if parsed.notna().mean() >= 0.8:
            candidates.append(column)
    return candidates


def basic_profile(df: pd.DataFrame) -> pd.DataFrame:
    return pd.DataFrame({
        "column": df.columns,
        "data_type": [str(df[c].dtype) for c in df.columns],
        "non_null": [int(df[c].notna().sum()) for c in df.columns],
        "nulls": [int(df[c].isna().sum()) for c in df.columns],
        "null_pct": [round(float(df[c].isna().mean() * 100), 2) for c in df.columns],
        "distinct": [int(df[c].nunique(dropna=True)) for c in df.columns],
    })


def classify_columns(df: pd.DataFrame) -> dict[str, list[str]]:
    result = {"numeric": [], "categorical": [], "datetime": [], "boolean": [], "empty": []}
    for column in df.columns:
        semantic = infer_semantic_type(df[column])
        if semantic in {"numerical", "numeric-like text"}:
            result["numeric"].append(column)
        elif semantic in {"datetime", "date-like text"}:
            result["datetime"].append(column)
        elif semantic == "boolean":
            result["boolean"].append(column)
        elif semantic == "empty":
            result["empty"].append(column)
        else:
            result["categorical"].append(column)
    return result


def all_column_descriptive_summary(df: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for column in df.columns:
        series = df[column]
        semantic = infer_semantic_type(series)
        non_null = series.dropna()
        row: dict[str, Any] = {
            "column": column,
            "semantic_type": semantic,
            "rows": len(series),
            "non_null": int(series.notna().sum()),
            "missing": int(series.isna().sum()),
            "unique": int(series.nunique(dropna=True)),
            "most_frequent": None,
            "frequency": 0,
            "min": None,
            "max": None,
            "mean": None,
            "median": None,
        }
        if not non_null.empty:
            counts = non_null.astype(str).value_counts()
            row["most_frequent"] = counts.index[0] if not counts.empty else None
            row["frequency"] = int(counts.iloc[0]) if not counts.empty else 0
        if semantic in {"numerical", "numeric-like text"}:
            numeric = pd.to_numeric(non_null.astype(str).str.replace(",", "", regex=False), errors="coerce")
            row.update({
                "min": numeric.min(), "max": numeric.max(),
                "mean": numeric.mean(), "median": numeric.median(),
            })
        elif semantic in {"datetime", "date-like text"}:
            dates = pd.to_datetime(non_null, errors="coerce")
            row["min"], row["max"] = dates.min(), dates.max()
        rows.append(row)
    return pd.DataFrame(rows)


def encoded_association(df: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    encoded = pd.DataFrame(index=df.index)
    for column in columns:
        semantic = infer_semantic_type(df[column])
        if semantic in {"numerical", "numeric-like text"}:
            encoded[column] = pd.to_numeric(
                df[column].astype(str).str.replace(",", "", regex=False), errors="coerce"
            )
        elif semantic in {"datetime", "date-like text"}:
            dates = pd.to_datetime(df[column], errors="coerce")
            encoded[column] = dates.map(lambda x: x.timestamp() if pd.notna(x) else float("nan"))
        else:
            codes, _ = pd.factorize(df[column].astype("string"), sort=True)
            encoded[column] = pd.Series(codes, index=df.index).replace(-1, pd.NA)
    return encoded.corr(method="spearman")


def build_chart_data(
    df: pd.DataFrame, x_col: str, y_col: str | None, aggregation: str,
    chart_type: str, top_n: int,
) -> tuple[pd.DataFrame, str | None]:
    work = df.copy()
    if chart_type in {"Histogram", "Box", "Scatter"}:
        return work, y_col
    if aggregation == "Row count":
        result = work.groupby(x_col, dropna=False).size().rename("__value__").reset_index()
        return result.nlargest(top_n, "__value__"), "__value__"
    if y_col is None:
        return work, None
    if aggregation == "Distinct count":
        result = work.groupby(x_col, dropna=False)[y_col].nunique(dropna=True).rename("__value__").reset_index()
        return result.nlargest(top_n, "__value__"), "__value__"
    numeric = pd.to_numeric(work[y_col].astype(str).str.replace(",", "", regex=False), errors="coerce")
    work = work.assign(__numeric_value__=numeric)
    agg_map = {"Sum": "sum", "Average": "mean", "Median": "median", "Minimum": "min", "Maximum": "max"}
    result = work.groupby(x_col, dropna=False)["__numeric_value__"].agg(agg_map[aggregation]).rename("__value__").reset_index()
    return result.nlargest(top_n, "__value__"), "__value__"


init_state()

with st.sidebar:
    st.header("1. Upload files")
    file_1 = st.file_uploader("File 1", type=["xlsx", "xlsm", "xls", "csv"], key="file_1")
    file_2 = st.file_uploader("File 2", type=["xlsx", "xlsm", "xls", "csv"], key="file_2")
    st.session_state.analysis_name = st.text_input("Analysis name", st.session_state.analysis_name)
    st.divider()
    st.subheader("Selected filter summary")
    filter_summary_placeholder = st.empty()
    if st.session_state.filters:
        filter_summary_placeholder.markdown("\n".join(
            f"**{i + 1}.** `{filter_summary(rule, i)}`"
            for i, rule in enumerate(st.session_state.filters)
        ))
    else:
        filter_summary_placeholder.info("No filters selected yet.")

if not file_1 or not file_2:
    st.info("Upload both files to begin.")
    st.stop()

try:
    bytes_1, bytes_2 = file_1.getvalue(), file_2.getvalue()
    sheets_1, sheets_2 = get_sheet_names(bytes_1, file_1.name), get_sheet_names(bytes_2, file_2.name)
    with st.sidebar:
        sheet_1 = st.selectbox("File 1 sheet", sheets_1)
        sheet_2 = st.selectbox("File 2 sheet", sheets_2)
    raw1 = load_table(bytes_1, file_1.name, None if sheet_1 == "CSV" else sheet_1)
    raw2 = load_table(bytes_2, file_2.name, None if sheet_2 == "CSV" else sheet_2)
    df1, df2 = make_unique_columns(raw1, "File1"), make_unique_columns(raw2, "File2")
except Exception as exc:
    st.error(f"Could not read the files: {exc}")
    st.stop()

m1, m2, m3, m4 = st.columns(4)
m1.metric("File 1 rows", f"{len(df1):,}")
m2.metric("File 1 columns", len(df1.columns))
m3.metric("File 2 rows", f"{len(df2):,}")
m4.metric("File 2 columns", len(df2.columns))

tab_join, tab_filter, tab_pivot, tab_chart, tab_profile, tab_eda, tab_audit = st.tabs(
    ["Join / Lookup", "Filters & Output", "Pivot", "Charts", "Data Profile", "EDA", "Audit & Dump"]
)

with tab_join:
    st.subheader("Join or lookup the two files")
    c1, c2, c3 = st.columns(3)
    left_key = c1.selectbox("File 1 lookup key", df1.columns)
    right_key = c2.selectbox("File 2 lookup key", df2.columns)
    join_type = c3.selectbox("Join type", ["left", "inner", "right", "outer"], format_func=lambda x: {
        "left": "Left lookup (VLOOKUP style)", "inner": "Inner join",
        "right": "Right join", "outer": "Full outer join"}[x])
    c4, c5, c6 = st.columns(3)
    trim_keys = c4.checkbox("Trim spaces in keys", True)
    case_insensitive = c5.checkbox("Case-insensitive keys", True)
    add_match_status = c6.checkbox("Add match status", True)
    selected_right = st.multiselect(
        "Columns to bring from File 2", [c for c in df2.columns if c != right_key],
        default=[c for c in df2.columns if c != right_key][:10],
    )

    if st.button("Run join / lookup", type="primary"):
        left_work = df1.copy()
        right_work = df2[[right_key] + selected_right].copy()
        key = "__lookup_key__"
        left_work[key] = normalize_key(left_work[left_key], trim_keys, case_insensitive)
        right_work[key] = normalize_key(right_work[right_key], trim_keys, case_insensitive)
        duplicates = int(right_work[key].duplicated(keep=False).sum())
        merged = left_work.merge(
            right_work, how=join_type, on=key, suffixes=("_file1", "_file2"),
            indicator=add_match_status,
        ).drop(columns=[key])
        if add_match_status:
            merged["_merge"] = merged["_merge"].astype(str).map({
                "left_only": "Only in File 1", "right_only": "Only in File 2", "both": "Matched"})
        st.session_state.joined_data = merged
        st.session_state.filtered_data = None
        st.session_state.join_config = {
            "left_key": left_key, "right_key": right_key, "join_type": join_type,
            "trim_keys": trim_keys, "case_insensitive": case_insensitive,
            "selected_file2_columns": selected_right, "duplicate_file2_key_rows": duplicates,
        }
        audit("JOIN_EXECUTED", {**st.session_state.join_config, "output_rows": len(merged)})
        st.success(f"Join created {len(merged):,} rows and {len(merged.columns):,} columns.")

    if st.session_state.joined_data is not None:
        st.caption("Columns are prefixed with File1. or File2. so filters can clearly use fields from either source.")
        render_grid(st.session_state.joined_data, "joined_grid")
    else:
        st.info("Configure and run the join before creating cross-file filters.")

with tab_filter:
    st.subheader("Visible AND/OR filter builder")
    source_options = {"Joined data": st.session_state.joined_data, "File 1": df1, "File 2": df2}
    available = [name for name, frame in source_options.items() if frame is not None]
    source_name = st.radio("Filter data source", available, horizontal=True)
    source_df = source_options[source_name].copy()

    load_col, clear_col = st.columns(2)
    uploaded_filters = load_col.file_uploader("Load saved filters", type=["json"], key="filter_upload")
    if uploaded_filters and load_col.button("Import filter file"):
        try:
            payload = json.loads(uploaded_filters.getvalue().decode("utf-8"))
            imported = payload.get("filters", payload)
            if not isinstance(imported, list):
                raise ValueError("The file does not contain a filter list.")
            valid = [r for r in imported if r.get("column") in source_df.columns]
            st.session_state.filters = valid
            audit("FILTER_SET_IMPORTED", {"imported": len(valid), "ignored": len(imported) - len(valid)})
            st.rerun()
        except Exception as exc:
            st.error(f"Could not import filters: {exc}")
    if clear_col.button("Clear all filters"):
        count = len(st.session_state.filters)
        st.session_state.filters = []
        st.session_state.filtered_data = None
        audit("FILTERS_CLEARED", {"count": count})
        st.rerun()

    st.markdown("#### Add condition")
    a, b, c, d = st.columns([1, 2.2, 1.8, 2])
    connector = a.selectbox("Connector", ["AND", "OR"], disabled=len(st.session_state.filters) == 0)
    column = b.selectbox("Column", source_df.columns)
    operator = c.selectbox("Operator", OPERATORS)
    value_disabled = operator in {"is blank", "is not blank"}
    value = d.text_input("Value", disabled=value_disabled, help="For 'in list', use comma-separated values.")
    e, f, g = st.columns([2, 1, 1])
    value2 = e.text_input("Upper value", disabled=operator != "between")
    case_sensitive = f.checkbox("Case-sensitive", False)
    if g.button("Add filter", type="primary"):
        rule = {
            "connector": "AND" if not st.session_state.filters else connector,
            "column": column, "operator": operator, "value": value,
            "value2": value2, "case_sensitive": case_sensitive,
        }
        st.session_state.filters.append(rule)
        audit("FILTER_ADDED", rule)
        st.rerun()

    st.markdown("#### Applied filter definition")
    if not st.session_state.filters:
        st.info("No conditions added. Add conditions above; every condition remains visible here.")
    else:
        for index, rule in enumerate(st.session_state.filters):
            with st.container(border=True):
                x1, x2, x3 = st.columns([7, 1, 1])
                x1.code(filter_summary(rule, index), language=None)
                if x2.button("↑", key=f"up_{index}", disabled=index == 0):
                    rules = st.session_state.filters
                    rules[index - 1], rules[index] = rules[index], rules[index - 1]
                    audit("FILTER_REORDERED", {"from": index, "to": index - 1})
                    st.rerun()
                if x3.button("Remove", key=f"remove_{index}"):
                    removed = st.session_state.filters.pop(index)
                    audit("FILTER_REMOVED", removed)
                    st.rerun()

    csel, csort, cascn = st.columns([3, 2, 1])
    selected_columns = csel.multiselect("Output columns and order", source_df.columns, default=list(source_df.columns))
    sort_columns = csort.multiselect("Sort by", selected_columns)
    ascending = cascn.checkbox("Ascending", True)
    remove_duplicates = st.checkbox("Remove duplicate output rows")

    apply_col, save_col = st.columns(2)
    if apply_col.button("Apply filters", type="primary"):
        try:
            filtered = apply_filter_rules(source_df, st.session_state.filters)
            if selected_columns:
                filtered = filtered[selected_columns]
            if sort_columns:
                filtered = filtered.sort_values(sort_columns, ascending=ascending, na_position="last")
            if remove_duplicates:
                filtered = filtered.drop_duplicates()
            st.session_state.filtered_data = filtered
            st.session_state.last_filter_config = {
                "source": source_name, "filters": st.session_state.filters,
                "selected_columns": selected_columns, "sort_columns": sort_columns,
                "ascending": ascending, "remove_duplicates": remove_duplicates,
            }
            audit("FILTERS_APPLIED", {
                "source": source_name, "conditions": len(st.session_state.filters),
                "input_rows": len(source_df), "output_rows": len(filtered),
                "sort_columns": sort_columns, "remove_duplicates": remove_duplicates,
            })
            st.success(f"Filters returned {len(filtered):,} of {len(source_df):,} rows.")
        except Exception as exc:
            st.error(f"Could not apply filters: {exc}")

    filter_payload = {"version": 1, "source": source_name, "filters": st.session_state.filters}
    save_col.download_button(
        "Save filter definition", json_bytes(filter_payload),
        file_name=f"{st.session_state.analysis_name}_filters.json", mime="application/json",
        on_click=lambda: audit("FILTER_SET_DOWNLOADED", {"conditions": len(st.session_state.filters)}),
    )

    if st.session_state.filtered_data is not None:
        st.markdown("#### Filtered output")
        visible_output = render_grid(st.session_state.filtered_data, "filtered_grid")
        st.download_button(
            "Download output Excel", to_excel_bytes({"Filtered_Output": visible_output}),
            file_name=f"{st.session_state.analysis_name}_output.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            on_click=lambda: audit("OUTPUT_EXCEL_DOWNLOADED", {"rows": len(visible_output)}),
        )

with tab_pivot:
    st.subheader("Pivot table")
    pivot_source = st.session_state.filtered_data if st.session_state.filtered_data is not None else st.session_state.joined_data
    if pivot_source is None or pivot_source.empty:
        st.info("Run a join and apply filters first.")
    else:
        p1, p2 = st.columns(2)
        index_columns = p1.multiselect("Rows", pivot_source.columns)
        pivot_columns = p2.multiselect("Columns", pivot_source.columns)
        numeric = list(pivot_source.select_dtypes(include="number").columns)
        values = st.multiselect("Values", pivot_source.columns, default=numeric[:1])
        aggregation = st.selectbox("Aggregation", ["sum", "mean", "count", "min", "max", "median", "nunique"])
        if st.button("Create pivot") and index_columns and values:
            pivot_df = pd.pivot_table(
                pivot_source, index=index_columns, columns=pivot_columns or None,
                values=values, aggfunc=aggregation, fill_value=0, dropna=False).reset_index()
            pivot_df.columns = [" | ".join(str(x) for x in col if str(x)) if isinstance(col, tuple) else str(col) for col in pivot_df.columns]
            audit("PIVOT_CREATED", {"rows": index_columns, "columns": pivot_columns, "values": values, "aggregation": aggregation})
            render_grid(pivot_df, "pivot_grid")

with tab_chart:
    st.subheader("Interactive charts for all column types")
    chart_df = st.session_state.filtered_data if st.session_state.filtered_data is not None else st.session_state.joined_data
    if chart_df is None or chart_df.empty:
        st.info("Run a join and apply filters first.")
    else:
        chart_type = st.selectbox("Chart type", ["Bar", "Line", "Scatter", "Histogram", "Box", "Pie"])
        columns = list(chart_df.columns)
        x_col = st.selectbox("X axis / category", columns)
        y_col = st.selectbox("Y axis / value", ["None"] + columns)
        y_col = None if y_col == "None" else y_col
        aggregation = st.selectbox(
            "Aggregation",
            ["Row count", "Distinct count", "Sum", "Average", "Median", "Minimum", "Maximum"],
            help="Row count and distinct count work with every data type. Numeric aggregations safely convert numeric-like text.",
        )
        color_col = st.selectbox("Color / group", ["None"] + columns)
        top_n = st.slider("Maximum categories", 5, 100, 30)
        if st.button("Create chart"):
            try:
                color = None if color_col == "None" else color_col
                plot_df, plot_y = build_chart_data(chart_df, x_col, y_col, aggregation, chart_type, top_n)
                if chart_type == "Bar":
                    fig = px.bar(plot_df, x=x_col, y=plot_y, color=color if color in plot_df.columns else None)
                elif chart_type == "Line":
                    fig = px.line(plot_df, x=x_col, y=plot_y, color=color if color in plot_df.columns else None, markers=True)
                elif chart_type == "Scatter":
                    if y_col is None:
                        raise ValueError("Select a Y-axis column for a scatter chart.")
                    fig = px.scatter(chart_df, x=x_col, y=y_col, color=color)
                elif chart_type == "Histogram":
                    fig = px.histogram(chart_df, x=x_col, color=color)
                elif chart_type == "Box":
                    fig = px.box(chart_df, x=x_col if y_col else None, y=y_col or x_col, color=color)
                else:
                    if aggregation == "Row count":
                        fig = px.pie(plot_df, names=x_col, values=plot_y)
                    elif y_col is not None:
                        fig = px.pie(plot_df, names=x_col, values=plot_y)
                    else:
                        raise ValueError("Choose Row count or select a value column for a pie chart.")
                st.plotly_chart(fig, use_container_width=True)
                audit("CHART_CREATED", {"type": chart_type, "x": x_col, "y": y_col, "aggregation": aggregation, "color": color_col})
            except Exception as exc:
                st.error(f"Could not create chart: {exc}")

with tab_profile:
    st.subheader("Detailed data quality profile")
    options = {"File 1": df1, "File 2": df2}
    if st.session_state.joined_data is not None:
        options["Joined data"] = st.session_state.joined_data
    if st.session_state.filtered_data is not None:
        options["Filtered output"] = st.session_state.filtered_data
    profile_name = st.radio("Profile source", options.keys(), horizontal=True)
    profile = options[profile_name]
    summary = quality_summary(profile)
    q1, q2, q3, q4, q5, q6 = st.columns(6)
    q1.metric("Rows", f"{summary['rows']:,}")
    q2.metric("Columns", f"{summary['columns']:,}")
    q3.metric("Duplicate rows", f"{summary['duplicate_rows']:,}")
    q4.metric("Missing cells", f"{summary['missing_cells']:,}")
    q5.metric("IQR outliers", f"{summary['outliers']:,}")
    q6.metric("Invalid values", f"{summary['invalid_values']:,}")

    profile_df = detailed_profile(profile)
    st.dataframe(profile_df, use_container_width=True, hide_index=True)
    st.caption("Invalid values identify failed conversions in columns that are predominantly numeric-like or date-like. Outliers use the 1.5×IQR rule.")

    c1, c2 = st.columns(2)
    missing_plot = profile_df.sort_values("missing_pct", ascending=False).head(30)
    c1.plotly_chart(px.bar(missing_plot, x="column", y="missing_pct", title="Missing values by column (%)"), use_container_width=True)
    unique_plot = profile_df.sort_values("unique_values", ascending=False).head(30)
    c2.plotly_chart(px.bar(unique_plot, x="column", y="unique_values", title="Unique values by column"), use_container_width=True)

    st.subheader("Column-level analysis")
    selected_profile_column = st.selectbox("Select any column", profile.columns, key="profile_any_column")
    selected_series = profile[selected_profile_column]
    semantic = infer_semantic_type(selected_series)
    st.write(f"Detected type: **{semantic}**")
    value_counts = selected_series.astype("string").fillna("<Missing>").value_counts(dropna=False).head(50).reset_index()
    value_counts.columns = ["value", "count"]
    st.plotly_chart(px.bar(value_counts, x="value", y="count", title=f"Value distribution: {selected_profile_column}"), use_container_width=True)
    st.dataframe(value_counts, use_container_width=True, hide_index=True)

    association_columns = st.multiselect(
        "Association matrix columns (numeric, categorical and date)",
        profile.columns, default=list(profile.columns[:min(12, len(profile.columns))]), key="profile_assoc_cols"
    )
    if len(association_columns) >= 2:
        association = encoded_association(profile, association_columns)
        st.plotly_chart(px.imshow(association, text_auto=".2f", aspect="auto", title="Encoded all-column association matrix"), use_container_width=True)
        st.caption("Categorical fields are factor-encoded and dates are converted to timestamps. Use this as exploratory association, not as proof of causal correlation.")

with tab_eda:
    st.subheader("Exploratory Data Analysis on joined output")
    eda_df = st.session_state.filtered_data if st.session_state.filtered_data is not None else st.session_state.joined_data
    if eda_df is None or eda_df.empty:
        st.info("Run the join first. EDA uses the filtered output when available; otherwise it uses the complete joined data.")
    else:
        groups = classify_columns(eda_df)
        all_columns = list(eda_df.columns)
        numerical_cols = groups["numeric"]
        categorical_cols = groups["categorical"] + groups["boolean"]
        datetime_cols = groups["datetime"]

        st.markdown("#### Descriptive analysis for all features")
        d1, d2, d3, d4 = st.columns(4)
        d1.metric("All features", len(all_columns))
        d2.metric("Numeric / numeric-like", len(numerical_cols))
        d3.metric("Categorical / boolean", len(categorical_cols))
        d4.metric("Date/time", len(datetime_cols))
        st.dataframe(all_column_descriptive_summary(eda_df), use_container_width=True, hide_index=True)

        selected_eda_col = st.selectbox("Explore any column", all_columns, key="eda_any_column")
        semantic = infer_semantic_type(eda_df[selected_eda_col])
        if semantic in {"numerical", "numeric-like text"}:
            values = pd.to_numeric(eda_df[selected_eda_col].astype(str).str.replace(",", "", regex=False), errors="coerce")
            st.plotly_chart(px.histogram(x=values, marginal="box", title=f"Distribution: {selected_eda_col}"), use_container_width=True)
        elif semantic in {"datetime", "date-like text"}:
            dates = pd.to_datetime(eda_df[selected_eda_col], errors="coerce")
            counts = dates.dt.to_period("M").astype(str).value_counts().sort_index().reset_index()
            counts.columns = ["period", "count"]
            st.plotly_chart(px.line(counts, x="period", y="count", markers=True, title=f"Monthly frequency: {selected_eda_col}"), use_container_width=True)
        else:
            counts = eda_df[selected_eda_col].astype("string").fillna("<Missing>").value_counts().head(50).reset_index()
            counts.columns = ["value", "count"]
            st.plotly_chart(px.bar(counts, x="value", y="count", title=f"Top values: {selected_eda_col}"), use_container_width=True)

        st.markdown("#### Time-based analysis")
        if not datetime_cols:
            st.info("No date/time column was detected with at least 90% parseable values.")
        else:
            t1, t2, t3 = st.columns(3)
            date_col = t1.selectbox("Date column", datetime_cols, key="eda_date")
            grain = t2.selectbox("Time grain", ["Daily", "Weekly", "Monthly", "Quarterly", "Yearly"], key="eda_grain")
            measure = t3.selectbox("Measure (any column)", ["Row count"] + all_columns, key="eda_measure")
            aggregation_options = ["count", "nunique"] if measure == "Row count" or measure not in numerical_cols else ["sum", "mean", "median", "min", "max", "count", "nunique"]
            aggregation = st.selectbox("Aggregation", aggregation_options, key="eda_agg")
            temp = eda_df.copy()
            temp["__date__"] = pd.to_datetime(temp[date_col], errors="coerce")
            temp = temp[temp["__date__"].notna()]
            freq = {"Daily":"D", "Weekly":"W", "Monthly":"MS", "Quarterly":"QS", "Yearly":"YS"}[grain]
            if measure == "Row count":
                trend = temp.set_index("__date__").resample(freq).size().rename("value").reset_index()
            elif aggregation == "nunique":
                trend = temp.set_index("__date__")[measure].resample(freq).nunique().rename("value").reset_index()
            elif aggregation == "count":
                trend = temp.set_index("__date__")[measure].resample(freq).count().rename("value").reset_index()
            else:
                temp["__measure__"] = pd.to_numeric(temp[measure].astype(str).str.replace(",", "", regex=False), errors="coerce")
                trend = temp.set_index("__date__")["__measure__"].resample(freq).agg(aggregation).rename("value").reset_index()
            trend["period_change_pct"] = trend["value"].pct_change() * 100
            st.plotly_chart(px.line(trend, x="__date__", y="value", markers=True, title=f"{grain} trend"), use_container_width=True)
            st.dataframe(trend.rename(columns={"__date__":"period"}), use_container_width=True, hide_index=True)

        st.markdown("#### Correlation and association analysis")
        selected_assoc = st.multiselect("Select columns of any type", all_columns, default=all_columns[:min(12, len(all_columns))], key="eda_assoc")
        if len(selected_assoc) >= 2:
            assoc = encoded_association(eda_df, selected_assoc)
            st.plotly_chart(px.imshow(assoc, text_auto=".2f", aspect="auto", title="Spearman association across encoded columns"), use_container_width=True)
            st.caption("Numeric-like fields are converted, dates use timestamps, and categorical values are factor-encoded.")

        st.markdown("#### Outlier and anomaly detection")
        anomaly_col = st.selectbox("Column of any type", all_columns, key="eda_anomaly_col")
        anomaly_semantic = infer_semantic_type(eda_df[anomaly_col])
        if anomaly_semantic in {"numerical", "numeric-like text"}:
            numeric_series = pd.to_numeric(eda_df[anomaly_col].astype(str).str.replace(",", "", regex=False), errors="coerce")
            method = st.radio("Method", ["IQR", "Z-score"], horizontal=True, key="eda_outlier_method")
            if method == "IQR":
                mask = outlier_mask_iqr(numeric_series)
                detail = "Outside Q1 − 1.5×IQR or Q3 + 1.5×IQR"
            else:
                std = numeric_series.std(ddof=0)
                z = (numeric_series - numeric_series.mean()) / std if pd.notna(std) and std != 0 else pd.Series(0, index=numeric_series.index)
                mask = z.abs() > 3
                detail = "Absolute Z-score greater than 3"
            st.metric("Outlier rows", f"{int(mask.sum()):,}")
            st.caption(detail)
            st.plotly_chart(px.box(y=numeric_series, points="outliers", title=f"Outliers: {anomaly_col}"), use_container_width=True)
            st.dataframe(eda_df.loc[mask].head(1000), use_container_width=True, hide_index=True)
        elif anomaly_semantic in {"datetime", "date-like text"}:
            parsed = pd.to_datetime(eda_df[anomaly_col], errors="coerce")
            invalid = parsed.isna() & eda_df[anomaly_col].notna()
            st.metric("Invalid date values", f"{int(invalid.sum()):,}")
            st.dataframe(eda_df.loc[invalid].head(1000), use_container_width=True, hide_index=True)
        else:
            frequency = eda_df[anomaly_col].astype("string").fillna("<Missing>").value_counts(dropna=False)
            threshold = st.slider("Rare-value threshold", 1, 100, 5, help="Values occurring at or below this count are treated as rare anomalies.")
            rare_values = frequency[frequency <= threshold].index
            mask = eda_df[anomaly_col].astype("string").fillna("<Missing>").isin(rare_values)
            st.metric("Rare/anomalous rows", f"{int(mask.sum()):,}")
            st.dataframe(frequency.rename("count").reset_index().rename(columns={"index":"value"}), use_container_width=True, hide_index=True)
            st.dataframe(eda_df.loc[mask].head(1000), use_container_width=True, hide_index=True)

with tab_audit:
    st.subheader("Audit trail and complete analysis dump")
    audit_df = pd.DataFrame(st.session_state.audit_log)
    if audit_df.empty:
        st.info("Audit entries appear after you run joins, add/apply filters, create pivots/charts, or download outputs.")
    else:
        st.dataframe(audit_df, use_container_width=True, hide_index=True)

    output_df = st.session_state.filtered_data
    if output_df is None:
        output_df = st.session_state.joined_data
    if output_df is None:
        output_df = pd.DataFrame()

    metadata = {
        "analysis_name": st.session_state.analysis_name,
        "created_at": utc_now(),
        "file_1": {"name": file_1.name, "sheet": sheet_1, "sha256_prefix": file_fingerprint(bytes_1), "rows": len(df1)},
        "file_2": {"name": file_2.name, "sheet": sheet_2, "sha256_prefix": file_fingerprint(bytes_2), "rows": len(df2)},
        "join_config": st.session_state.join_config,
        "filter_config": st.session_state.last_filter_config,
        "output_rows": len(output_df),
        "output_columns": list(output_df.columns),
    }
    dump = build_dump(output_df, st.session_state.filters, metadata)
    st.download_button(
        "Download complete analysis dump (.zip)", dump,
        file_name=f"{st.session_state.analysis_name}_dump.zip", mime="application/zip",
        on_click=lambda: audit("ANALYSIS_DUMP_DOWNLOADED", {"rows": len(output_df), "audit_entries": len(st.session_state.audit_log)}),
        disabled=output_df.empty,
    )
    st.caption("The dump contains output.xlsx, output.csv, filters.json, audit_log.csv/json, and session_metadata.json.")
