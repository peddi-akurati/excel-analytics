from __future__ import annotations
LEFT_ALIGN_CSS="""<style>


.ag-header-cell-label,.ag-header-cell-text{justify-content:flex-start!important;text-align:left!important;flex-direction:row!important}
.ag-right-aligned-header .ag-header-cell-label{justify-content:flex-start!important;text-align:left!important;flex-direction:row!important}
.ag-cell,.ag-right-aligned-cell,.ag-cell-value{text-align:left!important;justify-content:flex-start!important}

.stCaption,[data-testid="stCaptionContainer"],[data-testid="stFileUploaderFileName"]{color:#000000!important;}
</style>"""


from datetime import datetime, timezone
from io import BytesIO
from itertools import combinations
from pathlib import Path
from typing import Any
import hashlib
import json
import math
import zipfile
import re
import html
import os
import tempfile
from urllib.parse import quote

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from PIL import Image
from st_aggrid import AgGrid, GridOptionsBuilder, DataReturnMode, GridUpdateMode, JsCode
from mlxtend.frequent_patterns import fpgrowth, association_rules as mlxtend_association_rules
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import average_precision_score, classification_report, confusion_matrix, roc_auc_score, accuracy_score, precision_score, recall_score, f1_score, mean_absolute_error, mean_squared_error, r2_score, mean_absolute_percentage_error, roc_curve, precision_recall_curve
from sklearn.model_selection import train_test_split, cross_val_score, cross_validate, RandomizedSearchCV, StratifiedKFold, KFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler, label_binarize
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor, _tree, export_text
from sklearn.linear_model import LinearRegression, Ridge, LogisticRegression
from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor, GradientBoostingRegressor, RandomForestClassifier, ExtraTreesClassifier, GradientBoostingClassifier, IsolationForest
import joblib
from sklearn.inspection import permutation_importance, PartialDependenceDisplay
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from sklearn.mixture import GaussianMixture
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from statsmodels.tsa.statespace.sarimax import SARIMAX

# Enterprise dashboard chart defaults inspired by the Combined Ratio mockups.
px.defaults.template = "plotly_white"
px.defaults.color_discrete_sequence = [
    "#0B5ED7", "#2F80ED", "#16A085", "#F5A623", "#7B61C9", "#E74C3C", "#607D8B"
]

BASE_DIR = Path(__file__).resolve().parent
LOGO_PATH = BASE_DIR / "assets" / "clarity_logo_dashboard.png"
FAVICON_PATH = BASE_DIR / "assets" / "clarity_favicon.png"
CONNECTION_CONFIG_PATH = BASE_DIR / "connection_profiles.json"

page_icon = str(FAVICON_PATH) if FAVICON_PATH.exists() else "C"
st.set_page_config(page_title="Clarity", page_icon=page_icon, layout="wide")
st.markdown(LEFT_ALIGN_CSS, unsafe_allow_html=True)
st.markdown('<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" rel="stylesheet">', unsafe_allow_html=True)

# Render the transparent Clarity brand inside Streamlit's native sidebar header.
if LOGO_PATH.exists():
    st.logo(
        str(LOGO_PATH),
        icon_image=str(FAVICON_PATH) if FAVICON_PATH.exists() else None,
        size="large",
    )
    # Logo rendered large; CSS below scales it by 1.25.


def render_global_styles() -> None:
    """Apply stable app, sidebar, header, dataframe and grid styling."""
    sidebar_width = "27rem" if st.session_state.get("wide_sidebar", False) else "15.75rem"
    css = """
    <style>

    /* Increase logo render size within same header area */
    [data-testid="stLogo"] img, [data-testid="stSidebarHeader"] img{
        transform: scale(1.25);
        transform-origin:center;
    }

    html, body, [class*="css"], [data-testid="stAppViewContainer"],
    [data-testid="stSidebar"], button, input, textarea, select {
        font-family: Verdana, Geneva, sans-serif !important;
    }

    /* Keep selected and primary button hover states within the Clarity blue palette. */
    div[data-testid="stButton"] button[kind="primary"]:hover,
    div[data-testid="stDownloadButton"] button[kind="primary"]:hover,
    button[data-testid="baseButton-primary"]:hover {
        background: linear-gradient(135deg, #0b4db8 0%, #2563eb 52%, #60a5fa 100%) !important;
        color: #ffffff !important;
        border-color: #2563eb !important;
        box-shadow: 0 4px 12px rgba(37, 99, 235, .24) !important;
    }
    
    /* Enterprise button styling for all non-navigation action buttons */
    div[data-testid="stButton"] > button:not([kind="tertiary"]),
    div[data-testid="stDownloadButton"] > button,
    div[data-testid="stFormSubmitButton"] > button {
        border-radius:10px !important;
        padding:0.45rem 1rem !important;
        font-weight:600 !important;
        transition:all .2s ease !important;
    }
    div[data-testid="stButton"] > button[kind="primary"],
    div[data-testid="stFormSubmitButton"] > button[kind="primary"]{
        color:#fff !important;
    }
[data-testid="stAppDeployButton"], [data-testid="stDeployButton"] {
        display: none !important;
    }
    section[data-testid="stSidebar"][aria-expanded="true"] {
        width: __SIDEBAR_WIDTH__ !important;
        min-width: __SIDEBAR_WIDTH__ !important;
    }
    section[data-testid="stSidebar"][aria-expanded="true"] > div {
        width: __SIDEBAR_WIDTH__ !important;
    }
    section[data-testid="stSidebar"][aria-expanded="false"] {
        width: 0 !important;
        min-width: 0 !important;
    }
    /* Hide the sidebar brand completely while the pane is collapsed. */
    section[data-testid="stSidebar"][aria-expanded="false"] [data-testid="stSidebarHeader"],
    section[data-testid="stSidebar"][aria-expanded="false"] [data-testid="stLogo"],
    section[data-testid="stSidebar"][aria-expanded="false"] [data-testid="stSidebarHeader"] img {
        visibility: hidden !important;
        opacity: 0 !important;
        pointer-events: none !important;
    }
    [data-testid="collapsedControl"] {
        z-index: 10050 !important;
        top: .55rem !important;
        left: .6rem !important;
        width: 3.35rem !important;
        height: 3.35rem !important;
        border-radius: .75rem !important;
        background: #f3f6fb !important;
        border: 1px solid #dce4f0 !important;
        box-shadow: 0 2px 10px rgba(15, 23, 42, .10) !important;
    }
    [data-testid="collapsedControl"] img,
    [data-testid="collapsedControl"] svg {
        width: 2.35rem !important;
        height: 2.35rem !important;
    }
    section[data-testid="stSidebar"] [data-testid="stSidebarHeader"] {
        position: sticky !important;
        top: 0 !important;
        z-index: 10000 !important;
        min-height: 6.2rem !important;
        padding: .35rem .7rem !important;
        border-bottom: 1px solid #e8edf5 !important;
        background: #f3f6fb !important;
        backdrop-filter: none !important;
        overflow: hidden !important;
    }
    section[data-testid="stSidebar"] [data-testid="stSidebarHeader"] img {
        width: 12.25rem !important;
        min-width: 12.25rem !important;
        max-width: 12.25rem !important;
        height: 4.75rem !important;
        min-height: 4.75rem !important;
        max-height: 4.75rem !important;
        object-fit: contain !important;
        object-position: left center !important;
        opacity: 1 !important;
        background: transparent !important;
        flex: 0 0 12.25rem !important;
    }
    section[data-testid="stSidebar"] {
        background: #f3f6fb !important;
        border-right: 1px solid #dce4f0 !important;
    }
    section[data-testid="stSidebar"] div[data-testid="stSidebarUserContent"] {
        padding-top: .85rem !important;
        position: relative !important;
        z-index: 1 !important;
        background: #f3f6fb !important;
    }
    section[data-testid="stSidebar"] > div:first-child {
        background: #f3f6fb !important;
    }
    /* Header statement rendered in the right-pane stAppHeader. */
    [data-testid="stHeader"]::after,
    [data-testid="stAppHeader"]::after {
        content: "Add the data, conduct analysis, and uncover insights to facilitate clear, data-driven decisions";
        position: absolute;
        left: 5.35rem;
        top: 50%;
        transform: translateY(-50%);
        width: calc(100% - 6.35rem);
        max-width: none;
        padding: .58rem 1rem .58rem 1.15rem;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        color: #002060;
        font-size: .86rem;
        font-weight: 600;
        letter-spacing: .005em;
        line-height: 1.2;
        border: 1px solid #cbd8ec;
        border-left: 4px solid #002060;
        border-radius: .65rem;
        background: linear-gradient(90deg, #edf3ff 0%, #f8fbff 72%, #ffffff 100%);
        box-shadow: 0 3px 12px rgba(0, 32, 96, .08);
        pointer-events: none;
        box-sizing: border-box;
    }
    /* Left-align all native dataframe headers and values; keep headers sticky. */
    [data-testid="stDataFrame"] th, [data-testid="stDataFrame"] td,
    [data-testid="stDataEditor"] th, [data-testid="stDataEditor"] td {
        text-align: left !important;
        justify-content: flex-start !important;
    }
    [data-testid="stDataFrame"] thead th,
    [data-testid="stDataEditor"] thead th {
        position: sticky !important;
        top: 0 !important;
        z-index: 5 !important;
        background: #f8fafc !important;
    }
    /* Material 3 documentation-style navigation tabs. */
    div[data-testid="stHorizontalBlock"]:has(.modern-nav-anchor) {
        display: none !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] {
        display: grid !important;
        grid-template-columns: repeat(7, minmax(max-content, 1fr)) !important;
        align-items: end !important;
        padding: 0 .25rem;
        margin: .2rem 0 1.15rem 0;
        border: 0 !important;
        border-bottom: 1px solid #d7dee8 !important;
        border-radius: 0 !important;
        background: transparent !important;
        box-shadow: none !important;
        gap: .15rem !important;
        overflow-x: auto !important;
        scrollbar-width: thin;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] > div {
        width: 100% !important;
        min-width: max-content !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"],
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] > div {
        width: 100% !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button {
        position: relative !important;
        width: 100% !important;
        height: 3rem !important;
        min-height: 3rem !important;
        padding: .55rem .75rem .65rem !important;
        border: 0 !important;
        border-radius: .5rem .5rem 0 0 !important;
        background: transparent !important;
        color: #475569 !important;
        font-size: .79rem !important;
        font-weight: 600 !important;
        line-height: 1.1 !important;
        letter-spacing: .01em !important;
        white-space: nowrap !important;
        box-shadow: none !important;
        transition: background-color .16s ease, color .16s ease !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button::after {
        content: "" !important;
        position: absolute !important;
        left: 50% !important;
        bottom: 0 !important;
        width: 0 !important;
        height: 3px !important;
        border-radius: 3px 3px 0 0 !important;
        background: #002060 !important;
        transform: translateX(-50%) !important;
        transition: width .18s ease !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button:hover {
        transform: none !important;
        background: #f2f6fc !important;
        color: #002060 !important;
        box-shadow: none !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button:focus-visible {
        outline: 2px solid #5477b7 !important;
        outline-offset: -2px !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button[kind="primary"] {
        background: #edf3ff !important;
        color: #ffffff !important;
        font-weight: 700 !important;
        box-shadow: none !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button[kind="primary"]::after {
        width: calc(100% - 1.25rem) !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button[kind="primary"]:hover {
        background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 55%, #93c5fd 100%) !important;
        color: #ffffff !important;
    }

    /* White text only while a button is actively pressed or explicitly selected. */
    div[data-testid="stButton"] button:active,
    div[data-testid="stDownloadButton"] button:active,
    div[data-testid="stFormSubmitButton"] button:active,
    button[data-testid^="baseButton"]:active,
    button[aria-pressed="true"] {
        color: #ffffff !important;
    }

    /* Preview page: keep the preselected Preview tab and primary Submit label white.
       Streamlit renders button labels inside nested p/span elements, so the label
       nodes must be styled in addition to the button element itself. */
    .st-key-nav_button_preview button[kind="primary"],
    .st-key-nav_button_preview button[kind="primary"] *,
    [class*="st-key-preview_pivot_submit_"] button[kind="primary"],
    [class*="st-key-preview_pivot_submit_"] button[kind="primary"] * {
        color: #ffffff !important;
    }
    @media (max-width: 920px) {
        .modern-nav-anchor + div[data-testid="stHorizontalBlock"] {
            grid-template-columns: repeat(8, minmax(8rem, 1fr)) !important;
        }
    }
    

    /* Filter page: consistent form widths, heights and baseline alignment. */
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) div[data-testid="stHorizontalBlock"] {
        align-items: end !important;
    }
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stSelectbox"] > div,
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stTextInput"] > div,
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stMultiSelect"] > div {
        width: 100% !important;
    }
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-baseweb="select"] > div,
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stTextInput"] input {
        min-height: 2.65rem !important;
        height: 2.65rem !important;
        box-sizing: border-box !important;
    }
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stButton"] button,
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stDownloadButton"] button {
        min-height: 2.65rem !important;
        height: 2.65rem !important;
        width: 100% !important;
        padding-top: .45rem !important;
        padding-bottom: .45rem !important;
    }
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stFileUploader"] section {
        min-height: 2.65rem !important;
        padding: .35rem .55rem !important;
    }
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stFileUploader"] section > div:first-child,
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stFileUploader"] small {
        display: none !important;
    }
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stFileUploader"] section button {
        min-height: 2rem !important;
        height: 2rem !important;
        width: auto !important;
        margin: 0 !important;
    }
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stCheckbox"] {
        min-height: 2.65rem !important;
        display: flex !important;
        align-items: center !important;
        padding-top: 1.25rem !important;
        box-sizing: border-box !important;
    }
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stCheckbox"] label {
        margin: 0 !important;
    }
    div[data-testid="stVerticalBlock"]:has(.filter-page-anchor) [data-testid="stWidgetLabel"] {
        min-height: 1.35rem !important;
        margin-bottom: .25rem !important;
    }
</style>
    """.replace("__SIDEBAR_WIDTH__", sidebar_width)
    st.markdown(css, unsafe_allow_html=True)


render_global_styles()


def render_combined_ratio_dashboard_theme() -> None:
    """Apply the enterprise visual language used in the Combined Ratio dashboard mockups."""
    st.markdown("""
    <style>
    :root {
        --clarity-navy: #032b58;
        --clarity-navy-2: #07447c;
        --clarity-blue: #0b5ed7;
        --clarity-blue-soft: #eaf2ff;
        --clarity-canvas: #f5f8fc;
        --clarity-card: #ffffff;
        --clarity-border: #d9e3f0;
        --clarity-text: #0c2b54;
        --clarity-muted: #63738a;
        --clarity-green: #0f8a4b;
        --clarity-red: #d93025;
        --clarity-amber: #e58a00;
    }

    html, body, [class*="css"], [data-testid="stAppViewContainer"],
    [data-testid="stSidebar"], button, input, textarea, select {
        font-family: Inter, "Segoe UI", Arial, sans-serif !important;
    }
    .stApp, [data-testid="stAppViewContainer"], [data-testid="stMain"] {
        background: var(--clarity-canvas) !important;
        color: var(--clarity-text) !important;
    }
    [data-testid="stMainBlockContainer"], .block-container {
        max-width: none !important;
        padding: 1.05rem 1.15rem 2.25rem !important;
    }

    /* Dark, fixed enterprise navigation pane. */
    section[data-testid="stSidebar"],
    section[data-testid="stSidebar"] > div:first-child,
    section[data-testid="stSidebar"] div[data-testid="stSidebarUserContent"] {
        background: linear-gradient(180deg, #042e5b 0%, #063a70 58%, #02284f 100%) !important;
        border-right: 0 !important;
        color: #ffffff !important;
    }
    section[data-testid="stSidebar"] [data-testid="stSidebarHeader"] {
        min-height: 6.45rem !important;
        background: transparent !important;
        border-bottom: 1px solid rgba(255,255,255,.16) !important;
        padding: .55rem .65rem !important;
    }
    section[data-testid="stSidebar"] [data-testid="stSidebarHeader"] img {
        width: 13.2rem !important;
        max-width: 13.2rem !important;
        height: 5rem !important;
        max-height: 5rem !important;
        transform: none !important;
        object-fit: contain !important;
        object-position: left center !important;
    }
    section[data-testid="stSidebar"] * { color: #f7fbff; }
    section[data-testid="stSidebar"] label,
    section[data-testid="stSidebar"] p,
    section[data-testid="stSidebar"] small { color: #d7e7fb !important; }
    section[data-testid="stSidebar"] hr { border-color: rgba(255,255,255,.16) !important; }
    section[data-testid="stSidebar"] [data-baseweb="select"] > div,
    section[data-testid="stSidebar"] [data-testid="stTextInput"] input,
    section[data-testid="stSidebar"] [data-testid="stNumberInput"] input,
    section[data-testid="stSidebar"] textarea {
        background: rgba(255,255,255,.08) !important;
        border: 1px solid rgba(255,255,255,.24) !important;
        color: #ffffff !important;
        border-radius: .55rem !important;
    }
    section[data-testid="stSidebar"] [data-baseweb="select"] svg { fill: #d8e8ff !important; }
    section[data-testid="stSidebar"] div[data-testid="stButton"] button,
    section[data-testid="stSidebar"] div[data-testid="stDownloadButton"] button {
        width: 100% !important;
        background: transparent !important;
        color: #f7fbff !important;
        border: 1px solid rgba(255,255,255,.24) !important;
        border-radius: .55rem !important;
        box-shadow: none !important;
    }
    section[data-testid="stSidebar"] div[data-testid="stButton"] button:hover,
    section[data-testid="stSidebar"] div[data-testid="stDownloadButton"] button:hover {
        background: rgba(30,116,230,.95) !important;
        border-color: #6eb1ff !important;
    }

    /* v117: keep the sidebar logo outside the navigation scroll region. */
    section[data-testid="stSidebar"] > div:first-child {
        display: flex !important;
        flex-direction: column !important;
        height: 100vh !important;
        max-height: 100vh !important;
        overflow: hidden !important;
    }
    section[data-testid="stSidebar"] [data-testid="stSidebarHeader"] {
        position: relative !important;
        top: auto !important;
        flex: 0 0 6.45rem !important;
        z-index: 10000 !important;
        overflow: hidden !important;
    }
    section[data-testid="stSidebar"] div[data-testid="stSidebarUserContent"] {
        flex: 1 1 auto !important;
        min-height: 0 !important;
        overflow-y: auto !important;
        overflow-x: hidden !important;
        overscroll-behavior: contain !important;
        padding-top: .85rem !important;
        scrollbar-gutter: stable !important;
    }

    /* Compact white app header, matching dashboard toolbar treatment. */
    [data-testid="stHeader"], [data-testid="stAppHeader"] {
        background: rgba(255,255,255,.97) !important;
        border-bottom: 1px solid var(--clarity-border) !important;
        box-shadow: 0 2px 8px rgba(3,43,88,.05) !important;
    }
    [data-testid="stHeader"]::after, [data-testid="stAppHeader"]::after {
        content: "CLARITY  |  ENTERPRISE AUTOML & ANALYTICS" !important;
        left: 4.8rem !important;
        width: auto !important;
        max-width: calc(100% - 11rem) !important;
        border: 0 !important;
        border-left: 3px solid var(--clarity-blue) !important;
        border-radius: 0 !important;
        background: transparent !important;
        box-shadow: none !important;
        color: var(--clarity-text) !important;
        font-size: .82rem !important;
        letter-spacing: .04em !important;
        padding: .18rem .75rem !important;
    }
    [data-testid="collapsedControl"] {
        background: #ffffff !important;
        border-color: var(--clarity-border) !important;
        box-shadow: 0 2px 8px rgba(3,43,88,.12) !important;
    }

    /* Typography mirrors the dashboard's compact navy hierarchy. */
    h1, h2, h3, h4, h5, h6 { color: var(--clarity-text) !important; letter-spacing: -.015em; }
    h1 { font-size: 1.75rem !important; font-weight: 750 !important; margin-bottom: .25rem !important; }
    h2 { font-size: 1.35rem !important; font-weight: 720 !important; }
    h3 { font-size: 1.08rem !important; font-weight: 720 !important; text-transform: uppercase; letter-spacing: .01em; }
    h4 { font-size: .98rem !important; font-weight: 700 !important; }
    p, li, label { color: #263f60; }
    [data-testid="stCaptionContainer"], .stCaption { color: var(--clarity-muted) !important; }

    /* Dashboard cards: metrics, bordered groups, expanders and forms. */
    [data-testid="stMetric"],
    [data-testid="stExpander"],
    [data-testid="stForm"],
    div[data-testid="stVerticalBlockBorderWrapper"] {
        background: var(--clarity-card) !important;
        border: 1px solid var(--clarity-border) !important;
        border-radius: .72rem !important;
        box-shadow: 0 2px 8px rgba(3,43,88,.045) !important;
    }
    [data-testid="stMetric"] { padding: .78rem .9rem !important; min-height: 6rem; }
    [data-testid="stMetricLabel"] { color: var(--clarity-text) !important; font-weight: 700 !important; text-transform: uppercase; font-size: .72rem !important; }
    [data-testid="stMetricValue"] { color: #064da8 !important; font-weight: 760 !important; }
    [data-testid="stMetricDelta"] { font-weight: 700 !important; }
    [data-testid="stExpander"] details summary { color: var(--clarity-text) !important; font-weight: 700 !important; }

    /* Inputs and buttons use the same compact square-rounded toolbar style. */
    [data-baseweb="select"] > div,
    [data-testid="stTextInput"] input,
    [data-testid="stNumberInput"] input,
    [data-testid="stDateInput"] input,
    textarea {
        background: #ffffff !important;
        border-color: #cbd8e8 !important;
        border-radius: .52rem !important;
        color: var(--clarity-text) !important;
        box-shadow: none !important;
    }
    [data-baseweb="select"] > div:focus-within,
    [data-testid="stTextInput"] input:focus,
    [data-testid="stNumberInput"] input:focus,
    textarea:focus {
        border-color: var(--clarity-blue) !important;
        box-shadow: 0 0 0 2px rgba(11,94,215,.12) !important;
    }
    div[data-testid="stButton"] button,
    div[data-testid="stDownloadButton"] button,
    button[data-testid^="baseButton"] {
        border-radius: .5rem !important;
        border: 1px solid #bfd0e4 !important;
        background: #ffffff !important;
        color: #07458c !important;
        font-weight: 700 !important;
        box-shadow: none !important;
        min-height: 2.45rem !important;
    }
    div[data-testid="stButton"] button:hover,
    div[data-testid="stDownloadButton"] button:hover {
        border-color: var(--clarity-blue) !important;
        background: var(--clarity-blue-soft) !important;
        color: #064da8 !important;
    }
    div[data-testid="stButton"] button[kind="primary"],
    button[data-testid="baseButton-primary"] {
        background: linear-gradient(135deg, #0b5ed7 0%, #086ddf 100%) !important;
        border-color: #0b5ed7 !important;
        color: #ffffff !important;
        box-shadow: 0 3px 8px rgba(11,94,215,.20) !important;
    }

    /* Top navigation tabs become a blue dashboard navigation strip. */
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] {
        padding: .28rem !important;
        margin: .15rem 0 .9rem 0 !important;
        border: 1px solid var(--clarity-border) !important;
        border-radius: .72rem !important;
        background: #ffffff !important;
        box-shadow: 0 2px 8px rgba(3,43,88,.045) !important;
        gap: .25rem !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button {
        height: 2.75rem !important;
        min-height: 2.75rem !important;
        border-radius: .5rem !important;
        color: #48617f !important;
        padding: .45rem .65rem !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button::after { display:none !important; }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button[kind="primary"] {
        background: linear-gradient(135deg,#0a5fd3,#1378e8) !important;
        color: #ffffff !important;
        box-shadow: 0 3px 8px rgba(11,94,215,.18) !important;
    }

    /* Tables and grids match the dashboard's clean white/blue panels. */
    [data-testid="stDataFrame"], [data-testid="stDataEditor"] {
        background: #ffffff !important;
        border: 1px solid var(--clarity-border) !important;
        border-radius: .65rem !important;
        overflow: hidden !important;
        box-shadow: 0 2px 7px rgba(3,43,88,.04) !important;
    }
    [data-testid="stDataFrame"] thead th, [data-testid="stDataEditor"] thead th {
        background: #edf4fd !important;
        color: #0b3569 !important;
        font-weight: 750 !important;
        border-bottom: 1px solid #cedbea !important;
    }
    .ag-theme-streamlit, .ag-root-wrapper {
        --ag-header-background-color: #edf4fd;
        --ag-header-foreground-color: #0b3569;
        --ag-odd-row-background-color: #f8fbff;
        --ag-row-hover-color: #eaf2ff;
        --ag-border-color: #d8e3f0;
        --ag-font-family: Inter, "Segoe UI", Arial, sans-serif;
        --ag-font-size: 12px;
        border-radius: .65rem !important;
    }

    /* Charts sit on white cards without Plotly's default grey canvas. */
    [data-testid="stPlotlyChart"] {
        background: #ffffff !important;
        border: 1px solid var(--clarity-border) !important;
        border-radius: .7rem !important;
        padding: .25rem !important;
        box-shadow: 0 2px 8px rgba(3,43,88,.04) !important;
    }

    /* V113: keep every selected/active Streamlit button label white.
       Streamlit may place the visible label inside nested p/span/div nodes,
       so both the button and every label descendant must be overridden. */
    div[data-testid="stButton"] button[kind="primary"],
    div[data-testid="stButton"] button[kind="primary"] *,
    div[data-testid="stFormSubmitButton"] button[kind="primary"],
    div[data-testid="stFormSubmitButton"] button[kind="primary"] *,
    div[data-testid="stDownloadButton"] button[kind="primary"],
    div[data-testid="stDownloadButton"] button[kind="primary"] *,
    button[data-testid="baseButton-primary"],
    button[data-testid="baseButton-primary"] *,
    button[aria-pressed="true"],
    button[aria-pressed="true"] *,
    button[aria-selected="true"],
    button[aria-selected="true"] *,
    button[data-active="true"],
    button[data-active="true"] *,
    div[data-testid="stButton"] button:active,
    div[data-testid="stButton"] button:active *,
    div[data-testid="stFormSubmitButton"] button:active,
    div[data-testid="stFormSubmitButton"] button:active *,
    div[data-testid="stDownloadButton"] button:active,
    div[data-testid="stDownloadButton"] button:active * {
        color: #ffffff !important;
        -webkit-text-fill-color: #ffffff !important;
    }

    /* V114: selected buttons in the right-hand/top navigation strip.
       This selector is intentionally more specific than the generic navigation
       label rule so nested Streamlit p/span elements remain white. */
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"]
        div[data-testid="stButton"] button[kind="primary"],
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"]
        div[data-testid="stButton"] button[kind="primary"] *,
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"]
        button[data-testid="baseButton-primary"],
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"]
        button[data-testid="baseButton-primary"] * {
        color: #ffffff !important;
        -webkit-text-fill-color: #ffffff !important;
        fill: #ffffff !important;
    }

    /* V119: keep selected top-navigation labels dark and readable.
       This override is deliberately placed after the global selected-button rule.
       It applies only to the right-side page navigation strip and does not alter
       action, form-submit, download, or page-content buttons. */
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"]
        div[data-testid="stButton"] button[kind="primary"],
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"]
        div[data-testid="stButton"] button[kind="primary"] *,
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"]
        button[data-testid="baseButton-primary"],
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"]
        button[data-testid="baseButton-primary"] * {
        color: #0b3569 !important;
        -webkit-text-fill-color: #0b3569 !important;
        fill: #0b3569 !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"]
        div[data-testid="stButton"] button[kind="primary"],
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"]
        button[data-testid="baseButton-primary"] {
        background: #e7f1ff !important;
        border-color: #8fb9ee !important;
        box-shadow: inset 0 -2px 0 #0b5ed7 !important;
    }

    /* Status messaging. */
    [data-testid="stAlert"] { border-radius: .6rem !important; border-width: 1px !important; }
    [data-testid="stProgress"] > div > div { background: var(--clarity-blue) !important; }
    hr { border-color: #dce5ef !important; }

    /* Responsive refinements. */
    @media (max-width: 900px) {
        [data-testid="stMainBlockContainer"], .block-container { padding: .8rem .65rem 1.5rem !important; }
        [data-testid="stHeader"]::after, [data-testid="stAppHeader"]::after { content: "CLARITY AUTOML" !important; }
    }
    </style>
    """, unsafe_allow_html=True)


render_combined_ratio_dashboard_theme()


def render_v118_visibility_fixes() -> None:
    """Apply targeted visibility and header copy fixes requested for v118."""
    st.markdown(
        """
        <style>
        /* v118: sidebar section headings must remain visible on the dark pane. */
        section[data-testid="stSidebar"] h1,
        section[data-testid="stSidebar"] h2,
        section[data-testid="stSidebar"] h3,
        section[data-testid="stSidebar"] [data-testid="stHeading"] {
            color: #ffffff !important;
            -webkit-text-fill-color: #ffffff !important;
        }

        /* v118: Primary file uploader action text and icon use black for contrast. */
        section[data-testid="stSidebar"] [data-testid="stFileUploader"] button,
        section[data-testid="stSidebar"] [data-testid="stFileUploader"] button *,
        section[data-testid="stSidebar"] [data-testid="stFileUploaderDropzone"] button,
        section[data-testid="stSidebar"] [data-testid="stFileUploaderDropzone"] button * {
            color: #000000 !important;
            -webkit-text-fill-color: #000000 !important;
        }
        section[data-testid="stSidebar"] [data-testid="stFileUploader"] button svg,
        section[data-testid="stSidebar"] [data-testid="stFileUploaderDropzone"] button svg {
            color: #000000 !important;
            fill: #000000 !important;
            stroke: #000000 !important;
        }

        /* v121: explicitly rendered uploaded filenames remain visible in black. */
        section[data-testid="stSidebar"] .clarity-uploaded-filename,
        section[data-testid="stSidebar"] .clarity-uploaded-filename * {
            color: #000000 !important;
            -webkit-text-fill-color: #000000 !important;
            opacity: 1 !important;
        }

        /* v118: Analysis name entry is black on a white input surface. */
        section[data-testid="stSidebar"] [data-testid="stTextInput"] input {
            color: #000000 !important;
            -webkit-text-fill-color: #000000 !important;
            caret-color: #000000 !important;
            background: #ffffff !important;
        }
        section[data-testid="stSidebar"] [data-testid="stTextInput"] input::placeholder {
            color: #4b5563 !important;
            -webkit-text-fill-color: #4b5563 !important;
            opacity: 1 !important;
        }

        /* v118: selected-filter heading and rendered summary stay white. */
        section[data-testid="stSidebar"] div[data-testid="stSubheader"],
        section[data-testid="stSidebar"] div[data-testid="stSubheader"] *,
        section[data-testid="stSidebar"] [data-testid="stMarkdownContainer"] strong {
            color: #ffffff !important;
            -webkit-text-fill-color: #ffffff !important;
        }

        /* v118: replace the right-hand top-header label with decision-focused copy. */
        [data-testid="stHeader"]::after,
        [data-testid="stAppHeader"]::after {
            content: "Add the data, conduct analysis, and uncover insights to facilitate clear, data-driven decisions" !important;
            text-transform: none !important;
            letter-spacing: 0 !important;
            font-size: .82rem !important;
            font-weight: 600 !important;
        }
        @media (max-width: 900px) {
            [data-testid="stHeader"]::after,
            [data-testid="stAppHeader"]::after {
                content: "Add data, analyse, and uncover insights" !important;
            }
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


render_v118_visibility_fixes()


OPERATORS = [
    "equals", "not equals", "contains", "does not contain", "starts with", "ends with",
    "greater than", "greater than or equal", "less than", "less than or equal",
    "between", "in list", "not in list", "is blank", "is not blank",
]


def init_state() -> None:
    defaults: dict[str, Any] = {
        "filters": [],
        "audit_log": [],
        "joined_data": None,
        "filtered_data": None,
        "modified_dataset_revision": 0,
        "created_column_preview": None,
        "created_column_config": {},
        "bucket_count": 3,
        "join_config": {},
        "last_filter_config": {},
        "analysis_name": "excel_analysis",
        "input_signature": None,
        "db_data_1": None,
        "db_data_2": None,
        "db_meta_1": {},
        "db_meta_2": {},
        "base_data_1": None,
        "base_data_2": None,
        "profile_revision_1": 0,
        "profile_revision_2": 0,
        "pivot_data": None,
        "preview_pivot_data": None,
        "preview_pivot_config": {},
        "wide_sidebar": False,
        "saved_deep_dive_filters": {},
        "deep_dive_popup_event_id": 0,
        "deep_dive_popup_shown_event_id": 0,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def publish_modified_dataset(data: pd.DataFrame) -> None:
    """Publish a dataframe as Modified Dataset and mark it as a new revision."""
    st.session_state.filtered_data = data
    st.session_state.modified_dataset_revision = int(
        st.session_state.get("modified_dataset_revision", 0)
    ) + 1


def clear_modified_dataset() -> None:
    """Clear Modified Dataset and its automatic-selection tracking."""
    st.session_state.filtered_data = None
    st.session_state.modified_dataset_revision = int(
        st.session_state.get("modified_dataset_revision", 0)
    ) + 1
    st.session_state.pop("modified_dataset_applied_revision", None)




def transpose_rows_wide(
    df: pd.DataFrame,
    static_columns: list[str],
    column_name_field: str,
    value_field: str,
    aggregation: str = "First",
) -> pd.DataFrame:
    """Convert long-form rows to wide form using row values as new column names."""
    if not static_columns:
        raise ValueError("Select at least one static column.")
    if not column_name_field:
        raise ValueError("Select the column whose row values should become column names.")
    if not value_field:
        raise ValueError("Select the column containing the output values.")

    selected = static_columns + [column_name_field, value_field]
    if len(selected) != len(set(selected)):
        raise ValueError("Static, column-name, and value fields must be different.")

    work = df[selected].copy()
    work = work.dropna(subset=[column_name_field])
    if work.empty:
        raise ValueError("No usable values were found in the selected column-name field.")

    # Preserve readable labels while preventing accidental duplicate labels caused by
    # mixed numeric/string representations of the same value.
    work[column_name_field] = work[column_name_field].astype(str).str.strip()
    work = work[work[column_name_field] != ""]

    aggregation_map = {
        "First": "first",
        "Last": "last",
        "Sum": "sum",
        "Mean": "mean",
        "Minimum": "min",
        "Maximum": "max",
        "Count": "count",
    }
    aggfunc = aggregation_map.get(aggregation, "first")

    wide = pd.pivot_table(
        work,
        index=static_columns,
        columns=column_name_field,
        values=value_field,
        aggfunc=aggfunc,
        dropna=False,
        sort=False,
        observed=False,
    )
    wide = wide.reset_index()
    wide.columns.name = None
    return wide

def utc_now() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def audit(action: str, details: dict[str, Any] | None = None) -> None:
    st.session_state.audit_log.append({
        "timestamp": utc_now(),
        "action": action,
        "details": json.dumps(details or {}, ensure_ascii=False, default=str),
    })


def file_fingerprint(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()[:16]


def dataframe_signature(df: pd.DataFrame) -> str:
    """Create a lightweight, stable signature without hashing every cell on every rerun."""
    sample = df.head(128)
    payload = f"{len(df)}|{len(df.columns)}|{'|'.join(map(str, df.columns))}|{sample.to_csv(index=False)}"
    return hashlib.sha256(payload.encode("utf-8", errors="ignore")).hexdigest()[:16]


@st.cache_data(show_spinner=False, max_entries=12)
def sampled_explore_frame(df: pd.DataFrame, max_rows: int, seed: int, signature: str) -> pd.DataFrame:
    del signature
    if max_rows <= 0 or len(df) <= max_rows:
        return df
    return df.sample(n=int(max_rows), random_state=int(seed)).sort_index()


def candidate_combination_count(feature_count: int, max_len: int) -> int:
    return int(sum(math.comb(feature_count, k) for k in range(1, min(max_len, feature_count) + 1)))


@st.cache_data(show_spinner=False)
def get_sheet_names(file_bytes: bytes, filename: str) -> list[str]:
    if filename.lower().endswith(".csv"):
        return ["CSV"]
    return pd.ExcelFile(BytesIO(file_bytes)).sheet_names


@st.cache_data(show_spinner=False)
def load_table(file_bytes: bytes, filename: str, sheet_name: str | None) -> pd.DataFrame:
    """Read Excel or CSV files with resilient CSV encoding/delimiter handling."""
    stream = BytesIO(file_bytes)
    if filename.lower().endswith(".csv"):
        encodings = ["utf-8-sig", "utf-8", "cp1252", "latin-1"]
        last_error: Exception | None = None
        for encoding in encodings:
            try:
                stream.seek(0)
                # sep=None lets pandas detect comma, semicolon, tab, or pipe-delimited files.
                return pd.read_csv(
                    stream, encoding=encoding, sep=None, engine="python",
                    on_bad_lines="warn"
                )
            except (UnicodeDecodeError, UnicodeError, pd.errors.ParserError) as exc:
                last_error = exc
        raise ValueError(
            "CSV could not be decoded using UTF-8, Windows-1252, or Latin-1. "
            f"Last error: {last_error}"
        )
    return pd.read_excel(stream, sheet_name=sheet_name)


def validate_read_only_sql(query: str) -> str:
    """Allow result-returning SQL while blocking obvious write or multi-statement commands."""
    cleaned = query.strip().rstrip(";").strip()
    if not cleaned:
        raise ValueError("Enter a SQL query.")
    # Reject multiple statements. A trailing semicolon is accepted.
    if ";" in cleaned:
        raise ValueError("Run one SQL statement at a time.")
    first = re.match(r"^\s*([A-Za-z]+)", cleaned)
    command = first.group(1).lower() if first else ""
    allowed = {"select", "with", "show", "describe", "desc", "explain"}
    if command not in allowed:
        raise ValueError("Only read-only SELECT, WITH, SHOW, DESCRIBE, or EXPLAIN queries are allowed.")
    return cleaned


def run_postgres_query(
    host: str, port: int, database: str, user: str, password: str,
    query: str, sslmode: str = "prefer",
) -> pd.DataFrame:
    import psycopg2

    sql_text = validate_read_only_sql(query)
    connection = psycopg2.connect(
        host=host, port=int(port), dbname=database, user=user, password=password,
        sslmode=sslmode, connect_timeout=20,
    )
    try:
        connection.set_session(readonly=True, autocommit=False)
        return pd.read_sql_query(sql_text, connection)
    finally:
        connection.close()


def run_databricks_query(
    server_hostname: str, http_path: str, access_token: str, query: str,
    catalog: str | None = None, schema: str | None = None,
) -> pd.DataFrame:
    from databricks import sql as dbsql

    sql_text = validate_read_only_sql(query)
    kwargs: dict[str, Any] = {
        "server_hostname": server_hostname,
        "http_path": http_path,
        "access_token": access_token,
    }
    if catalog:
        kwargs["catalog"] = catalog
    if schema:
        kwargs["schema"] = schema
    connection = dbsql.connect(**kwargs)
    try:
        cursor = connection.cursor()
        try:
            cursor.execute(sql_text)
            rows = cursor.fetchall()
            columns = [item[0] for item in cursor.description] if cursor.description else []
            return pd.DataFrame(rows, columns=columns)
        finally:
            cursor.close()
    finally:
        connection.close()


def load_connection_profiles() -> dict[str, dict[str, dict[str, Any]]]:
    """Load saved database profiles from the project folder."""
    empty = {"PostgreSQL": {}, "Databricks": {}}
    if not CONNECTION_CONFIG_PATH.exists():
        return empty
    try:
        payload = json.loads(CONNECTION_CONFIG_PATH.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            return empty
        for db_type in empty:
            value = payload.get(db_type, {})
            empty[db_type] = value if isinstance(value, dict) else {}
        return empty
    except Exception:
        return empty


def save_connection_profiles(profiles: dict[str, dict[str, dict[str, Any]]]) -> None:
    """Persist profiles atomically in the project folder with owner-only permissions where supported."""
    CONNECTION_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix="connection_profiles_", suffix=".json", dir=str(CONNECTION_CONFIG_PATH.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(profiles, handle, indent=2, ensure_ascii=False)
        try:
            os.chmod(tmp_name, 0o600)
        except OSError:
            pass
        os.replace(tmp_name, CONNECTION_CONFIG_PATH)
        try:
            os.chmod(CONNECTION_CONFIG_PATH, 0o600)
        except OSError:
            pass
    finally:
        if os.path.exists(tmp_name):
            os.unlink(tmp_name)


def apply_connection_profile(dataset_number: int, db_type: str, profile: dict[str, Any]) -> None:
    """Populate source-specific Streamlit widget state from a saved profile."""
    if db_type == "PostgreSQL":
        mapping = {
            f"pg_host_{dataset_number}": profile.get("host", ""),
            f"pg_port_{dataset_number}": int(profile.get("port", 5432)),
            f"pg_database_{dataset_number}": profile.get("database", ""),
            f"pg_user_{dataset_number}": profile.get("user", ""),
            f"pg_password_{dataset_number}": profile.get("password", ""),
            f"pg_sslmode_{dataset_number}": profile.get("sslmode", "prefer"),
        }
    else:
        mapping = {
            f"dbx_host_{dataset_number}": profile.get("server_hostname", ""),
            f"dbx_http_path_{dataset_number}": profile.get("http_path", ""),
            f"dbx_token_{dataset_number}": profile.get("access_token", ""),
            f"dbx_catalog_{dataset_number}": profile.get("catalog", ""),
            f"dbx_schema_{dataset_number}": profile.get("schema", ""),
        }
    for key, value in mapping.items():
        st.session_state[key] = value


def render_connection_profile_manager(dataset_number: int, db_type: str) -> None:
    """Render load/save/delete controls for persistent project-level connection profiles."""
    profiles = load_connection_profiles()
    type_profiles = profiles.get(db_type, {})
    profile_names = sorted(type_profiles)
    db_slug = db_type.lower().replace(" ", "_")

    st.markdown("**Saved connection profiles**")
    selected = st.selectbox(
        "Saved profile", ["— Select —"] + profile_names,
        key=f"saved_profile_{dataset_number}_{db_slug}", label_visibility="collapsed",
    )

    # Keep profile actions below the selector in a responsive two-button row.
    # Container-width buttons shrink and grow with the sidebar without overlapping.
    with st.container(key=f"profile_actions_{dataset_number}_{db_slug}"):
        load_col, delete_col = st.columns([1, 1], gap="small")
        load_clicked = load_col.button(
            "Load", key=f"load_profile_{dataset_number}_{db_slug}", use_container_width=True
        )
        delete_clicked = delete_col.button(
            "Delete", key=f"delete_profile_{dataset_number}_{db_slug}", use_container_width=True
        )

    if load_clicked:
        if selected == "— Select —":
            st.warning("Select a saved profile first.")
        else:
            apply_connection_profile(dataset_number, db_type, type_profiles[selected])
            st.session_state[f"profile_name_{dataset_number}_{db_slug}"] = selected
            audit("CONNECTION_PROFILE_LOADED", {"dataset": dataset_number, "database_type": db_type, "profile": selected})
            st.rerun()
    if delete_clicked:
        if selected == "— Select —":
            st.warning("Select a saved profile first.")
        else:
            del profiles[db_type][selected]
            save_connection_profiles(profiles)
            audit("CONNECTION_PROFILE_DELETED", {"dataset": dataset_number, "database_type": db_type, "profile": selected})
            st.success(f"Deleted profile '{selected}'.")
            st.rerun()


def render_database_source(dataset_number: int, db_type: str) -> tuple[pd.DataFrame | None, dict[str, Any]]:
    """Render controls for one explicit database source and return its persisted query result."""
    db_slug = db_type.lower().replace(" ", "_")
    state_key = f"db_data_{dataset_number}_{db_slug}"
    meta_key = f"db_meta_{dataset_number}_{db_slug}"
    with st.expander(f"{db_type} connection details", expanded=True):
        render_connection_profile_manager(dataset_number, db_type)
        st.divider()
        if db_type == "PostgreSQL":
            c1, c2 = st.columns([3, 1])
            host = c1.text_input("Host", key=f"pg_host_{dataset_number}")
            port = c2.number_input("Port", 1, 65535, 5432, key=f"pg_port_{dataset_number}")
            database = st.text_input("Database", key=f"pg_database_{dataset_number}")
            user = st.text_input("User", key=f"pg_user_{dataset_number}")
            password = st.text_input("Password", type="password", key=f"pg_password_{dataset_number}")
            sslmode = st.selectbox(
                "SSL mode", ["prefer", "require", "verify-ca", "verify-full", "disable"],
                key=f"pg_sslmode_{dataset_number}",
            )
        else:
            server_hostname = st.text_input(
                "Server hostname", placeholder="dbc-xxxxxxxx.cloud.databricks.com",
                key=f"dbx_host_{dataset_number}",
            )
            http_path = st.text_input(
                "HTTP path", placeholder="/sql/1.0/warehouses/xxxxxxxx",
                key=f"dbx_http_path_{dataset_number}",
            )
            access_token = st.text_input("Access token", type="password", key=f"dbx_token_{dataset_number}")
            c1, c2 = st.columns(2)
            catalog = c1.text_input("Catalog (optional)", key=f"dbx_catalog_{dataset_number}")
            schema = c2.text_input("Schema (optional)", key=f"dbx_schema_{dataset_number}")

        st.markdown("**Save this connection**")
        profile_name = st.text_input(
            "Profile name", placeholder="e.g. Production warehouse",
            key=f"profile_name_{dataset_number}_{db_slug}", label_visibility="collapsed",
        )
        save_actions_key = f"save_actions_{dataset_number}_{db_slug}"
        save_actions_css = """
            <style>
            .st-key-__SAVE_ACTIONS_KEY__ div[data-testid="stButton"] button {
                width: 120px !important;
                min-width: 120px !important;
                max-width: 120px !important;
            }
            </style>
        """.replace("__SAVE_ACTIONS_KEY__", save_actions_key)
        st.markdown(save_actions_css, unsafe_allow_html=True)
        with st.container(key=save_actions_key):
            save_clicked = st.button(
                "Save config", key=f"save_profile_{dataset_number}_{db_slug}", use_container_width=False
            )
        if save_clicked:
            clean_profile_name = profile_name.strip()
            if not clean_profile_name:
                st.warning("Enter a profile name before saving.")
            else:
                profiles = load_connection_profiles()
                if db_type == "PostgreSQL":
                    profile_payload = {
                        "host": host, "port": int(port), "database": database, "user": user,
                        "password": password, "sslmode": sslmode,
                    }
                else:
                    profile_payload = {
                        "server_hostname": server_hostname, "http_path": http_path,
                        "access_token": access_token, "catalog": catalog, "schema": schema,
                    }
                profiles.setdefault(db_type, {})[clean_profile_name] = profile_payload
                save_connection_profiles(profiles)
                audit("CONNECTION_PROFILE_SAVED", {
                    "dataset": dataset_number, "database_type": db_type, "profile": clean_profile_name,
                    "config_file": CONNECTION_CONFIG_PATH.name,
                })
                st.success(f"Saved profile '{clean_profile_name}' to {CONNECTION_CONFIG_PATH.name}.")
                st.rerun()
        st.caption(
            f"Profiles are stored in `{CONNECTION_CONFIG_PATH.name}` inside the project folder. "
            "Passwords and access tokens are saved because the profile is intended for reuse; keep this file private and exclude it from source control."
        )

        query = st.text_area(
            "Custom SQL query", height=150, placeholder="SELECT * FROM schema.table LIMIT 1000",
            key=f"db_query_{dataset_number}_{db_slug}",
        )
        query_actions_key = f"query_actions_{dataset_number}_{db_slug}"
        # Responsive action row: both buttons share the available pane width.
        # A wider ratio is reserved for the longer clear label.
        with st.container(key=query_actions_key):
            run_col, clear_col = st.columns([1, 1.55], gap="small")
            run_query_clicked = run_col.button(
                "Run", type="primary", key=f"run_db_query_{dataset_number}_{db_slug}",
                use_container_width=True,
            )
            clear_query_clicked = clear_col.button(
                "Clear", key=f"clear_db_query_{dataset_number}_{db_slug}",
                use_container_width=True,
            )

        if run_query_clicked:
            try:
                with st.spinner("Running query..."):
                    if db_type == "PostgreSQL":
                        if not all([host, database, user, password]):
                            raise ValueError("Host, database, user, and password are required.")
                        result = run_postgres_query(host, int(port), database, user, password, query, sslmode)
                        safe_meta = {"database_type": db_type, "host": host, "database": database, "query": query}
                    else:
                        if not all([server_hostname, http_path, access_token]):
                            raise ValueError("Server hostname, HTTP path, and access token are required.")
                        result = run_databricks_query(server_hostname, http_path, access_token, query, catalog or None, schema or None)
                        safe_meta = {
                            "database_type": db_type, "server_hostname": server_hostname,
                            "http_path": http_path, "catalog": catalog, "schema": schema, "query": query,
                        }
                st.session_state[state_key] = result
                st.session_state[meta_key] = safe_meta
                audit("DATABASE_QUERY_EXECUTED", {
                    "dataset": dataset_number, "database_type": db_type,
                    "rows": len(result), "columns": len(result.columns),
                    "query_hash": hashlib.sha256(query.encode("utf-8")).hexdigest()[:16],
                })
                st.success(f"Query returned {len(result):,} rows and {len(result.columns):,} columns.")
                st.rerun()
            except Exception as exc:
                audit("DATABASE_QUERY_FAILED", {"dataset": dataset_number, "database_type": db_type, "error": str(exc)})
                st.error(f"Could not run query: {exc}")
        if clear_query_clicked:
            st.session_state[state_key] = None
            st.session_state[meta_key] = {}
            st.rerun()

    result = st.session_state.get(state_key)
    meta = st.session_state.get(meta_key, {})
    # Database query results are retained in session state and loaded into the
    # selected dataset, but are intentionally not rendered in the left pane.
    return result, meta


def make_unique_columns(df: pd.DataFrame, source: str) -> pd.DataFrame:
    result = df.copy()
    counts: dict[str, int] = {}
    columns: list[str] = []
    for raw in result.columns:
        col = str(raw).strip() or "Unnamed"
        counts[col] = counts.get(col, 0) + 1
        unique = col if counts[col] == 1 else f"{col}_{counts[col]}"
        columns.append(f"{source}.{unique}")
    result.columns = columns
    return result


def normalize_key(series: pd.Series, trim: bool, lower: bool) -> pd.Series:
    result = series.astype("string")
    if trim:
        result = result.str.strip()
    if lower:
        result = result.str.lower()
    return result


def json_bytes(value: Any) -> bytes:
    return json.dumps(value, indent=2, ensure_ascii=False, default=str).encode("utf-8")


def to_excel_bytes(sheets: dict[str, pd.DataFrame]) -> bytes:
    output = BytesIO()
    with pd.ExcelWriter(output, engine="xlsxwriter") as writer:
        for sheet_name, df in sheets.items():
            safe_name = sheet_name[:31]
            df.to_excel(writer, index=False, sheet_name=safe_name)
            worksheet = writer.sheets[safe_name]
            for index, column in enumerate(df.columns):
                if df.empty:
                    sample_width = 0
                else:
                    lengths = df[column].head(500).map(
                        lambda value: len(str(value)) if pd.notna(value) else 0
                    )
                    max_width = lengths.max()
                    sample_width = int(max_width) if pd.notna(max_width) else 0
                header_width = len(str(column))
                worksheet.set_column(index, index, min(max(sample_width, header_width) + 2, 50))
    return output.getvalue()


def render_profile_style_grid(
    df: pd.DataFrame,
    key: str,
    height: int = 480,
) -> pd.DataFrame:
    """Render a read-only profile-style grid with per-column filters."""
    return render_grid(
        df.copy(),
        key=key,
        fit_columns=False,
        wrap_headers=False,
        force_horizontal_scroll=True,
        enable_floating_filters=True,
        height=height,
    )


def render_grid(
    df: pd.DataFrame,
    key: str,
    fit_columns: bool = False,
    wrap_headers: bool = True,
    force_horizontal_scroll: bool = False,
    enable_floating_filters: bool = False,
    height: int = 480,
) -> pd.DataFrame:
    gb = GridOptionsBuilder.from_dataframe(df)
    gb.configure_default_column(
        sortable=True, filter=True, resizable=True, editable=False,
        enableRowGroup=True, enablePivot=True, enableValue=True,
        wrapHeaderText=wrap_headers, autoHeaderHeight=wrap_headers,
        minWidth=140 if force_horizontal_scroll else 100,
        floatingFilter=enable_floating_filters,
        headerClass="clarity-left-header",
        cellClass="clarity-left-cell",
        cellStyle={"textAlign": "left", "justifyContent": "flex-start"},
    )
    # Explicitly remove AG Grid's numeric-column type from every field. That type
    # injects right-aligned header/cell classes even when a general style is set.
    for column in df.columns:
        gb.configure_column(
            column,
            type=[],
            headerClass="clarity-left-header",
            cellClass="clarity-left-cell",
            cellStyle={"textAlign": "left", "justifyContent": "flex-start"},
        )
    if force_horizontal_scroll:
        # Give every column a stable width based on its header. With size-to-fit disabled,
        # the total grid width can exceed the viewport and AG Grid renders its native
        # horizontal scrollbar instead of wrapping or compressing the headers.
        for column in df.columns:
            header_width = max(140, min(320, len(str(column)) * 9 + 44))
            gb.configure_column(
                column,
                type=[],
                width=header_width,
                minWidth=header_width,
                wrapHeaderText=False,
                autoHeaderHeight=False,
                headerClass="clarity-left-header",
                cellClass="clarity-left-cell",
                cellStyle={"textAlign": "left", "justifyContent": "flex-start"},
            )

    gb.configure_pagination(enabled=True, paginationAutoPageSize=False, paginationPageSize=50)
    gb.configure_grid_options(
        sideBar=True,
        rowSelection="multiple",
        animateRows=True,
        domLayout="normal",
        suppressPaginationPanel=False,
        suppressHorizontalScroll=False,
        alwaysShowHorizontalScroll=force_horizontal_scroll,
    )
    grid_css = {
        ".ag-header": {"position": "sticky", "top": "0", "z-index": "10"},
        ".clarity-left-header .ag-header-cell-label": {
            "justify-content": "flex-start !important",
            "text-align": "left !important",
            "flex-direction": "row !important",
            "white-space": "nowrap !important" if not wrap_headers else "normal",
            "overflow": "visible !important" if not wrap_headers else "hidden",
        },
        ".clarity-left-header .ag-header-cell-text": {
            "text-align": "left !important",
            "margin-left": "0 !important",
            "margin-right": "auto !important",
            "white-space": "nowrap !important" if not wrap_headers else "normal",
            "overflow": "hidden",
            "text-overflow": "ellipsis",
        },
        ".ag-right-aligned-header .ag-header-cell-label": {
            "justify-content": "flex-start !important",
            "text-align": "left !important",
            "flex-direction": "row !important",
        },
        ".ag-right-aligned-header .ag-header-cell-text": {
            "text-align": "left !important",
            "margin-left": "0 !important",
            "margin-right": "auto !important",
        },
        ".clarity-left-cell": {"text-align": "left !important", "justify-content": "flex-start !important"},
        ".ag-cell": {"text-align": "left !important", "justify-content": "flex-start !important"},
        ".ag-right-aligned-cell": {"text-align": "left !important", "justify-content": "flex-start !important"},
        ".ag-cell-value": {"text-align": "left !important", "justify-content": "flex-start !important"},
        ".ag-center-cols-viewport": {"overflow-x": "auto !important"},
        ".ag-body-horizontal-scroll": {
            "display": "flex !important",
            "visibility": "visible !important",
            "min-height": "18px !important",
            "height": "18px !important",
        },
        ".ag-body-horizontal-scroll-viewport": {
            "display": "block !important",
            "overflow-x": "scroll !important",
            "min-height": "18px !important",
            "height": "18px !important",
        },
        ".ag-body-horizontal-scroll-container": {"min-width": "100% !important"},
    }
    response = AgGrid(
        df, gridOptions=gb.build(), height=height, fit_columns_on_grid_load=fit_columns,
        data_return_mode=DataReturnMode.FILTERED_AND_SORTED,
        update_mode=GridUpdateMode.NO_UPDATE, allow_unsafe_jscode=False,
        theme="streamlit", key=key, custom_css=grid_css,
    )
    return pd.DataFrame(response.get("data", df))


@st.dialog("Categorize Calculated Column", width="large")
def render_bucket_dialog() -> None:
    """Create a categorized companion column from the selected/calculated column."""
    calculated = st.session_state.get("created_column_preview")
    config = st.session_state.get("created_column_config", {})
    created_name = config.get("created_column")
    if calculated is None or not created_name or created_name not in calculated.columns:
        st.warning("Create or select a column before categorizing it.")
        return

    source = calculated[created_name]
    category_column = f"{created_name}_Cat"
    method = st.radio(
        "Category condition",
        ["Minimum / Maximum ranges", "Is blank / Is defined"],
        horizontal=True,
        key="bucket_category_condition",
        help="Use numeric ranges, or classify each row based on whether the selected column has a value.",
    )

    if method == "Is blank / Is defined":
        st.caption(
            f"Create **{category_column}** by checking whether **{created_name}** is blank or defined. "
            "Blank includes null values and empty or whitespace-only text."
        )
        cols = st.columns(2)
        blank_label = cols[0].text_input(
            "Category name for blank values", value="Blank", key="bucket_blank_label"
        )
        defined_label = cols[1].text_input(
            "Category name for defined values", value="Defined", key="bucket_defined_label"
        )

        blank_mask = source.isna() | source.astype("string").str.strip().eq("")
        metric_cols = st.columns(2)
        metric_cols[0].metric("Blank rows", f"{int(blank_mask.sum()):,}")
        metric_cols[1].metric("Defined rows", f"{int((~blank_mask).sum()):,}")

        if st.button("Apply categories", type="primary", use_container_width=True, key="apply_blank_defined_categories"):
            blank_name = blank_label.strip()
            defined_name = defined_label.strip()
            if not blank_name or not defined_name:
                st.error("Both category names are required.")
                return
            if blank_name == defined_name:
                st.error("Blank and defined categories must have different names.")
                return

            categorized = calculated.copy()
            categorized[category_column] = pd.Series(
                np.where(blank_mask, blank_name, defined_name),
                index=calculated.index,
                dtype="string",
            )
            new_config = {
                **config,
                "bucketed": True,
                "categorized": True,
                "category_column": category_column,
                "category_method": "blank_defined",
                "blank_label": blank_name,
                "defined_label": defined_name,
            }
            st.session_state.created_column_preview = categorized
            st.session_state.created_column_config = new_config
            if config.get("published"):
                publish_modified_dataset(categorized)
                st.session_state.last_filter_config = dict(new_config)
                st.session_state.main_preview_source = "Modified Dataset"
            audit("CALCULATED_COLUMN_CATEGORIZED", {
                "column": created_name,
                "category_column": category_column,
                "category_method": "blank_defined",
                "blank_rows": int(blank_mask.sum()),
                "defined_rows": int((~blank_mask).sum()),
                "published": bool(config.get("published")),
            })
            st.success(f"Created '{category_column}' using blank/defined conditions.")
            st.rerun()
        return

    numeric = pd.to_numeric(source, errors="coerce")
    valid = numeric.dropna()
    if valid.empty:
        st.warning(
            f"'{created_name}' does not contain numeric values for minimum/maximum categorization. "
            "Select 'Is blank / Is defined' to categorize this column by value availability."
        )
        return

    data_min = float(valid.min())
    data_max = float(valid.max())
    st.info(
        f"Data range for **{created_name}** — Minimum: **{data_min:,.6g}** | "
        f"Maximum: **{data_max:,.6g}**"
    )
    st.caption(
        f"Define labels and ranges for **{created_name}**. Clarity will create a separate "
        f"category column named **{category_column}**. Minimum values are inclusive; maximum "
        "values are exclusive except for the final category."
    )
    bucket_count = st.number_input(
        "Number of categories", min_value=2, max_value=10, value=int(st.session_state.get("bucket_count", 3)),
        step=1, key="bucket_dialog_count", help="Choose how many labelled value ranges to create.",
    )
    st.session_state.bucket_count = int(bucket_count)
    edges = np.linspace(data_min, data_max, int(bucket_count) + 1)
    definitions = []
    header = st.columns([1.4, 1, 1])
    header[0].markdown("**Category name**")
    header[1].markdown("**Minimum**")
    header[2].markdown("**Maximum**")
    for idx in range(int(bucket_count)):
        cols = st.columns([1.4, 1, 1])
        name = cols[0].text_input(
            f"Category {idx + 1} name", value=f"Category {idx + 1}",
            key=f"bucket_name_{idx}", label_visibility="collapsed",
        )
        minimum = cols[1].number_input(
            f"Category {idx + 1} minimum", value=float(edges[idx]), format="%.6f",
            key=f"bucket_min_{idx}", label_visibility="collapsed",
        )
        maximum = cols[2].number_input(
            f"Category {idx + 1} maximum", value=float(edges[idx + 1]), format="%.6f",
            key=f"bucket_max_{idx}", label_visibility="collapsed",
        )
        definitions.append({"name": str(name).strip(), "min": float(minimum), "max": float(maximum)})

    unmatched_label = st.text_input(
        "Label for values outside all ranges", value="Uncategorized",
        help="Values not covered by the configured ranges receive this label. Original missing values remain missing.",
    )
    if st.button("Apply categories", type="primary", use_container_width=True, key="apply_range_categories"):
        names = [item["name"] for item in definitions]
        if any(not name for name in names):
            st.error("Every category must have a name.")
            return
        if len(set(names)) != len(names):
            st.error("Category names must be unique.")
            return
        ordered = sorted(definitions, key=lambda item: (item["min"], item["max"]))
        if any(item["min"] >= item["max"] for item in ordered):
            st.error("Each category minimum must be less than its maximum.")
            return
        for previous, current in zip(ordered, ordered[1:]):
            if current["min"] < previous["max"]:
                st.error(
                    f"Ranges '{previous['name']}' and '{current['name']}' overlap. "
                    "Adjust their minimum or maximum values."
                )
                return

        labels = pd.Series(pd.NA, index=numeric.index, dtype="string")
        covered = pd.Series(False, index=numeric.index)
        for idx, item in enumerate(ordered):
            is_final = idx == len(ordered) - 1
            upper_mask = numeric.le(item["max"]) if is_final else numeric.lt(item["max"])
            mask = numeric.ge(item["min"]) & upper_mask & numeric.notna()
            labels.loc[mask] = item["name"]
            covered |= mask
        outside = numeric.notna() & ~covered
        labels.loc[outside] = unmatched_label.strip() or "Uncategorized"

        categorized = calculated.copy()
        categorized[category_column] = labels
        new_config = {
            **config,
            "bucketed": True,
            "categorized": True,
            "category_column": category_column,
            "category_method": "min_max_ranges",
            "bucket_definitions": ordered,
            "unmatched_label": unmatched_label.strip() or "Uncategorized",
        }
        st.session_state.created_column_preview = categorized
        st.session_state.created_column_config = new_config
        if config.get("published"):
            publish_modified_dataset(categorized)
            st.session_state.last_filter_config = dict(new_config)
            st.session_state.main_preview_source = "Modified Dataset"
        audit("CALCULATED_COLUMN_CATEGORIZED", {
            "column": created_name, "category_column": category_column, "bucket_count": len(ordered),
            "category_method": "min_max_ranges", "published": bool(config.get("published")),
            "unmatched_rows": int(outside.sum()), "definitions": ordered,
        })
        st.success(f"Created '{category_column}' with {len(ordered)} categories.")
        st.rerun()



def safe_python_scalar(value: Any) -> Any:
    """Convert pandas/NumPy scalar values into stable native Python values.

    Missing and non-finite values become None so they can be safely used by
    Streamlit widgets, JSON audit payloads, and dataframe summaries.
    """
    if value is None or value is pd.NA or value is pd.NaT:
        return None

    # NumPy scalar types (np.int64, np.float64, np.bool_, datetime64, etc.).
    if isinstance(value, np.generic):
        value = value.item()

    if isinstance(value, (pd.Timestamp, datetime)):
        if pd.isna(value):
            return None
        return value.to_pydatetime() if isinstance(value, pd.Timestamp) else value

    if isinstance(value, pd.Timedelta):
        return None if pd.isna(value) else value.to_pytimedelta()

    try:
        missing = pd.isna(value)
        if isinstance(missing, (bool, np.bool_)) and bool(missing):
            return None
    except (TypeError, ValueError):
        pass

    if isinstance(value, float) and not math.isfinite(value):
        return None

    return value


def safe_numeric_series(series: pd.Series) -> pd.Series:
    """Convert values to float-compatible numbers while treating pd.NA safely."""
    cleaned = series.astype("string").str.replace(",", "", regex=False).str.strip()
    cleaned = cleaned.mask(cleaned.isin(["", "<NA>", "NA", "N/A", "None", "null", "NULL"]))
    return pd.to_numeric(cleaned, errors="coerce").astype("float64")


def safe_datetime_series(
    series: pd.Series, *, utc: bool = False, dayfirst: bool = False
) -> pd.Series:
    """Parse datetimes consistently without pandas format-inference warnings."""
    if pd.api.types.is_datetime64_any_dtype(series):
        return pd.to_datetime(series, errors="coerce", utc=utc)
    if pd.api.types.is_numeric_dtype(series):
        return pd.to_datetime(series, errors="coerce", utc=utc)
    return pd.to_datetime(
        series.astype("string"),
        errors="coerce",
        format="mixed",
        dayfirst=dayfirst,
        utc=utc,
    )

def condition_mask(df: pd.DataFrame, rule: dict[str, Any]) -> pd.Series:
    column = rule["column"]
    operator = rule["operator"]
    value = str(rule.get("value", ""))
    value2 = str(rule.get("value2", ""))
    case_sensitive = bool(rule.get("case_sensitive", False))
    series = df[column]
    text = series.astype("string")
    left = text if case_sensitive else text.str.lower()
    right = value if case_sensitive else value.lower()

    if operator == "equals": return left == right
    if operator == "not equals": return left != right
    if operator == "contains": return left.str.contains(right, na=False, regex=False)
    if operator == "does not contain": return ~left.str.contains(right, na=False, regex=False)
    if operator == "starts with": return left.str.startswith(right, na=False)
    if operator == "ends with": return left.str.endswith(right, na=False)
    if operator == "is blank": return series.isna() | text.str.strip().eq("")
    if operator == "is not blank": return series.notna() & ~text.str.strip().eq("")
    if operator in {"in list", "not in list"}:
        values = [item.strip() for item in value.split(",") if item.strip()]
        if not case_sensitive:
            values = [item.lower() for item in values]
        mask = left.isin(values)
        return ~mask if operator == "not in list" else mask

    numeric = safe_numeric_series(series)
    try:
        number = float(value)
    except ValueError as exc:
        raise ValueError(f"'{value}' is not numeric for {column}") from exc
    if operator == "greater than": return numeric > number
    if operator == "greater than or equal": return numeric >= number
    if operator == "less than": return numeric < number
    if operator == "less than or equal": return numeric <= number
    if operator == "between":
        try:
            number2 = float(value2)
        except ValueError as exc:
            raise ValueError(f"'{value2}' is not numeric for the upper bound") from exc
        return numeric.between(min(number, number2), max(number, number2), inclusive="both")
    raise ValueError(f"Unsupported operator: {operator}")


def apply_filter_rules(df: pd.DataFrame, rules: list[dict[str, Any]]) -> pd.DataFrame:
    if not rules:
        return df.copy()
    combined: pd.Series | None = None
    for index, rule in enumerate(rules):
        mask = condition_mask(df, rule).fillna(False)
        if index == 0:
            combined = mask
        elif rule.get("connector", "AND") == "OR":
            combined = combined | mask  # type: ignore[operator]
        else:
            combined = combined & mask  # type: ignore[operator]
    return df[combined].copy() if combined is not None else df.copy()


def filter_summary(rule: dict[str, Any], index: int) -> str:
    prefix = "WHERE" if index == 0 else rule.get("connector", "AND")
    operator = rule["operator"]
    if operator in {"is blank", "is not blank"}:
        return f"{prefix} {rule['column']} {operator}"
    if operator == "between":
        return f"{prefix} {rule['column']} between {rule.get('value', '')} and {rule.get('value2', '')}"
    return f"{prefix} {rule['column']} {operator} {rule.get('value', '')}"


def build_dump(output_df: pd.DataFrame, filters: list[dict[str, Any]], metadata: dict[str, Any]) -> bytes:
    memory = BytesIO()
    audit_df = pd.DataFrame(st.session_state.audit_log)
    with zipfile.ZipFile(memory, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("output.xlsx", to_excel_bytes({"Analysis_Output": output_df, "Audit_Log": audit_df}))
        archive.writestr("output.csv", output_df.to_csv(index=False).encode("utf-8"))
        archive.writestr("filters.json", json_bytes({"version": 1, "filters": filters}))
        archive.writestr("audit_log.json", json_bytes(st.session_state.audit_log))
        archive.writestr("audit_log.csv", audit_df.to_csv(index=False).encode("utf-8"))
        archive.writestr("session_metadata.json", json_bytes(metadata))
    return memory.getvalue()



def infer_semantic_type(series: pd.Series) -> str:
    non_null = series.dropna()
    if non_null.empty:
        return "empty"
    if pd.api.types.is_bool_dtype(series):
        return "boolean"
    if pd.api.types.is_numeric_dtype(series):
        return "numerical"
    if pd.api.types.is_datetime64_any_dtype(series):
        return "datetime"
    text = non_null.astype(str).str.strip()
    numeric_ratio = pd.to_numeric(text.str.replace(",", "", regex=False), errors="coerce").notna().mean()
    date_ratio = safe_datetime_series(text, dayfirst=False).notna().mean()
    if numeric_ratio >= 0.9:
        return "numeric-like text"
    if date_ratio >= 0.9:
        return "date-like text"
    unique_ratio = text.nunique(dropna=True) / max(len(text), 1)
    return "identifier/text" if unique_ratio > 0.8 else "categorical"


def outlier_mask_iqr(series: pd.Series) -> pd.Series:
    numeric = safe_numeric_series(series)
    valid = numeric.dropna()
    if len(valid) < 4:
        return pd.Series(False, index=series.index)
    q1, q3 = valid.quantile([0.25, 0.75])
    iqr = q3 - q1
    if pd.isna(iqr) or iqr == 0:
        return pd.Series(False, index=series.index)
    return (numeric < q1 - 1.5 * iqr) | (numeric > q3 + 1.5 * iqr)


def detailed_profile(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    total = len(df)
    for column in df.columns:
        series = df[column]
        non_null = series.dropna()
        semantic = infer_semantic_type(series)
        blank_count = int(series.astype("string").str.strip().eq("").fillna(False).sum())
        outliers = int(outlier_mask_iqr(series).sum()) if semantic in {"numerical", "numeric-like text"} else 0
        invalid = 0
        consistency = 100.0
        if semantic == "numeric-like text":
            converted = safe_numeric_series(non_null)
            invalid = int(converted.isna().sum())
            consistency = round((1 - invalid / max(len(non_null), 1)) * 100, 2)
        elif semantic == "date-like text":
            converted = safe_datetime_series(non_null)
            invalid = int(converted.isna().sum())
            consistency = round((1 - invalid / max(len(non_null), 1)) * 100, 2)
        top_values = non_null.astype(str).value_counts().head(5)
        top_text = "; ".join(f"{k} ({v})" for k, v in top_values.items())
        rows.append({
            "column": column, "physical_type": str(series.dtype), "semantic_type": semantic,
            "rows": total, "non_null": int(series.notna().sum()), "missing": int(series.isna().sum()),
            "missing_pct": round(float(series.isna().mean() * 100), 2) if total else 0.0,
            "blank_strings": blank_count, "unique_values": int(series.nunique(dropna=True)),
            "duplicate_values": int(non_null.duplicated(keep=False).sum()),
            "outliers_iqr": outliers, "invalid_values": invalid,
            "type_consistency_pct": consistency, "top_values": top_text,
        })
    return pd.DataFrame(rows)


def quality_summary(df: pd.DataFrame) -> dict[str, int | float]:
    profile = detailed_profile(df)
    return {
        "rows": len(df), "columns": len(df.columns),
        "duplicate_rows": int(df.duplicated().sum()),
        "missing_cells": int(df.isna().sum().sum()),
        "outliers": int(profile["outliers_iqr"].sum()) if not profile.empty else 0,
        "invalid_values": int(profile["invalid_values"].sum()) if not profile.empty else 0,
    }


def detect_datetime_candidates(df: pd.DataFrame) -> list[str]:
    candidates = []
    for column in df.columns:
        series = df[column]
        if pd.api.types.is_datetime64_any_dtype(series):
            candidates.append(column)
            continue
        non_null = series.dropna().head(1000)
        if non_null.empty or pd.api.types.is_numeric_dtype(series):
            continue
        parsed = safe_datetime_series(non_null)
        if parsed.notna().mean() >= 0.8:
            candidates.append(column)
    return candidates


def basic_profile(df: pd.DataFrame) -> pd.DataFrame:
    return pd.DataFrame({
        "column": df.columns,
        "data_type": [str(df[c].dtype) for c in df.columns],
        "non_null": [int(df[c].notna().sum()) for c in df.columns],
        "nulls": [int(df[c].isna().sum()) for c in df.columns],
        "null_pct": [round(float(df[c].isna().mean() * 100), 2) for c in df.columns],
        "distinct": [int(df[c].nunique(dropna=True)) for c in df.columns],
    })


def classify_columns(df: pd.DataFrame) -> dict[str, list[str]]:
    result = {"numeric": [], "categorical": [], "datetime": [], "boolean": [], "empty": []}
    for column in df.columns:
        semantic = infer_semantic_type(df[column])
        if semantic in {"numerical", "numeric-like text"}:
            result["numeric"].append(column)
        elif semantic in {"datetime", "date-like text"}:
            result["datetime"].append(column)
        elif semantic == "boolean":
            result["boolean"].append(column)
        elif semantic == "empty":
            result["empty"].append(column)
        else:
            result["categorical"].append(column)
    return result


def all_column_descriptive_summary(df: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for column in df.columns:
        series = df[column]
        semantic = infer_semantic_type(series)
        non_null = series.dropna()
        row: dict[str, Any] = {
            "column": column,
            "semantic_type": semantic,
            "rows": len(series),
            "non_null": int(series.notna().sum()),
            "missing": int(series.isna().sum()),
            "unique": int(series.nunique(dropna=True)),
            "most_frequent": None,
            "frequency": 0,
            "min": None,
            "max": None,
            "mean": None,
            "median": None,
        }
        if not non_null.empty:
            counts = non_null.astype(str).value_counts()
            row["most_frequent"] = counts.index[0] if not counts.empty else None
            row["frequency"] = int(counts.iloc[0]) if not counts.empty else 0
        if semantic in {"numerical", "numeric-like text"}:
            numeric = safe_numeric_series(non_null)
            row.update({
                "min": safe_python_scalar(numeric.min()), "max": safe_python_scalar(numeric.max()),
                "mean": safe_python_scalar(numeric.mean()), "median": safe_python_scalar(numeric.median()),
            })
        elif semantic in {"datetime", "date-like text"}:
            dates = safe_datetime_series(non_null)
            row["min"], row["max"] = safe_python_scalar(dates.min()), safe_python_scalar(dates.max())
        rows.append(row)
    return pd.DataFrame(rows)


def encoded_association(df: pd.DataFrame, columns: list[str], method: str = "spearman") -> pd.DataFrame:
    """Create a stable numeric association matrix for mixed data types.

    Unsupported, constant, or insufficient pairs are displayed as 0.00 instead of
    NaN so the Data Mining page always shows numeric values. Valid diagonals are 1.00.
    """
    encoded = pd.DataFrame(index=df.index)
    for column in columns:
        series = df[column]
        semantic = infer_semantic_type(series)
        if semantic in {"numerical", "numeric-like text"}:
            values = safe_numeric_series(series)
        elif semantic in {"datetime", "date-like text"}:
            dates = safe_datetime_series(series, utc=True)
            values = pd.Series(np.nan, index=df.index, dtype="float64")
            valid = dates.notna()
            if valid.any():
                values.loc[valid] = dates.loc[valid].astype("int64") / 1_000_000_000
        else:
            text = series.astype("string")
            valid = text.notna() & ~text.isin(["", "<NA>"])
            values = pd.Series(np.nan, index=df.index, dtype="float64")
            if valid.any():
                codes, _ = pd.factorize(text.loc[valid], sort=True)
                values.loc[valid] = codes.astype("float64")
        encoded[str(column)] = pd.to_numeric(values, errors="coerce").replace([np.inf, -np.inf], np.nan)

    matrix = encoded.corr(method=method, min_periods=2)
    matrix = matrix.reindex(index=columns, columns=columns).astype("float64")
    matrix = matrix.replace([np.inf, -np.inf], np.nan).fillna(0.0)
    for column in columns:
        valid = encoded[str(column)].dropna()
        matrix.loc[column, column] = 1.0 if valid.nunique() > 1 else 0.0
    return matrix.clip(-1.0, 1.0)


def association_pairs_by_strength(
    matrices: dict[str, pd.DataFrame],
    medium_threshold: float = 0.40,
    high_threshold: float = 0.70,
) -> list[dict[str, Any]]:
    """Return unique medium/high association pairs, retaining the strongest algorithm result."""
    strongest: dict[tuple[str, str], dict[str, Any]] = {}
    for algorithm, matrix in matrices.items():
        columns = list(matrix.columns)
        for index, left in enumerate(columns):
            for right in columns[index + 1:]:
                value = matrix.loc[left, right]
                if pd.isna(value) or abs(float(value)) < medium_threshold:
                    continue
                key = tuple(sorted((str(left), str(right))))
                candidate = {
                    "left": str(left),
                    "right": str(right),
                    "association": float(value),
                    "algorithm": algorithm,
                    "strength": "High" if abs(float(value)) >= high_threshold else "Medium",
                }
                if key not in strongest or abs(candidate["association"]) > abs(strongest[key]["association"]):
                    strongest[key] = candidate
    return sorted(strongest.values(), key=lambda item: abs(item["association"]), reverse=True)


def grouped_deep_dive_aggregations(
    df: pd.DataFrame, categorical_column: str, numeric_column: str
) -> pd.DataFrame:
    """Aggregate a numeric feature by every category using the requested five measures."""
    work = pd.DataFrame({
        categorical_column: df[categorical_column].astype("string").fillna("<Missing>"),
        "__numeric__": safe_numeric_series(df[numeric_column]),
    })

    def first_mode(series: pd.Series):
        modes = series.dropna().mode()
        return safe_python_scalar(modes.iloc[0]) if not modes.empty else None

    result = (
        work.groupby(categorical_column, dropna=False)["__numeric__"]
        .agg(
            sum="sum",
            count="count",
            mean="mean",
            median="median",
            mode=first_mode,
        )
        .reset_index()
    )
    return result


def deep_dive_crosstab(
    df: pd.DataFrame, left: str, right: str, max_levels: int = 50
) -> tuple[pd.DataFrame, str | None]:
    """Build a readable cross-tab, binning numeric fields and limiting very wide cardinality."""
    prepared: dict[str, pd.Series] = {}
    notes: list[str] = []
    for column in (left, right):
        semantic = infer_semantic_type(df[column])
        if semantic in {"numerical", "numeric-like text"}:
            numeric = safe_numeric_series(df[column])
            unique_count = int(numeric.nunique(dropna=True))
            if unique_count > max_levels:
                try:
                    prepared[column] = pd.qcut(
                        numeric, q=min(10, unique_count), duplicates="drop"
                    ).astype("string").fillna("<Missing>")
                    notes.append(f"{column} was grouped into quantile bands for readability")
                except (ValueError, TypeError):
                    prepared[column] = numeric.astype("string").fillna("<Missing>")
            else:
                prepared[column] = numeric.astype("string").fillna("<Missing>")
        else:
            values = df[column].astype("string").fillna("<Missing>")
            top_values = values.value_counts(dropna=False).head(max_levels).index
            if values.nunique(dropna=False) > max_levels:
                prepared[column] = values.where(values.isin(top_values), "<Other>")
                notes.append(f"{column} was limited to its top {max_levels} values; remaining values are shown as <Other>")
            else:
                prepared[column] = values
    table = pd.crosstab(prepared[left], prepared[right], dropna=False)
    return table, "; ".join(notes) if notes else None


def deep_dive_prepared_series(
    df: pd.DataFrame, column: str, max_levels: int = 50
) -> tuple[pd.Series, str | None]:
    """Prepare one feature exactly as it is displayed in a Deep Dive cross-tab."""
    semantic = infer_semantic_type(df[column])
    note = None
    if semantic in {"numerical", "numeric-like text"}:
        numeric = safe_numeric_series(df[column])
        unique_count = int(numeric.nunique(dropna=True))
        if unique_count > max_levels:
            try:
                prepared = pd.qcut(
                    numeric, q=min(10, unique_count), duplicates="drop"
                ).astype("string").fillna("<Missing>")
                note = f"{column} was grouped into quantile bands for readability"
                return prepared, note
            except (ValueError, TypeError):
                pass
        return numeric.astype("string").fillna("<Missing>"), note

    values = df[column].astype("string").fillna("<Missing>")
    top_values = values.value_counts(dropna=False).head(max_levels).index
    if values.nunique(dropna=False) > max_levels:
        note = f"{column} was limited to its top {max_levels} values; remaining values are shown as <Other>"
        return values.where(values.isin(top_values), "<Other>"), note
    return values, note



def selectable_heatmap_figure(
    matrix: pd.DataFrame, title: str, x_title: str, y_title: str, color_title: str
) -> go.Figure:
    """Render a heatmap-like grid using selectable scatter points.

    Streamlit does not consistently emit point-selection events for Plotly Heatmap
    traces. Square scatter markers preserve the heatmap appearance while making
    every cell a real selectable point.
    """
    x_labels = [str(v) for v in matrix.columns]
    y_labels = [str(v) for v in matrix.index]
    x_values: list[str] = []
    y_values: list[str] = []
    z_values: list[float] = []
    cell_text: list[str] = []
    custom_data: list[list[str]] = []
    for row_label, row in matrix.iterrows():
        for column_label, value in row.items():
            numeric_value = float(value) if pd.notna(value) else 0.0
            x_values.append(str(column_label))
            y_values.append(str(row_label))
            z_values.append(numeric_value)
            cell_text.append(f"{numeric_value:.2f}" if isinstance(value, (float, np.floating)) else f"{int(numeric_value):,}")
            custom_data.append([str(row_label), str(column_label)])

    cell_count = max(len(x_labels), len(y_labels), 1)
    marker_size = max(18, min(58, int(620 / cell_count)))
    figure = go.Figure(
        go.Scatter(
            x=x_values,
            y=y_values,
            mode="markers+text",
            text=cell_text,
            textposition="middle center",
            customdata=custom_data,
            hovertemplate=(
                f"{y_title}: %{{customdata[0]}}<br>"
                f"{x_title}: %{{customdata[1]}}<br>"
                f"{color_title}: %{{marker.color}}<extra></extra>"
            ),
            marker={
                "symbol": "square",
                "size": marker_size,
                "color": z_values,
                "colorscale": "RdBu" if any(v < 0 for v in z_values) else "Blues",
                "cmid": 0 if any(v < 0 for v in z_values) else None,
                "showscale": True,
                "colorbar": {"title": color_title},
                "line": {"width": 1, "color": "rgba(255,255,255,0.55)"},
            },
            selected={"marker": {"opacity": 1}},
            unselected={"marker": {"opacity": 0.88}},
        )
    )
    figure.update_layout(
        title=title,
        xaxis={"title": x_title, "type": "category", "categoryorder": "array", "categoryarray": x_labels},
        yaxis={"title": y_title, "type": "category", "categoryorder": "array", "categoryarray": list(reversed(y_labels))},
        dragmode="select",
        clickmode="event+select",
        margin={"l": 80, "r": 40, "t": 70, "b": 80},
        height=max(420, min(850, 130 + len(y_labels) * marker_size)),
    )
    return figure



def clickable_heatmap_table(
    matrix: pd.DataFrame,
    key_prefix: str,
    value_format: str = ".2f",
    disable_diagonal: bool = False,
) -> tuple[str | None, str | None]:
    """Render a scrollable AG Grid heatmap and return a newly clicked value cell.

    Cell clicks are captured through hidden data fields rather than row selection.
    This keeps the heatmap visible while the dialog opens and prevents retained
    selection state from retriggering the previous popup on unrelated reruns.
    """
    if matrix.empty:
        return None, None

    numeric_matrix = matrix.apply(pd.to_numeric, errors="coerce").fillna(0.0)
    is_count = value_format == "count"
    max_value = float(np.nanmax(np.abs(numeric_matrix.to_numpy(dtype=float)))) if numeric_matrix.size else 0.0

    display = numeric_matrix.copy()
    display.insert(0, "Feature", [str(value) for value in numeric_matrix.index])
    display["__row_label"] = [str(value) for value in numeric_matrix.index]
    display["__clicked_col"] = ""
    display["__click_nonce"] = ""

    gb = GridOptionsBuilder.from_dataframe(display)
    gb.configure_default_column(
        sortable=False, filter=False, resizable=False, editable=False,
        suppressMovable=True, suppressSizeToFit=True, flex=0,
        wrapHeaderText=False, autoHeaderHeight=False,
        minWidth=140,
        headerClass="ag-left-aligned-header",
        cellStyle={"textAlign": "left", "justifyContent": "flex-start", "fontWeight": "700", "padding": "0 2px"},
    )
    gb.configure_column(
        "Feature", pinned="left", lockPinned=True, suppressSizeToFit=True,
        width=150, minWidth=150, maxWidth=150,
        cellStyle={"backgroundColor": "#f5f7fb", "color": "#25324a", "fontWeight": "700", "textAlign": "left"},
    )
    gb.configure_column("__row_label", hide=True)
    gb.configure_column("__clicked_col", hide=True)
    gb.configure_column("__click_nonce", hide=True)

    for column in numeric_matrix.columns:
        column_text = str(column)
        style_js = JsCode(f"""
        function(params) {{
            const value = Number(params.value || 0);
            const maxValue = {max_value!r};
            const isCount = {str(is_count).lower()};
            const disabled = {str(disable_diagonal).lower()} && String(params.data.__row_label) === {json.dumps(column_text)};
            let strength = isCount ? (maxValue <= 0 ? 0 : Math.min(Math.abs(value) / maxValue, 1)) : Math.min(Math.abs(value), 1);
            let lightness = 97 - (58 * strength);
            let hue = isCount ? 211 : (value >= 0 ? 211 : 8);
            return {{
                backgroundColor: `hsl(${{hue}}, 78%, ${{lightness}}%)`,
                color: strength >= 0.58 ? '#ffffff' : '#162033',
                fontWeight: '700', textAlign: 'left', justifyContent: 'flex-start',
                cursor: disabled ? 'not-allowed' : 'pointer',
                opacity: disabled ? 0.72 : 1, padding: '0 2px'
            }};
        }}
        """)
        formatter_js = JsCode("""
        function(params) {
            const value = Number(params.value || 0);
            return %s ? Math.round(value).toLocaleString() : value.toFixed(2);
        }
        """ % str(is_count).lower())
        gb.configure_column(
            column, width=120, minWidth=120, maxWidth=120, flex=0,
            suppressSizeToFit=True, cellStyle=style_js, valueFormatter=formatter_js,
        )

    click_js = JsCode(f"""
    function(params) {{
        if (!params.colDef || !params.colDef.field || params.colDef.field === 'Feature') return;
        if (params.colDef.field.startsWith('__')) return;
        const disabled = {str(disable_diagonal).lower()} && String(params.data.__row_label) === String(params.colDef.field);
        if (disabled) return;
        params.node.setDataValue('__clicked_col', String(params.colDef.field));
        params.node.setDataValue('__click_nonce', String(Date.now()) + '-' + String(Math.random()));
    }}
    """)
    visible_rows = min(len(display), 16)
    # Include room for AG Grid's horizontal scrollbar. The Feature column stays
    # pinned; only the centre value-column viewport scrolls horizontally.
    grid_height = 42 + (visible_rows * 34) + 24
    needs_vertical_scroll = len(display) > visible_rows

    gb.configure_grid_options(
        onCellClicked=click_js, domLayout="normal",
        suppressHorizontalScroll=False, alwaysShowHorizontalScroll=True,
        alwaysShowVerticalScroll=needs_vertical_scroll, ensureDomOrder=True,
        suppressScrollOnNewData=True, suppressColumnVirtualisation=True,
        headerHeight=42, rowHeight=34,
    )

    response = AgGrid(
        display, gridOptions=gb.build(), height=grid_height, fit_columns_on_grid_load=False,
        data_return_mode=DataReturnMode.FILTERED_AND_SORTED,
        update_mode=GridUpdateMode.VALUE_CHANGED,
        allow_unsafe_jscode=True, theme="streamlit", key=key_prefix,
        custom_css={
            # Do not override AG Grid viewport widths/overflow here. Native AG Grid
            # scrolling is driven by fixed, non-flex value columns above. Overriding
            # centre viewport/container sizing can suppress the scrollbar in some
            # streamlit-aggrid / AG Grid versions.
            ".ag-root-wrapper": {"border-radius": "10px", "max-width": "100% !important"},
            ".ag-body-horizontal-scroll": {"display": "flex !important", "visibility": "visible !important", "min-height": "18px !important", "height": "18px !important"},
            ".ag-body-horizontal-scroll-viewport": {"overflow-x": "scroll !important", "min-height": "18px !important"},
            ".ag-header-cell-label": {"justify-content": "flex-start", "font-size": "11px", "line-height": "1.1"},
            ".ag-cell": {"font-size": "11px", "line-height": "34px", "text-align": "left", "justify-content": "flex-start"},
        },
    )

    returned = response.get("data")
    if returned is None:
        return None, None
    returned_df = returned if isinstance(returned, pd.DataFrame) else pd.DataFrame(returned)
    if returned_df.empty or "__click_nonce" not in returned_df.columns:
        return None, None
    clicked = returned_df[returned_df["__click_nonce"].astype("string").fillna("").str.len() > 0]
    if clicked.empty:
        return None, None
    selected = clicked.iloc[-1].to_dict()
    row_label = selected.get("__row_label")
    column_label = selected.get("__clicked_col")
    click_nonce = selected.get("__click_nonce")
    if not row_label or not column_label or not click_nonce:
        return None, None

    signature = f"{row_label}|{column_label}|{click_nonce}"
    state_key = f"__processed_heatmap_click_{key_prefix}"
    if st.session_state.get(state_key) == signature:
        return None, None
    st.session_state[state_key] = signature
    return str(row_label), str(column_label)


def selected_cell_labels(point: dict[str, Any]) -> tuple[str | None, str | None]:
    """Read row/column labels from a selectable heatmap scatter point."""
    custom = point.get("customdata")
    if isinstance(custom, (list, tuple)) and len(custom) >= 2:
        return str(custom[0]), str(custom[1])
    x_value = point.get("x")
    y_value = point.get("y")
    return (str(y_value), str(x_value)) if x_value is not None and y_value is not None else (None, None)

def selected_plotly_point(event: Any) -> dict[str, Any] | None:
    """Return the first selected Plotly point across Streamlit state formats."""
    if event is None:
        return None
    try:
        selection = event.selection
        points = selection.points
    except Exception:
        try:
            points = event.get("selection", {}).get("points", [])
        except Exception:
            points = []
    return points[0] if points else None


def heatmap_point_labels(
    point: dict[str, Any], row_labels: list[Any], column_labels: list[Any]
) -> tuple[str | None, str | None]:
    """Resolve heatmap cell labels across Plotly/Streamlit event payload formats."""
    x_value = point.get("x")
    y_value = point.get("y")
    if x_value is not None and y_value is not None:
        return str(y_value), str(x_value)

    point_number = point.get("point_number", point.get("pointNumber"))
    if isinstance(point_number, (list, tuple)) and len(point_number) >= 2:
        row_index, column_index = int(point_number[0]), int(point_number[1])
        if 0 <= row_index < len(row_labels) and 0 <= column_index < len(column_labels):
            return str(row_labels[row_index]), str(column_labels[column_index])
    return None, None


def register_deep_dive_popup(
    filtered: pd.DataFrame, title: str, filter_text: str, audit_details: dict[str, Any],
    filter_spec: dict[str, Any] | None = None,
) -> None:
    """Apply a Deep Dive cell filter and stage its records for an in-page dialog."""
    # Keep the user on Explore. The selected records are staged only for the
    # in-place dialog; no Preview navigation or Preview-source state is changed.
    st.session_state.nav_page = "Data Mining"
    # Do not overwrite filtered_data here. Explore uses filtered_data as its
    # analysis source, so changing it during a cell click causes the heatmap to
    # be rebuilt from the selected subset and makes the clicked visual vanish.
    st.session_state.deep_dive_popup = {
        "title": title,
        "filter_text": filter_text,
        "records": filtered.copy(),
        "filter_spec": filter_spec or {},
    }
    st.session_state.deep_dive_popup_event_id = int(
        st.session_state.get("deep_dive_popup_event_id", 0)
    ) + 1
    audit("EDA_DEEP_DIVE_DRILLTHROUGH", {**audit_details, "output_rows": len(filtered)})


@st.dialog("Deep Dive records", width="large")
def show_deep_dive_popup() -> None:
    """Display records matching the selected heatmap-table cell in place."""
    popup = st.session_state.get("deep_dive_popup")
    if not popup:
        st.info("Select a Deep Dive heatmap cell to view its records.")
        return
    records = popup["records"]
    st.markdown(f"### {popup['title']}")
    st.caption(popup["filter_text"])
    st.metric("Matching records", f"{len(records):,}")
    if records.empty:
        st.warning("No records match the selected cell.")
    else:
        st.dataframe(records, use_container_width=True, hide_index=True, height=430)

    st.markdown("#### Save this filter")
    save_name = st.text_input(
        "Filter name",
        value=popup["title"][:80],
        key="deep_dive_filter_save_name",
        help="Saved filters remain available during this analysis session and can be reused from the Filter page.",
    )
    save_col, download_col = st.columns(2)
    if save_col.button("Save filter", type="primary", use_container_width=True, key="deep_dive_popup_save_filter"):
        clean_name = save_name.strip()
        if not clean_name:
            st.warning("Enter a filter name before saving.")
        else:
            st.session_state.saved_deep_dive_filters[clean_name] = {
                "name": clean_name,
                "title": popup["title"],
                "filter_text": popup["filter_text"],
                "filter_spec": popup.get("filter_spec", {}),
                "saved_at": utc_now(),
            }
            audit("EDA_DEEP_DIVE_FILTER_SAVED", {"name": clean_name, "filter_spec": popup.get("filter_spec", {})})
            st.success(f"Saved filter: {clean_name}")

    payload = {
        "version": 1,
        "name": save_name.strip() or popup["title"],
        "filter_text": popup["filter_text"],
        "filter_spec": popup.get("filter_spec", {}),
    }
    download_col.download_button(
        "Download filter JSON",
        json_bytes(payload),
        file_name=f"{re.sub(r'[^A-Za-z0-9_-]+', '_', payload['name']).strip('_') or 'deep_dive_filter'}.json",
        mime="application/json",
        use_container_width=True,
        key="deep_dive_popup_download_filter",
    )
    use_col, _ = st.columns([1, 1])
    if use_col.button(
        "Use records as modified dataset",
        use_container_width=True,
        key="deep_dive_popup_use_filtered_output",
    ):
        publish_modified_dataset(records.copy())
        audit("EDA_DEEP_DIVE_OUTPUT_APPLIED", {"rows": len(records), "filter_spec": popup.get("filter_spec", {})})
        st.success("Selected records are now available as Modified Dataset. The Data Mining heatmap remains unchanged until you leave or refresh the analysis source.")

    st.caption("Cell selection only opens this popup. It does not replace the Data Mining analysis dataset or change the active page.")

def apply_saved_deep_dive_filter(df: pd.DataFrame, spec: dict[str, Any]) -> pd.DataFrame:
    """Reapply a saved Deep Dive filter definition to the current dataset."""
    filter_type = spec.get("type")
    if filter_type == "non_missing_pair":
        left, right = spec.get("left"), spec.get("right")
        if left in df.columns and right in df.columns:
            return df[df[left].notna() & df[right].notna()].copy()
    if filter_type == "prepared_pair":
        left, right = spec.get("left"), spec.get("right")
        if left in df.columns and right in df.columns:
            prepared_left, _ = deep_dive_prepared_series(df, left)
            prepared_right, _ = deep_dive_prepared_series(df, right)
            mask = (
                prepared_left.astype("string") == str(spec.get("left_value"))
            ) & (
                prepared_right.astype("string") == str(spec.get("right_value"))
            )
            return df[mask].copy()
    return df.iloc[0:0].copy()

def build_chart_data(
    df: pd.DataFrame, x_col: str, y_col: str | None, aggregation: str,
    chart_type: str, top_n: int,
) -> tuple[pd.DataFrame, str | None]:
    work = df.copy()
    if chart_type in {"Histogram", "Box", "Scatter"}:
        return work, y_col
    if aggregation == "Row count":
        result = work.groupby(x_col, dropna=False).size().rename("__value__").reset_index()
        return result.nlargest(top_n, "__value__"), "__value__"
    if y_col is None:
        return work, None
    if aggregation == "Distinct count":
        result = work.groupby(x_col, dropna=False)[y_col].nunique(dropna=True).rename("__value__").reset_index()
        return result.nlargest(top_n, "__value__"), "__value__"
    numeric = safe_numeric_series(work[y_col])
    work = work.assign(__numeric_value__=numeric)
    agg_map = {"Sum": "sum", "Average": "mean", "Median": "median", "Minimum": "min", "Maximum": "max"}
    result = work.groupby(x_col, dropna=False)["__numeric_value__"].agg(agg_map[aggregation]).rename("__value__").reset_index()
    return result.nlargest(top_n, "__value__"), "__value__"


def correlation_summary_text(matrix: pd.DataFrame) -> str:
    """Create a concise strength summary from a symmetric correlation/association matrix."""
    pairs: list[tuple[str, str, float]] = []
    cols = list(matrix.columns)
    for i, left in enumerate(cols):
        for right in cols[i + 1:]:
            value = matrix.loc[left, right]
            if pd.notna(value):
                pairs.append((str(left), str(right), float(value)))

    bands = {"High": [], "Medium": [], "Low": []}
    for left, right, value in sorted(pairs, key=lambda x: abs(x[2]), reverse=True):
        strength = abs(value)
        item = f"{left} ↔ {right} ({value:+.2f})"
        if strength >= 0.70:
            bands["High"].append(item)
        elif strength >= 0.40:
            bands["Medium"].append(item)
        elif strength >= 0.10:
            bands["Low"].append(item)

    lines = []
    for label in ("High", "Medium", "Low"):
        values = bands[label]
        if values:
            shown = "; ".join(values[:8])
            remainder = len(values) - 8
            suffix = f"; and {remainder} more" if remainder > 0 else ""
            lines.append(f"**{label} correlation:** {shown}{suffix}.")
        else:
            lines.append(f"**{label} correlation:** No feature pairs detected in this range.")
    lines.append("Positive values move in the same direction; negative values move in opposite directions. Association does not imply causation.")
    return "\n\n".join(lines)


def apply_default_data_labels(fig):
    """Apply readable value labels to Plotly charts by default."""
    try:
        for trace in fig.data:
            trace_type = getattr(trace, "type", "")
            if trace_type == "bar":
                orientation = getattr(trace, "orientation", None)
                template = "%{x:,.2f}" if orientation == "h" else "%{y:,.2f}"
                trace.update(texttemplate=template, textposition="auto", cliponaxis=False)
            elif trace_type == "pie":
                trace.update(textinfo="label+percent+value", textposition="auto")
            elif trace_type in {"scatter", "scattergl"}:
                mode = getattr(trace, "mode", "") or ""
                if "lines" in mode:
                    trace.update(mode="lines+markers+text", texttemplate="%{y:,.2f}", textposition="top center")
                else:
                    trace.update(mode="markers+text", texttemplate="%{y:,.2f}", textposition="top center")
            elif trace_type in {"histogram"}:
                trace.update(texttemplate="%{y}", textposition="auto")
    except Exception:
        pass
    return fig


def plot_chart(fig, *args, **kwargs):
    return st.plotly_chart(apply_default_data_labels(fig), *args, **kwargs)


def impute_base_column(dataset_name: str, column: str, semantic_type: str) -> tuple[int, Any]:
    """Impute one base-data column and invalidate stale downstream outputs."""
    dataset_name = canonical_source_name(dataset_name)
    state_key = "base_data_1" if dataset_name == "File 1" else "base_data_2"
    base = st.session_state.get(state_key)
    if base is None or column not in base.columns:
        raise ValueError(f"{dataset_name} is not available or no longer contains '{column}'.")

    corrected = base.copy()
    series = corrected[column]
    blank_mask = series.astype("string").str.strip().eq("").fillna(False)
    missing_mask = series.isna() | blank_mask
    missing_count = int(missing_mask.sum())
    if missing_count == 0:
        return 0, None

    if semantic_type in {"numerical", "numeric-like text"}:
        numeric = safe_numeric_series(series)
        median_value = numeric[~missing_mask].median()
        if pd.isna(median_value):
            raise ValueError("Median cannot be calculated because the column has no valid numerical values.")
        corrected.loc[missing_mask, column] = median_value
        strategy = "median"
        replacement_value = safe_python_scalar(median_value)
    else:
        corrected.loc[missing_mask, column] = "Unknown"
        strategy = "unknown_category"
        replacement_value = "Unknown"

    st.session_state[state_key] = corrected
    st.session_state.joined_data = None
    clear_modified_dataset()
    st.session_state.created_column_preview = None
    st.session_state.created_column_config = {}
    st.session_state.pivot_data = None
    st.session_state.join_config = {}
    st.session_state.last_filter_config = {}
    st.session_state.filters = []
    audit("MISSING_VALUES_IMPUTED", {
        "dataset": dataset_name,
        "column": column,
        "semantic_type": semantic_type,
        "strategy": strategy,
        "replacement_value": replacement_value,
        "updated_rows": missing_count,
    })
    return missing_count, replacement_value


def update_profile_source_data(profile_name: str, corrected: pd.DataFrame, action: str, details: dict[str, Any]) -> None:
    """Persist Data Profile corrections and invalidate dependent outputs safely."""
    profile_name = canonical_source_name(profile_name)
    if profile_name == "File 1":
        st.session_state.base_data_1 = corrected.copy()
        st.session_state.profile_revision_1 = int(st.session_state.get("profile_revision_1", 0)) + 1
        st.session_state.joined_data = None
        clear_modified_dataset()
    elif profile_name == "File 2":
        st.session_state.base_data_2 = corrected.copy()
        st.session_state.profile_revision_2 = int(st.session_state.get("profile_revision_2", 0)) + 1
        st.session_state.joined_data = None
        clear_modified_dataset()
    elif profile_name == "Joined data":
        st.session_state.joined_data = corrected.copy()
        clear_modified_dataset()
    elif profile_name == "Modified Dataset":
        publish_modified_dataset(corrected.copy())
    else:
        raise ValueError(f"Unsupported profile source: {profile_name}")

    st.session_state.pivot_data = None
    st.session_state.created_column_preview = None
    st.session_state.created_column_config = {}
    st.session_state.last_filter_config = {}
    st.session_state.filters = []
    audit(action, {"profile_source": profile_name, **details})


def apply_numeric_profile_correction(profile_name: str, data: pd.DataFrame, column: str, strategy: str) -> tuple[pd.DataFrame, int, str]:
    """Apply a numeric data-quality correction and return corrected data and affected rows."""
    if column not in data.columns:
        raise ValueError(f"Column '{column}' is no longer available.")
    corrected = data.copy()
    numeric = safe_numeric_series(corrected[column])

    if strategy == "drop_nulls":
        mask = numeric.isna()
        affected = int(mask.sum())
        corrected = corrected.loc[~mask].copy()
        message = f"Dropped {affected:,} rows with null or non-numeric values."
    elif strategy == "fill_median":
        mask = numeric.isna()
        affected = int(mask.sum())
        median_value = numeric.dropna().median()
        if pd.isna(median_value):
            raise ValueError("Median cannot be calculated because the column has no valid numeric values.")
        corrected.loc[mask, column] = median_value
        message = f"Filled {affected:,} values with median {median_value:,.4g}."
    elif strategy == "drop_outliers":
        mask = outlier_mask_iqr(corrected[column]).fillna(False)
        affected = int(mask.sum())
        corrected = corrected.loc[~mask].copy()
        message = f"Dropped {affected:,} IQR outlier rows."
    else:
        raise ValueError("Unsupported numeric correction strategy.")

    update_profile_source_data(profile_name, corrected, "PROFILE_NUMERIC_CORRECTION", {
        "column": column, "strategy": strategy, "affected_rows": affected,
        "remaining_rows": len(corrected),
    })
    return corrected, affected, message



def _unique_derived_column_name(existing_columns: set[str], requested: str) -> str:
    """Return a collision-safe derived column name and reserve it."""
    candidate = requested
    suffix = 2
    while candidate in existing_columns:
        candidate = f"{requested}_{suffix}"
        suffix += 1
    existing_columns.add(candidate)
    return candidate


def is_verified_temporal_series(series: pd.Series) -> bool:
    """Identify datetime values or text columns that reliably represent dates."""
    if pd.api.types.is_datetime64_any_dtype(series):
        return True
    if pd.api.types.is_numeric_dtype(series) or pd.api.types.is_bool_dtype(series):
        return False
    text = series.astype("string").str.strip()
    missing_tokens = {"", "<NA>", "NA", "N/A", "None", "null", "NULL", "NaT"}
    candidates = text.mask(text.isin(missing_tokens)).dropna()
    if candidates.empty:
        return False
    # Require visible date syntax or month names so identifiers are not mistaken for dates.
    date_signal = candidates.str.contains(
        r"(?:\d{1,4}[-/.]\d{1,2}(?:[-/.]\d{1,4})?|[A-Za-z]{3,9}[\s,-]+\d{1,2}|\d{1,2}[\s,-]+[A-Za-z]{3,9})",
        regex=True, na=False,
    )
    if int(date_signal.sum()) < 2 or float(date_signal.mean()) < 0.6:
        return False
    parsed = safe_datetime_series(candidates, dayfirst=False)
    return int(parsed.notna().sum()) >= 2 and float(parsed.notna().mean()) >= 0.6


def standardize_temporal_columns(
    data: pd.DataFrame, columns: list[str]
) -> tuple[pd.DataFrame, list[dict[str, Any]]]:
    """Normalize date/date-time columns and add calendar analysis features."""
    corrected = data.copy()
    existing_columns = set(map(str, corrected.columns))
    temporal_details: list[dict[str, Any]] = []

    for column in columns:
        if column not in corrected.columns:
            continue
        semantic = infer_semantic_type(corrected[column])
        if semantic not in {"datetime", "date-like text"} and not is_verified_temporal_series(corrected[column]):
            continue
        if semantic not in {"datetime", "date-like text"}:
            semantic = "date-like text"

        source = corrected[column]
        parsed = safe_datetime_series(source, dayfirst=False)
        # Some mixed-offset inputs can produce object dtype; normalize each valid
        # value to a timezone-naive Timestamp while preserving its displayed clock.
        if not pd.api.types.is_datetime64_any_dtype(parsed):
            def _to_naive_timestamp(value: Any) -> Any:
                if value is None or value is pd.NA:
                    return pd.NaT
                try:
                    timestamp = pd.Timestamp(value)
                    if pd.isna(timestamp):
                        return pd.NaT
                    if timestamp.tzinfo is not None:
                        timestamp = timestamp.tz_localize(None)
                    return timestamp
                except (TypeError, ValueError, OverflowError):
                    return pd.NaT
            parsed = source.map(_to_naive_timestamp)
            parsed = pd.to_datetime(parsed, errors="coerce")

        source_text = source.astype("string").str.strip()
        explicit_time = source_text.str.contains(
            r"(?:[T\s]\d{1,2}:\d{2}(?::\d{2})?|\d{1,2}:\d{2}(?::\d{2})?)",
            regex=True, na=False,
        ).any()
        parsed_has_time = bool(
            (
                parsed.notna()
                & ((parsed.dt.hour != 0) | (parsed.dt.minute != 0) | (parsed.dt.second != 0))
            ).any()
        )
        is_timestamp = bool(explicit_time or parsed_has_time)
        output_format = "%Y-%m-%d %H:%M:%S" if is_timestamp else "%Y-%m-%d"

        formatted = parsed.dt.strftime(output_format).astype("string")
        formatted = formatted.mask(parsed.isna(), pd.NA)
        corrected[column] = formatted

        year_column = _unique_derived_column_name(existing_columns, f"{column}_year")
        month_column = _unique_derived_column_name(existing_columns, f"{column}_month")
        weekday_column = _unique_derived_column_name(existing_columns, f"{column}_weekday")
        corrected[year_column] = parsed.dt.year.astype("Int64")
        corrected[month_column] = parsed.dt.month.astype("Int64")
        corrected[weekday_column] = parsed.dt.day_name().astype("string").mask(parsed.isna(), pd.NA)

        temporal_details.append({
            "column": column,
            "semantic_type": semantic,
            "output_format": "YYYY-MM-DD HH:MM:SS" if is_timestamp else "YYYY-MM-DD",
            "valid_values": int(parsed.notna().sum()),
            "null_values": int(parsed.isna().sum()),
            "derived_columns": [year_column, month_column, weekday_column],
        })

    return corrected, temporal_details


def standardize_profile_selection(data: pd.DataFrame, selected_columns: list[str], target_column: str) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Prepare a target-aware standardized dataset without publishing it yet."""
    if not selected_columns:
        raise ValueError("Select at least one column in the profile grid.")
    if target_column not in selected_columns:
        raise ValueError("The target column must be one of the selected columns.")

    corrected = data.loc[:, selected_columns].copy()
    corrected, temporal_details = standardize_temporal_columns(corrected, selected_columns)
    details: dict[str, Any] = {
        "target_column": target_column,
        "selected_columns": selected_columns,
        "target_rows_dropped": 0,
        "median_values_filled": 0,
        "outlier_rows_dropped": 0,
        "processed_numeric_columns": [],
        "standardized_temporal_columns": temporal_details,
        "derived_temporal_columns": [
            derived
            for item in temporal_details
            for derived in item["derived_columns"]
        ],
    }

    target_semantic = infer_semantic_type(corrected[target_column])
    if target_semantic in {"numerical", "numeric-like text"}:
        target_numeric = safe_numeric_series(corrected[target_column])
        missing_target = target_numeric.isna()
        details["target_rows_dropped"] = int(missing_target.sum())
        corrected = corrected.loc[~missing_target].copy()

    numeric_columns = [
        column for column in selected_columns
        if column != target_column
        and column in corrected.columns
        and infer_semantic_type(corrected[column]) in {"numerical", "numeric-like text"}
    ]
    for column in numeric_columns:
        numeric = safe_numeric_series(corrected[column])
        missing_mask = numeric.isna()
        median_value = numeric.dropna().median()
        if missing_mask.any() and pd.notna(median_value):
            corrected.loc[missing_mask, column] = median_value
            details["median_values_filled"] += int(missing_mask.sum())

        outliers = outlier_mask_iqr(corrected[column]).fillna(False)
        if outliers.any():
            details["outlier_rows_dropped"] += int(outliers.sum())
            corrected = corrected.loc[~outliers].copy()
        details["processed_numeric_columns"].append(column)

    details["rows_after_standardization"] = len(corrected)
    details["columns_after_standardization"] = len(corrected.columns)
    return corrected, details


@st.dialog("Standardize selected data")
def show_profile_standardize_dialog(profile_name: str, data: pd.DataFrame, selected_columns: list[str], profile_revision: int) -> None:
    st.caption("Select the target column. The standardized result will be staged until you click Confirm Dataset.")
    if not selected_columns:
        st.warning("Select at least one column in the profile grid before standardizing.")
        return
    target_column = st.selectbox(
        "Target column for analysis",
        selected_columns,
        key=f"profile_standardize_target_{profile_name}_{profile_revision}",
    )
    st.markdown(
        "Date, datetime, and reliably date-like text columns are standardized first. Dates use `YYYY-MM-DD`; "
        "timestamps use `YYYY-MM-DD HH:MM:SS`; invalid or missing values become null. Year, month, and weekday "
        "columns are created automatically for every detected date column. For a numerical target, rows with "
        "missing target values are dropped. For every other selected numerical column, missing values are filled "
        "with the median and IQR outlier rows are removed."
    )
    if st.button("Apply standardization", type="primary", use_container_width=True, key=f"apply_profile_standardize_{profile_name}_{profile_revision}"):
        try:
            standardized, details = standardize_profile_selection(data, selected_columns, target_column)
            st.session_state.profile_pending_standardized_data = standardized
            st.session_state.profile_pending_standardized_details = details
            st.session_state.profile_pending_standardized_source = profile_name
            st.session_state.profile_pending_standardized_revision = profile_revision
            audit("PROFILE_STANDARDIZATION_STAGED", {"profile_source": profile_name, **details})
            st.session_state.profile_standardization_notice = (
                f"Standardization completed and staged: {len(standardized):,} rows and "
                f"{len(standardized.columns):,} columns. Click Confirm Dataset to publish it."
            )
            st.rerun()
        except Exception as exc:
            st.error(f"Could not standardize the selected data: {exc}")


def auto_expand_database_source(source_key: str) -> None:
    """Widen the source pane when a database source is selected."""
    if st.session_state.get(source_key) in {"Databricks", "PostgreSQL"}:
        st.session_state["wide_sidebar"] = True


init_state()

with st.sidebar:
    st.checkbox(
        "Expand left pane", key="wide_sidebar",
        help="Use a wider sidebar for SQL connection details."
    )
    st.header("1. Data sources")
    st.caption("Use an uploaded file or a database query for each dataset.")

    source_type_1 = st.radio(
        "Dataset 1 source", ["Upload file", "Databricks", "PostgreSQL"], horizontal=True,
        key="source_type_1", on_change=auto_expand_database_source, args=("source_type_1",),
    )
    file_1 = None
    db_raw_1 = None
    db_meta_1: dict[str, Any] = {}
    if source_type_1 == "Upload file":
        file_1 = st.file_uploader("Primary file", type=["xlsx", "xlsm", "xls", "csv"], key="file_1")
        if file_1 is not None:
            st.markdown(f'<div class="clarity-uploaded-filename">Loaded: {html.escape(file_1.name)}</div>', unsafe_allow_html=True)
    else:
        db_raw_1, db_meta_1 = render_database_source(1, source_type_1)

    enable_dataset_2 = st.checkbox("Add Dataset 2 for join / lookup", value=False, key="enable_dataset_2")
    source_type_2 = None
    file_2 = None
    db_raw_2 = None
    db_meta_2: dict[str, Any] = {}
    if enable_dataset_2:
        source_type_2 = st.radio(
            "Dataset 2 source", ["Upload file", "Databricks", "PostgreSQL"], horizontal=True,
            key="source_type_2", on_change=auto_expand_database_source, args=("source_type_2",),
        )
        if source_type_2 == "Upload file":
            file_2 = st.file_uploader("Second file", type=["xlsx", "xlsm", "xls", "csv"], key="file_2")
            if file_2 is not None:
                st.markdown(f'<div class="clarity-uploaded-filename">Loaded: {html.escape(file_2.name)}</div>', unsafe_allow_html=True)
        else:
            db_raw_2, db_meta_2 = render_database_source(2, source_type_2)

    st.session_state.analysis_name = st.text_input("Analysis name", st.session_state.analysis_name)
    st.divider()
    st.subheader("Selected filter summary")
    filter_summary_placeholder = st.empty()
    if st.session_state.filters:
        filter_summary_placeholder.markdown("\n".join(
            f"**{i + 1}.** `{filter_summary(rule, i)}`"
            for i, rule in enumerate(st.session_state.filters)
        ))
    else:
        filter_summary_placeholder.info("No filters selected yet.")

    st.divider()
    st.button(
        "Audit",
        key="sidebar_audit_button",
        type="primary" if st.session_state.get("nav_page") == "Audit" else "secondary",
        use_container_width=True,
        on_click=lambda: st.session_state.__setitem__("nav_page", "Audit"),
    )

# Resolve Dataset 1.
if source_type_1 == "Upload file" and not file_1:
    st.info("Upload Dataset 1 or choose Database query and run a query to begin.")
    st.stop()
if source_type_1 in {"Databricks", "PostgreSQL"} and db_raw_1 is None:
    st.info(f"Configure the Dataset 1 {source_type_1} connection and run a query to begin.")
    st.stop()

try:
    bytes_1 = None
    bytes_2 = None
    sheet_1 = None
    sheet_2 = None

    if source_type_1 == "Upload file":
        bytes_1 = file_1.getvalue()
        sheets_1 = get_sheet_names(bytes_1, file_1.name)
        with st.sidebar:
            sheet_1 = st.selectbox("File 1 sheet", sheets_1)
        raw1 = load_table(bytes_1, file_1.name, None if sheet_1 == "CSV" else sheet_1)
        source_label_1 = file_1.name
        signature_1 = ("file", file_fingerprint(bytes_1), sheet_1)
    else:
        raw1 = db_raw_1.copy()
        source_label_1 = f"{db_meta_1.get('database_type', 'Database')} query"
        signature_1 = (
            "database", db_meta_1.get("database_type"),
            hashlib.sha256(db_meta_1.get("query", "").encode("utf-8")).hexdigest()[:16],
            len(raw1), tuple(map(str, raw1.columns)),
        )
    df1 = make_unique_columns(raw1, "File1")

    df2 = None
    source_label_2 = None
    signature_2 = None
    if enable_dataset_2:
        if source_type_2 == "Upload file":
            if file_2 is not None:
                bytes_2 = file_2.getvalue()
                sheets_2 = get_sheet_names(bytes_2, file_2.name)
                with st.sidebar:
                    sheet_2 = st.selectbox("File 2 sheet", sheets_2)
                raw2 = load_table(bytes_2, file_2.name, None if sheet_2 == "CSV" else sheet_2)
                df2 = make_unique_columns(raw2, "File2")
                source_label_2 = file_2.name
                signature_2 = ("file", file_fingerprint(bytes_2), sheet_2)
        elif db_raw_2 is not None:
            raw2 = db_raw_2.copy()
            df2 = make_unique_columns(raw2, "File2")
            source_label_2 = f"{db_meta_2.get('database_type', 'Database')} query"
            signature_2 = (
                "database", db_meta_2.get("database_type"),
                hashlib.sha256(db_meta_2.get("query", "").encode("utf-8")).hexdigest()[:16],
                len(raw2), tuple(map(str, raw2.columns)),
            )
except Exception as exc:
    st.error(f"Could not load the selected data sources: {exc}")
    st.stop()

input_signature = (signature_1, signature_2)
if st.session_state.input_signature != input_signature:
    st.session_state.input_signature = input_signature
    st.session_state.base_data_1 = df1.copy()
    st.session_state.base_data_2 = df2.copy() if df2 is not None else None
    st.session_state.profile_revision_1 = 0
    st.session_state.profile_revision_2 = 0
    st.session_state.joined_data = None
    clear_modified_dataset()
    st.session_state.pivot_data = None
    st.session_state.join_config = {}
    st.session_state.last_filter_config = {}
    st.session_state.filters = []
    audit("INPUT_SOURCES_CHANGED", {
        "dataset_1": source_label_1,
        "dataset_2": source_label_2,
        "dataset_1_source_type": source_type_1,
        "dataset_2_source_type": source_type_2 if enable_dataset_2 else None,
        "single_dataset_mode": df2 is None,
    })

# Use session-backed base datasets so data-quality corrections survive Streamlit reruns
# and are automatically consumed by every downstream module.
df1 = st.session_state.base_data_1.copy()
df2 = st.session_state.base_data_2.copy() if st.session_state.base_data_2 is not None else None

# User-facing source names always follow the actual uploaded filename (or database query label).
# Internal state continues to use stable File 1 / File 2 identifiers where required.
dataset_1_name = source_label_1 or "Dataset 1"
dataset_2_name = source_label_2 or "Dataset 2"

def canonical_source_name(display_name: str) -> str:
    if display_name == dataset_1_name:
        return "File 1"
    if display_name == dataset_2_name:
        return "File 2"
    return display_name

if df2 is None:
    m1, m2 = st.columns(2)
    m1.metric(f"{dataset_1_name} rows", f"{len(df1):,}")
    m2.metric(f"{dataset_1_name} columns", len(df1.columns))
    st.caption("Single-dataset analysis mode is active. Add a second file only when a join or lookup is required.")
else:
    m1, m2, m3, m4 = st.columns(4)
    m1.metric(f"{dataset_1_name} rows", f"{len(df1):,}")
    m2.metric(f"{dataset_1_name} columns", len(df1.columns))
    m3.metric(f"{dataset_2_name} rows", f"{len(df2):,}")
    m4.metric(f"{dataset_2_name} columns", len(df2.columns))

# Modern top-level navigation. Button cards avoid radio indicators and support
# programmatic navigation from actions such as the filtered-output Preview button.
NAV_ITEMS = [
    "Preview",
    "Join/Lookup",
    "Filter/Create",
    "Data Profile",
    "Visualize",
    "Data Mining",
    "Machine Learning",
]
legacy_page_names = {"Filter": "Filter/Create", "Pivot": "Visualize", "Charts": "Visualize", "Explore": "Data Mining"}
if st.session_state.get("nav_page") in legacy_page_names:
    st.session_state.nav_page = legacy_page_names[st.session_state.nav_page]
if "nav_page" not in st.session_state or st.session_state.nav_page not in set(NAV_ITEMS + ["Audit"]):
    st.session_state.nav_page = "Preview"


def clean_name(value: Any) -> str:
    """Standardize a column name using the notebook's clean_name logic."""
    return re.sub(r"[^a-z0-9]+", "_", str(value).strip().lower()).strip("_")


def standardize_object_dtypes(data: pd.DataFrame, null_patterns: list[str]) -> tuple[pd.DataFrame, int]:
    """Apply the notebook object-dtype cleanup and return changed-cell count."""
    cleaned = data.copy()
    object_columns = list(cleaned.select_dtypes(include=["object", "string"]).columns)
    changed_cells = 0

    for column in object_columns:
        before = cleaned[column].copy()
        # Notebook behavior: normalize object values to pandas string, trim
        # surrounding whitespace, and convert blank values to missing.
        normalized = cleaned[column].astype("string").str.strip().replace({"": pd.NA})
        # Reapply null patterns after trimming so padded patterns such as
        # " ? " and " NULL " are also standardized.
        normalized = normalized.replace(null_patterns, pd.NA)
        cleaned[column] = normalized

        before_cmp = before.astype("string").fillna("<NA>")
        after_cmp = normalized.astype("string").fillna("<NA>")
        changed_cells += int((before_cmp != after_cmp).sum())

    return cleaned, changed_cells


def standardize_base_data(dataset_name: str) -> tuple[int, int, int, int]:
    """Apply notebook column-name, null-pattern, and object-dtype standardization."""
    dataset_name = canonical_source_name(dataset_name)
    if dataset_name not in {"File 1", "File 2"}:
        raise ValueError("Select File 1 or File 2 to standardize reusable base data.")

    state_key = "base_data_1" if dataset_name == "File 1" else "base_data_2"
    base = st.session_state.get(state_key)
    if base is None:
        raise ValueError(f"{dataset_name} is not available.")

    standardized = base.copy()
    original_columns = list(standardized.columns)
    cleaned_columns = [clean_name(column) for column in original_columns]

    # Preserve every column even when multiple original names normalize identically.
    seen: dict[str, int] = {}
    unique_columns: list[str] = []
    for cleaned in cleaned_columns:
        base_name = cleaned or "unnamed"
        seen[base_name] = seen.get(base_name, 0) + 1
        unique_columns.append(base_name if seen[base_name] == 1 else f"{base_name}_{seen[base_name]}")
    standardized.columns = unique_columns

    missing_before = int(standardized.isna().sum().sum())
    null_patterns = ["?", "", "NA", "N/A", "NULL", "null", "None", "none", "-", "--"]
    standardized = standardized.replace(null_patterns, np.nan)
    standardized, object_values_cleaned = standardize_object_dtypes(standardized, null_patterns)
    missing_after = int(standardized.isna().sum().sum())

    renamed_columns = sum(str(old) != str(new) for old, new in zip(original_columns, unique_columns))
    converted_to_null = max(0, missing_after - missing_before)

    st.session_state[state_key] = standardized

    # Force all column-dependent Data Profile widgets to rebuild from the
    # standardized schema. File 1 and File 2 use independent revisions.
    revision_key = "profile_revision_1" if dataset_name == "File 1" else "profile_revision_2"
    st.session_state[revision_key] = int(st.session_state.get(revision_key, 0)) + 1

    st.session_state.joined_data = None
    clear_modified_dataset()
    st.session_state.pivot_data = None
    st.session_state.join_config = {}
    st.session_state.last_filter_config = {}
    st.session_state.filters = []
    audit("DATA_STANDARDIZED", {
        "dataset": dataset_name,
        "rows": len(standardized),
        "columns": len(standardized.columns),
        "renamed_columns": renamed_columns,
        "values_converted_to_null": converted_to_null,
        "object_values_cleaned": object_values_cleaned,
        "functions": ["clean_name", "df.replace null patterns", "object dtype handling"],
    })
    return renamed_columns, converted_to_null, len(standardized.columns), object_values_cleaned


def ml_problem_type(target: pd.Series) -> str:
    """Infer the v76 supervised learning problem from the selected target."""
    non_null = target.dropna()
    if non_null.empty:
        return "Unknown"
    if pd.api.types.is_numeric_dtype(non_null):
        unique_count = int(non_null.nunique())
        threshold = max(15, int(len(non_null) * 0.03))
        if unique_count > threshold:
            return "Regression"
    return "Binary Classification" if non_null.nunique() == 2 else "Multiclass Classification"


def ml_feature_groups(frame: pd.DataFrame) -> tuple[list[str], list[str]]:
    numeric = list(frame.select_dtypes(include=[np.number]).columns)
    categorical = [c for c in frame.columns if c not in numeric]
    return numeric, categorical


def ml_build_preprocessor(frame: pd.DataFrame, scale_numeric: bool = True) -> ColumnTransformer:
    numeric, categorical = ml_feature_groups(frame)
    numeric_steps = [("imputer", SimpleImputer(strategy="median"))]
    if scale_numeric:
        numeric_steps.append(("scaler", StandardScaler()))
    transformers = []
    if numeric:
        transformers.append(("numeric", Pipeline(numeric_steps), numeric))
    if categorical:
        transformers.append(("categorical", Pipeline([
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("encoder", OneHotEncoder(handle_unknown="ignore", sparse_output=True, max_categories=50)),
        ]), categorical))
    return ColumnTransformer(transformers=transformers, remainder="drop")


def ml_model_catalog(problem: str, seed: int) -> dict[str, Any]:
    if problem == "Regression":
        return {
            "Linear Regression": LinearRegression(),
            "Ridge": Ridge(alpha=1.0),
            "Decision Tree": DecisionTreeRegressor(max_depth=8, min_samples_leaf=5, random_state=seed),
            "Random Forest": RandomForestRegressor(n_estimators=160, max_depth=14, min_samples_leaf=2, n_jobs=-1, random_state=seed),
            "Extra Trees": ExtraTreesRegressor(n_estimators=160, max_depth=14, min_samples_leaf=2, n_jobs=-1, random_state=seed),
            "Gradient Boosting": GradientBoostingRegressor(random_state=seed),
        }
    return {
        "Logistic Regression": LogisticRegression(max_iter=1500, class_weight="balanced"),
        "Decision Tree": DecisionTreeClassifier(max_depth=8, min_samples_leaf=5, class_weight="balanced", random_state=seed),
        "Random Forest": RandomForestClassifier(n_estimators=160, max_depth=14, min_samples_leaf=2, class_weight="balanced", n_jobs=-1, random_state=seed),
        "Extra Trees": ExtraTreesClassifier(n_estimators=160, max_depth=14, min_samples_leaf=2, class_weight="balanced", n_jobs=-1, random_state=seed),
        "Gradient Boosting": GradientBoostingClassifier(random_state=seed),
    }


def ml_primary_metric(problem: str) -> str:
    return "RMSE" if problem == "Regression" else "F1 Weighted"


def ml_tuning_space(problem: str, model_name: str) -> dict[str, list[Any]]:
    prefix = "model__"
    common = {
        "Decision Tree": {prefix+"max_depth": [3, 5, 8, 12, None], prefix+"min_samples_leaf": [1, 2, 5, 10, 20]},
        "Random Forest": {prefix+"n_estimators": [100, 200, 350], prefix+"max_depth": [8, 14, 22, None], prefix+"min_samples_leaf": [1, 2, 5, 10], prefix+"max_features": ["sqrt", "log2", None]},
        "Extra Trees": {prefix+"n_estimators": [100, 200, 350], prefix+"max_depth": [8, 14, 22, None], prefix+"min_samples_leaf": [1, 2, 5, 10], prefix+"max_features": ["sqrt", "log2", None]},
        "Gradient Boosting": {prefix+"n_estimators": [75, 125, 200], prefix+"learning_rate": [0.03, 0.05, 0.1, 0.2], prefix+"max_depth": [2, 3, 5], prefix+"subsample": [0.7, 0.9, 1.0]},
    }
    if model_name == "Ridge":
        return {prefix+"alpha": [0.01, 0.1, 1.0, 10.0, 100.0]}
    if model_name == "Logistic Regression":
        return {prefix+"C": [0.01, 0.1, 1.0, 10.0, 100.0], prefix+"solver": ["lbfgs", "liblinear"]}
    return common.get(model_name, {})


def ml_cv_splitter(problem: str, y: pd.Series, folds: int, seed: int):
    folds = max(2, int(folds))
    if problem == "Regression":
        return KFold(n_splits=min(folds, len(y)), shuffle=True, random_state=seed)
    min_class = int(y.value_counts().min())
    return StratifiedKFold(n_splits=max(2, min(folds, min_class)), shuffle=True, random_state=seed)


def ml_explain_model(best: Pipeline, X_test: pd.DataFrame, y_test: pd.Series, problem: str, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, str]:
    """Return permutation importance and optional SHAP summary values."""
    permutation_df = pd.DataFrame()
    shap_df = pd.DataFrame()
    method = "Permutation importance"
    try:
        sample = X_test.sample(n=min(1000, len(X_test)), random_state=seed) if len(X_test) > 1000 else X_test
        sample_y = y_test.loc[sample.index]
        scoring = "neg_root_mean_squared_error" if problem == "Regression" else "f1_weighted"
        pi = permutation_importance(best, sample, sample_y, n_repeats=5, random_state=seed, scoring=scoring, n_jobs=-1)
        permutation_df = pd.DataFrame({"Feature": X_test.columns, "Importance": pi.importances_mean, "Std Dev": pi.importances_std}).sort_values("Importance", ascending=False)
    except Exception:
        pass
    try:
        import shap
        transformed = best.named_steps["preprocessor"].transform(X_test.head(min(500, len(X_test))))
        if hasattr(transformed, "toarray") and transformed.shape[1] <= 1500:
            transformed = transformed.toarray()
        names = best.named_steps["preprocessor"].get_feature_names_out()
        estimator = best.named_steps["model"]
        explainer = shap.Explainer(estimator, transformed)
        values = explainer(transformed)
        arr = np.asarray(values.values)
        if arr.ndim == 3:
            arr = np.mean(np.abs(arr), axis=(0, 2))
        else:
            arr = np.mean(np.abs(arr), axis=0)
        shap_df = pd.DataFrame({"Feature": names, "Mean Absolute SHAP": arr}).sort_values("Mean Absolute SHAP", ascending=False).head(100)
        method = "SHAP and permutation importance"
    except Exception:
        pass
    return permutation_df, shap_df, method


def ml_train_models(data: pd.DataFrame, target: str, features: list[str], problem: str,
                    selected_models: list[str], test_size: float, seed: int,
                    cv_folds: int, max_rows: int, tuning_enabled: bool = False,
                    tuning_iterations: int = 12) -> dict[str, Any]:
    work = data[features + [target]].copy().replace([np.inf, -np.inf], np.nan)
    work = work.dropna(subset=[target])
    if len(work) > max_rows:
        if problem != "Regression":
            parts=[]
            for _, grp in work.groupby(target, dropna=False):
                take=max(1, round(max_rows * len(grp) / len(work)))
                parts.append(grp.sample(n=min(len(grp), take), random_state=seed))
            work=pd.concat(parts).sample(frac=1, random_state=seed).head(max_rows)
        else:
            work=work.sample(n=max_rows, random_state=seed)
    X = work[features]
    y = pd.to_numeric(work[target], errors="coerce") if problem == "Regression" else work[target].astype(str)
    valid = y.notna(); X, y = X.loc[valid], y.loc[valid]
    if len(X) < 20: raise ValueError("At least 20 valid rows are required for AutoML.")
    if problem != "Regression" and y.value_counts().min() < 2: raise ValueError("Every target class needs at least two rows.")
    stratify = y if problem != "Regression" and y.value_counts().min() >= 2 else None
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=seed, stratify=stratify)
    catalog=ml_model_catalog(problem, seed)
    rows=[]; trained={}; predictions={}; cv_details=[]; tuning_details=[]
    scoring = "neg_root_mean_squared_error" if problem == "Regression" else "f1_weighted"
    splitter = ml_cv_splitter(problem, y_train, cv_folds, seed)
    for name in selected_models:
        model=catalog[name]
        pipeline=Pipeline([("preprocessor", ml_build_preprocessor(X, scale_numeric=name in {"Linear Regression","Ridge","Logistic Regression"})), ("model", model)])
        started=datetime.now(timezone.utc)
        try:
            fitted = pipeline
            space = ml_tuning_space(problem, name) if tuning_enabled else {}
            if space:
                search = RandomizedSearchCV(pipeline, space, n_iter=min(int(tuning_iterations), max(1, np.prod([len(v) for v in space.values()]))), scoring=scoring, cv=splitter, n_jobs=-1, random_state=seed, refit=True, error_score=np.nan)
                search.fit(X_train, y_train); fitted = search.best_estimator_
                tuning_details.append({"Model":name,"Best CV score":abs(float(search.best_score_)) if problem=="Regression" else float(search.best_score_),"Best parameters":json.dumps(search.best_params_,default=str)})
            else:
                fitted.fit(X_train, y_train)
            pred=fitted.predict(X_test)
            elapsed=(datetime.now(timezone.utc)-started).total_seconds()
            scores = cross_validate(fitted, X_train, y_train, cv=splitter, scoring=scoring, n_jobs=1, return_train_score=True)
            fold_test = -scores["test_score"] if problem=="Regression" else scores["test_score"]
            fold_train = -scores["train_score"] if problem=="Regression" else scores["train_score"]
            for i,(tr,va) in enumerate(zip(fold_train,fold_test),1): cv_details.append({"Model":name,"Fold":i,"Train score":float(tr),"Validation score":float(va)})
            cv_mean=float(np.mean(fold_test)); cv_std=float(np.std(fold_test))
            if problem == "Regression":
                rmse=float(np.sqrt(mean_squared_error(y_test,pred))); mae=float(mean_absolute_error(y_test,pred)); r2=float(r2_score(y_test,pred)); mape=float(mean_absolute_percentage_error(y_test,pred))
                rows.append({"Model":name,"RMSE":rmse,"MAE":mae,"MAPE":mape,"R²":r2,"CV mean":cv_mean,"CV std":cv_std,"Training seconds":elapsed,"Tuned":"Yes" if space else "No","Status":"Completed"})
            else:
                acc=float(accuracy_score(y_test,pred)); prec=float(precision_score(y_test,pred,average="weighted",zero_division=0)); rec=float(recall_score(y_test,pred,average="weighted",zero_division=0)); f1=float(f1_score(y_test,pred,average="weighted",zero_division=0))
                rows.append({"Model":name,"Accuracy":acc,"Precision Weighted":prec,"Recall Weighted":rec,"F1 Weighted":f1,"CV mean":cv_mean,"CV std":cv_std,"Training seconds":elapsed,"Tuned":"Yes" if space else "No","Status":"Completed"})
            trained[name]=fitted; predictions[name]=pred
        except Exception as exc:
            rows.append({"Model":name,"Status":f"Failed: {exc}","Training seconds":0.0,"Tuned":"No"})
    leaderboard=pd.DataFrame(rows); completed=leaderboard[leaderboard["Status"]=="Completed"].copy()
    if completed.empty: raise ValueError("No selected model completed successfully.")
    best_name=(completed.sort_values("RMSE").iloc[0]["Model"] if problem=="Regression" else completed.sort_values("F1 Weighted",ascending=False).iloc[0]["Model"])
    best=trained[best_name]; best_pred=predictions[best_name]
    validation=pd.DataFrame({"Actual":y_test.reset_index(drop=True),"Predicted":pd.Series(best_pred)})
    if problem=="Regression": validation["Residual"]=validation["Actual"]-validation["Predicted"]
    else:
        validation["Correct"]=validation["Actual"].astype(str)==validation["Predicted"].astype(str)
        try:
            probs=best.predict_proba(X_test); classes=[str(x) for x in best.classes_]
            for idx,label in enumerate(classes): validation[f"Probability: {label}"]=probs[:,idx]
        except Exception: pass
    feature_importance=pd.DataFrame()
    try:
        names=best.named_steps["preprocessor"].get_feature_names_out(); estimator=best.named_steps["model"]
        values=getattr(estimator,"feature_importances_",None)
        if values is None and hasattr(estimator,"coef_"):
            coef=np.asarray(estimator.coef_); values=np.mean(np.abs(coef),axis=0) if coef.ndim>1 else np.abs(coef)
        if values is not None: feature_importance=pd.DataFrame({"Feature":names,"Importance":values}).sort_values("Importance",ascending=False).head(100)
    except Exception: pass
    permutation_df, shap_df, explanation_method = ml_explain_model(best, X_test, y_test, problem, seed)
    bundle={"pipeline":best,"problem":problem,"target":target,"features":features,"model_name":best_name,"created_at":utc_now()}
    bio=BytesIO(); joblib.dump(bundle,bio)
    return {"problem":problem,"target":target,"features":features,"rows":len(work),"train_rows":len(X_train),"test_rows":len(X_test),"leaderboard":leaderboard,"best_model_name":best_name,"best_pipeline":best,"validation":validation,"feature_importance":feature_importance,"permutation_importance":permutation_df,"shap_importance":shap_df,"explanation_method":explanation_method,"cv_details":pd.DataFrame(cv_details),"tuning_details":pd.DataFrame(tuning_details),"model_bytes":bio.getvalue(),"classes":sorted(y.astype(str).unique().tolist()) if problem!="Regression" else [],"created_at":utc_now(),"settings":{"test_size":test_size,"seed":seed,"cv_folds":cv_folds,"max_rows":max_rows,"tuning_enabled":tuning_enabled,"tuning_iterations":tuning_iterations}}


def ml_build_target_explanation(result: dict[str, Any], data: pd.DataFrame, top_n: int = 10) -> dict[str, Any]:
    """Build a business-readable explanation of the trained target using model importance and observed relationships."""
    target = result.get("target")
    features = [c for c in result.get("features", []) if c in data.columns]
    problem = result.get("problem", "Regression")
    if not target or target not in data.columns or not features:
        raise ValueError("The trained target or feature columns are unavailable in the active dataset.")

    importance = result.get("permutation_importance", pd.DataFrame()).copy()
    importance_method = "Permutation importance"
    if importance.empty:
        importance = result.get("feature_importance", pd.DataFrame()).copy()
        importance_method = "Native model importance"
    if importance.empty:
        importance = result.get("shap_importance", pd.DataFrame()).copy()
        if not importance.empty and "Mean Absolute SHAP" in importance.columns:
            importance = importance.rename(columns={"Mean Absolute SHAP": "Importance"})
        importance_method = "Mean absolute SHAP"
    if importance.empty or "Feature" not in importance.columns or "Importance" not in importance.columns:
        raise ValueError("Feature importance is unavailable for the winning model.")

    # Prefer original feature names. Permutation importance is already at the original-column level.
    importance["Feature"] = importance["Feature"].astype(str)
    importance = importance[importance["Feature"].isin(features)].copy()
    importance["Importance"] = pd.to_numeric(importance["Importance"], errors="coerce").fillna(0.0)
    importance = importance.sort_values("Importance", ascending=False).head(max(1, int(top_n)))
    positive_total = importance["Importance"].clip(lower=0).sum()

    target_numeric = pd.to_numeric(data[target], errors="coerce") if problem == "Regression" else None
    rows = []
    for _, item in importance.iterrows():
        feature = item["Feature"]
        score = float(item["Importance"])
        share = (max(score, 0.0) / positive_total * 100.0) if positive_total > 0 else 0.0
        series = data[feature]
        direction = "Model-dependent"
        relationship = "The model uses this feature, but a single directional effect is not established."
        evidence = np.nan

        numeric = pd.to_numeric(series, errors="coerce")
        numeric_coverage = float(numeric.notna().mean()) if len(numeric) else 0.0
        if problem == "Regression" and numeric_coverage >= 0.80:
            pair = pd.DataFrame({"x": numeric, "y": target_numeric}).dropna()
            if len(pair) >= 3 and pair["x"].nunique() > 1 and pair["y"].nunique() > 1:
                corr = float(pair["x"].corr(pair["y"], method="spearman"))
                evidence = corr
                if corr > 0.05:
                    direction = "Increases target"
                    relationship = f"Higher {feature} values are generally associated with higher {target} values (Spearman {corr:.2f})."
                elif corr < -0.05:
                    direction = "Decreases target"
                    relationship = f"Higher {feature} values are generally associated with lower {target} values (Spearman {corr:.2f})."
                else:
                    direction = "Weak monotonic effect"
                    relationship = f"{feature} has little simple monotonic relationship with {target} (Spearman {corr:.2f}), suggesting nonlinear effects or interactions."
        elif problem == "Regression":
            grouped = pd.DataFrame({"category": series.astype("string").fillna("Unknown"), "target": target_numeric}).dropna(subset=["target"])
            stats = grouped.groupby("category", dropna=False)["target"].agg(["mean", "count"]).query("count >= 2").sort_values("mean")
            if len(stats) >= 2:
                low_name, high_name = str(stats.index[0]), str(stats.index[-1])
                low_mean, high_mean = float(stats.iloc[0]["mean"]), float(stats.iloc[-1]["mean"])
                evidence = high_mean - low_mean
                direction = "Varies by category"
                relationship = f"Average {target} ranges from {low_mean:.2f} for {low_name} to {high_mean:.2f} for {high_name}."
        else:
            relationship = f"Changing {feature} reduces the winning model's predictive quality, so it contributes to predicting {target}."

        rows.append({
            "Rank": len(rows) + 1,
            "Feature": feature,
            "Importance": score,
            "Relative importance %": share,
            "Observed direction": direction,
            "Relationship evidence": evidence,
            "Interpretation": relationship,
        })

    factors = pd.DataFrame(rows)
    if factors.empty:
        raise ValueError("No original feature-level importance values were available.")

    top = factors.iloc[0]
    top_names = factors.head(3)["Feature"].tolist()
    model_name = result.get("best_model_name", "winning model")
    if problem == "Regression":
        narrative = (
            f"The strongest modelled factor for {target} is {top['Feature']}. "
            f"The leading factors are {', '.join(top_names)}. "
            f"These rankings come from {importance_method.lower()} for the winning {model_name} model. "
            "Observed directions describe association in this dataset and should not be interpreted as proof of causation."
        )
    else:
        narrative = (
            f"The strongest modelled factor for predicting {target} is {top['Feature']}. "
            f"The leading factors are {', '.join(top_names)}. "
            f"These rankings come from {importance_method.lower()} for the winning {model_name} model."
        )

    return {"factors": factors, "narrative": narrative, "method": importance_method, "target": target, "model": model_name, "created_at": result.get("created_at")}

def set_navigation(page: str) -> None:
    st.session_state.nav_page = page

def render_navigation() -> str:
    st.markdown('<div class="modern-nav-anchor"></div>', unsafe_allow_html=True)
    nav_columns = st.columns(len(NAV_ITEMS), gap="small")
    current_page = st.session_state.nav_page
    for column, page in zip(nav_columns, NAV_ITEMS):
        column.button(
            page,
            key=f"nav_button_{page.lower().replace(' ', '_').replace('/', '_').replace('&', 'and')}",
            type="primary" if current_page == page else "secondary",
            use_container_width=True,
            on_click=set_navigation,
            args=(page,),
        )
    return st.session_state.nav_page

active_page = render_navigation()

# Prefer the latest Modified Dataset across every downstream analysis page.
# Each publication increments a persistent revision. Every selector is reset once
# for that revision, avoiding unreliable Python object-id/shape comparisons.
MODIFIED_DATASET_SOURCE_KEYS = (
    "main_preview_source",
    "filter_source",
    "create_column_source",
    "pivot_profile_source",
    "charts_profile_source",
    "data_profile_source",
    "ml_source",
    "explore_profile_source",
)

def activate_modified_dataset_defaults() -> None:
    modified = st.session_state.get("filtered_data")
    if modified is None:
        st.session_state.pop("modified_dataset_applied_revision", None)
        return

    revision = int(st.session_state.get("modified_dataset_revision", 0))
    if st.session_state.get("modified_dataset_applied_revision") == revision:
        return

    for source_key in MODIFIED_DATASET_SOURCE_KEYS:
        st.session_state[source_key] = "Modified Dataset"
    st.session_state.modified_dataset_applied_revision = revision

activate_modified_dataset_defaults()


def navigate_to_preview() -> None:
    set_navigation("Preview")

if active_page == "Preview":
    st.subheader("Data preview")
    preview_sources: dict[str, pd.DataFrame] = {dataset_1_name: df1}
    # Use both the current resolved dataframe and the session-backed copy so Dataset 2
    # remains explicitly available in Preview after Streamlit reruns.
    preview_dataset_2 = df2
    if preview_dataset_2 is None and st.session_state.get("base_data_2") is not None:
        preview_dataset_2 = st.session_state.base_data_2.copy()
    if preview_dataset_2 is not None:
        preview_sources[dataset_2_name] = preview_dataset_2
    if st.session_state.joined_data is not None:
        preview_sources["Joined dataset"] = st.session_state.joined_data
    if st.session_state.filtered_data is not None:
        preview_sources["Modified Dataset"] = st.session_state.filtered_data

    preview_controls = st.columns([3, 1])
    preview_names = list(preview_sources.keys())
    if st.session_state.filtered_data is not None and st.session_state.get("main_preview_source") not in preview_names:
        st.session_state.main_preview_source = "Modified Dataset"
    preview_source_name = preview_controls[0].selectbox(
        "Preview source", preview_names, key="main_preview_source"
    )
    preview_row_limit = preview_controls[1].selectbox(
        "Preview rows", [25, 50, 100, 250, 500], index=2, key="main_preview_rows"
    )
    preview_df = preview_sources[preview_source_name]
    st.caption(
        f"Showing up to {min(preview_row_limit, len(preview_df)):,} of "
        f"{len(preview_df):,} rows and {len(preview_df.columns):,} columns."
    )
    preview_slice = preview_df.head(int(preview_row_limit)).copy()
    # Match the Data Profile page grid exactly by using the same read-only
    # Streamlit data-editor component and container-width behaviour.
    render_profile_style_grid(
        preview_slice,
        key=f"main_preview_grid_{preview_source_name}_{preview_row_limit}",
    )

    st.divider()
    st.subheader("Data Pivot")
    st.caption(
        "Keep identifier columns static, use the distinct row values from one field as new "
        "column names, and fill those columns with values from another field."
    )

    pivot_column_options = list(preview_df.columns)
    static_columns = st.multiselect(
        "Static columns",
        pivot_column_options,
        key=f"preview_pivot_static_{preview_source_name}",
        help="Identifier or grouping columns that should remain as rows, such as Customer.",
    )
    remaining_after_static = [
        column for column in pivot_column_options if column not in static_columns
    ]
    pivot_controls = st.columns(3)
    column_name_field = pivot_controls[0].selectbox(
        "Column values to become headers",
        [""] + remaining_after_static,
        key=f"preview_pivot_header_field_{preview_source_name}",
        help="Distinct values in this field become new columns, such as BP, HbA1C, and Basophils.",
    )
    value_field_options = [
        column for column in remaining_after_static if column != column_name_field
    ]
    value_field = pivot_controls[1].selectbox(
        "Values column",
        [""] + value_field_options,
        key=f"preview_pivot_value_field_{preview_source_name}",
        help="Values from this field populate the newly created columns, such as Result.",
    )
    aggregation = pivot_controls[2].selectbox(
        "Duplicate handling",
        ["First", "Last", "Sum", "Mean", "Minimum", "Maximum", "Count"],
        key=f"preview_pivot_aggregation_{preview_source_name}",
        help="Used only when the same static-key and header value occur more than once.",
    )

    pivot_submit_col, pivot_confirm_col, pivot_status_col = st.columns([1, 1, 3])
    pivot_submit = pivot_submit_col.button(
        "Submit",
        type="primary",
        key=f"preview_pivot_submit_{preview_source_name}",
        use_container_width=True,
    )

    source_signature = dataframe_signature(preview_df)
    current_pivot_config = st.session_state.get("preview_pivot_config", {})
    pivot_is_current = (
        st.session_state.get("preview_pivot_data") is not None
        and current_pivot_config.get("source_name") == preview_source_name
        and current_pivot_config.get("source_signature") == source_signature
    )
    pivot_confirm = pivot_confirm_col.button(
        "Confirm Dataset",
        key=f"preview_pivot_confirm_{preview_source_name}",
        use_container_width=True,
        disabled=not pivot_is_current,
    )

    if pivot_submit:
        try:
            generated_pivot = transpose_rows_wide(
                preview_df,
                list(static_columns),
                column_name_field,
                value_field,
                aggregation,
            )
            st.session_state.preview_pivot_data = generated_pivot
            st.session_state.preview_pivot_config = {
                "source_name": preview_source_name,
                "source_signature": source_signature,
                "static_columns": list(static_columns),
                "column_name_field": column_name_field,
                "value_field": value_field,
                "aggregation": aggregation,
            }
            audit(
                "PREVIEW_DATA_PIVOT_GENERATED",
                {
                    **st.session_state.preview_pivot_config,
                    "input_rows": len(preview_df),
                    "output_rows": len(generated_pivot),
                    "output_columns": len(generated_pivot.columns),
                },
            )
            st.rerun()
        except Exception as exc:
            st.error(f"Unable to generate Data Pivot: {exc}")

    if pivot_confirm and pivot_is_current:
        confirmed_pivot = st.session_state.preview_pivot_data.copy()
        publish_modified_dataset(confirmed_pivot)
        st.session_state.main_preview_source = "Modified Dataset"
        audit(
            "PREVIEW_DATA_PIVOT_CONFIRMED",
            {
                **st.session_state.preview_pivot_config,
                "rows": len(confirmed_pivot),
                "columns": len(confirmed_pivot.columns),
            },
        )
        st.success(
            "Pivoted data is now the Modified Dataset and will be selected by default "
            "on all subsequent pages."
        )
        st.rerun()

    current_pivot_config = st.session_state.get("preview_pivot_config", {})
    pivot_is_current = (
        st.session_state.get("preview_pivot_data") is not None
        and current_pivot_config.get("source_name") == preview_source_name
        and current_pivot_config.get("source_signature") == source_signature
    )
    if pivot_is_current:
        pivot_result = st.session_state.preview_pivot_data
        pivot_status_col.caption(
            f"Generated result: {len(pivot_result):,} rows × "
            f"{len(pivot_result.columns):,} columns"
        )
        st.markdown("#### Pivoted Dataset Preview")
        render_profile_style_grid(
            pivot_result.head(int(preview_row_limit)),
            key=f"preview_pivot_grid_{preview_source_name}_{source_signature}_{preview_row_limit}",
        )

if active_page == "Join/Lookup":
    if df2 is None:
        st.info("Add and load a second file to enable join/lookup. All other analysis pages can use the first file directly.")
    else:
        st.subheader("Join or lookup the two datasets")
        c1, c2, c3 = st.columns(3)
        left_key = c1.selectbox(f"{dataset_1_name} lookup key", df1.columns)
        right_key = c2.selectbox(f"{dataset_2_name} lookup key", df2.columns)
        join_type = c3.selectbox("Join type", ["left", "inner", "right", "outer"], format_func=lambda x: {
            "left": "Left lookup (VLOOKUP style)", "inner": "Inner join",
            "right": "Right join", "outer": "Full outer join"}[x])
        c4, c5, c6 = st.columns(3)
        trim_keys = c4.checkbox("Trim spaces in keys", True)
        case_insensitive = c5.checkbox("Case-insensitive keys", True)
        add_match_status = c6.checkbox("Add match status", True)
        selected_right = st.multiselect(
            f"Columns to bring from {dataset_2_name}", [c for c in df2.columns if c != right_key],
            default=[c for c in df2.columns if c != right_key][:10],
        )
    
        if st.button("Run join / lookup", type="primary"):
            left_work = df1.copy()
            right_work = df2[[right_key] + selected_right].copy()
            key = "__lookup_key__"
            left_work[key] = normalize_key(left_work[left_key], trim_keys, case_insensitive)
            right_work[key] = normalize_key(right_work[right_key], trim_keys, case_insensitive)
            duplicates = int(right_work[key].duplicated(keep=False).sum())
            merged = left_work.merge(
                right_work, how=join_type, on=key, suffixes=("_file1", "_file2"),
                indicator=True,
            ).drop(columns=[key])
    
            file1_key_count = int(left_work[left_key].notna().sum())
            file2_key_count = int(right_work[right_key].notna().sum())
            joined_match_count = int(merged["_merge"].eq("both").sum())
            missing_not_joined_count = int(merged["_merge"].ne("both").sum())
    
            if add_match_status:
                merged["_merge"] = merged["_merge"].astype(str).map({
                    "left_only": f"Only in {dataset_1_name}", "right_only": f"Only in {dataset_2_name}", "both": "Matched"})
            else:
                merged = merged.drop(columns=["_merge"])
            st.session_state.joined_data = merged
            clear_modified_dataset()
            st.session_state.join_config = {
                "left_key": left_key, "right_key": right_key, "join_type": join_type,
                "trim_keys": trim_keys, "case_insensitive": case_insensitive,
                "selected_file2_columns": selected_right, "duplicate_file2_key_rows": duplicates,
            }
            st.session_state.join_config.update({
                "file1_key_record_count": file1_key_count,
                "file2_key_record_count": file2_key_count,
                "joined_match_count": joined_match_count,
                "missing_not_joined_count": missing_not_joined_count,
            })
            audit("JOIN_EXECUTED", {**st.session_state.join_config, "output_rows": len(merged)})
            st.success(
                f"Total records of {dataset_1_name} ({left_key} count): {file1_key_count:,} | "
                f"Total records of {dataset_2_name} ({right_key} count): {file2_key_count:,} | "
                f"Joined dataset count (key column match): {joined_match_count:,} | "
                f"Missing or not joined count (key column non-match): {missing_not_joined_count:,}"
            )
    
        if st.session_state.joined_data is not None:
            st.caption(f"Columns are prefixed internally with File1. or File2.; the source files are {dataset_1_name} and {dataset_2_name}.")
            render_profile_style_grid(
                st.session_state.joined_data,
                "joined_grid",
            )
        else:
            st.info("Configure and run the join before creating cross-file filters.")
if active_page == "Filter/Create":
    st.markdown('<span class="filter-page-anchor"></span>', unsafe_allow_html=True)

    # All derived outputs use the existing Modified Dataset session slot. This makes
    # a newly calculated column immediately available to Preview, Profile, Visualize,
    # Data Mining and Machine Learning without duplicating downstream logic.
    create_source_options = {dataset_1_name: df1}
    if df2 is not None:
        create_source_options[dataset_2_name] = df2
    if st.session_state.joined_data is not None:
        create_source_options = {"Joined data": st.session_state.joined_data, **create_source_options}
    if st.session_state.filtered_data is not None:
        create_source_options["Modified Dataset"] = st.session_state.filtered_data

    st.subheader("Create Column")
    st.caption("Build a numeric column from two existing columns, or select No Derivation to categorize an existing numeric column directly.")
    create_source_name = st.selectbox(
        "Data source",
        list(create_source_options.keys()),
        key="create_column_source",
        help="Choose the dataset that will receive the calculated column.",
    )
    create_source_df = create_source_options[create_source_name].copy()
    formula_columns = list(create_source_df.columns)
    right_operand_options = formula_columns + ["Constant: 0", "Constant: 1"]
    no_derivation = st.checkbox(
        "No Derivation",
        value=False,
        key="create_column_no_derivation",
        help="Select this to categorize an existing numeric column directly without creating a formula-derived column.",
    )

    name_col, left_col, operator_col, right_col = st.columns([1.35, 1.5, 1.1, 1.5], vertical_alignment="bottom")
    new_column_name = name_col.text_input(
        "New column name",
        key="create_column_name",
        placeholder="Example: Total_Value",
        help="Enter a unique name for the calculated column.",
        disabled=no_derivation,
    )
    left_column = left_col.selectbox(
        "First formula column",
        formula_columns,
        key="create_column_left",
        help="Select the source column to categorize directly when No Derivation is selected, or the first column in the formula.",
    )
    calculation_label = operator_col.selectbox(
        "Calculation type",
        ["Add", "Minus", "Multiply", "Divide"],
        key="create_column_operator",
        help="Choose the arithmetic operation to apply between the two columns.",
        disabled=no_derivation,
    )
    right_operand = right_col.selectbox(
        "Second formula value",
        right_operand_options,
        key="create_column_right",
        help="Select an existing column or use the numeric constant 0 or 1.",
        disabled=no_derivation,
    )
    right_is_constant = right_operand.startswith("Constant: ")
    right_display = right_operand.split(": ", 1)[1] if right_is_constant else right_operand

    symbol_map = {"Add": "+", "Minus": "−", "Multiply": "×", "Divide": "÷"}
    if no_derivation:
        st.code(f"Categorize existing column: {left_column}", language=None)
    else:
        st.code(f"{new_column_name or '<new column>'} = {left_column} {symbol_map[calculation_label]} {right_display}", language=None)
    conclude_column = st.checkbox(
        "Conclude as final dataset and make it available to the remaining pages",
        value=True,
        key="create_column_conclude",
        help="When selected, the calculated dataset becomes Modified Dataset and is available in Preview, Data Profile, Visualize, Data Mining and Machine Learning.",
    )
    create_action_col, create_spacer_col = st.columns([1, 3], vertical_alignment="bottom")
    if create_action_col.button("Create column", type="primary", use_container_width=True, disabled=no_derivation):
        clean_new_name = str(new_column_name).strip()
        if not clean_new_name:
            st.error("Enter a name for the new column.")
        elif clean_new_name in create_source_df.columns:
            st.error(f"A column named '{clean_new_name}' already exists. Use a different name.")
        else:
            try:
                left_values = pd.to_numeric(create_source_df[left_column], errors="coerce")
                if right_is_constant:
                    constant_value = float(right_display)
                    right_values = pd.Series(constant_value, index=create_source_df.index, dtype="float64")
                else:
                    right_values = pd.to_numeric(create_source_df[right_operand], errors="coerce")
                if left_values.notna().sum() == 0:
                    raise ValueError(f"'{left_column}' does not contain usable numeric values.")
                if right_values.notna().sum() == 0:
                    raise ValueError(f"'{right_display}' does not contain usable numeric values.")

                calculated = create_source_df.copy()
                if calculation_label == "Add":
                    result = left_values + right_values
                elif calculation_label == "Minus":
                    result = left_values - right_values
                elif calculation_label == "Multiply":
                    result = left_values * right_values
                else:
                    zero_count = int(right_values.eq(0).sum())
                    safe_divisor = right_values.mask(right_values.eq(0))
                    result = left_values / safe_divisor
                    if zero_count:
                        st.warning(f"{zero_count:,} row(s) had a zero divisor and were set to missing in '{clean_new_name}'.")

                calculated[clean_new_name] = result.replace([np.inf, -np.inf], np.nan)
                st.session_state.created_column_preview = calculated
                st.session_state.created_column_config = {
                    "source": create_source_name,
                    "created_column": clean_new_name,
                    "left_column": left_column,
                    "right_column": None if right_is_constant else right_operand,
                    "right_operand": right_display,
                    "right_operand_type": "constant" if right_is_constant else "column",
                    "formula": f"{left_column} {symbol_map[calculation_label]} {right_display}",
                    "operation": calculation_label,
                    "published": bool(conclude_column),
                    "bucketed": False,
                }
                if conclude_column:
                    publish_modified_dataset(calculated)
                    st.session_state.last_filter_config = dict(st.session_state.created_column_config)
                    st.session_state.main_preview_source = "Modified Dataset"
                audit("CALCULATED_COLUMN_CREATED", {
                    "source": create_source_name,
                    "new_column": clean_new_name,
                    "left_column": left_column,
                    "operation": calculation_label,
                    "right_operand": right_display,
                    "right_operand_type": "constant" if right_is_constant else "column",
                    "rows": len(calculated),
                    "published": conclude_column,
                })
                st.success(
                    f"Created '{clean_new_name}' for {len(calculated):,} rows. "
                    + ("The dataset is now available as Modified Dataset across Clarity." if conclude_column else "The result is available below on this page.")
                )
            except Exception as exc:
                st.error(f"Could not create the column: {exc}")

    bucket_action_col, bucket_spacer_col = st.columns([1, 3], vertical_alignment="bottom")
    bucket_available = no_derivation or (
        st.session_state.created_column_preview is not None
        and bool(st.session_state.created_column_config.get("created_column"))
    )
    if bucket_action_col.button(
        "Categorize", use_container_width=True, disabled=not bucket_available,
        help="Categorize the selected existing column directly when No Derivation is checked, or categorize the latest calculated column.",
    ):
        if no_derivation:
            direct_numeric = pd.to_numeric(create_source_df[left_column], errors="coerce")
            if direct_numeric.dropna().empty:
                st.error(f"'{left_column}' does not contain usable numeric values for categorization.")
            else:
                st.session_state.created_column_preview = create_source_df.copy()
                st.session_state.created_column_config = {
                    "source": create_source_name,
                    "created_column": left_column,
                    "left_column": left_column,
                    "right_column": None,
                    "right_operand": None,
                    "right_operand_type": None,
                    "formula": "No Derivation",
                    "operation": "No Derivation",
                    "published": bool(conclude_column),
                    "bucketed": False,
                    "categorized": False,
                    "no_derivation": True,
                }
                audit("DIRECT_COLUMN_CATEGORIZATION_STARTED", {
                    "source": create_source_name,
                    "column": left_column,
                    "rows": len(create_source_df),
                    "published": conclude_column,
                })
                render_bucket_dialog()
        else:
            render_bucket_dialog()

    if st.session_state.created_column_preview is not None and st.session_state.created_column_config.get("created_column"):
        created_name = st.session_state.created_column_config.get("created_column")
        preview_left = st.session_state.created_column_config.get("left_column")
        preview_right = st.session_state.created_column_config.get("right_column")
        preview_title = "Categorized-column preview" if st.session_state.created_column_config.get("categorized") else "Created-column preview"
        st.markdown(f"#### {preview_title}")
        category_name = st.session_state.created_column_config.get("category_column")
        preview_cols = []
        for column in [preview_left, preview_right, created_name, category_name]:
            if column in st.session_state.created_column_preview.columns and column not in preview_cols:
                preview_cols.append(column)
        st.dataframe(st.session_state.created_column_preview[preview_cols].head(25), use_container_width=True, hide_index=True)

    st.divider()
    st.subheader("Visible AND/OR filter builder")
    source_options = {dataset_1_name: df1}
    if df2 is not None:
        source_options[dataset_2_name] = df2
    if st.session_state.joined_data is not None:
        source_options = {"Joined data": st.session_state.joined_data, **source_options}
    if st.session_state.filtered_data is not None:
        source_options["Modified Dataset"] = st.session_state.filtered_data
    available = list(source_options.keys())
    source_col, upload_col = st.columns([1, 1], vertical_alignment="bottom")
    source_name = source_col.selectbox("Filter data source", available, key="filter_source")
    uploaded_filters = upload_col.file_uploader(
        "Load saved filters", type=["json"], key="filter_upload",
        help="Select a previously saved filter-definition JSON file.",
    )
    source_df = source_options[source_name].copy()

    saved_deep_dive = st.session_state.get("saved_deep_dive_filters", {})
    if saved_deep_dive:
        st.markdown("#### Saved Deep Dive filters")
        preset_col, apply_preset_col, delete_preset_col = st.columns([3, 1, 1], vertical_alignment="bottom")
        preset_name = preset_col.selectbox("Saved filter", list(saved_deep_dive.keys()), key="saved_deep_dive_filter_choice")
        if apply_preset_col.button("Apply saved", type="primary", use_container_width=True):
            preset = saved_deep_dive[preset_name]
            reapplied = apply_saved_deep_dive_filter(source_df, preset.get("filter_spec", {}))
            publish_modified_dataset(reapplied)
            st.session_state.main_preview_source = "Modified Dataset"
            audit("EDA_DEEP_DIVE_FILTER_REAPPLIED", {"name": preset_name, "output_rows": len(reapplied)})
            st.success(f"Applied '{preset_name}' to {len(reapplied):,} matching records.")
        if delete_preset_col.button("Delete", use_container_width=True):
            del st.session_state.saved_deep_dive_filters[preset_name]
            audit("EDA_DEEP_DIVE_FILTER_DELETED", {"name": preset_name})
            st.rerun()

    import_col, clear_col, spacer_col = st.columns([1, 1, 2], vertical_alignment="bottom")
    if import_col.button(
        "Import filter file", use_container_width=True, disabled=uploaded_filters is None
    ):
        try:
            payload = json.loads(uploaded_filters.getvalue().decode("utf-8"))
            imported = payload.get("filters", payload)
            if not isinstance(imported, list):
                raise ValueError("The file does not contain a filter list.")
            valid = [r for r in imported if r.get("column") in source_df.columns]
            st.session_state.filters = valid
            audit("FILTER_SET_IMPORTED", {"imported": len(valid), "ignored": len(imported) - len(valid)})
            st.rerun()
        except Exception as exc:
            st.error(f"Could not import filters: {exc}")
    if clear_col.button("Clear all filters", use_container_width=True):
        count = len(st.session_state.filters)
        st.session_state.filters = []
        clear_modified_dataset()
        audit("FILTERS_CLEARED", {"count": count})
        st.rerun()

    st.divider()
    st.markdown("#### Add condition")
    a, b, c, d = st.columns([1, 1.6, 1.4, 1.6], vertical_alignment="bottom")
    connector = a.selectbox("Connector", ["AND", "OR"], disabled=len(st.session_state.filters) == 0)
    column = b.selectbox("Column", source_df.columns)
    operator = c.selectbox("Operator", OPERATORS)
    value_disabled = operator in {"is blank", "is not blank"}
    value = d.text_input("Value", disabled=value_disabled, help="For 'in list', use comma-separated values.")
    e, f, g = st.columns([2, 1, 1], vertical_alignment="bottom")
    value2 = e.text_input("Upper value", disabled=operator != "between")
    case_sensitive = f.checkbox("Case-sensitive", False)
    if g.button("Add filter", type="primary", use_container_width=True):
        rule = {
            "connector": "AND" if not st.session_state.filters else connector,
            "column": column, "operator": operator, "value": value,
            "value2": value2, "case_sensitive": case_sensitive,
        }
        st.session_state.filters.append(rule)
        audit("FILTER_ADDED", rule)
        st.rerun()

    st.divider()
    st.markdown("#### Applied filter definition")
    if not st.session_state.filters:
        st.info("No conditions added. Add conditions above; every condition remains visible here.")
    else:
        for index, rule in enumerate(st.session_state.filters):
            with st.container(border=True):
                x1, x2, x3 = st.columns([7, 1, 1])
                x1.code(filter_summary(rule, index), language=None)
                if x2.button("↑", key=f"up_{index}", disabled=index == 0):
                    rules = st.session_state.filters
                    rules[index - 1], rules[index] = rules[index], rules[index - 1]
                    audit("FILTER_REORDERED", {"from": index, "to": index - 1})
                    st.rerun()
                if x3.button("Remove", key=f"remove_{index}"):
                    removed = st.session_state.filters.pop(index)
                    audit("FILTER_REMOVED", removed)
                    st.rerun()

    st.divider()
    st.markdown("#### Output configuration")
    csel, csort, cascn = st.columns([2.2, 1.6, 1], vertical_alignment="bottom")
    selected_columns = csel.multiselect("Output columns and order", source_df.columns, default=list(source_df.columns))
    sort_columns = csort.multiselect("Sort by", selected_columns)
    ascending = cascn.checkbox("Ascending", True)
    dedupe_col, dedupe_spacer = st.columns([1, 3], vertical_alignment="bottom")
    remove_duplicates = dedupe_col.checkbox("Remove duplicate output rows")

    apply_col, save_col = st.columns(2, vertical_alignment="bottom")
    if apply_col.button("Apply filters", type="primary", use_container_width=True):
        try:
            filtered = apply_filter_rules(source_df, st.session_state.filters)
            if selected_columns:
                filtered = filtered[selected_columns]
            if sort_columns:
                filtered = filtered.sort_values(sort_columns, ascending=ascending, na_position="last")
            if remove_duplicates:
                filtered = filtered.drop_duplicates()
            publish_modified_dataset(filtered)
            st.session_state.last_filter_config = {
                "source": source_name, "filters": st.session_state.filters,
                "selected_columns": selected_columns, "sort_columns": sort_columns,
                "ascending": ascending, "remove_duplicates": remove_duplicates,
            }
            audit("FILTERS_APPLIED", {
                "source": source_name, "conditions": len(st.session_state.filters),
                "input_rows": len(source_df), "output_rows": len(filtered),
                "sort_columns": sort_columns, "remove_duplicates": remove_duplicates,
            })
            st.session_state.main_preview_source = "Modified Dataset"
            set_navigation("Preview")
            st.rerun()
        except Exception as exc:
            st.error(f"Could not apply filters: {exc}")

    filter_payload = {"version": 1, "source": source_name, "filters": st.session_state.filters}
    save_col.download_button(
        "Save filter definition", json_bytes(filter_payload),
        file_name=f"{st.session_state.analysis_name}_filters.json", mime="application/json",
        on_click=lambda: audit("FILTER_SET_DOWNLOADED", {"conditions": len(st.session_state.filters)}),
        use_container_width=True,
    )
    if st.session_state.filtered_data is not None:
        st.divider()
        st.markdown("#### Modified Dataset")
        filtered_output = st.session_state.filtered_data
        filtered_controls = st.columns([3, 1])
        filtered_controls[0].caption(
            f"{len(filtered_output):,} rows and {len(filtered_output.columns):,} columns. "
            "Scroll horizontally to view all columns."
        )
        filtered_row_limit = filtered_controls[1].selectbox(
            "Rows to display", [25, 50, 100, 250, 500], index=2, key="filtered_output_rows",
        )
        visible_output = filtered_output.head(int(filtered_row_limit)).copy()
        st.dataframe(
            visible_output, use_container_width=True,
            height=min(620, max(260, 38 + 35 * min(len(visible_output), 15))), hide_index=True,
        )
        st.download_button(
            "Download output Excel", to_excel_bytes({"Modified_Dataset": filtered_output}),
            file_name=f"{st.session_state.analysis_name}_output.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            on_click=lambda: audit("OUTPUT_EXCEL_DOWNLOADED", {"rows": len(filtered_output)}),
        )

if active_page == "Visualize":
    st.subheader("Pivot table")
    st.caption("Summarize data across rows, columns and measures, then visualize the resulting pivot.")
    pivot_options = {dataset_1_name: df1}
    if df2 is not None:
        pivot_options[dataset_2_name] = df2
    if st.session_state.joined_data is not None:
        pivot_options["Joined data"] = st.session_state.joined_data
    if st.session_state.filtered_data is not None:
        pivot_options["Modified Dataset"] = st.session_state.filtered_data
    pivot_source_name = st.radio("Profile source", pivot_options.keys(), horizontal=True, key="pivot_profile_source")
    if st.session_state.get("pivot_last_profile_source") != pivot_source_name:
        st.session_state.pivot_data = None
        st.session_state.show_pivot_visualization = False
        st.session_state.pivot_last_profile_source = pivot_source_name
    pivot_source = pivot_options[pivot_source_name]
    if pivot_source is None or pivot_source.empty:
        st.info("No analysis data is available.")
    else:
        p1, p2 = st.columns(2)
        index_columns = p1.multiselect("Rows", pivot_source.columns)
        pivot_columns = p2.multiselect("Columns", pivot_source.columns)
        numeric = list(pivot_source.select_dtypes(include="number").columns)
        values = st.multiselect("Values", pivot_source.columns, default=numeric[:1])
        aggregation = st.selectbox("Aggregation", ["sum", "mean", "count", "min", "max", "median", "nunique"])
        if st.button("Create pivot") and index_columns and values:
            pivot_df = pd.pivot_table(
                pivot_source, index=index_columns, columns=pivot_columns or None,
                values=values, aggfunc=aggregation, fill_value=0, dropna=False).reset_index()
            pivot_df.columns = [" | ".join(str(x) for x in col if str(x)) if isinstance(col, tuple) else str(col) for col in pivot_df.columns]
            st.session_state.pivot_data = pivot_df
            st.session_state.show_pivot_visualization = False
            audit("PIVOT_CREATED", {"rows": index_columns, "columns": pivot_columns, "values": values, "aggregation": aggregation})

        pivot_df = st.session_state.get("pivot_data")
        if pivot_df is not None:
            st.caption("Column headings are automatically expanded for readability.")
            visible_pivot = render_grid(pivot_df, "pivot_grid", fit_columns=True)
            d1, d2, d3, _pivot_spacer = st.columns([1.35, 1.25, 0.9, 3.5])
            d1.download_button(
                "Download pivot Excel", to_excel_bytes({"Pivot_Output": visible_pivot}),
                file_name=f"{st.session_state.analysis_name}_pivot.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                on_click=lambda: audit("PIVOT_EXCEL_DOWNLOADED", {"rows": len(visible_pivot)}),
                use_container_width=True,
            )
            d2.download_button(
                "Download pivot CSV", visible_pivot.to_csv(index=False).encode("utf-8-sig"),
                file_name=f"{st.session_state.analysis_name}_pivot.csv", mime="text/csv",
                on_click=lambda: audit("PIVOT_CSV_DOWNLOADED", {"rows": len(visible_pivot)}),
                use_container_width=True,
            )
            if d3.button("Visualize", key="visualize_pivot_button", type="primary", use_container_width=True):
                st.session_state.show_pivot_visualization = True
                audit("PIVOT_VISUALIZATION_OPENED", {"rows": len(visible_pivot), "columns": len(visible_pivot.columns)})

            if st.session_state.get("show_pivot_visualization", False):
                st.markdown("#### Pivot visualization")
                pivot_chart_columns = list(visible_pivot.columns)
                pivot_numeric_columns = [
                    col for col in pivot_chart_columns
                    if pd.api.types.is_numeric_dtype(visible_pivot[col])
                ]
                pivot_category_columns = [col for col in pivot_chart_columns if col not in pivot_numeric_columns]

                if not pivot_numeric_columns:
                    st.info("The pivot result does not contain a numeric measure that can be charted.")
                else:
                    pv1, pv2, pv3 = st.columns(3)
                    pivot_chart_type = pv1.selectbox(
                        "Chart type", ["Bar", "Line", "Pie", "Heatmap"], key="pivot_visual_chart_type"
                    )
                    category_candidates = pivot_category_columns or pivot_chart_columns
                    pivot_x = pv2.selectbox(
                        "Category / X axis", category_candidates, key="pivot_visual_x"
                    )
                    pivot_y = pv3.selectbox(
                        "Value / Y axis", pivot_numeric_columns, key="pivot_visual_y"
                    )

                    series_candidates = [col for col in pivot_category_columns if col != pivot_x]
                    pivot_series = st.selectbox(
                        "Series / group (optional)", ["None"] + series_candidates,
                        key="pivot_visual_series",
                    )
                    pivot_series_col = None if pivot_series == "None" else pivot_series

                    try:
                        pivot_plot = visible_pivot.copy()
                        pivot_plot[pivot_y] = safe_numeric_series(pivot_plot[pivot_y])
                        pivot_plot = pivot_plot.dropna(subset=[pivot_y])
                        if pivot_plot.empty:
                            raise ValueError("No numeric pivot values are available after cleaning.")

                        if pivot_chart_type == "Bar":
                            fig = px.bar(
                                pivot_plot, x=pivot_x, y=pivot_y,
                                color=pivot_series_col, barmode="group",
                                title=f"{pivot_y} by {pivot_x}",
                            )
                        elif pivot_chart_type == "Line":
                            fig = px.line(
                                pivot_plot, x=pivot_x, y=pivot_y,
                                color=pivot_series_col, markers=True,
                                title=f"{pivot_y} by {pivot_x}",
                            )
                        elif pivot_chart_type == "Pie":
                            fig = px.pie(
                                pivot_plot, names=pivot_x, values=pivot_y,
                                title=f"{pivot_y} distribution by {pivot_x}",
                            )
                        else:
                            if pivot_series_col:
                                heatmap_data = pd.pivot_table(
                                    pivot_plot, index=pivot_x, columns=pivot_series_col,
                                    values=pivot_y, aggfunc="sum", fill_value=0,
                                )
                            else:
                                heatmap_data = pivot_plot.set_index(pivot_x)[[pivot_y]].T
                            fig = px.imshow(
                                heatmap_data, text_auto=".2f", aspect="auto",
                                title=f"Pivot heatmap: {pivot_y}",
                            )
                        plot_chart(fig, use_container_width=True)
                    except Exception as exc:
                        st.error(f"Could not visualize the pivot result: {exc}")

    st.divider()
    st.subheader("Charts")
    st.caption("Build interactive charts across numeric, categorical and date columns.")
    chart_options = {dataset_1_name: df1}
    if df2 is not None:
        chart_options[dataset_2_name] = df2
    if st.session_state.joined_data is not None:
        chart_options["Joined data"] = st.session_state.joined_data
    if st.session_state.filtered_data is not None:
        chart_options["Modified Dataset"] = st.session_state.filtered_data
    chart_source_name = st.radio("Profile source", chart_options.keys(), horizontal=True, key="charts_profile_source")
    chart_df = chart_options[chart_source_name]
    if chart_df is None or chart_df.empty:
        st.info("No analysis data is available.")
    else:
        chart_type = st.selectbox("Chart type", ["Bar", "Line", "Scatter", "Histogram", "Box", "Pie", "Heatmap (cross tab)"])
        columns = list(chart_df.columns)

        if chart_type == "Heatmap (cross tab)":
            h1, h2 = st.columns(2)
            row_col = h1.selectbox("Cross-tab rows", columns, key="heatmap_rows")
            col_col = h2.selectbox("Cross-tab columns", columns, index=min(1, len(columns)-1), key="heatmap_cols")
            value_cols = st.multiselect("Value columns (optional)", columns, key="heatmap_values")
            heatmap_agg = st.selectbox("Aggregation", ["Row count", "Distinct count", "Sum", "Average", "Median", "Minimum", "Maximum"], key="heatmap_agg")
            normalize = st.selectbox("Normalize", ["None", "By row (%)", "By column (%)", "Overall (%)"], key="heatmap_normalize")
            max_categories = st.slider("Maximum categories per axis", 5, 50, 20, key="heatmap_max_categories")
            if st.button("Create heatmap", type="primary"):
                try:
                    work = chart_df.copy()
                    top_rows = work[row_col].astype("string").fillna("<Missing>").value_counts().head(max_categories).index
                    top_cols = work[col_col].astype("string").fillna("<Missing>").value_counts().head(max_categories).index
                    work["__row__"] = work[row_col].astype("string").fillna("<Missing>")
                    work["__col__"] = work[col_col].astype("string").fillna("<Missing>")
                    work = work[work["__row__"].isin(top_rows) & work["__col__"].isin(top_cols)]

                    if heatmap_agg == "Row count" or not value_cols:
                        cross = pd.crosstab(work["__row__"], work["__col__"])
                    else:
                        frames = []
                        for value_col in value_cols:
                            if heatmap_agg == "Distinct count":
                                pivot = pd.pivot_table(work, index="__row__", columns="__col__", values=value_col, aggfunc=pd.Series.nunique, fill_value=0)
                            else:
                                work["__heat_value__"] = safe_numeric_series(work[value_col])
                                agg_map = {"Sum":"sum", "Average":"mean", "Median":"median", "Minimum":"min", "Maximum":"max"}
                                pivot = pd.pivot_table(work, index="__row__", columns="__col__", values="__heat_value__", aggfunc=agg_map[heatmap_agg], fill_value=0)
                            if len(value_cols) > 1:
                                pivot.columns = [f"{value_col} | {c}" for c in pivot.columns]
                            frames.append(pivot)
                        cross = pd.concat(frames, axis=1)

                    if normalize == "By row (%)":
                        cross = cross.div(cross.sum(axis=1).replace(0, np.nan), axis=0) * 100
                    elif normalize == "By column (%)":
                        cross = cross.div(cross.sum(axis=0).replace(0, np.nan), axis=1) * 100
                    elif normalize == "Overall (%)":
                        total = cross.to_numpy().sum()
                        cross = cross / total * 100 if total else cross

                    fig = px.imshow(cross, text_auto=".2f", aspect="auto", labels={"x": col_col, "y": row_col, "color": heatmap_agg}, title=f"Cross-tab heatmap: {row_col} × {col_col}")
                    plot_chart(fig, use_container_width=True)
                    st.dataframe(cross, use_container_width=True)
                    audit("HEATMAP_CREATED", {"rows": row_col, "columns": col_col, "values": value_cols, "aggregation": heatmap_agg, "normalize": normalize})
                except Exception as exc:
                    st.error(f"Could not create heatmap: {exc}")
        else:
            x_columns = st.multiselect("X axis / category columns", columns, default=[columns[0]], max_selections=3)
            y_columns = st.multiselect("Y axis / value columns", columns, default=[])
            aggregation = st.selectbox(
                "Aggregation",
                ["Row count", "Distinct count", "Sum", "Average", "Median", "Minimum", "Maximum"],
                help="Select multiple columns to generate multiple series. Row count works without a Y column.",
            )
            color_col = st.selectbox("Color / group", ["None"] + columns)
            top_n = st.slider("Maximum categories", 5, 100, 30)
            if st.button("Create chart"):
                try:
                    if not x_columns:
                        raise ValueError("Select at least one X-axis/category column.")
                    color = None if color_col == "None" else color_col
                    x_col = x_columns[0] if len(x_columns) == 1 else " | ".join(x_columns)
                    work = chart_df.copy()
                    if len(x_columns) > 1:
                        work[x_col] = work[x_columns].astype("string").fillna("<Missing>").agg(" | ".join, axis=1)

                    if chart_type in {"Scatter", "Box"} and not y_columns:
                        raise ValueError(f"Select at least one Y-axis column for a {chart_type.lower()} chart.")

                    if chart_type == "Histogram":
                        melted = work.melt(value_vars=x_columns, var_name="column", value_name="value")
                        fig = px.histogram(melted, x="value", color="column", barmode="overlay")
                    elif chart_type == "Scatter":
                        scatter_y = y_columns[:5]
                        melted = work.melt(id_vars=[x_col] + ([color] if color and color != x_col else []), value_vars=scatter_y, var_name="series", value_name="value")
                        melted["value"] = safe_numeric_series(melted["value"])
                        fig = px.scatter(melted, x=x_col, y="value", color="series", symbol=color if color and color in melted.columns else None)
                    elif chart_type == "Box":
                        melted = work.melt(id_vars=[x_col], value_vars=y_columns, var_name="series", value_name="value")
                        melted["value"] = safe_numeric_series(melted["value"])
                        fig = px.box(melted, x=x_col, y="value", color="series", points="outliers")
                    else:
                        series_cols = y_columns or [None]
                        frames = []
                        for y_col in series_cols:
                            plot_df, plot_y = build_chart_data(work, x_col, y_col, aggregation, chart_type, top_n)
                            plot_df = plot_df.copy()
                            plot_df["series"] = y_col or aggregation
                            plot_df["value"] = plot_df[plot_y]
                            frames.append(plot_df[[x_col, "series", "value"]])
                        combined = pd.concat(frames, ignore_index=True)
                        if chart_type == "Bar":
                            fig = px.bar(combined, x=x_col, y="value", color="series", barmode="group")
                        elif chart_type == "Line":
                            fig = px.line(combined, x=x_col, y="value", color="series", markers=True)
                        elif chart_type == "Pie":
                            if len(series_cols) > 1:
                                raise ValueError("Pie charts support one selected value column at a time.")
                            fig = px.pie(combined, names=x_col, values="value")
                        else:
                            raise ValueError("Unsupported chart configuration.")
                    plot_chart(fig, use_container_width=True)
                    audit("CHART_CREATED", {"type": chart_type, "x": x_columns, "y": y_columns, "aggregation": aggregation, "color": color_col})
                except Exception as exc:
                    st.error(f"Could not create chart: {exc}")


if active_page == "Data Profile":
    st.subheader("Detailed data quality profile")
    if st.session_state.pop("profile_standardization_notice", None):
        st.success("Standardization completed and staged. Click Confirm Dataset to publish the prepared data.")
    if st.session_state.pop("profile_confirmation_notice", None):
        st.success("Dataset confirmed. The result grid and detailed cards now use the finalized data.")
    options = {dataset_1_name: df1}
    if df2 is not None:
        options[dataset_2_name] = df2
    if st.session_state.joined_data is not None:
        options["Joined data"] = st.session_state.joined_data
    if st.session_state.filtered_data is not None:
        options["Modified Dataset"] = st.session_state.filtered_data
    profile_name = st.radio(
        "Profile source", options.keys(), horizontal=True, key="data_profile_source"
    )
    profile = options[profile_name]
    summary = quality_summary(profile)
    q1, q2, q3, q4, q5, q6 = st.columns(6)
    q1.metric("Rows", f"{summary['rows']:,}")
    q2.metric("Columns", f"{summary['columns']:,}")
    q3.metric("Duplicate rows", f"{summary['duplicate_rows']:,}")
    q4.metric("Missing cells", f"{summary['missing_cells']:,}")
    q5.metric("IQR outliers", f"{summary['outliers']:,}")
    q6.metric("Invalid values", f"{summary['invalid_values']:,}")

    profile_df = detailed_profile(profile)
    if canonical_source_name(profile_name) == "File 1":
        profile_revision = int(st.session_state.get("profile_revision_1", 0))
    elif canonical_source_name(profile_name) == "File 2":
        profile_revision = int(st.session_state.get("profile_revision_2", 0))
    else:
        profile_revision = int(len(profile) + len(profile.columns))

    st.markdown("#### Profile results and final column selection")
    selection_df = profile_df.copy()
    selection_df.insert(0, "include", True)
    selection_df = selection_df.drop(columns=["top_values"], errors="ignore")
    edited_profile = st.data_editor(
        selection_df,
        use_container_width=True,
        hide_index=True,
        key=f"data_profile_grid_{profile_name}_{profile_revision}",
        disabled=[column for column in selection_df.columns if column != "include"],
        column_config={
            "include": st.column_config.CheckboxColumn("Select", help="Include this column in the final dataset", default=True),
            "column": st.column_config.TextColumn("Column"),
        },
    )
    selected_final_columns = edited_profile.loc[edited_profile["include"], "column"].astype(str).tolist()

    action_col1, action_col2, action_status = st.columns([1.15, 1.15, 2.7])
    with action_col1:
        standardize_clicked = st.button(
            "Standardize Data",
            type="primary",
            use_container_width=True,
            key=f"standardize_profile_selection_{profile_name}_{profile_revision}",
            disabled=not selected_final_columns,
        )
    with action_col2:
        confirm_final = st.button(
            "Confirm Dataset",
            use_container_width=True,
            key=f"confirm_profile_columns_{profile_name}_{profile_revision}",
            disabled=not selected_final_columns,
        )
    with action_status:
        pending_matches = (
            st.session_state.get("profile_pending_standardized_data") is not None
            and st.session_state.get("profile_pending_standardized_source") == profile_name
        )
        if pending_matches:
            staged = st.session_state.profile_pending_standardized_data
            st.caption(
                f"Standardized dataset staged: {len(staged):,} rows and {len(staged.columns):,} columns. "
                "Click Confirm Dataset to publish and refresh the profile."
            )
        else:
            st.caption(f"{len(selected_final_columns):,} of {len(profile.columns):,} columns selected. All columns are selected by default.")

    if standardize_clicked:
        show_profile_standardize_dialog(profile_name, profile, selected_final_columns, profile_revision)

    if confirm_final:
        if not selected_final_columns:
            st.error("Select at least one column for the final dataset.")
        else:
            pending_data = st.session_state.get("profile_pending_standardized_data")
            pending_source = st.session_state.get("profile_pending_standardized_source")
            if pending_data is not None and pending_source == profile_name:
                finalized = pending_data.copy()
                standardization_details = st.session_state.get("profile_pending_standardized_details", {})
                update_profile_source_data(
                    canonical_source_name(profile_name),
                    finalized,
                    "PROFILE_STANDARDIZED_DATASET_CONFIRMED",
                    standardization_details,
                )
            else:
                finalized = profile.loc[:, selected_final_columns].copy()
                update_profile_source_data(
                    canonical_source_name(profile_name),
                    finalized,
                    "PROFILE_FINAL_DATASET_CONFIRMED",
                    {
                        "selected_columns": selected_final_columns,
                        "rows": len(finalized),
                        "columns": len(selected_final_columns),
                    },
                )

            # Publish the confirmed data for every downstream page and clear the staged copy.
            publish_modified_dataset(finalized.copy())
            st.session_state.profile_pending_standardized_data = None
            st.session_state.profile_pending_standardized_details = {}
            st.session_state.profile_pending_standardized_source = None
            st.session_state.profile_pending_standardized_revision = None
            if canonical_source_name(profile_name) == "File 1":
                refreshed_revision = int(st.session_state.get("profile_revision_1", 0))
            elif canonical_source_name(profile_name) == "File 2":
                refreshed_revision = int(st.session_state.get("profile_revision_2", 0))
            else:
                refreshed_revision = int(len(finalized) + len(finalized.columns))
            st.session_state[f"profile_card_columns_{profile_name}_{refreshed_revision}"] = list(finalized.columns)
            st.session_state.profile_confirmation_notice = (
                f"Dataset confirmed with {len(finalized):,} rows and {len(finalized.columns):,} columns. "
                "The profile grid and detailed cards were refreshed from the finalized data."
            )
            st.success(
                f"Dataset confirmed with {len(finalized):,} rows and {len(finalized.columns):,} columns. "
                "The profile grid and detailed cards are being refreshed from the finalized data."
            )
            st.rerun()

    st.caption("Invalid values identify failed conversions in predominantly numeric-like or date-like columns. Outliers use the 1.5×IQR rule.")

    st.divider()
    st.subheader("Detailed data cards")
    selected_card_columns = st.multiselect(
        "Columns to display",
        list(profile.columns),
        default=[],
        key=f"profile_card_columns_{profile_name}_{profile_revision}",
        placeholder="Select one or more columns",
    )

    if not selected_card_columns:
        st.info("No columns are selected by default. Select the required columns to display detailed cards.")
    else:
        cards_per_row = 2
        for start_idx in range(0, len(selected_card_columns), cards_per_row):
            card_row = st.columns(cards_per_row)
            for position, column in enumerate(selected_card_columns[start_idx:start_idx + cards_per_row]):
                series = profile[column]
                row = profile_df.loc[profile_df["column"] == column].iloc[0]
                with card_row[position]:
                    with st.container(border=True):
                        st.markdown(f"**{column}**")
                        st.caption(f"{row['semantic_type']} · {row['physical_type']}")
                        m1, m2, m3 = st.columns(3)
                        m1.metric("Valid", f"{int(row['non_null']):,}")
                        m2.metric("Missing", f"{int(row['missing']):,}", f"{float(row['missing_pct']):.1f}%")
                        m3.metric("Unique", f"{int(row['unique_values']):,}")
                        d1, d2, d3 = st.columns(3)
                        d1.metric("Duplicates", f"{int(row['duplicate_values']):,}")
                        d2.metric("Invalid", f"{int(row['invalid_values']):,}")
                        d3.metric("Consistency", f"{float(row['type_consistency_pct']):.1f}%")

                        semantic = str(row["semantic_type"])
                        if semantic in {"numerical", "numeric-like text"}:
                            numeric_all = safe_numeric_series(series)
                            numeric = numeric_all.dropna()
                            if not numeric.empty:
                                skewness = float(numeric.skew()) if len(numeric) >= 3 else np.nan
                                stats = pd.DataFrame({
                                    "Metric": ["Mean", "Median", "Minimum", "Maximum", "Std. deviation", "Skewness", "IQR outliers"],
                                    "Value": [numeric.mean(), numeric.median(), numeric.min(), numeric.max(), numeric.std(), skewness, int(row["outliers_iqr"])],
                                })
                                stats["Value"] = stats["Value"].map(lambda value: f"{value:,.2f}" if isinstance(value, (int, float, np.integer, np.floating)) and not pd.isna(value) else "Not available")
                                st.dataframe(stats, use_container_width=True, hide_index=True)
                                plot_chart(px.histogram(numeric, nbins=20, labels={"value": column}, title=f"Distribution · skewness {skewness:,.2f}" if pd.notna(skewness) else "Distribution"), use_container_width=True, key=f"profile_card_hist_{start_idx}_{position}_{column}")

                            st.markdown("**Numeric corrections**")
                            a1, a2, a3 = st.columns(3)
                            drop_nulls = a1.button("Drop nulls", key=f"profile_drop_nulls_{profile_name}_{profile_revision}_{column}", use_container_width=True, disabled=int(row["missing"]) == 0 and int(row["invalid_values"]) == 0)
                            fill_median = a2.button("Fill with median", key=f"profile_fill_median_{profile_name}_{profile_revision}_{column}", use_container_width=True, disabled=int(row["missing"]) == 0 and int(row["invalid_values"]) == 0)
                            drop_outliers = a3.button("Drop outliers", key=f"profile_drop_outliers_{profile_name}_{profile_revision}_{column}", use_container_width=True, disabled=int(row["outliers_iqr"]) == 0)
                            strategy = "drop_nulls" if drop_nulls else "fill_median" if fill_median else "drop_outliers" if drop_outliers else None
                            if strategy:
                                try:
                                    _, _, message = apply_numeric_profile_correction(profile_name, profile, column, strategy)
                                    st.success(message + " The corrected dataset is now the active source for subsequent analysis.")
                                    st.rerun()
                                except Exception as exc:
                                    st.error(f"Could not apply correction: {exc}")
                        elif semantic in {"datetime", "date-like text"}:
                            dates = safe_datetime_series(series).dropna()
                            if not dates.empty:
                                date_stats = pd.DataFrame({"Metric": ["Earliest", "Latest", "Distinct dates"], "Value": [str(dates.min()), str(dates.max()), f"{dates.nunique():,}"]})
                                st.dataframe(date_stats, use_container_width=True, hide_index=True)
                                monthly = dates.dt.to_period("M").astype(str).value_counts().sort_index().tail(24).reset_index()
                                monthly.columns = ["Period", "Count"]
                                plot_chart(px.bar(monthly, x="Period", y="Count"), use_container_width=True, key=f"profile_card_date_{start_idx}_{position}_{column}")
                        else:
                            top_values = series.astype("string").fillna("<Missing>").value_counts(dropna=False).head(10).reset_index()
                            top_values.columns = ["Value", "Count"]
                            st.dataframe(top_values, use_container_width=True, hide_index=True)
                            plot_chart(px.bar(top_values, x="Count", y="Value", orientation="h"), use_container_width=True, key=f"profile_card_cat_{start_idx}_{position}_{column}")

    st.markdown("#### Outlier and anomaly detection")
    profile_columns = list(profile.columns)
    if not profile_columns:
        st.info("No columns are available for anomaly detection.")
    else:
        anomaly_col = st.selectbox("Column of any type", profile_columns, key=f"profile_anomaly_col_{profile_name}_{profile_revision}")
        anomaly_semantic = infer_semantic_type(profile[anomaly_col])
        if anomaly_semantic in {"numerical", "numeric-like text"}:
            numeric_series = safe_numeric_series(profile[anomaly_col])
            method = st.radio("Method", ["IQR", "Z-score"], horizontal=True, key=f"profile_outlier_method_{profile_name}_{profile_revision}")
            if method == "IQR":
                mask = outlier_mask_iqr(numeric_series)
                detail = "Outside Q1 − 1.5×IQR or Q3 + 1.5×IQR"
            else:
                std = numeric_series.std(ddof=0)
                z = (numeric_series - numeric_series.mean()) / std if pd.notna(std) and std != 0 else pd.Series(0, index=numeric_series.index)
                mask = z.abs() > 3
                detail = "Absolute Z-score greater than 3"
            st.metric("Outlier rows", f"{int(mask.sum()):,}")
            st.caption(detail)
            plot_chart(px.box(y=numeric_series, points="outliers", title=f"Outliers: {anomaly_col}"), use_container_width=True)
            st.dataframe(profile.loc[mask].head(1000), use_container_width=True, hide_index=True)
        elif anomaly_semantic in {"datetime", "date-like text"}:
            parsed = safe_datetime_series(profile[anomaly_col])
            invalid = parsed.isna() & profile[anomaly_col].notna()
            st.metric("Invalid date values", f"{int(invalid.sum()):,}")
            st.dataframe(profile.loc[invalid].head(1000), use_container_width=True, hide_index=True)
        else:
            frequency = profile[anomaly_col].astype("string").fillna("<Missing>").value_counts(dropna=False)
            threshold = st.slider("Rare-value threshold", 1, 100, 5, key=f"profile_rare_threshold_{profile_name}_{profile_revision}", help="Values occurring at or below this count are treated as rare anomalies.")
            rare_values = frequency[frequency <= threshold].index
            mask = profile[anomaly_col].astype("string").fillna("<Missing>").isin(rare_values)
            st.metric("Rare/anomalous rows", f"{int(mask.sum()):,}")
            st.dataframe(frequency.rename("count").reset_index().rename(columns={"index":"value"}), use_container_width=True, hide_index=True)
            st.dataframe(profile.loc[mask].head(1000), use_container_width=True, hide_index=True)


def wilson_interval(successes: int, total: int) -> tuple[float, float]:
    """Return the notebook-equivalent 95% Wilson score interval."""
    if total == 0:
        return np.nan, np.nan
    z = 1.959963984540054
    p = successes / total
    denominator = 1 + (z * z / total)
    center = (p + z * z / (2 * total)) / denominator
    margin = (
        z
        * math.sqrt((p * (1 - p) + z * z / (4 * total)) / total)
        / denominator
    )
    return center - margin, center + margin



def normalize_target_text(value: Any) -> str:
    if _safe_scalar_missing(value):
        return ""
    return str(value).strip()


def parse_ordinal_mapping(mapping_text: str) -> dict[str, float]:
    mapping: dict[str, float] = {}
    for item in str(mapping_text or "").split(","):
        item = item.strip()
        if not item:
            continue
        if ":" not in item:
            raise ValueError(f"Invalid ordinal mapping '{item}'. Use Class:order, for example Low:1, Medium:2, High:3.")
        label, order = item.split(":", 1)
        label = label.strip()
        if not label:
            raise ValueError("Ordinal class labels cannot be blank.")
        try:
            numeric_order = float(order.strip())
        except Exception as exc:
            raise ValueError(f"Ordinal order for '{label}' must be numeric.") from exc
        if not np.isfinite(numeric_order):
            raise ValueError(f"Ordinal order for '{label}' must be finite.")
        mapping[label.casefold()] = numeric_order
    if len(mapping) < 2:
        raise ValueError("Ordinal analysis requires mappings for at least two classes.")
    return mapping


def prepare_target_analysis(
    source_data: pd.DataFrame,
    target_column: str,
    target_mode: str,
    positive_class: str = "",
    focus_class: str = "",
    target_classes: list[str] | None = None,
    ordinal_mapping_text: str = "",
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Create validated binary, one-vs-rest, multiclass, or ordinal targets."""
    if source_data is None or source_data.empty:
        raise ValueError("The selected source has no rows.")
    if target_column not in source_data.columns:
        raise ValueError("The selected target column is not present in the source.")
    valid = source_data[target_column].notna().fillna(False)
    work = source_data.loc[valid].copy()
    if work.empty:
        raise ValueError("No non-null target rows are available.")
    raw = work[target_column]
    mode = str(target_mode).strip().lower().replace("-", "_").replace(" ", "_")
    if mode in {"binary", "one_vs_rest"}:
        chosen = positive_class if mode == "binary" else focus_class
        if not str(chosen).strip():
            raise ValueError("Provide a positive/focus class value.")
        if pd.api.types.is_numeric_dtype(raw):
            try:
                chosen_value = pd.to_numeric(pd.Series([chosen]), errors="raise").iloc[0]
            except Exception as exc:
                raise ValueError("The selected class cannot be converted to the numeric target type.") from exc
            flag = raw.eq(chosen_value).fillna(False).astype(int)
        else:
            flag = raw.astype("string").fillna("").str.strip().str.casefold().eq(str(chosen).strip().casefold()).fillna(False).astype(int)
        if flag.nunique() < 2:
            raise ValueError("The selected class must have both matching and non-matching rows.")
        work["target_flag"] = flag.to_numpy()
        label = str(chosen).strip()
        info = {"mode": mode, "class_label": label, "classes": [label], "target_column": target_column}
    else:
        class_series = raw.map(normalize_target_text).astype(object)
        available = [x for x in pd.unique(class_series) if str(x).strip()]
        if mode == "multiclass":
            selected = [str(x).strip() for x in (target_classes or available) if str(x).strip()]
            if len(selected) < 2:
                raise ValueError("Multiclass analysis requires at least two selected classes.")
            selected_lookup = {x.casefold(): x for x in selected}
            canonical = class_series.map(lambda x: selected_lookup.get(str(x).casefold(), np.nan))
            keep = canonical.notna().fillna(False)
            work = work.loc[keep].copy()
            canonical = canonical.loc[keep]
            if canonical.nunique() < 2:
                raise ValueError("Fewer than two selected classes are present in the source.")
            work["target_class"] = canonical.to_numpy()
            classes = [x for x in selected if x in set(canonical)]
            info = {"mode": mode, "classes": classes, "target_column": target_column}
        elif mode == "ordinal":
            mapping = parse_ordinal_mapping(ordinal_mapping_text)
            canonical_labels = {key: normalize_target_text(label) for key, label in [(k, k) for k in mapping]}
            order = class_series.map(lambda x: mapping.get(str(x).casefold(), np.nan))
            keep = order.notna().fillna(False)
            work = work.loc[keep].copy()
            class_kept = class_series.loc[keep]
            order = order.loc[keep].astype(float)
            if class_kept.nunique() < 2:
                raise ValueError("Ordinal analysis requires at least two mapped classes present in the source.")
            work["target_class"] = class_kept.to_numpy()
            work["target_ordinal"] = order.to_numpy()
            ordered_pairs = sorted(((label, value) for label, value in zip(class_kept, order)), key=lambda x: x[1])
            classes = list(dict.fromkeys(label for label, _ in ordered_pairs))
            info = {"mode": mode, "classes": classes, "ordinal_mapping": mapping, "target_column": target_column}
        else:
            raise ValueError("Unsupported target mode.")
    return work, info


def target_distribution(work: pd.DataFrame, target_info: dict[str, Any]) -> pd.DataFrame:
    if target_info["mode"] in {"binary", "one_vs_rest"}:
        positives = int(work["target_flag"].sum())
        total = int(len(work))
        return pd.DataFrame([{"target_class": target_info["class_label"], "class_count": positives, "records": total, "class_rate": positives / total if total else np.nan}])
    counts = work["target_class"].value_counts(dropna=False).rename("class_count").reset_index().rename(columns={"index": "target_class"})
    counts["target_class"] = counts["target_class"].map(normalize_target_text)
    counts["records"] = len(work)
    counts["class_rate"] = counts["class_count"] / max(len(work), 1)
    return counts


def categorical_lift_summary(data: pd.DataFrame, feature: str, target_info: dict[str, Any]) -> pd.DataFrame:
    temp = pd.DataFrame({feature: data[feature].astype("string").fillna("UNKNOWN")}, index=data.index)
    if target_info["mode"] in {"binary", "one_vs_rest"}:
        temp["target_flag"] = data["target_flag"].astype(int).to_numpy()
        out = temp.groupby(feature, dropna=False)["target_flag"].agg(records="count", class_count="sum").reset_index()
        out["target_class"] = target_info["class_label"]
        out["global_class_rate"] = float(data["target_flag"].mean())
    else:
        temp["target_class"] = data["target_class"].map(normalize_target_text).to_numpy()
        out = temp.groupby([feature, "target_class"], dropna=False).size().rename("class_count").reset_index()
        support = temp.groupby(feature, dropna=False).size().rename("records").reset_index()
        out = out.merge(support, on=feature, how="left")
        rates = temp["target_class"].value_counts(normalize=True).to_dict()
        out["global_class_rate"] = out["target_class"].map(rates)
    out["class_rate"] = out["class_count"] / out["records"]
    out["lift"] = out["class_rate"] / out["global_class_rate"].clip(lower=1e-9)
    intervals = out.apply(lambda row: wilson_interval(int(row["class_count"]), int(row["records"])), axis=1)
    out["ci_low"] = [x[0] for x in intervals]
    out["ci_high"] = [x[1] for x in intervals]
    out["feature"] = feature
    out["value"] = out[feature].astype(str)
    return out[["feature", "value", "target_class", "records", "class_count", "class_rate", "global_class_rate", "lift", "ci_low", "ci_high"]]


def discretize_rule_numeric_features(data: pd.DataFrame, columns: list[str], max_bins: int = 5) -> tuple[pd.DataFrame, pd.DataFrame]:
    output = pd.DataFrame(index=data.index); metadata=[]
    for column in columns:
        series = pd.to_numeric(data[column], errors="coerce").replace([np.inf, -np.inf], np.nan)
        unique_count = int(series.nunique(dropna=True))
        if unique_count < 2: continue
        try:
            binned, edges = pd.qcut(series, q=min(max_bins, unique_count), duplicates="drop", retbins=True)
            output[f"{column}__bin"] = binned.astype("string").fillna("UNKNOWN")
            metadata.append({"feature": column, "binning": "quantile", "bins": int(len(edges)-1), "edges": edges.tolist()})
        except Exception:
            binned = pd.cut(series, bins=max_bins, duplicates="drop")
            output[f"{column}__bin"] = binned.astype("string").fillna("UNKNOWN")
            metadata.append({"feature": column, "binning": "equal_width_fallback", "bins": int(output[f"{column}__bin"].nunique()), "edges": None})
    return output, pd.DataFrame(metadata)


def prepare_combination_rule_frame(data: pd.DataFrame, target_info: dict[str, Any], numeric_columns: list[str], categorical_columns: list[str], top_n_categories: int = 20, max_numeric_bins: int = 5) -> tuple[pd.DataFrame, pd.DataFrame]:
    numeric_binned, meta = discretize_rule_numeric_features(data, numeric_columns, max_numeric_bins)
    frame = pd.DataFrame(index=data.index)
    for column in categorical_columns:
        values = data[column].astype("string").fillna("UNKNOWN")
        if values.nunique(dropna=True) > top_n_categories:
            top = values.value_counts().head(top_n_categories).index
            values = values.where(values.isin(top), "OTHER")
        frame[column] = values
    frame = pd.concat([frame, numeric_binned], axis=1)
    if target_info["mode"] in {"binary", "one_vs_rest"}:
        frame["target_flag"] = data["target_flag"].astype(int).to_numpy()
    else:
        frame["target_class"] = data["target_class"].map(normalize_target_text).to_numpy()
        if target_info["mode"] == "ordinal": frame["target_ordinal"] = pd.to_numeric(data["target_ordinal"], errors="coerce").to_numpy()
    return frame, meta


def mine_exhaustive_combinations(data: pd.DataFrame, target_info: dict[str, Any], max_len: int = 3, min_support: int = 20, min_pos: int = 5, min_confidence: float = .35, min_lift: float = 1.3) -> pd.DataFrame:
    excluded={"target_flag","target_class","target_ordinal"}; features=[c for c in data.columns if c not in excluded]; results=[]
    if target_info["mode"] in {"binary", "one_vs_rest"}:
        global_rates={target_info["class_label"]: float(data["target_flag"].mean())}
    else:
        global_rates=data["target_class"].value_counts(normalize=True).to_dict()
    for length in range(1, max_len+1):
        for cols in combinations(features, length):
            if target_info["mode"] in {"binary", "one_vs_rest"}:
                grouped=data.groupby(list(cols),dropna=False)["target_flag"].agg(records="count",class_count="sum").reset_index()
                grouped["target_class"]=target_info["class_label"]; grouped["global_class_rate"]=list(global_rates.values())[0]
            else:
                grouped=data.groupby(list(cols),dropna=False)["target_class"].value_counts().rename("class_count").reset_index()
                support=data.groupby(list(cols),dropna=False).size().rename("records").reset_index(); grouped=grouped.merge(support,on=list(cols)); grouped["global_class_rate"]=grouped["target_class"].map(global_rates)
            grouped["class_rate"]=grouped["class_count"]/grouped["records"]; grouped["lift"]=grouped["class_rate"]/grouped["global_class_rate"].clip(lower=1e-9)
            grouped=grouped[(grouped.records>=min_support)&(grouped.class_count>=min_pos)&(grouped.class_rate>=min_confidence)&(grouped.lift>=min_lift)]
            for _,row in grouped.iterrows():
                lo,hi=wilson_interval(int(row.class_count),int(row.records))
                results.append({"rule_length":length,"rule":" AND ".join(f"{c} = {row[c]}" for c in cols),"features":" | ".join(cols),"target_class":normalize_target_text(row.target_class),"records":int(row.records),"class_count":int(row.class_count),"class_rate":float(row.class_rate),"global_class_rate":float(row.global_class_rate),"lift":float(row.lift),"ci_low":lo,"ci_high":hi})
    cols=["rule_length","rule","features","target_class","records","class_count","class_rate","global_class_rate","lift","ci_low","ci_high","rule_score"]
    if not results:return pd.DataFrame(columns=cols)
    out=pd.DataFrame(results); out["rule_score"]=out.lift*out.class_rate*np.log1p(out.records)*np.sqrt(out.class_count)
    return out.sort_values(["rule_score","lift","records"],ascending=False).reset_index(drop=True)


def mine_fp_growth_associations(rule_frame: pd.DataFrame, target_info: dict[str, Any], min_support: float, min_confidence: float, min_lift: float, max_len: int) -> tuple[pd.DataFrame,pd.DataFrame]:
    excluded={"target_flag","target_class","target_ordinal"}; features=[c for c in rule_frame.columns if c not in excluded]
    output_cols=["rule","target_class","support","confidence","lift","leverage","conviction"]
    if rule_frame.empty or not features:return pd.DataFrame(columns=output_cols),pd.DataFrame()
    parts=[]
    for c in features:
        items=rule_frame[c].astype("string").fillna("UNKNOWN").map(lambda v:f"{c}={v}")
        parts.append(pd.get_dummies(items,prefix="",prefix_sep="").astype(bool))
    basket=pd.concat(parts,axis=1)
    if basket.shape[1] > 500:
        support = basket.mean(axis=0).sort_values(ascending=False)
        keep = support[support >= float(min_support)].head(500).index
        basket = basket.loc[:, keep]
    if basket.shape[1] == 0:
        return pd.DataFrame(columns=output_cols),pd.DataFrame()
    if target_info["mode"] in {"binary","one_vs_rest"}:
        name=f"TARGET={target_info['class_label']}"; basket[name]=rule_frame.target_flag.fillna(0).astype(bool).to_numpy(); target_items={name}
    else:
        td=pd.get_dummies(rule_frame.target_class.astype(str).map(lambda v:f"TARGET={v}"),prefix="",prefix_sep="").astype(bool); basket=pd.concat([basket,td],axis=1); target_items=set(td.columns)
    fi=fpgrowth(basket,min_support=float(min_support),use_colnames=True,max_len=int(max_len))
    if fi.empty:return pd.DataFrame(columns=output_cols),fi
    rules=mlxtend_association_rules(fi,metric="confidence",min_threshold=float(min_confidence))
    if rules.empty:return pd.DataFrame(columns=output_cols),fi
    rules=rules[rules.consequents.apply(lambda x:len(x)==1 and next(iter(x)) in target_items)].copy(); rules=rules[rules.lift>=float(min_lift)].copy()
    if rules.empty:return pd.DataFrame(columns=output_cols),fi
    rules["target_class"]=rules.consequents.apply(lambda x:next(iter(x)).replace("TARGET=","")); rules["rule"]=rules.antecedents.apply(lambda x:" AND ".join(sorted(x)))+" => TARGET="+rules.target_class
    return rules.sort_values(["lift","confidence","support"],ascending=False)[output_cols].reset_index(drop=True),fi


def _safe_scalar_missing(value: Any) -> bool:
    try:
        result=pd.isna(value)
        return bool(result) if isinstance(result,(bool,np.bool_)) else False
    except Exception:return False


def _clean_rule_value(value: Any) -> str:
    if _safe_scalar_missing(value):return "UNKNOWN"
    text=str(value).strip();return text if text else "UNKNOWN"


def apply_equality_rule(data: pd.DataFrame, rule: Any) -> pd.Series:
    mask=pd.Series(True,index=data.index,dtype=bool)
    if _safe_scalar_missing(rule) or not isinstance(rule,str) or not rule.strip():return pd.Series(False,index=data.index,dtype=bool)
    for condition in rule.split(" AND "):
        if " = " not in condition:return pd.Series(False,index=data.index,dtype=bool)
        feature,expected=condition.split(" = ",1);feature=feature.strip()
        if not feature or feature not in data.columns:return pd.Series(False,index=data.index,dtype=bool)
        actual=data[feature].astype("string").fillna("UNKNOWN").str.strip();mask=mask&actual.eq(expected.strip()).fillna(False)
    return mask.fillna(False).astype(bool)


def extract_decision_tree_rules(tree: DecisionTreeClassifier, feature_names: list[str]) -> pd.DataFrame:
    columns=["rule","weighted_records","predicted_target_class","predicted_class_rate","class_distribution"]
    if tree is None or not hasattr(tree,"tree_"):return pd.DataFrame(columns=columns)
    structure=tree.tree_; labels=[normalize_target_text(x) for x in tree.classes_]; output=[]
    def rec(node,conds):
        idx=structure.feature[node]
        if idx!=_tree.TREE_UNDEFINED:
            name=feature_names[idx] if 0<=idx<len(feature_names) else f"feature_{idx}";thr=float(structure.threshold[node]);rec(structure.children_left[node],conds+[f"{name} <= {thr:.4f}"]);rec(structure.children_right[node],conds+[f"{name} > {thr:.4f}"])
        else:
            counts=np.asarray(structure.value[node]).reshape(-1);total=float(np.nansum(counts));best=int(np.nanargmax(counts)) if counts.size else 0
            distribution=" | ".join(f"{labels[i]}:{float(counts[i]):.2f}" for i in range(min(len(labels),len(counts))))
            output.append({"rule":" AND ".join(conds) if conds else "ALL RECORDS","weighted_records":total,"predicted_target_class":labels[best] if labels else "","predicted_class_rate":float(counts[best]/total) if total else 0.0,"class_distribution":distribution})
    rec(0,[])
    return pd.DataFrame(output,columns=columns).sort_values(["predicted_class_rate","weighted_records"],ascending=False).reset_index(drop=True)


def finalize_rules_workflow(source_data: pd.DataFrame, target_config: dict[str,Any], combination_result: dict[str,Any]|None, tree_max_depth:int, tree_min_leaf:int, test_size:float, random_state:int) -> dict[str,Any]:
    warnings=[]; target_column=target_config["target_column"]
    work,target_info=prepare_target_analysis(source_data,target_column,target_config["mode"],target_config.get("positive_class",""),target_config.get("focus_class",""),target_config.get("target_classes"),target_config.get("ordinal_mapping_text",""))
    groups=classify_columns(work); date_cols=set(groups.get("datetime",[])); excluded={target_column,"target_flag","target_class","target_ordinal"}; features=[c for c in work.columns if c not in excluded and c not in date_cols]
    if not features:raise ValueError("No eligible model features remain after excluding target and date/time columns.")
    X=work[features].copy(); numeric=[c for c in features if pd.api.types.is_numeric_dtype(X[c])]; categorical=[c for c in features if c not in numeric]
    for c in numeric:X[c]=pd.to_numeric(X[c],errors="coerce").replace([np.inf,-np.inf],np.nan)
    for c in categorical:
        X[c]=X[c].map(lambda v: np.nan if _safe_scalar_missing(v) or not str(v).strip() else str(v).strip()).astype(object)
    y=work["target_flag"].astype(int) if target_info["mode"] in {"binary","one_vs_rest"} else work["target_class"].map(normalize_target_text)
    counts=y.value_counts(); n_classes=int(counts.size)
    if n_classes<2:raise ValueError("Model validation requires at least two target classes.")
    if int(counts.min())<2:raise ValueError("Each target class requires at least two rows for stratified validation.")
    transformers=[]
    if numeric:transformers.append(("num",Pipeline([("imp",SimpleImputer(strategy="median"))]),numeric))
    if categorical:transformers.append(("cat",Pipeline([("imp",SimpleImputer(strategy="most_frequent")),("enc",OneHotEncoder(handle_unknown="ignore",min_frequency=5))]),categorical))
    prep=ColumnTransformer(transformers,remainder="drop"); model=DecisionTreeClassifier(max_depth=int(tree_max_depth),min_samples_leaf=int(tree_min_leaf),class_weight="balanced",random_state=int(random_state));pipe=Pipeline([("prep",prep),("model",model)])
    X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=float(test_size),stratify=y,random_state=int(random_state));pipe.fit(X_train,y_train);pred=pipe.predict(X_test);proba=pipe.predict_proba(X_test);classes=[normalize_target_text(x) for x in pipe.named_steps["model"].classes_]
    report=pd.DataFrame(classification_report(y_test,pred,output_dict=True,zero_division=0)).T.reset_index(names="class");matrix=confusion_matrix(y_test,pred,labels=pipe.named_steps["model"].classes_);confusion=pd.DataFrame(matrix,index=[f"Actual {c}" for c in classes],columns=[f"Predicted {c}" for c in classes])
    roc_auc=np.nan;pr_auc=np.nan
    try:
        if n_classes==2:
            positive_proba=proba[:,1]; actual_binary=(pd.Series(y_test).reset_index(drop=True)==pipe.named_steps["model"].classes_[1]).astype(int);roc_auc=float(roc_auc_score(actual_binary,positive_proba));pr_auc=float(average_precision_score(actual_binary,positive_proba))
        else:
            y_bin=label_binarize(y_test,classes=pipe.named_steps["model"].classes_);roc_auc=float(roc_auc_score(y_bin,proba,multi_class="ovr",average="weighted"));pr_auc=float(average_precision_score(y_bin,proba,average="weighted"))
    except Exception as exc:warnings.append(f"Aggregate AUC metrics were unavailable: {exc}")
    names=list(pipe.named_steps["prep"].get_feature_names_out());tree_rules=extract_decision_tree_rules(pipe.named_steps["model"],names);tree_text=export_text(pipe.named_steps["model"],feature_names=names,decimals=3)
    if n_classes==2 and target_info["mode"] in {"binary","one_vs_rest"}:
        scored=pd.DataFrame({"actual":pd.Series(y_test).to_numpy(),"score":proba[:,1]});q=max(1,min(10,int(scored.score.nunique()),len(scored)))
        try:scored["risk_band"]=pd.qcut(scored.score,q=q,duplicates="drop").astype(str) if q>=2 else "D1"
        except Exception:scored["risk_band"]="D1"
        risk=scored.groupby("risk_band",dropna=False).agg(records=("actual","size"),class_count=("actual","sum"),average_score=("score","mean")).reset_index();risk["class_rate"]=risk.class_count/risk.records;risk["target_class"]=target_info["class_label"]
    else:
        rows=[];yt=pd.Series(y_test).reset_index(drop=True);pp=pd.Series(pred)
        for i,c in enumerate(classes):
            actual=yt.astype(str).eq(c); predicted=pp.astype(str).eq(c);correct=actual&predicted
            rows.append({"target_class":c,"actual_records":int(actual.sum()),"predicted_records":int(predicted.sum()),"correct_predictions":int(correct.sum()),"class_recall":float(correct.sum()/actual.sum()) if actual.sum() else np.nan,"class_precision":float(correct.sum()/predicted.sum()) if predicted.sum() else np.nan,"average_probability":float(proba[:,i].mean())})
        risk=pd.DataFrame(rows)
    combination_rules=pd.DataFrame();validated=pd.DataFrame()
    if isinstance(combination_result,dict) and isinstance(combination_result.get("rules"),pd.DataFrame):
        combination_rules=combination_result["rules"].copy();settings=combination_result.get("settings",{}) if isinstance(combination_result.get("settings",{}),dict) else {}
        num=[c for c in groups.get("numeric",[]) if c not in excluded];cat=[c for c in groups.get("categorical",[])+groups.get("boolean",[]) if c not in excluded]
        frame,_=prepare_combination_rule_frame(work,target_info,num,cat,int(settings.get("top_n_categories",20) or 20),int(settings.get("max_numeric_bins",5) or 5))
        train_idx,test_idx=train_test_split(frame.index,test_size=float(test_size),stratify=y,random_state=int(random_state));train_frame,test_frame=frame.loc[train_idx],frame.loc[test_idx]
        rows=[]
        for _,r in combination_rules.head(500).iterrows():
            cls=normalize_target_text(r.get("target_class",target_info.get("class_label","")));tm=apply_equality_rule(train_frame,r.get("rule"));em=apply_equality_rule(test_frame,r.get("rule"));trn=int(tm.sum());ten=int(em.sum())
            if target_info["mode"] in {"binary","one_vs_rest"}:ty=train_frame.target_flag.astype(int);ey=test_frame.target_flag.astype(int);tb=max(float(ty.mean()),1e-9);eb=max(float(ey.mean()),1e-9)
            else:ty=train_frame.target_class.astype(str).eq(cls).astype(int);ey=test_frame.target_class.astype(str).eq(cls).astype(int);tb=max(float(ty.mean()),1e-9);eb=max(float(ey.mean()),1e-9)
            trc=int(ty.loc[tm].sum()) if trn else 0;tec=int(ey.loc[em].sum()) if ten else 0;trr=trc/trn if trn else np.nan;ter=tec/ten if ten else np.nan
            rows.append({"rule":_clean_rule_value(r.get("rule")),"target_class":cls,"train_records":trn,"train_class_rate":trr,"train_lift":trr/tb if trn else np.nan,"test_records":ten,"test_class_count":tec,"test_class_rate":ter,"test_lift":ter/eb if ten else np.nan,"rate_drop":trr-ter if trn and ten else np.nan})
        validated=pd.DataFrame(rows).sort_values(["test_lift","test_records"],ascending=False,na_position="last") if rows else pd.DataFrame()
    else:warnings.append("Evaluate Combination Mining before finalization to include holdout-validated business rules.")
    final_rules=combination_rules.copy()
    if not final_rules.empty:
        if not validated.empty:final_rules=final_rules.merge(validated,on=["rule","target_class"],how="left")
        final_rules["recommended_action"]=final_rules["lift"].map(lambda x:"Enhanced validation / specialist review" if pd.notna(x) and x>=2 else ("Additional automated checks" if pd.notna(x) and x>=1.5 else "Monitor"));final_rules.insert(0,"rule_id",[f"R{i:04d}" for i in range(1,len(final_rules)+1)])
    ordinal_summary=pd.DataFrame()
    if target_info["mode"]=="ordinal":
        rows=[];rule_features=[c for c in frame.columns if c not in {"target_flag","target_class","target_ordinal"}] if 'frame' in locals() else [];portfolio=float(work.target_ordinal.mean())
        for length in range(1,min(3,len(rule_features))+1):
            for cols in combinations(rule_features,length):
                g=frame.groupby(list(cols),dropna=False).target_ordinal.agg(records="size",average_severity="mean",median_severity="median").reset_index();g=g[g.records>=20]
                for _,r in g.iterrows():rows.append({"rule_length":length,"rule":" AND ".join(f"{c} = {r[c]}" for c in cols),"records":int(r.records),"average_severity":float(r.average_severity),"median_severity":float(r.median_severity),"severity_index":float(r.average_severity/portfolio) if portfolio else np.nan})
        if rows:ordinal_summary=pd.DataFrame(rows).sort_values(["severity_index","records"],ascending=False)
    output=BytesIO()
    with pd.ExcelWriter(output,engine="openpyxl") as writer:
        tree_rules.to_excel(writer,sheet_name="Tree_Rules",index=False);report.to_excel(writer,sheet_name="Model_Metrics",index=False);confusion.to_excel(writer,sheet_name="Confusion_Matrix");risk.to_excel(writer,sheet_name="Model_Performance",index=False)
        if not validated.empty:validated.to_excel(writer,sheet_name="Validated_Rules",index=False)
        if not final_rules.empty:final_rules.to_excel(writer,sheet_name="Final_Business_Rules",index=False)
        if not ordinal_summary.empty:ordinal_summary.to_excel(writer,sheet_name="Ordinal_Severity_Rules",index=False)
    output.seek(0)
    return {"target_info":target_info,"tree_rules":tree_rules,"tree_text":tree_text,"classification_report":report,"confusion_matrix":confusion,"roc_auc":roc_auc,"pr_auc":pr_auc,"risk_bands":risk,"validated_rules":validated,"final_rules":final_rules,"ordinal_rules":ordinal_summary,"excel":output.getvalue(),"warnings":warnings,"train_rows":len(X_train),"test_rows":len(X_test),"features":len(names)}



def ml_prepare_unsupervised_frame(df: pd.DataFrame, features: list[str], max_rows: int, seed: int):
    work=df[features].copy()
    if len(work)>max_rows: work=work.sample(max_rows,random_state=seed)
    numeric=[c for c in features if pd.api.types.is_numeric_dtype(work[c])]
    categorical=[c for c in features if c not in numeric]
    transformers=[]
    if numeric: transformers.append(("num",Pipeline([("imputer",SimpleImputer(strategy="median")),("scale",StandardScaler())]),numeric))
    if categorical: transformers.append(("cat",Pipeline([("imputer",SimpleImputer(strategy="most_frequent")),("onehot",OneHotEncoder(handle_unknown="ignore",max_categories=50,sparse_output=False))]),categorical))
    if not transformers: raise ValueError("Select at least one usable feature.")
    pre=ColumnTransformer(transformers,remainder="drop")
    matrix=pre.fit_transform(work)
    return work,pre,np.asarray(matrix,dtype=float)


def ml_build_deployment_bundle(result: dict) -> bytes:
    metadata={"application":"Clarity","release":"v77","created_at":result.get("created_at"),"problem":result.get("problem"),"target":result.get("target"),"features":result.get("features",[]),"best_model":result.get("best_model_name")}
    script="""import joblib
import pandas as pd

MODEL_PATH = 'clarity_model.joblib'
artifact = joblib.load(MODEL_PATH)
model = artifact['pipeline'] if isinstance(artifact, dict) and 'pipeline' in artifact else artifact
features = artifact.get('features', []) if isinstance(artifact, dict) else []

def predict(records):
    frame = pd.DataFrame(records)
    missing = [column for column in features if column not in frame.columns]
    if missing:
        raise ValueError('Missing feature columns: ' + ', '.join(missing))
    model_input = frame[features] if features else frame
    output = frame.copy()
    output['Prediction'] = model.predict(model_input)
    if hasattr(model, 'predict_proba'):
        probabilities = model.predict_proba(model_input)
        for index, label in enumerate(model.classes_):
            output[f'Probability_{label}'] = probabilities[:, index]
    return output

if __name__ == '__main__':
    source = pd.read_csv('input.csv')
    predict(source).to_csv('predictions.csv', index=False)
"""
    api="""from fastapi import FastAPI
from pydantic import BaseModel
from typing import Any
from inference import predict

app = FastAPI(title='Clarity Model API')
class Request(BaseModel):
    records: list[dict[str, Any]]

@app.post('/predict')
def score(request: Request):
    return predict(request.records).to_dict(orient='records')
"""
    out=BytesIO()
    with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED) as z:
        z.writestr("clarity_model.joblib", result.get("model_bytes", b""))
        z.writestr("metadata.json", json.dumps(metadata, indent=2, default=str))
        z.writestr("inference.py", script)
        z.writestr("api.py", api)
        z.writestr("requirements.txt", "pandas\nscikit-learn\njoblib\nfastapi\nuvicorn\n")
        z.writestr("README.md", "# Clarity v77 deployment bundle\n\nRun `python inference.py` for batch scoring or `uvicorn api:app` for an API.\n")
    return out.getvalue()


if active_page == "Machine Learning":
    st.subheader("Machine Learning")
    st.caption("Enterprise AutoML with supervised learning, clustering, anomaly detection, forecasting, model registry, versioning, and deployment export.")
    ml_sources={dataset_1_name:df1}
    if df2 is not None: ml_sources[dataset_2_name]=df2
    if st.session_state.joined_data is not None: ml_sources["Joined data"]=st.session_state.joined_data
    if st.session_state.filtered_data is not None: ml_sources["Modified Dataset"]=st.session_state.filtered_data
    source_name=st.radio("Training source", ml_sources.keys(), horizontal=True, key="ml_source", help="Dataset used for model training, validation, and prediction schema.")
    ml_df=ml_sources[source_name]
    if ml_df is None or ml_df.empty:
        st.info("Select a non-empty dataset to begin AutoML.")
    else:
        st.markdown("#### Problem and features")
        c1,c2,c3=st.columns([1.4,1.2,1.4])
        target=c1.selectbox("Target column", list(ml_df.columns), key="ml_target", help="The value Clarity should learn to predict.")
        detected=ml_problem_type(ml_df[target])
        problem_options=["Regression","Binary Classification","Multiclass Classification"]
        problem=c2.selectbox("Problem type", problem_options, index=problem_options.index(detected) if detected in problem_options else 0, key="ml_problem", help="Automatically inferred from the target; override when business meaning requires it.")
        default_features=[c for c in ml_df.columns if c!=target]
        features=c3.multiselect("Feature columns", default_features, default=default_features, key="ml_features", help="Input columns available to the model. Remove IDs, leakage fields, and post-outcome information.")
        n1,n2,n3,n4,n5=st.columns(5)
        groups=classify_columns(ml_df[features]) if features else {"numeric":[],"categorical":[],"boolean":[],"datetime":[]}
        n1.metric("Rows",f"{len(ml_df):,}",help="Rows available before target cleaning and optional training sampling.")
        n2.metric("Features",len(features),help="Selected predictor columns.")
        n3.metric("Numeric",len(groups.get("numeric",[])),help="Selected features detected as numeric.")
        n4.metric("Categorical",len(groups.get("categorical",[]))+len(groups.get("boolean",[])),help="Selected categorical and Boolean features.")
        n5.metric("Target values",int(ml_df[target].nunique(dropna=True)),help="Distinct non-missing target values.")
        st.divider()
        st.markdown("#### AutoML configuration")
        catalog=list(ml_model_catalog(problem,42).keys())
        mode=st.radio("AutoML mode",["Quick","Balanced","Best Accuracy"],horizontal=True,key="ml_mode",help="Quick compares a compact set. Balanced compares all models. Best Accuracy also tunes supported algorithms.")
        defaults=catalog[:3] if mode=="Quick" else catalog
        selected_models=st.multiselect("Models",catalog,default=defaults,key=f"ml_models_{problem}",help="Algorithms included in the model comparison leaderboard.")
        a,b,c,d=st.columns(4)
        test_size=a.slider("Holdout fraction",0.10,0.40,0.20,0.05,key="ml_test_size",help="Rows reserved for independent model evaluation.")
        cv_folds=b.number_input("Cross-validation folds",2,10,5 if mode=="Best Accuracy" else 3,key="ml_cv",help="Repeated training folds used to estimate model stability.")
        max_rows=c.number_input("Maximum training rows",100,min(1000000,max(100,len(ml_df))),min(200000,max(100,len(ml_df))),1000,key="ml_max_rows",help="Caps training size for responsive execution; sampling is reproducible.")
        seed=d.number_input("Random seed",0,999999,42,key="ml_seed",help="Controls train-test split, sampling, tuning, and stochastic models.")
        tuning_enabled = mode=="Best Accuracy"
        tuning_iterations=12
        if tuning_enabled:
            t1,t2=st.columns([1,3])
            tuning_iterations=t1.slider("Tuning iterations",5,40,12,1,key="ml_tuning_iterations",help="Random hyperparameter combinations tested for each supported model.")
            t2.info("Best Accuracy mode performs randomized hyperparameter search and may take considerably longer than Quick or Balanced mode.")
        train_col,_=st.columns([.9,5])
        train_clicked=train_col.button("Train Models",type="primary",use_container_width=True,key="ml_train")
        if train_clicked:
            if not features: st.error("Select at least one feature column.")
            elif not selected_models: st.error("Select at least one model.")
            elif target in features: st.error("The target cannot also be a feature.")
            else:
                try:
                    with st.spinner("Preparing data, cross-validating models, tuning where enabled, and generating explanations..."):
                        result=ml_train_models(ml_df,target,features,problem,selected_models,float(test_size),int(seed),int(cv_folds),int(max_rows),tuning_enabled,int(tuning_iterations))
                    result["source_name"]=source_name; st.session_state["ml_result"]=result
                    history=st.session_state.setdefault("ml_experiment_history",[])
                    best_row=result["leaderboard"].query("Status == 'Completed'").loc[lambda x:x["Model"]==result["best_model_name"]].iloc[0].to_dict()
                    history.append({"Run":len(history)+1,"Created at":result["created_at"],"Source":source_name,"Target":target,"Problem":problem,"Mode":mode,"Best model":result["best_model_name"],"Primary score":best_row.get("RMSE",best_row.get("F1 Weighted",np.nan)),"Rows":result["rows"],"Features":len(features),"Tuned":tuning_enabled})
                    audit("AUTOML_V77_TRAINED",{"source":source_name,"target":target,"problem":problem,"mode":mode,"best_model":result["best_model_name"]})
                except Exception as exc: st.session_state.pop("ml_result",None); st.error(f"AutoML training could not complete: {exc}")
        result=st.session_state.get("ml_result")
        if isinstance(result,dict) and result.get("source_name")==source_name:
            st.divider(); st.markdown("#### 3. Model comparison")
            r1,r2,r3,r4,r5=st.columns(5)
            r1.metric("Best model",result["best_model_name"],help="Top holdout model ranked by RMSE for regression or weighted F1 for classification.")
            r2.metric("Training rows",f"{result['train_rows']:,}",help="Rows used to fit each model.")
            r3.metric("Holdout rows",f"{result['test_rows']:,}",help="Rows used only for final comparison.")
            r4.metric("Completed models",int((result["leaderboard"]["Status"]=="Completed").sum()),help="Models that trained successfully.")
            r5.metric("Explanation",result.get("explanation_method","Permutation importance"),help="Explainability methods successfully generated for the winning model.")
            st.dataframe(result["leaderboard"],use_container_width=True,hide_index=True)
            tabs=st.tabs(["Validation","Cross-validation","Explain AI","Tuning","Predict","Experiments","Explain Target","Export"])
            with tabs[0]:
                st.dataframe(result["validation"].head(2000),use_container_width=True,hide_index=True)
                if result["problem"]=="Regression":
                    st.plotly_chart(px.scatter(result["validation"],x="Actual",y="Predicted",title="Actual vs Predicted",trendline="ols"),use_container_width=True)
                    st.plotly_chart(px.scatter(result["validation"],x="Predicted",y="Residual",title="Residuals vs Predicted"),use_container_width=True)
                    st.plotly_chart(px.histogram(result["validation"],x="Residual",title="Residual distribution"),use_container_width=True)
                else:
                    cm=pd.crosstab(result["validation"]["Actual"],result["validation"]["Predicted"],rownames=["Actual"],colnames=["Predicted"]); st.dataframe(cm,use_container_width=True)
                    st.plotly_chart(px.imshow(cm,text_auto=True,aspect="auto",title="Confusion matrix"),use_container_width=True)
            with tabs[1]:
                cv=result.get("cv_details",pd.DataFrame())
                if cv.empty: st.info("Cross-validation diagnostics are unavailable.")
                else:
                    st.dataframe(cv,use_container_width=True,hide_index=True)
                    st.plotly_chart(px.box(cv,x="Model",y="Validation score",points="all",title="Cross-validation stability"),use_container_width=True)
                    cv_summary=cv.groupby("Model")["Validation score"].agg(["mean","std","min","max"]).reset_index(); st.dataframe(cv_summary,use_container_width=True,hide_index=True)
            with tabs[2]:
                fi=result.get("feature_importance",pd.DataFrame()); pi=result.get("permutation_importance",pd.DataFrame()); shi=result.get("shap_importance",pd.DataFrame())
                explain_tabs=st.tabs(["Model importance","Permutation importance","SHAP"])
                with explain_tabs[0]:
                    if fi.empty: st.info("Native model importance is unavailable for this estimator.")
                    else: st.dataframe(fi,use_container_width=True,hide_index=True); st.plotly_chart(px.bar(fi.head(25).sort_values("Importance"),x="Importance",y="Feature",orientation="h",title="Native model importance"),use_container_width=True)
                with explain_tabs[1]:
                    if pi.empty: st.info("Permutation importance could not be generated.")
                    else: st.dataframe(pi,use_container_width=True,hide_index=True); st.plotly_chart(px.bar(pi.head(25).sort_values("Importance"),x="Importance",y="Feature",orientation="h",error_x="Std Dev",title="Permutation importance"),use_container_width=True)
                with explain_tabs[2]:
                    if shi.empty: st.info("SHAP is unavailable for this model or dataset shape. Permutation importance remains available.")
                    else: st.dataframe(shi,use_container_width=True,hide_index=True); st.plotly_chart(px.bar(shi.head(25).sort_values("Mean Absolute SHAP"),x="Mean Absolute SHAP",y="Feature",orientation="h",title="Global SHAP importance"),use_container_width=True)
            with tabs[3]:
                tuning=result.get("tuning_details",pd.DataFrame())
                if tuning.empty: st.info("No hyperparameter tuning was performed. Select Best Accuracy mode to tune supported models.")
                else: st.dataframe(tuning,use_container_width=True,hide_index=True)
            with tabs[4]:
                st.markdown("##### Single-record prediction")
                values={}; input_cols=st.columns(3)
                for i,col in enumerate(result["features"]):
                    series=ml_df[col]
                    with input_cols[i%3]:
                        if pd.api.types.is_numeric_dtype(series): values[col]=st.number_input(col,value=float(pd.to_numeric(series,errors="coerce").median()) if pd.to_numeric(series,errors="coerce").notna().any() else 0.0,key=f"ml_pred_{col}")
                        else:
                            opts=series.dropna().astype(str).value_counts().head(100).index.tolist() or [""]; values[col]=st.selectbox(col,opts,key=f"ml_pred_{col}")
                if st.button("Predict",key="ml_single_predict"):
                    one=pd.DataFrame([values]); pred=result["best_pipeline"].predict(one)[0]; st.success(f"Prediction: {pred}")
                    if result["problem"]!="Regression" and hasattr(result["best_pipeline"],"predict_proba"):
                        probs=result["best_pipeline"].predict_proba(one)[0]; labels=result["best_pipeline"].classes_; st.dataframe(pd.DataFrame({"Class":labels,"Probability":probs}).sort_values("Probability",ascending=False),hide_index=True,use_container_width=True)
                st.markdown("##### Batch prediction")
                batch=st.file_uploader("Upload CSV for batch scoring",type=["csv"],key="ml_batch_file",help="CSV must contain the same feature columns used during training.")
                if batch is not None:
                    batch_df=pd.read_csv(batch); missing=[c for c in result["features"] if c not in batch_df.columns]
                    if missing: st.error("Missing feature columns: "+", ".join(missing))
                    else:
                        scored=batch_df.copy(); scored["Prediction"]=result["best_pipeline"].predict(batch_df[result["features"]])
                        if result["problem"]!="Regression" and hasattr(result["best_pipeline"],"predict_proba"):
                            probs=result["best_pipeline"].predict_proba(batch_df[result["features"]])
                            for idx,label in enumerate(result["best_pipeline"].classes_): scored[f"Probability_{label}"]=probs[:,idx]
                        st.dataframe(scored.head(500),use_container_width=True,hide_index=True); st.download_button("Download predictions",scored.to_csv(index=False).encode(),"clarity_predictions.csv","text/csv",key="ml_download_predictions")
            with tabs[5]:
                history=pd.DataFrame(st.session_state.get("ml_experiment_history",[]))
                if history.empty: st.info("No experiments have been recorded in this session.")
                else:
                    st.dataframe(history.sort_values("Run",ascending=False),use_container_width=True,hide_index=True)
                    st.download_button("Download experiment history",history.to_csv(index=False).encode(),"clarity_experiment_history.csv","text/csv",key="ml_download_history")
                if st.button("Clear experiment history",key="ml_clear_history"): st.session_state["ml_experiment_history"]=[]; st.rerun()
            with tabs[6]:
                st.markdown("##### Explain Target")
                st.caption("Rank the strongest factors influencing the trained target and translate the model evidence into business-readable findings.")
                et1,et2=st.columns([1,2])
                max_explain_factors=max(1,min(25,len(result.get("features",[]))))
                explain_top_n=et1.slider("Number of factors",1,max_explain_factors,min(10,max_explain_factors),1,key="ml_explain_target_top_n",disabled=max_explain_factors==1)
                et2.info("The ranking prioritizes permutation importance when available, then adds observed direction using Spearman correlation for numeric regression features or target averages for categorical features.")
                if st.button("Explain Target",type="primary",key="ml_explain_target_button"):
                    try:
                        st.session_state["ml_target_explanation"]=ml_build_target_explanation(result,ml_df,int(explain_top_n))
                        audit("AUTOML_EXPLAIN_TARGET",{"target":result.get("target"),"model":result.get("best_model_name"),"top_n":int(explain_top_n)})
                    except Exception as exc:
                        st.session_state.pop("ml_target_explanation",None)
                        st.error(f"Target explanation could not be generated: {exc}")
                target_explanation=st.session_state.get("ml_target_explanation")
                if isinstance(target_explanation,dict) and target_explanation.get("target")==result.get("target") and target_explanation.get("model")==result.get("best_model_name") and target_explanation.get("created_at")==result.get("created_at"):
                    factors=target_explanation.get("factors",pd.DataFrame())
                    st.success(target_explanation.get("narrative","Target explanation generated."))
                    if not factors.empty:
                        st.dataframe(factors,use_container_width=True,hide_index=True)
                        st.plotly_chart(px.bar(factors.sort_values("Relative importance %"),x="Relative importance %",y="Feature",orientation="h",title=f"Top factors influencing {result.get('target','target')}",hover_data=["Observed direction","Interpretation"]),use_container_width=True)
                        st.markdown("##### Factor-by-factor interpretation")
                        for _,factor in factors.head(10).iterrows():
                            st.markdown(f"**{int(factor['Rank'])}. {factor['Feature']} — {factor['Observed direction']}**  ")
                            st.write(factor["Interpretation"])
                        report_lines=[f"Explain Target: {result.get('target','')}",f"Winning model: {result.get('best_model_name','')}",f"Importance method: {target_explanation.get('method','')}","",target_explanation.get("narrative",""),"","Ranked factors:"]
                        for _,factor in factors.iterrows():
                            report_lines.append(f"{int(factor['Rank'])}. {factor['Feature']} | Relative importance: {factor['Relative importance %']:.2f}% | {factor['Observed direction']} | {factor['Interpretation']}")
                        st.download_button("Download target explanation","\n".join(report_lines).encode("utf-8"),"clarity_target_explanation.txt","text/plain",key="ml_download_target_explanation")
                        st.download_button("Download factor ranking",factors.to_csv(index=False).encode(),"clarity_target_factor_ranking.csv","text/csv",key="ml_download_target_factors")
            with tabs[7]:
                st.download_button("Download trained model",result["model_bytes"],"clarity_automl_model.joblib","application/octet-stream",key="ml_download_model")
                st.download_button("Download leaderboard",result["leaderboard"].to_csv(index=False).encode(),"clarity_model_leaderboard.csv","text/csv",key="ml_download_leaderboard")
                st.download_button("Download validation predictions",result["validation"].to_csv(index=False).encode(),"clarity_validation_predictions.csv","text/csv",key="ml_download_validation")
                st.download_button("Download cross-validation results",result.get("cv_details",pd.DataFrame()).to_csv(index=False).encode(),"clarity_cross_validation.csv","text/csv",key="ml_download_cv")
                if not result.get("permutation_importance",pd.DataFrame()).empty: st.download_button("Download permutation importance",result["permutation_importance"].to_csv(index=False).encode(),"clarity_permutation_importance.csv","text/csv",key="ml_download_pi")
                if not result.get("shap_importance",pd.DataFrame()).empty: st.download_button("Download SHAP importance",result["shap_importance"].to_csv(index=False).encode(),"clarity_shap_importance.csv","text/csv",key="ml_download_shap")

        st.divider()
        st.markdown("#### Enterprise AI Lab")
        st.caption("Clustering, anomaly detection, forecasting, registry, versioning, and deployment packaging.")
        enterprise_tabs=st.tabs(["Clustering","Anomaly Detection","Forecasting","Model Registry"])
        with enterprise_tabs[0]:
            cluster_features=st.multiselect("Clustering features",[c for c in ml_df.columns if c!=target],default=features[:min(8,len(features))],key="v77_cluster_features")
            ca,cb,cc=st.columns(3);cluster_method=ca.selectbox("Algorithm",["K-Means","Gaussian Mixture","Agglomerative","DBSCAN"],key="v77_cluster_method");cluster_count=cb.slider("Clusters",2,12,4,key="v77_cluster_count",disabled=cluster_method=="DBSCAN");cluster_rows=cc.number_input("Maximum rows",500,200000,min(50000,max(500,len(ml_df))),500,key="v77_cluster_rows")
            if st.button("Run Clustering",key="v77_run_cluster"):
                try:
                    raw,pre,matrix=ml_prepare_unsupervised_frame(ml_df,cluster_features,int(cluster_rows),int(seed))
                    if cluster_method=="K-Means": labels=KMeans(n_clusters=int(cluster_count),random_state=int(seed),n_init="auto").fit_predict(matrix)
                    elif cluster_method=="Gaussian Mixture": labels=GaussianMixture(n_components=int(cluster_count),random_state=int(seed)).fit_predict(matrix)
                    elif cluster_method=="Agglomerative": labels=AgglomerativeClustering(n_clusters=int(cluster_count)).fit_predict(matrix)
                    else: labels=DBSCAN(eps=.8,min_samples=5).fit_predict(matrix)
                    scored=raw.copy();scored["Cluster"]=labels;valid=labels>=0;sil=float(silhouette_score(matrix[valid],labels[valid])) if valid.sum()>2 and len(set(labels[valid]))>1 else np.nan;pca=PCA(n_components=2,random_state=int(seed)).fit_transform(matrix);plot=pd.DataFrame({"PCA 1":pca[:,0],"PCA 2":pca[:,1],"Cluster":labels.astype(str)});st.session_state["v77_cluster_result"]={"data":scored,"plot":plot,"silhouette":sil}
                except Exception as exc: st.error(f"Clustering could not complete: {exc}")
            cluster_result=st.session_state.get("v77_cluster_result")
            if cluster_result:
                q1,q2,q3=st.columns(3);q1.metric("Rows clustered",f"{len(cluster_result['data']):,}");q2.metric("Clusters",cluster_result['data']['Cluster'].nunique());q3.metric("Silhouette",f"{cluster_result['silhouette']:.4f}" if pd.notna(cluster_result['silhouette']) else "N/A");st.plotly_chart(px.scatter(cluster_result["plot"],x="PCA 1",y="PCA 2",color="Cluster",title="Cluster projection"),use_container_width=True);st.dataframe(cluster_result["data"].head(1000),use_container_width=True,hide_index=True);st.download_button("Download clustered data",cluster_result["data"].to_csv(index=False).encode(),"clarity_clusters.csv","text/csv",key="v77_download_clusters")
        with enterprise_tabs[1]:
            anomaly_features=st.multiselect("Anomaly features",[c for c in ml_df.columns if c!=target],default=features[:min(8,len(features))],key="v77_anomaly_features")
            aa,ab=st.columns(2);contamination=aa.slider("Expected anomaly rate",0.001,0.20,0.02,0.001,key="v77_contamination");anomaly_rows=ab.number_input("Maximum rows",500,500000,min(100000,max(500,len(ml_df))),500,key="v77_anomaly_rows")
            if st.button("Detect Anomalies",key="v77_run_anomaly"):
                try:
                    raw,pre,matrix=ml_prepare_unsupervised_frame(ml_df,anomaly_features,int(anomaly_rows),int(seed));model=IsolationForest(contamination=float(contamination),random_state=int(seed),n_jobs=-1);flag=model.fit_predict(matrix);score=-model.score_samples(matrix);out=raw.copy();out["Anomaly_Score"]=score;out["Is_Anomaly"]=flag==-1;st.session_state["v77_anomaly_result"]=out.sort_values("Anomaly_Score",ascending=False)
                except Exception as exc: st.error(f"Anomaly detection could not complete: {exc}")
            anomaly_result=st.session_state.get("v77_anomaly_result")
            if isinstance(anomaly_result,pd.DataFrame):
                a1,a2=st.columns(2);a1.metric("Analysed rows",f"{len(anomaly_result):,}");a2.metric("Anomalies",f"{int(anomaly_result['Is_Anomaly'].sum()):,}");st.dataframe(anomaly_result.head(1000),use_container_width=True,hide_index=True);st.download_button("Download anomaly results",anomaly_result.to_csv(index=False).encode(),"clarity_anomalies.csv","text/csv",key="v77_download_anomalies")
        with enterprise_tabs[2]:
            date_candidates=[c for c in ml_df.columns if pd.api.types.is_datetime64_any_dtype(ml_df[c]) or ml_df[c].dtype==object];numeric_candidates=[c for c in ml_df.columns if pd.api.types.is_numeric_dtype(ml_df[c])]
            if not date_candidates or not numeric_candidates: st.info("Forecasting requires a date-like column and a numeric value column.")
            else:
                fa,fb,fc,fd=st.columns(4);date_col=fa.selectbox("Date column",date_candidates,key="v77_date_col");value_col=fb.selectbox("Value column",numeric_candidates,key="v77_value_col");freq=fc.selectbox("Frequency",["D","W","M","Q"],index=2,key="v77_freq");horizon=fd.number_input("Forecast periods",1,60,12,key="v77_horizon");forecast_model=st.selectbox("Forecast model",["Exponential Smoothing","SARIMA"],key="v77_forecast_model")
                if st.button("Generate Forecast",key="v77_run_forecast"):
                    try:
                        temp=ml_df[[date_col,value_col]].copy();temp[date_col]=pd.to_datetime(temp[date_col],errors="coerce");temp[value_col]=pd.to_numeric(temp[value_col],errors="coerce");series=temp.dropna().set_index(date_col)[value_col].resample(freq).sum().sort_index()
                        if len(series)<8: raise ValueError("At least eight aggregated time periods are required.")
                        seasonal=max(2,12 if freq=="M" else 4 if freq=="Q" else 7)
                        if forecast_model=="Exponential Smoothing": fitted=ExponentialSmoothing(series,trend="add",seasonal="add" if len(series)>=seasonal*2 else None,seasonal_periods=seasonal if len(series)>=seasonal*2 else None).fit(optimized=True);pred=fitted.forecast(int(horizon))
                        else: fitted=SARIMAX(series,order=(1,1,1),seasonal_order=(1,0,0,seasonal) if len(series)>=seasonal*2 else (0,0,0,0),enforce_stationarity=False,enforce_invertibility=False).fit(disp=False);pred=fitted.forecast(int(horizon))
                        hist=pd.DataFrame({"Date":series.index,"Actual":series.values,"Forecast":np.nan});future=pd.DataFrame({"Date":pred.index,"Actual":np.nan,"Forecast":pred.values});st.session_state["v77_forecast_result"]=pd.concat([hist,future],ignore_index=True)
                    except Exception as exc: st.error(f"Forecasting could not complete: {exc}")
                forecast_result=st.session_state.get("v77_forecast_result")
                if isinstance(forecast_result,pd.DataFrame): st.plotly_chart(px.line(forecast_result,x="Date",y=["Actual","Forecast"],title="Historical values and forecast"),use_container_width=True);st.dataframe(forecast_result.tail(int(horizon)+20),use_container_width=True,hide_index=True);st.download_button("Download forecast",forecast_result.to_csv(index=False).encode(),"clarity_forecast.csv","text/csv",key="v77_download_forecast")
        with enterprise_tabs[3]:
            registry=st.session_state.setdefault("ml_model_registry",[])
            if isinstance(result,dict) and result.get("source_name")==source_name:
                ra,rb,rc=st.columns([2,1,1]);model_name=ra.text_input("Registered model name",value=f"{target}_{result['best_model_name']}",key="v77_registry_name");version=rb.text_input("Version",value=f"1.{len(registry)}.0",key="v77_registry_version");stage=rc.selectbox("Stage",["Development","Staging","Production","Archived"],key="v77_registry_stage")
                if st.button("Register Current Model",key="v77_register_model"): registry.append({"Name":model_name,"Version":version,"Stage":stage,"Created at":datetime.now(timezone.utc).isoformat(),"Target":target,"Problem":problem,"Algorithm":result["best_model_name"],"Rows":result["rows"],"Features":len(result["features"])});st.session_state["ml_model_registry"]=registry;st.success(f"Registered {model_name} version {version}.")
                st.download_button("Download Deployment Bundle",ml_build_deployment_bundle(result),"clarity_v77_deployment_bundle.zip","application/zip",key="v77_download_bundle")
            registry_df=pd.DataFrame(registry)
            if registry_df.empty: st.info("No models have been registered in this session.")
            else:
                st.dataframe(registry_df,use_container_width=True,hide_index=True);st.download_button("Download Registry",registry_df.to_csv(index=False).encode(),"clarity_model_registry.csv","text/csv",key="v77_download_registry")
                if st.button("Clear Registry",key="v77_clear_registry"): st.session_state["ml_model_registry"]=[];st.rerun()

if active_page == "Data Mining":
    st.subheader("Exploratory Data Analysis")
    explore_options = {dataset_1_name: df1}
    if df2 is not None:
        explore_options[dataset_2_name] = df2
    if st.session_state.joined_data is not None:
        explore_options["Joined data"] = st.session_state.joined_data
    if st.session_state.filtered_data is not None:
        explore_options["Modified Dataset"] = st.session_state.filtered_data
    explore_source_name = st.radio("Profile source", explore_options.keys(), horizontal=True, key="explore_profile_source", help="Choose the dataset that will be used by every Data Mining evaluation.")
    eda_df = explore_options[explore_source_name]
    perf1, perf2, perf3 = st.columns([1.2, 1.2, 2.6], vertical_alignment="bottom")
    explore_execution_mode = perf1.selectbox("Execution mode", ["Fast", "Full"], key="eda_execution_mode", help="Fast mode uses a representative sample for interactive analysis. Full mode scans all rows.")
    explore_max_rows = perf2.number_input("Fast-mode rows", min_value=10000, max_value=1000000, value=100000, step=10000, key="eda_fast_max_rows", disabled=explore_execution_mode == "Full", help="Maximum number of rows used in Fast mode. A smaller value executes faster; Full mode ignores this setting.")
    explore_seed = perf3.number_input("Sampling seed", min_value=0, max_value=999999, value=42, step=1, key="eda_sampling_seed", disabled=explore_execution_mode == "Full", help="Controls reproducible sampling. Reusing the same seed produces the same Fast-mode sample.")
    if eda_df is not None and not eda_df.empty:
        explore_sig = dataframe_signature(eda_df)
        analysis_df = eda_df if explore_execution_mode == "Full" else sampled_explore_frame(eda_df, int(explore_max_rows), int(explore_seed), explore_sig)
        if len(analysis_df) < len(eda_df):
            st.info(f"Fast mode is analysing {len(analysis_df):,} of {len(eda_df):,} rows. Final rule validation can be rerun in Full mode.")
    else:
        analysis_df = eda_df
    if eda_df is None or eda_df.empty:
        st.info("Run the join first. EDA uses the modified dataset when available; otherwise it uses the complete joined data.")
    else:
        groups = classify_columns(analysis_df)
        all_columns = list(eda_df.columns)
        numerical_cols = groups["numeric"]
        categorical_cols = groups["categorical"] + groups["boolean"]
        datetime_cols = groups["datetime"]

        st.markdown("#### Descriptive analysis for all features")
        d1, d2, d3, d4 = st.columns(4)
        d1.metric("All features", len(all_columns), help="Total number of columns in the selected Data Mining dataset.")
        d2.metric("Numeric / numeric-like", len(numerical_cols), help="Columns detected as numeric or reliably convertible to numeric values.")
        d3.metric("Categorical / boolean", len(categorical_cols), help="Columns treated as categories, labels, text groups, or Boolean values.")
        d4.metric("Date/time", len(datetime_cols), help="Columns detected as date or timestamp fields with sufficient parseable values.")
        st.dataframe(all_column_descriptive_summary(analysis_df), use_container_width=True, hide_index=True)

        control_result_key = "eda_control_selection_result"

        st.divider()
        st.markdown("#### Control Selection")
        mode_labels={"Binary":"binary","One vs Rest":"one_vs_rest","Multiclass":"multiclass","Ordinal":"ordinal"}
        c1,c2,c3=st.columns([1.5,1.2,2.2],vertical_alignment="bottom")
        target_column=c1.selectbox("Target column",all_columns,key="eda_control_target_column",help="Outcome column whose classes or ordered levels will be analysed.")
        target_mode_label=c2.selectbox("Target mode",list(mode_labels),key="eda_control_target_mode",help="Binary compares one positive class; One vs Rest isolates one class; Multiclass analyses several classes; Ordinal preserves class order.")
        target_mode=mode_labels[target_mode_label]
        available_classes=[normalize_target_text(x) for x in eda_df[target_column].dropna().unique() if normalize_target_text(x)]
        positive_class=focus_class="";target_classes=[];ordinal_mapping_text=""
        if target_mode=="binary":positive_class=c3.text_input("Positive class",key="eda_control_positive_class",help="Exact target value to treat as positive in Binary mode.")
        elif target_mode=="one_vs_rest":focus_class=c3.selectbox("Focus class",available_classes,key="eda_control_focus_class",help="Class to compare against all remaining classes.") if available_classes else ""
        elif target_mode=="multiclass":target_classes=c3.multiselect("Target classes",available_classes,default=available_classes,key="eda_control_target_classes",help="Classes to retain for multiclass evaluation. Unselected target values are excluded.")
        else:
            default_mapping=", ".join(f"{v}:{i+1}" for i,v in enumerate(available_classes));ordinal_mapping_text=c3.text_input("Ordinal mapping (Class:order)",value=default_mapping,key="eda_control_ordinal_mapping",help="Comma-separated class-to-rank mapping, for example Low:1, Medium:2, High:3.")
        _,eval_col=st.columns([4.5,.7],vertical_alignment="center");evaluate=eval_col.button("Evaluate",key="eda_control_evaluate",use_container_width=True)
        control_result_key="eda_control_selection_result"
        if evaluate:
            try:
                work,target_info=prepare_target_analysis(analysis_df,target_column,target_mode,positive_class,focus_class,target_classes,ordinal_mapping_text)
                config={"source":explore_source_name,"target_column":target_column,"mode":target_mode,"positive_class":positive_class,"focus_class":focus_class,"target_classes":target_classes,"ordinal_mapping_text":ordinal_mapping_text,"target_info":target_info,"distribution":target_distribution(work,target_info),"rows":len(work),"execution_mode":explore_execution_mode,"sample_rows":len(analysis_df),"source_rows":len(eda_df)}
                st.session_state[control_result_key]=config
                for key in ["eda_combination_mining_result","eda_association_mining_result","eda_finalize_rules_result"]:st.session_state.pop(key,None)
            except Exception as exc:st.session_state.pop(control_result_key,None);st.error(f"Control evaluation failed: {exc}")
        control=st.session_state.get(control_result_key)
        if isinstance(control,dict) and control.get("source")==explore_source_name:
            distribution=control["distribution"]
            m1,m2,m3=st.columns(3);m1.metric("Evaluated rows",f"{control['rows']:,}",help="Rows remaining after target validation, missing-target removal, and selected-class filtering.");m2.metric("Classes",f"{len(distribution):,}",help="Number of target classes included in the current evaluation.");m3.metric("Largest class rate",f"{distribution['class_rate'].max():.4f}",help="Share of evaluated rows belonging to the most frequent target class.")
            st.dataframe(distribution,use_container_width=True,hide_index=True,column_config={"class_rate":st.column_config.NumberColumn(format="%.4f")})

        st.divider()

        combination_header,combination_action=st.columns([4.5,.7],vertical_alignment="center");combination_header.markdown("#### Combination Mining");execute_combination=combination_action.button("Evaluate",key="eda_combination_execute",use_container_width=True)
        with st.expander("Combination Mining settings",expanded=False):
            a,b,c,d=st.columns(4);max_len=a.number_input("Maximum rule length",1,3,2,key="eda_combination_max_len",help="Maximum number of feature conditions allowed in one combination rule.");min_support=b.number_input("Minimum support count",1,1000000,20,key="eda_combination_min_support",help="Minimum number of rows that must satisfy a candidate rule.");min_class=c.number_input("Minimum class count",1,1000000,5,key="eda_combination_min_class",help="Minimum target-class rows required inside a candidate rule.");min_conf=d.number_input("Minimum confidence",0.0,1.0,.35,.05,key="eda_combination_min_conf",help="Minimum conditional class rate among rows matching the rule.")
            e,f,g,h=st.columns(4);min_lift=e.number_input("Minimum lift",0.0,100.0,1.3,.1,key="eda_combination_min_lift",help="Minimum ratio of rule class rate to the overall class rate. Values above 1 indicate enrichment.");top_n=f.number_input("Top categories per feature",2,100,20,key="eda_combination_top_n",help="Retains the most frequent categories and groups the remainder into OTHER.");max_bins=g.number_input("Maximum numeric bins",2,10,5,key="eda_combination_bins",help="Maximum quantile or fallback bins created for each numeric feature.");max_features=h.number_input("Maximum mining features",2,20,10,key="eda_combination_max_features",help="Limits the number of candidate features to control execution time and combination growth.")
        if execute_combination:
            if not isinstance(control,dict) or control.get("source")!=explore_source_name:st.warning("Evaluate Control Selection before combination mining.")
            else:
                try:
                    work,target_info=prepare_target_analysis(analysis_df,control["target_column"],control["mode"],control.get("positive_class",""),control.get("focus_class",""),control.get("target_classes"),control.get("ordinal_mapping_text",""));g=classify_columns(work);num=[x for x in g["numeric"] if x not in {control["target_column"],"target_ordinal","target_flag"}];cat=[x for x in g["categorical"]+g["boolean"] if x not in {control["target_column"],"target_class"} and work[x].nunique(dropna=True)<=100];selected=(cat+num)[:int(max_features)];cat=[x for x in selected if x in cat];num=[x for x in selected if x in num];estimated=candidate_combination_count(len(selected),int(max_len));
                    if estimated>50000:raise ValueError(f"Estimated candidate combinations ({estimated:,}) exceed the safe limit of 50,000. Reduce maximum mining features or rule length.")
                    frame,meta=prepare_combination_rule_frame(work,target_info,num,cat,int(top_n),int(max_bins));rules=mine_exhaustive_combinations(frame,target_info,int(max_len),int(min_support),int(min_class),float(min_conf),float(min_lift));st.session_state["eda_combination_mining_result"]={"source":explore_source_name,"rules":rules,"frame":frame,"bin_metadata":meta,"target_info":target_info,"settings":{"top_n_categories":int(top_n),"max_numeric_bins":int(max_bins)}}
                except Exception as exc:st.error(f"Combination mining could not complete: {exc}")
        cr=st.session_state.get("eda_combination_mining_result")
        if isinstance(cr,dict) and cr.get("source")==explore_source_name:
            combo_rules = cr.get("rules", pd.DataFrame())
            combo_frame = cr.get("frame", pd.DataFrame())
            combo_features = max(0, len(combo_frame.columns) - 1) if isinstance(combo_frame, pd.DataFrame) else 0
            cm1, cm2, cm3 = st.columns(3)
            cm1.metric("Rules discovered", f"{len(combo_rules):,}", help="Number of combination rules that passed all configured support, confidence, lift, and class-count thresholds.")
            cm2.metric("Rows prepared", f"{len(combo_frame):,}", help="Rows available in the prepared rule-mining frame after target and feature preparation.")
            cm3.metric("Mining features", f"{combo_features:,}", help="Prepared feature columns considered by combination mining, excluding the target column.")
            if combo_rules.empty:
                st.info("No combinations met the configured thresholds.")
            else:
                st.dataframe(combo_rules.head(1000),use_container_width=True,hide_index=True)
                st.download_button("Download combination rules",combo_rules.to_csv(index=False).encode(),"combination_rules.csv","text/csv",key="eda_download_combination_rules")

        st.divider()

        association_header,association_action=st.columns([4.5,.7],vertical_alignment="center");association_header.markdown("#### Association Mining");execute_association=association_action.button("Evaluate",key="eda_association_execute",use_container_width=True)
        with st.expander("Association Mining settings",expanded=False):
            a,b,c,d=st.columns(4);asup=a.number_input("Minimum support",0.001,1.0,.02,.01,key="eda_assoc_support",help="Minimum fraction of rows containing an itemset.");aconf=b.number_input("Minimum confidence",0.0,1.0,.35,.05,key="eda_assoc_conf",help="Minimum probability of the target class when the antecedent is present.");alift=c.number_input("Minimum lift",0.0,100.0,1.3,.1,key="eda_assoc_lift",help="Minimum improvement over the target class baseline rate.");alen=d.number_input("Maximum itemset length",2,10,4,key="eda_assoc_len",help="Maximum number of items allowed in a frequent itemset.")
        if execute_association:
            if not isinstance(control,dict) or control.get("source")!=explore_source_name:st.warning("Evaluate Control Selection before association mining.")
            else:
                try:
                    cr=st.session_state.get("eda_combination_mining_result")
                    if not isinstance(cr,dict) or cr.get("source")!=explore_source_name:
                        work,target_info=prepare_target_analysis(analysis_df,control["target_column"],control["mode"],control.get("positive_class",""),control.get("focus_class",""),control.get("target_classes"),control.get("ordinal_mapping_text",""));g=classify_columns(work);num=[x for x in g["numeric"] if x not in {control["target_column"],"target_ordinal","target_flag"}];cat=[x for x in g["categorical"]+g["boolean"] if x not in {control["target_column"],"target_class"}];frame,meta=prepare_combination_rule_frame(work,target_info,num,cat,20,5)
                    else:frame=cr["frame"];meta=cr["bin_metadata"];target_info=cr["target_info"]
                    rules,fi=mine_fp_growth_associations(frame,target_info,float(asup),float(aconf),float(alift),int(alen));st.session_state["eda_association_mining_result"]={"source":explore_source_name,"rules":rules,"frequent_itemsets":fi,"bin_metadata":meta,"target_info":target_info}
                except Exception as exc:st.error(f"Association mining could not complete: {exc}")
        ar=st.session_state.get("eda_association_mining_result")
        if isinstance(ar,dict) and ar.get("source")==explore_source_name:
            association_rules = ar.get("rules", pd.DataFrame())
            frequent_itemsets = ar.get("frequent_itemsets", pd.DataFrame())
            target_count = association_rules["target_class"].nunique() if isinstance(association_rules, pd.DataFrame) and "target_class" in association_rules.columns else 0
            am1, am2, am3 = st.columns(3)
            am1.metric("Association rules", f"{len(association_rules):,}", help="Number of target-predicting association rules that passed support, confidence, and lift thresholds.")
            am2.metric("Frequent itemsets", f"{len(frequent_itemsets):,}", help="Number of frequent itemsets found by FP-Growth before target-rule filtering.")
            am3.metric("Target classes", f"{target_count:,}", help="Distinct target classes predicted by the retained association rules.")
            if association_rules.empty:
                st.info("No class-target association rules met the thresholds.")
            else:
                st.dataframe(association_rules.head(1000),use_container_width=True,hide_index=True)
                st.download_button("Download association rules",association_rules.to_csv(index=False).encode(),"association_rules.csv","text/csv",key="eda_download_association_rules")

        st.divider()

        finalize_header,finalize_action=st.columns([4.5,.7],vertical_alignment="center");finalize_header.markdown("#### Finalize Rules");execute_finalize=finalize_action.button("Evaluate",key="eda_finalize_execute",use_container_width=True)
        with st.expander("Finalize Rules settings",expanded=False):
            a,b,c,d=st.columns(4);depth=a.number_input("Tree maximum depth",1,20,5,key="eda_finalize_depth",help="Maximum number of decision levels in the class-aware tree.");leaf=b.number_input("Minimum samples per leaf",1,10000,20,key="eda_finalize_leaf",help="Minimum observations required in each terminal decision-tree segment.");test=c.number_input("Holdout fraction",.10,.50,.25,.05,key="eda_finalize_test_size",help="Share of rows reserved for unbiased rule and model validation.");seed=d.number_input("Random seed",0,100000,42,key="eda_finalize_seed",help="Controls reproducible train/holdout splitting and model behaviour.")
        if execute_finalize:
            if not isinstance(control,dict) or control.get("source")!=explore_source_name:st.warning("Evaluate Control Selection before finalizing rules.")
            else:
                try:
                    with st.spinner("Training class-aware model and validating rules..."):result=finalize_rules_workflow(eda_df,control,st.session_state.get("eda_combination_mining_result"),int(depth),int(leaf),float(test),int(seed))
                    result.update({"source":explore_source_name,"target_column":control["target_column"],"mode":control["mode"]});st.session_state["eda_finalize_rules_result"]=result
                except Exception as exc:st.session_state.pop("eda_finalize_rules_result",None);st.error(f"Finalize Rules could not complete: {exc}")
        fr=st.session_state.get("eda_finalize_rules_result")
        if isinstance(fr,dict) and fr.get("source")==explore_source_name:
            for w in fr.get("warnings",[]):st.warning(w)
            m1,m2,m3,m4,m5=st.columns(5);m1.metric("Encoded features",fr["features"],help="Number of model-ready columns after imputation and categorical encoding.");m2.metric("Training rows",fr["train_rows"],help="Rows used to train the decision-tree validation model.");m3.metric("Holdout rows",fr["test_rows"],help="Rows withheld from training and used for independent validation.");m4.metric("ROC-AUC","N/A" if pd.isna(fr["roc_auc"]) else f"{fr['roc_auc']:.4f}",help="Area under the receiver operating characteristic curve. Higher values indicate better class ranking.");m5.metric("PR-AUC","N/A" if pd.isna(fr["pr_auc"]) else f"{fr['pr_auc']:.4f}",help="Area under the precision-recall curve, especially useful for imbalanced classes.")
            tabs=st.tabs(["Final business rules","Validated rules","Tree rules","Model performance","Model validation","Ordinal severity"])
            with tabs[0]:
                if not fr["final_rules"].empty:
                    st.dataframe(fr["final_rules"].head(500), use_container_width=True, hide_index=True)
                else:
                    st.info("Evaluate Combination Mining first or relax thresholds.")
            with tabs[1]:
                if not fr["validated_rules"].empty:
                    st.dataframe(fr["validated_rules"].head(500), use_container_width=True, hide_index=True)
                else:
                    st.info("No mined rules were available for holdout validation.")
            with tabs[2]:
                st.dataframe(fr["tree_rules"], use_container_width=True, hide_index=True)
            with tabs[3]:
                st.dataframe(fr["risk_bands"], use_container_width=True, hide_index=True)
            with tabs[4]:
                st.dataframe(fr["classification_report"], use_container_width=True, hide_index=True)
                st.dataframe(fr["confusion_matrix"], use_container_width=True)
            with tabs[5]:
                if not fr["ordinal_rules"].empty:
                    st.dataframe(fr["ordinal_rules"].head(500), use_container_width=True, hide_index=True)
                else:
                    st.info("Ordinal severity rules are generated only in Ordinal mode.")
            st.download_button("Download complete finalized-rules workbook",fr["excel"],"finalized_rules.xlsx","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",key="eda_download_finalize_workbook")

        st.divider()

        time_title_col, time_button_col = st.columns([4.5, .7], vertical_alignment="center")
        with time_title_col:
            st.markdown("#### Time-based analysis")
        with time_button_col:
            execute_time_analysis = st.button(
                "Evaluate", key="eda_execute_time_analysis", use_container_width=True
            )

        if not datetime_cols:
            st.info("No date/time column was detected with at least 90% parseable values.")
            st.session_state.pop("eda_time_analysis_result", None)
        else:
            t1, t2, t3 = st.columns(3)
            date_col = t1.selectbox("Date column", datetime_cols, key="eda_date", help="Date or timestamp field used to place records into time periods.")
            grain = t2.selectbox("Time grain", ["Daily", "Weekly", "Monthly", "Quarterly", "Yearly"], key="eda_grain", help="Calendar interval used to group the selected records.")
            measure = t3.selectbox("Measure (any column)", ["Row count"] + all_columns, key="eda_measure", help="Value to aggregate over time. Row count measures record volume.")
            aggregation_options = ["count", "nunique"] if measure == "Row count" or measure not in numerical_cols else ["sum", "mean", "median", "min", "max", "count", "nunique"]
            aggregation = st.selectbox("Aggregation", aggregation_options, key="eda_agg", help="Function used to summarize the selected measure within each time period.")

            if execute_time_analysis:
                try:
                    temp = analysis_df.copy()
                    temp["__date__"] = safe_datetime_series(temp[date_col])
                    temp = temp[temp["__date__"].notna()]
                    if temp.empty:
                        raise ValueError("No valid date/time values are available for the selected date column.")
                    freq = {"Daily":"D", "Weekly":"W", "Monthly":"MS", "Quarterly":"QS", "Yearly":"YS"}[grain]
                    if measure == "Row count":
                        trend = temp.set_index("__date__").resample(freq).size().rename("value").reset_index()
                    elif aggregation == "nunique":
                        trend = temp.set_index("__date__")[measure].resample(freq).nunique().rename("value").reset_index()
                    elif aggregation == "count":
                        trend = temp.set_index("__date__")[measure].resample(freq).count().rename("value").reset_index()
                    else:
                        temp["__measure__"] = safe_numeric_series(temp[measure])
                        trend = temp.set_index("__date__")["__measure__"].resample(freq).agg(aggregation).rename("value").reset_index()
                    trend["period_change_pct"] = trend["value"].pct_change() * 100
                    st.session_state.eda_time_analysis_result = {
                        "trend": trend,
                        "grain": grain,
                        "date_col": date_col,
                        "measure": measure,
                        "aggregation": aggregation,
                    }
                except Exception as exc:
                    st.session_state.pop("eda_time_analysis_result", None)
                    st.error(f"Time-based analysis could not complete: {exc}")

            time_result = st.session_state.get("eda_time_analysis_result")
            if time_result:
                trend = time_result["trend"]
                latest_value = trend["value"].dropna().iloc[-1] if not trend.empty and trend["value"].notna().any() else np.nan
                valid_periods = int(trend["value"].notna().sum()) if not trend.empty else 0
                tm1, tm2, tm3 = st.columns(3)
                tm1.metric("Time periods", f"{len(trend):,}", help="Number of calendar periods produced at the selected time grain.")
                tm2.metric("Periods with values", f"{valid_periods:,}", help="Number of generated periods containing a non-missing aggregated value.")
                tm3.metric("Latest value", "N/A" if pd.isna(latest_value) else f"{latest_value:,.4g}", help="Most recent non-missing aggregated value in the evaluated trend.")
                plot_chart(
                    px.line(
                        trend, x="__date__", y="value", markers=True,
                        title=f"{time_result['grain']} trend",
                    ),
                    use_container_width=True,
                )
                st.dataframe(trend.rename(columns={"__date__":"period"}), use_container_width=True, hide_index=True)
                st.caption(
                    f"Last executed for `{time_result['date_col']}` using "
                    f"`{time_result['aggregation']}` on `{time_result['measure']}`."
                )
            else:
                st.info("Select the time-analysis settings and click Evaluate to calculate the trend.")

        st.divider()

        corr_title_col, corr_button_col = st.columns([4.5, .7], vertical_alignment="center")
        with corr_title_col:
            st.markdown("#### Correlation and association analysis")
        with corr_button_col:
            execute_correlation_analysis = st.button(
                "Evaluate", key="eda_execute_correlation_analysis", use_container_width=True
            )
        selected_assoc = st.multiselect(
            "Select columns of any type", all_columns, default=all_columns[:15],
            key="eda_assoc", help="Choose 2 to 20 fields. Numeric, date, Boolean, and categorical fields are encoded appropriately for the selected methods."
        )
        selected_algorithms = st.multiselect(
            "Correlation algorithms", ["Pearson", "Spearman", "Kendall"],
            default=["Spearman"], key="eda_corr_algorithms", help="Pearson measures linear association; Spearman measures ranked monotonic association; Kendall measures ordinal concordance."
        )
        if execute_correlation_analysis:
            if len(selected_assoc) > 20:
                st.session_state.pop("eda_correlation_analysis_result", None)
                st.warning("Select no more than 20 columns for one correlation run.")
            elif len(selected_assoc) < 2:
                st.session_state.pop("eda_correlation_analysis_result", None)
                st.warning("Select at least two columns before executing correlation and association analysis.")
            elif not selected_algorithms:
                st.session_state.pop("eda_correlation_analysis_result", None)
                st.warning("Select at least one correlation algorithm before executing the analysis.")
            else:
                try:
                    calculated_matrices: dict[str, pd.DataFrame] = {}
                    for algorithm in selected_algorithms:
                        calculated_matrices[algorithm] = encoded_association(
                            analysis_df, selected_assoc, method=algorithm.lower()
                        )
                    st.session_state.eda_correlation_analysis_result = {
                        "matrices": calculated_matrices,
                        "columns": list(selected_assoc),
                        "algorithms": list(selected_algorithms),
                    }
                    st.session_state.eda_deep_dive_enabled = False
                except Exception as exc:
                    st.session_state.pop("eda_correlation_analysis_result", None)
                    st.error(f"Correlation and association analysis could not complete: {exc}")

        correlation_result = st.session_state.get("eda_correlation_analysis_result")
        if correlation_result:
            association_matrices: dict[str, pd.DataFrame] = correlation_result["matrices"]
            evaluated_columns = len(correlation_result.get("columns", []))
            algorithm_count = len(association_matrices)
            unique_pairs = evaluated_columns * (evaluated_columns - 1) // 2
            rm1, rm2, rm3 = st.columns(3)
            rm1.metric("Columns evaluated", f"{evaluated_columns:,}", help="Number of selected columns included in the correlation and association matrices.")
            rm2.metric("Algorithms", f"{algorithm_count:,}", help="Number of correlation methods calculated for the selected columns.")
            rm3.metric("Unique pairs", f"{unique_pairs:,}", help="Number of unique column pairs evaluated per selected algorithm, excluding self-correlations.")
            for algorithm, assoc in association_matrices.items():
                method = algorithm.lower()
                # Each algorithm gets its own bounded result section. Horizontal
                # movement is handled inside its AG Grid rather than by the full
                # Data Mining page or the combined analysis division.
                with st.container(border=True):
                    st.markdown(f"##### {algorithm} correlation / association")
                    st.caption("Scroll horizontally inside the result grid to view additional value columns. Select any colored value cell to filter and open its source records.")
                    selected_left, selected_right = clickable_heatmap_table(
                        assoc, key_prefix=f"eda_assoc_cell_{method}", disable_diagonal=True
                    )
                    if selected_left and selected_right:
                        matching = analysis_df[
                            analysis_df[selected_left].notna() & analysis_df[selected_right].notna()
                        ]
                        register_deep_dive_popup(
                            matching,
                            f"{algorithm}: {selected_left} ↔ {selected_right}",
                            f"Filter applied: `{selected_left}` is not missing AND `{selected_right}` is not missing.",
                            {
                                "drill_type": "correlation_cell",
                                "algorithm": algorithm,
                                "left": selected_left,
                                "right": selected_right,
                                "association": safe_python_scalar(assoc.loc[selected_left, selected_right]),
                            },
                            filter_spec={"type": "non_missing_pair", "left": selected_left, "right": selected_right},
                        )
                    st.markdown(f"**{algorithm} summary**")
                    st.markdown(correlation_summary_text(assoc))
            st.caption("Numeric-like fields are converted, dates use timestamps, and categorical values are factor-encoded. Pearson measures linear association, Spearman rank association, and Kendall ordinal concordance.")

            qualifying_pairs = association_pairs_by_strength(association_matrices)
            if st.button("Deep Dive", type="primary", key="eda_deep_dive_button"):
                st.session_state.eda_deep_dive_enabled = True

            if st.session_state.get("eda_deep_dive_enabled", False):
                st.markdown("#### Deep Dive: medium and high associations")
                if not qualifying_pairs:
                    st.info("No medium or high associations were found using the selected columns and algorithms.")
                else:
                    st.caption(
                        f"Analysing {len(qualifying_pairs):,} unique feature pairs with an absolute association of 0.40 or above. "
                        "Pairs detected by more than one algorithm are shown once using their strongest result."
                    )
                    for pair_number, pair in enumerate(qualifying_pairs, start=1):
                        left = pair["left"]
                        right = pair["right"]
                        left_semantic = infer_semantic_type(eda_df[left])
                        right_semantic = infer_semantic_type(eda_df[right])
                        left_numeric = left_semantic in {"numerical", "numeric-like text"}
                        right_numeric = right_semantic in {"numerical", "numeric-like text"}
                        title = (
                            f'{pair_number}. {left} ↔ {right} — {pair["strength"]} '
                            f'({pair["association"]:+.2f}, {pair["algorithm"]})'
                        )
                        with st.expander(title, expanded=True):
                            if left_numeric != right_numeric:
                                numeric_column = left if left_numeric else right
                                categorical_column = right if left_numeric else left
                                aggregation_table = grouped_deep_dive_aggregations(
                                    eda_df, categorical_column, numeric_column
                                )
                                st.markdown(
                                    f"**Numeric feature:** `{numeric_column}`  ·  "
                                    f"**Categorical feature:** `{categorical_column}`"
                                )
                                st.dataframe(aggregation_table, use_container_width=True, hide_index=True)
                            else:
                                cross_tab, cross_tab_note = deep_dive_crosstab(eda_df, left, right)
                                pair_type = "numeric–numeric" if left_numeric else "categorical–categorical"
                                st.markdown(f"**Pair type:** {pair_type}")
                                if cross_tab_note:
                                    st.caption(cross_tab_note + ".")
                                st.caption("Select any colored count cell to apply that exact combination and open its records.")
                                selected_left_value, selected_right_value = clickable_heatmap_table(
                                    cross_tab,
                                    key_prefix=f"eda_deep_dive_cell_{pair_number}",
                                    value_format="count",
                                )
                                if selected_left_value is not None and selected_right_value is not None:
                                    prepared_left, _ = deep_dive_prepared_series(eda_df, left)
                                    prepared_right, _ = deep_dive_prepared_series(eda_df, right)
                                    matching_mask = (
                                        prepared_left.astype("string") == selected_left_value
                                    ) & (
                                        prepared_right.astype("string") == selected_right_value
                                    )
                                    matching = eda_df[matching_mask]
                                    register_deep_dive_popup(
                                        matching,
                                        f"{left} = {selected_left_value} · {right} = {selected_right_value}",
                                        f"Filter applied: `{left}` = `{selected_left_value}` AND `{right}` = `{selected_right_value}`.",
                                        {
                                            "drill_type": "cross_tab_cell",
                                            "left": left,
                                            "right": right,
                                            "left_value": selected_left_value,
                                            "right_value": selected_right_value,
                                            "pair_strength": pair["strength"],
                                            "association": pair["association"],
                                            "algorithm": pair["algorithm"],
                                        },
                                        filter_spec={
                                            "type": "prepared_pair",
                                            "left": left,
                                            "right": right,
                                            "left_value": selected_left_value,
                                            "right_value": selected_right_value,
                                        },
                                    )

        else:
            st.info("Select columns and algorithms, then click Evaluate to calculate correlation and association results.")

    popup_event_id = int(st.session_state.get("deep_dive_popup_event_id", 0))
    shown_event_id = int(st.session_state.get("deep_dive_popup_shown_event_id", 0))
    if st.session_state.get("deep_dive_popup") and popup_event_id > shown_event_id:
        # Mark consumed before opening. Any later full-app rerun (sidebar,
        # navigation, expanders, etc.) will not reopen this same dialog.
        st.session_state.deep_dive_popup_shown_event_id = popup_event_id
        show_deep_dive_popup()


if active_page == "Audit":
    st.subheader("Audit trail and complete analysis dump")
    audit_df = pd.DataFrame(st.session_state.audit_log)
    if audit_df.empty:
        st.info("Audit entries appear after you run joins, add/apply filters, create pivots/charts, or download outputs.")
    else:
        st.dataframe(audit_df, use_container_width=True, hide_index=True)

    output_df = st.session_state.filtered_data
    if output_df is None:
        output_df = st.session_state.joined_data
    if output_df is None:
        output_df = df1

    metadata = {
        "analysis_name": st.session_state.analysis_name,
        "created_at": utc_now(),
        "dataset_1": ({
            "source_type": "upload", "name": file_1.name, "sheet": sheet_1,
            "sha256_prefix": file_fingerprint(bytes_1), "rows": len(df1),
        } if source_type_1 == "Upload file" else {
            "source_type": "database_query", "database_type": db_meta_1.get("database_type"),
            "endpoint": db_meta_1.get("host") or db_meta_1.get("server_hostname"),
            "database": db_meta_1.get("database"), "catalog": db_meta_1.get("catalog"),
            "schema": db_meta_1.get("schema"),
            "query_hash": hashlib.sha256(db_meta_1.get("query", "").encode("utf-8")).hexdigest()[:16],
            "rows": len(df1),
        }),
        "dataset_2": (({
            "source_type": "upload", "name": file_2.name, "sheet": sheet_2,
            "sha256_prefix": file_fingerprint(bytes_2), "rows": len(df2),
        } if source_type_2 == "Upload file" else {
            "source_type": "database_query", "database_type": db_meta_2.get("database_type"),
            "endpoint": db_meta_2.get("host") or db_meta_2.get("server_hostname"),
            "database": db_meta_2.get("database"), "catalog": db_meta_2.get("catalog"),
            "schema": db_meta_2.get("schema"),
            "query_hash": hashlib.sha256(db_meta_2.get("query", "").encode("utf-8")).hexdigest()[:16],
            "rows": len(df2),
        }) if df2 is not None else None),
        "join_config": st.session_state.join_config,
        "filter_config": st.session_state.last_filter_config,
        "output_rows": len(output_df),
        "output_columns": list(output_df.columns),
    }
    dump = build_dump(output_df, st.session_state.filters, metadata)
    st.download_button(
        "Download complete analysis dump (.zip)", dump,
        file_name=f"{st.session_state.analysis_name}_dump.zip", mime="application/zip",
        on_click=lambda: audit("ANALYSIS_DUMP_DOWNLOADED", {"rows": len(output_df), "audit_entries": len(st.session_state.audit_log)}),
        disabled=output_df.empty,
    )
    st.caption("The dump contains output.xlsx, output.csv, filters.json, audit_log.csv/json, and session_metadata.json.")
