@echo off
rem Setup and launch use the same safe process.
call "%~dp0run_portal.bat"
