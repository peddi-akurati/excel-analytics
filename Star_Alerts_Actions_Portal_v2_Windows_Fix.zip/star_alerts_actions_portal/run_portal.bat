@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ============================================================
echo  Star Health Alerts ^& Actions Portal
echo ============================================================

rem Prefer a supported python.org CPython installation.
set "PYTHON_CMD="
where py >nul 2>nul
if %errorlevel%==0 (
    py -3.12 -c "import sys" >nul 2>nul && set "PYTHON_CMD=py -3.12"
    if not defined PYTHON_CMD py -3.11 -c "import sys" >nul 2>nul && set "PYTHON_CMD=py -3.11"
)

if not defined PYTHON_CMD (
    where python >nul 2>nul
    if %errorlevel%==0 (
        for /f "usebackq delims=" %%V in (`python -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2^>nul`) do set "PYVER=%%V"
        if "%PYVER%"=="3.12" set "PYTHON_CMD=python"
        if "%PYVER%"=="3.11" set "PYTHON_CMD=python"
    )
)

if not defined PYTHON_CMD (
    echo.
    echo ERROR: Python 3.11 or 3.12 was not found.
    echo.
    echo The previous pyproject.toml/vswhere error occurs when pip cannot find
    echo a compatible wheel and attempts to compile a dependency with Visual Studio.
    echo Install 64-bit Python 3.12 from python.org, select "Add python.exe to PATH",
    echo then run this file again.
    echo.
    pause
    exit /b 1
)

echo Using: %PYTHON_CMD%

if exist .venv\pyvenv.cfg (
    for /f "tokens=2 delims== " %%V in ('findstr /b /c:"version =" .venv\pyvenv.cfg 2^>nul') do set "VENVVER=%%V"
    echo Existing virtual environment detected: !VENVVER!
)

if not exist .venv\Scripts\python.exe (
    echo Creating virtual environment...
    %PYTHON_CMD% -m venv .venv || goto :error
)

call .venv\Scripts\activate.bat || goto :error

for /f "delims=" %%V in ('python -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"') do set "ACTIVE_VER=%%V"
if not "%ACTIVE_VER%"=="3.11" if not "%ACTIVE_VER%"=="3.12" (
    echo Existing .venv uses unsupported Python %ACTIVE_VER%.
    echo Removing and recreating it with a supported Python version...
    call deactivate >nul 2>nul
    rmdir /s /q .venv
    %PYTHON_CMD% -m venv .venv || goto :error
    call .venv\Scripts\activate.bat || goto :error
)

echo Upgrading package installer...
python -m pip install --upgrade pip setuptools wheel || goto :error

echo Installing prebuilt dependency wheels only...
python -m pip install --only-binary=:all: -r requirements.txt || goto :wheel_error

echo Starting portal at http://localhost:8501
python -m streamlit run app.py
exit /b 0

:wheel_error
echo.
echo ERROR: A compatible prebuilt package wheel was not available.
echo Confirm that you installed 64-bit CPython 3.11 or 3.12 from python.org.
echo Do not use Python 3.13/3.14, Microsoft Store Python, or a 32-bit installation.
echo.
pause
exit /b 1

:error
echo.
echo Portal setup failed. Review the error above.
echo.
pause
exit /b 1
