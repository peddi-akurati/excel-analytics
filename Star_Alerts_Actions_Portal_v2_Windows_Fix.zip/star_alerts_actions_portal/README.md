# Star Health Alerts & Actions Portal

A CSV-backed Streamlit mock portal reproducing the shared Alerts & Actions dashboard design.

## Included
- Executive alert KPI cards
- Sidebar and top-level filters
- Searchable, sortable open-alert table
- Alerts by category donut
- Weekly alert trend
- Action tracker and progress fields
- Financial impact waterfall
- Notification and owner summaries
- Static mock datasets under `data/`


## Fix for `pyproject.toml` / `vswhere` errors on Windows

This project does not require Visual Studio Build Tools. A `pyproject.toml` message followed by a `vswhere` failure means `pip` attempted to compile a dependency because no compatible prebuilt wheel was found for the active Python installation.

Use **64-bit CPython 3.11 or 3.12 from python.org**. Python 3.13/3.14, 32-bit Python, and some Microsoft Store installations can cause source-build fallbacks.

The updated `run_portal.bat` now:

1. Selects Python 3.12 or 3.11 through the Windows `py` launcher.
2. Recreates an incompatible existing `.venv`.
3. Installs only prebuilt binary wheels with `--only-binary=:all:`.
4. Stops with a clear message instead of invoking Visual Studio or `vswhere`.

After installing Python 3.12, double-click `run_portal.bat`. To reset an old environment manually, delete the `.venv` folder and run the launcher again.

## Windows setup
1. Install Python 3.11 or 3.12 from python.org. During installation select **Add Python to PATH**.
2. Extract the ZIP.
3. Open the extracted folder.
4. Double-click `run_portal.bat`.
5. The browser should open automatically at `http://localhost:8501`.

## macOS/Linux setup
1. Install Python 3.11 or 3.12.
2. Extract the ZIP and open Terminal in the project folder.
3. Run:
   ```bash
   chmod +x run_portal.sh
   ./run_portal.sh
   ```
4. Open `http://localhost:8501` if the browser does not open automatically.

## Manual setup
```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
streamlit run app.py
```

## Updating the static mock data
Edit these CSV files and restart the portal:
- `data/alerts.csv`
- `data/actions.csv`
- `data/alert_trend.csv`
- `data/notifications.csv`

Do not rename CSV columns unless the matching references in `app.py` are also updated.

## Stop the portal
Press `Ctrl+C` in the terminal window.
