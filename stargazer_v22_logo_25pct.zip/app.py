from __future__ import annotations

from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
from typing import Any
import hashlib
import json
import zipfile
import re

import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st
from PIL import Image
from st_aggrid import AgGrid, GridOptionsBuilder, DataReturnMode, GridUpdateMode

BASE_DIR = Path(__file__).resolve().parent
LOGO_PATH = BASE_DIR / "assets" / "clarity_logo.png"
FAVICON_PATH = BASE_DIR / "assets" / "clarity_favicon.png"

page_icon = Image.open(FAVICON_PATH) if FAVICON_PATH.exists() else "🔭"
st.set_page_config(page_title="Stargazer", page_icon=page_icon, layout="wide")
st.markdown('<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded" rel="stylesheet">', unsafe_allow_html=True)

# Render the transparent Clarity brand inside Streamlit's native sidebar header.
if LOGO_PATH.exists():
    st.logo(str(LOGO_PATH), icon_image=str(FAVICON_PATH) if FAVICON_PATH.exists() else None, size="large"
    # logo rendered large; CSS below scales by 1.25)


def render_global_styles() -> None:
    """Apply stable app, sidebar, header, dataframe and grid styling."""
    sidebar_width = "27rem" if st.session_state.get("wide_sidebar", False) else "15.75rem"
    css = """
    <style>

    /* Increase logo render size within same header area */
    [data-testid="stLogo"] img, [data-testid="stSidebarHeader"] img{
        transform: scale(1.25);
        transform-origin:center;
    }

    html, body, [class*="css"], [data-testid="stAppViewContainer"],
    [data-testid="stSidebar"], button, input, textarea, select {
        font-family: Verdana, Geneva, sans-serif !important;
    }
    [data-testid="stAppDeployButton"], [data-testid="stDeployButton"] {
        display: none !important;
    }
    section[data-testid="stSidebar"][aria-expanded="true"] {
        width: __SIDEBAR_WIDTH__ !important;
        min-width: __SIDEBAR_WIDTH__ !important;
    }
    section[data-testid="stSidebar"][aria-expanded="true"] > div {
        width: __SIDEBAR_WIDTH__ !important;
    }
    section[data-testid="stSidebar"][aria-expanded="false"] {
        width: 0 !important;
        min-width: 0 !important;
    }
    [data-testid="collapsedControl"] {
        z-index: 10050 !important;
        top: .45rem !important;
        left: .45rem !important;
        width: 3.35rem !important;
        height: 3.35rem !important;
        border-radius: .75rem !important;
        background: #f3f6fb !important;
        border: 1px solid #dce4f0 !important;
        box-shadow: 0 2px 10px rgba(15, 23, 42, .10) !important;
    }
    [data-testid="collapsedControl"] img,
    [data-testid="collapsedControl"] svg {
        width: 2.35rem !important;
        height: 2.35rem !important;
    }
    section[data-testid="stSidebar"] [data-testid="stSidebarHeader"] {
        position: sticky !important;
        top: 0 !important;
        z-index: 10000 !important;
        min-height: 6.2rem !important;
        padding: .35rem .7rem !important;
        border-bottom: 1px solid #e8edf5 !important;
        background: #f3f6fb !important;
        backdrop-filter: none !important;
        overflow: hidden !important;
    }
    section[data-testid="stSidebar"] [data-testid="stSidebarHeader"] img {
        width: 12.25rem !important;
        min-width: 12.25rem !important;
        max-width: 12.25rem !important;
        height: 4.75rem !important;
        min-height: 4.75rem !important;
        max-height: 4.75rem !important;
        object-fit: contain !important;
        object-position: left center !important;
        opacity: 1 !important;
        background: transparent !important;
        flex: 0 0 12.25rem !important;
    }
    section[data-testid="stSidebar"] {
        background: #f3f6fb !important;
        border-right: 1px solid #dce4f0 !important;
    }
    section[data-testid="stSidebar"] div[data-testid="stSidebarUserContent"] {
        padding-top: .85rem !important;
        position: relative !important;
        z-index: 1 !important;
        background: #f3f6fb !important;
    }
    section[data-testid="stSidebar"] > div:first-child {
        background: #f3f6fb !important;
    }
    /* Header statement rendered in the right-pane stAppHeader. */
    [data-testid="stHeader"]::after,
    [data-testid="stAppHeader"]::after {
        content: "Add the data, conduct analysis, and uncover insights to facilitate clear, data-driven decisions";
        position: absolute;
        left: 4.75rem;
        top: 50%;
        transform: translateY(-50%);
        width: min(52rem, calc(100% - 11.5rem));
        padding: .58rem 1rem .58rem 1.15rem;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        color: #002060;
        font-size: .86rem;
        font-weight: 600;
        letter-spacing: .005em;
        line-height: 1.2;
        border: 1px solid #cbd8ec;
        border-left: 4px solid #002060;
        border-radius: .65rem;
        background: linear-gradient(90deg, #edf3ff 0%, #f8fbff 72%, #ffffff 100%);
        box-shadow: 0 3px 12px rgba(0, 32, 96, .08);
        pointer-events: none;
        box-sizing: border-box;
    }
    /* Left-align all native dataframe headers and values; keep headers sticky. */
    [data-testid="stDataFrame"] th, [data-testid="stDataFrame"] td,
    [data-testid="stDataEditor"] th, [data-testid="stDataEditor"] td {
        text-align: left !important;
        justify-content: flex-start !important;
    }
    [data-testid="stDataFrame"] thead th,
    [data-testid="stDataEditor"] thead th {
        position: sticky !important;
        top: 0 !important;
        z-index: 5 !important;
        background: #f8fafc !important;
    }
    /* Material 3 documentation-style navigation tabs. */
    div[data-testid="stHorizontalBlock"]:has(.modern-nav-anchor) {
        display: none !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] {
        display: grid !important;
        grid-template-columns: repeat(8, minmax(max-content, 1fr)) !important;
        align-items: end !important;
        padding: 0 .25rem;
        margin: .2rem 0 1.15rem 0;
        border: 0 !important;
        border-bottom: 1px solid #d7dee8 !important;
        border-radius: 0 !important;
        background: transparent !important;
        box-shadow: none !important;
        gap: .15rem !important;
        overflow-x: auto !important;
        scrollbar-width: thin;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] > div {
        width: 100% !important;
        min-width: max-content !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"],
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] > div {
        width: 100% !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button {
        position: relative !important;
        width: 100% !important;
        height: 3rem !important;
        min-height: 3rem !important;
        padding: .55rem .75rem .65rem !important;
        border: 0 !important;
        border-radius: .5rem .5rem 0 0 !important;
        background: transparent !important;
        color: #475569 !important;
        font-size: .79rem !important;
        font-weight: 600 !important;
        line-height: 1.1 !important;
        letter-spacing: .01em !important;
        white-space: nowrap !important;
        box-shadow: none !important;
        transition: background-color .16s ease, color .16s ease !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button::after {
        content: "" !important;
        position: absolute !important;
        left: 50% !important;
        bottom: 0 !important;
        width: 0 !important;
        height: 3px !important;
        border-radius: 3px 3px 0 0 !important;
        background: #002060 !important;
        transform: translateX(-50%) !important;
        transition: width .18s ease !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button:hover {
        transform: none !important;
        background: #f2f6fc !important;
        color: #002060 !important;
        box-shadow: none !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button:focus-visible {
        outline: 2px solid #5477b7 !important;
        outline-offset: -2px !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button[kind="primary"] {
        background: #edf3ff !important;
        color: #002060 !important;
        font-weight: 700 !important;
        box-shadow: none !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button[kind="primary"]::after {
        width: calc(100% - 1.25rem) !important;
    }
    .modern-nav-anchor + div[data-testid="stHorizontalBlock"] [data-testid="stButton"] button[kind="primary"]:hover {
        background: #e4edfc !important;
        color: #002060 !important;
    }
    @media (max-width: 920px) {
        .modern-nav-anchor + div[data-testid="stHorizontalBlock"] {
            grid-template-columns: repeat(8, minmax(8rem, 1fr)) !important;
        }
    }
    </style>
    """.replace("__SIDEBAR_WIDTH__", sidebar_width)
    st.markdown(css, unsafe_allow_html=True)


render_global_styles()


OPERATORS = [
    "equals", "not equals", "contains", "does not contain", "starts with", "ends with",
    "greater than", "greater than or equal", "less than", "less than or equal",
    "between", "in list", "not in list", "is blank", "is not blank",
]


def init_state() -> None:
    defaults: dict[str, Any] = {
        "filters": [],
        "audit_log": [],
        "joined_data": None,
        "filtered_data": None,
        "join_config": {},
        "last_filter_config": {},
        "analysis_name": "excel_analysis",
        "input_signature": None,
        "db_data_1": None,
        "db_data_2": None,
        "db_meta_1": {},
        "db_meta_2": {},
        "pivot_data": None,
        "wide_sidebar": False,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def utc_now() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def audit(action: str, details: dict[str, Any] | None = None) -> None:
    st.session_state.audit_log.append({
        "timestamp": utc_now(),
        "action": action,
        "details": json.dumps(details or {}, ensure_ascii=False, default=str),
    })


def file_fingerprint(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()[:16]


@st.cache_data(show_spinner=False)
def get_sheet_names(file_bytes: bytes, filename: str) -> list[str]:
    if filename.lower().endswith(".csv"):
        return ["CSV"]
    return pd.ExcelFile(BytesIO(file_bytes)).sheet_names


@st.cache_data(show_spinner=False)
def load_table(file_bytes: bytes, filename: str, sheet_name: str | None) -> pd.DataFrame:
    """Read Excel or CSV files with resilient CSV encoding/delimiter handling."""
    stream = BytesIO(file_bytes)
    if filename.lower().endswith(".csv"):
        encodings = ["utf-8-sig", "utf-8", "cp1252", "latin-1"]
        last_error: Exception | None = None
        for encoding in encodings:
            try:
                stream.seek(0)
                # sep=None lets pandas detect comma, semicolon, tab, or pipe-delimited files.
                return pd.read_csv(
                    stream, encoding=encoding, sep=None, engine="python",
                    on_bad_lines="warn"
                )
            except (UnicodeDecodeError, UnicodeError, pd.errors.ParserError) as exc:
                last_error = exc
        raise ValueError(
            "CSV could not be decoded using UTF-8, Windows-1252, or Latin-1. "
            f"Last error: {last_error}"
        )
    return pd.read_excel(stream, sheet_name=sheet_name)


def validate_read_only_sql(query: str) -> str:
    """Allow result-returning SQL while blocking obvious write or multi-statement commands."""
    cleaned = query.strip().rstrip(";").strip()
    if not cleaned:
        raise ValueError("Enter a SQL query.")
    # Reject multiple statements. A trailing semicolon is accepted.
    if ";" in cleaned:
        raise ValueError("Run one SQL statement at a time.")
    first = re.match(r"^\s*([A-Za-z]+)", cleaned)
    command = first.group(1).lower() if first else ""
    allowed = {"select", "with", "show", "describe", "desc", "explain"}
    if command not in allowed:
        raise ValueError("Only read-only SELECT, WITH, SHOW, DESCRIBE, or EXPLAIN queries are allowed.")
    return cleaned


def run_postgres_query(
    host: str, port: int, database: str, user: str, password: str,
    query: str, sslmode: str = "prefer",
) -> pd.DataFrame:
    import psycopg2

    sql_text = validate_read_only_sql(query)
    connection = psycopg2.connect(
        host=host, port=int(port), dbname=database, user=user, password=password,
        sslmode=sslmode, connect_timeout=20,
    )
    try:
        connection.set_session(readonly=True, autocommit=False)
        return pd.read_sql_query(sql_text, connection)
    finally:
        connection.close()


def run_databricks_query(
    server_hostname: str, http_path: str, access_token: str, query: str,
    catalog: str | None = None, schema: str | None = None,
) -> pd.DataFrame:
    from databricks import sql as dbsql

    sql_text = validate_read_only_sql(query)
    kwargs: dict[str, Any] = {
        "server_hostname": server_hostname,
        "http_path": http_path,
        "access_token": access_token,
    }
    if catalog:
        kwargs["catalog"] = catalog
    if schema:
        kwargs["schema"] = schema
    connection = dbsql.connect(**kwargs)
    try:
        cursor = connection.cursor()
        try:
            cursor.execute(sql_text)
            rows = cursor.fetchall()
            columns = [item[0] for item in cursor.description] if cursor.description else []
            return pd.DataFrame(rows, columns=columns)
        finally:
            cursor.close()
    finally:
        connection.close()


def render_database_source(dataset_number: int) -> tuple[pd.DataFrame | None, dict[str, Any]]:
    """Render database connection controls and return the persisted query result."""
    state_key = f"db_data_{dataset_number}"
    meta_key = f"db_meta_{dataset_number}"
    db_type = st.selectbox(
        f"Dataset {dataset_number} database", ["PostgreSQL", "Databricks"],
        key=f"db_type_{dataset_number}",
    )
    with st.expander(f"{db_type} connection details", expanded=True):
        if db_type == "PostgreSQL":
            c1, c2 = st.columns([3, 1])
            host = c1.text_input("Host", key=f"pg_host_{dataset_number}")
            port = c2.number_input("Port", 1, 65535, 5432, key=f"pg_port_{dataset_number}")
            database = st.text_input("Database", key=f"pg_database_{dataset_number}")
            user = st.text_input("User", key=f"pg_user_{dataset_number}")
            password = st.text_input("Password", type="password", key=f"pg_password_{dataset_number}")
            sslmode = st.selectbox(
                "SSL mode", ["prefer", "require", "verify-ca", "verify-full", "disable"],
                key=f"pg_sslmode_{dataset_number}",
            )
        else:
            server_hostname = st.text_input(
                "Server hostname", placeholder="dbc-xxxxxxxx.cloud.databricks.com",
                key=f"dbx_host_{dataset_number}",
            )
            http_path = st.text_input(
                "HTTP path", placeholder="/sql/1.0/warehouses/xxxxxxxx",
                key=f"dbx_http_path_{dataset_number}",
            )
            access_token = st.text_input("Access token", type="password", key=f"dbx_token_{dataset_number}")
            c1, c2 = st.columns(2)
            catalog = c1.text_input("Catalog (optional)", key=f"dbx_catalog_{dataset_number}")
            schema = c2.text_input("Schema (optional)", key=f"dbx_schema_{dataset_number}")

        query = st.text_area(
            "Custom SQL query", height=150, placeholder="SELECT * FROM schema.table LIMIT 1000",
            key=f"db_query_{dataset_number}",
        )
        q1, q2 = st.columns(2)
        if q1.button("Run query", type="primary", key=f"run_db_query_{dataset_number}"):
            try:
                with st.spinner("Running query..."):
                    if db_type == "PostgreSQL":
                        if not all([host, database, user, password]):
                            raise ValueError("Host, database, user, and password are required.")
                        result = run_postgres_query(host, int(port), database, user, password, query, sslmode)
                        safe_meta = {"database_type": db_type, "host": host, "database": database, "query": query}
                    else:
                        if not all([server_hostname, http_path, access_token]):
                            raise ValueError("Server hostname, HTTP path, and access token are required.")
                        result = run_databricks_query(server_hostname, http_path, access_token, query, catalog or None, schema or None)
                        safe_meta = {
                            "database_type": db_type, "server_hostname": server_hostname,
                            "http_path": http_path, "catalog": catalog, "schema": schema, "query": query,
                        }
                st.session_state[state_key] = result
                st.session_state[meta_key] = safe_meta
                audit("DATABASE_QUERY_EXECUTED", {
                    "dataset": dataset_number, "database_type": db_type,
                    "rows": len(result), "columns": len(result.columns),
                    "query_hash": hashlib.sha256(query.encode("utf-8")).hexdigest()[:16],
                })
                st.success(f"Query returned {len(result):,} rows and {len(result.columns):,} columns.")
                st.rerun()
            except Exception as exc:
                audit("DATABASE_QUERY_FAILED", {"dataset": dataset_number, "database_type": db_type, "error": str(exc)})
                st.error(f"Could not run query: {exc}")
        if q2.button("Clear query result", key=f"clear_db_query_{dataset_number}"):
            st.session_state[state_key] = None
            st.session_state[meta_key] = {}
            st.rerun()

    result = st.session_state.get(state_key)
    meta = st.session_state.get(meta_key, {})
    if result is not None:
        st.caption(f"Current query result: {len(result):,} rows × {len(result.columns):,} columns")
        preview_rows = st.number_input(
            "Preview rows", min_value=5, max_value=500, value=50, step=5,
            key=f"db_preview_rows_{dataset_number}"
        )
        st.dataframe(result.head(int(preview_rows)), use_container_width=True, height=420 if st.session_state.get("wide_sidebar") else 260)
    return result, meta


def make_unique_columns(df: pd.DataFrame, source: str) -> pd.DataFrame:
    result = df.copy()
    counts: dict[str, int] = {}
    columns: list[str] = []
    for raw in result.columns:
        col = str(raw).strip() or "Unnamed"
        counts[col] = counts.get(col, 0) + 1
        unique = col if counts[col] == 1 else f"{col}_{counts[col]}"
        columns.append(f"{source}.{unique}")
    result.columns = columns
    return result


def normalize_key(series: pd.Series, trim: bool, lower: bool) -> pd.Series:
    result = series.astype("string")
    if trim:
        result = result.str.strip()
    if lower:
        result = result.str.lower()
    return result


def json_bytes(value: Any) -> bytes:
    return json.dumps(value, indent=2, ensure_ascii=False, default=str).encode("utf-8")


def to_excel_bytes(sheets: dict[str, pd.DataFrame]) -> bytes:
    output = BytesIO()
    with pd.ExcelWriter(output, engine="xlsxwriter") as writer:
        for sheet_name, df in sheets.items():
            safe_name = sheet_name[:31]
            df.to_excel(writer, index=False, sheet_name=safe_name)
            worksheet = writer.sheets[safe_name]
            for index, column in enumerate(df.columns):
                if df.empty:
                    sample_width = 0
                else:
                    lengths = df[column].head(500).map(
                        lambda value: len(str(value)) if pd.notna(value) else 0
                    )
                    max_width = lengths.max()
                    sample_width = int(max_width) if pd.notna(max_width) else 0
                header_width = len(str(column))
                worksheet.set_column(index, index, min(max(sample_width, header_width) + 2, 50))
    return output.getvalue()


def render_grid(df: pd.DataFrame, key: str, fit_columns: bool = False) -> pd.DataFrame:
    gb = GridOptionsBuilder.from_dataframe(df)
    gb.configure_default_column(
        sortable=True, filter=True, resizable=True, editable=False,
        enableRowGroup=True, enablePivot=True, enableValue=True,
        wrapHeaderText=True, autoHeaderHeight=True,
        cellStyle={"textAlign": "left"},
    )
    gb.configure_pagination(enabled=True, paginationAutoPageSize=False, paginationPageSize=50)
    gb.configure_grid_options(
        sideBar=True,
        rowSelection="multiple",
        animateRows=True,
        domLayout="normal",
        suppressPaginationPanel=False,
    )
    grid_css = {
        ".ag-header": {"position": "sticky", "top": "0", "z-index": "10"},
        ".ag-header-cell-label": {"justify-content": "flex-start"},
        ".ag-cell": {"text-align": "left", "justify-content": "flex-start"},
    }
    response = AgGrid(
        df, gridOptions=gb.build(), height=480, fit_columns_on_grid_load=fit_columns,
        data_return_mode=DataReturnMode.FILTERED_AND_SORTED,
        update_mode=GridUpdateMode.NO_UPDATE, allow_unsafe_jscode=False,
        theme="streamlit", key=key, custom_css=grid_css,
    )
    return pd.DataFrame(response.get("data", df))


def safe_numeric_series(series: pd.Series) -> pd.Series:
    """Convert values to float-compatible numbers while treating pd.NA safely."""
    cleaned = series.astype("string").str.replace(",", "", regex=False).str.strip()
    cleaned = cleaned.mask(cleaned.isin(["", "<NA>", "NA", "N/A", "None", "null", "NULL"]))
    return pd.to_numeric(cleaned, errors="coerce").astype("float64")


def safe_python_scalar(value: Any) -> Any:
    """Convert pandas/numpy scalar values to UI/JSON-safe Python values."""
    if value is pd.NA or value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(value, np.generic):
        return value.item()
    return value


def condition_mask(df: pd.DataFrame, rule: dict[str, Any]) -> pd.Series:
    column = rule["column"]
    operator = rule["operator"]
    value = str(rule.get("value", ""))
    value2 = str(rule.get("value2", ""))
    case_sensitive = bool(rule.get("case_sensitive", False))
    series = df[column]
    text = series.astype("string")
    left = text if case_sensitive else text.str.lower()
    right = value if case_sensitive else value.lower()

    if operator == "equals": return left == right
    if operator == "not equals": return left != right
    if operator == "contains": return left.str.contains(right, na=False, regex=False)
    if operator == "does not contain": return ~left.str.contains(right, na=False, regex=False)
    if operator == "starts with": return left.str.startswith(right, na=False)
    if operator == "ends with": return left.str.endswith(right, na=False)
    if operator == "is blank": return series.isna() | text.str.strip().eq("")
    if operator == "is not blank": return series.notna() & ~text.str.strip().eq("")
    if operator in {"in list", "not in list"}:
        values = [item.strip() for item in value.split(",") if item.strip()]
        if not case_sensitive:
            values = [item.lower() for item in values]
        mask = left.isin(values)
        return ~mask if operator == "not in list" else mask

    numeric = safe_numeric_series(series)
    try:
        number = float(value)
    except ValueError as exc:
        raise ValueError(f"'{value}' is not numeric for {column}") from exc
    if operator == "greater than": return numeric > number
    if operator == "greater than or equal": return numeric >= number
    if operator == "less than": return numeric < number
    if operator == "less than or equal": return numeric <= number
    if operator == "between":
        try:
            number2 = float(value2)
        except ValueError as exc:
            raise ValueError(f"'{value2}' is not numeric for the upper bound") from exc
        return numeric.between(min(number, number2), max(number, number2), inclusive="both")
    raise ValueError(f"Unsupported operator: {operator}")


def apply_filter_rules(df: pd.DataFrame, rules: list[dict[str, Any]]) -> pd.DataFrame:
    if not rules:
        return df.copy()
    combined: pd.Series | None = None
    for index, rule in enumerate(rules):
        mask = condition_mask(df, rule).fillna(False)
        if index == 0:
            combined = mask
        elif rule.get("connector", "AND") == "OR":
            combined = combined | mask  # type: ignore[operator]
        else:
            combined = combined & mask  # type: ignore[operator]
    return df[combined].copy() if combined is not None else df.copy()


def filter_summary(rule: dict[str, Any], index: int) -> str:
    prefix = "WHERE" if index == 0 else rule.get("connector", "AND")
    operator = rule["operator"]
    if operator in {"is blank", "is not blank"}:
        return f"{prefix} {rule['column']} {operator}"
    if operator == "between":
        return f"{prefix} {rule['column']} between {rule.get('value', '')} and {rule.get('value2', '')}"
    return f"{prefix} {rule['column']} {operator} {rule.get('value', '')}"


def build_dump(output_df: pd.DataFrame, filters: list[dict[str, Any]], metadata: dict[str, Any]) -> bytes:
    memory = BytesIO()
    audit_df = pd.DataFrame(st.session_state.audit_log)
    with zipfile.ZipFile(memory, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("output.xlsx", to_excel_bytes({"Analysis_Output": output_df, "Audit_Log": audit_df}))
        archive.writestr("output.csv", output_df.to_csv(index=False).encode("utf-8"))
        archive.writestr("filters.json", json_bytes({"version": 1, "filters": filters}))
        archive.writestr("audit_log.json", json_bytes(st.session_state.audit_log))
        archive.writestr("audit_log.csv", audit_df.to_csv(index=False).encode("utf-8"))
        archive.writestr("session_metadata.json", json_bytes(metadata))
    return memory.getvalue()



def infer_semantic_type(series: pd.Series) -> str:
    non_null = series.dropna()
    if non_null.empty:
        return "empty"
    if pd.api.types.is_bool_dtype(series):
        return "boolean"
    if pd.api.types.is_numeric_dtype(series):
        return "numerical"
    if pd.api.types.is_datetime64_any_dtype(series):
        return "datetime"
    text = non_null.astype(str).str.strip()
    numeric_ratio = pd.to_numeric(text.str.replace(",", "", regex=False), errors="coerce").notna().mean()
    date_ratio = pd.to_datetime(text, errors="coerce", dayfirst=False).notna().mean()
    if numeric_ratio >= 0.9:
        return "numeric-like text"
    if date_ratio >= 0.9:
        return "date-like text"
    unique_ratio = text.nunique(dropna=True) / max(len(text), 1)
    return "identifier/text" if unique_ratio > 0.8 else "categorical"


def outlier_mask_iqr(series: pd.Series) -> pd.Series:
    numeric = safe_numeric_series(series)
    valid = numeric.dropna()
    if len(valid) < 4:
        return pd.Series(False, index=series.index)
    q1, q3 = valid.quantile([0.25, 0.75])
    iqr = q3 - q1
    if pd.isna(iqr) or iqr == 0:
        return pd.Series(False, index=series.index)
    return (numeric < q1 - 1.5 * iqr) | (numeric > q3 + 1.5 * iqr)


def detailed_profile(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    total = len(df)
    for column in df.columns:
        series = df[column]
        non_null = series.dropna()
        semantic = infer_semantic_type(series)
        blank_count = int(series.astype("string").str.strip().eq("").fillna(False).sum())
        outliers = int(outlier_mask_iqr(series).sum()) if semantic in {"numerical", "numeric-like text"} else 0
        invalid = 0
        consistency = 100.0
        if semantic == "numeric-like text":
            converted = safe_numeric_series(non_null)
            invalid = int(converted.isna().sum())
            consistency = round((1 - invalid / max(len(non_null), 1)) * 100, 2)
        elif semantic == "date-like text":
            converted = pd.to_datetime(non_null.astype(str), errors="coerce")
            invalid = int(converted.isna().sum())
            consistency = round((1 - invalid / max(len(non_null), 1)) * 100, 2)
        top_values = non_null.astype(str).value_counts().head(5)
        top_text = "; ".join(f"{k} ({v})" for k, v in top_values.items())
        rows.append({
            "column": column, "physical_type": str(series.dtype), "semantic_type": semantic,
            "rows": total, "non_null": int(series.notna().sum()), "missing": int(series.isna().sum()),
            "missing_pct": round(float(series.isna().mean() * 100), 2) if total else 0.0,
            "blank_strings": blank_count, "unique_values": int(series.nunique(dropna=True)),
            "duplicate_values": int(non_null.duplicated(keep=False).sum()),
            "outliers_iqr": outliers, "invalid_values": invalid,
            "type_consistency_pct": consistency, "top_values": top_text,
        })
    return pd.DataFrame(rows)


def quality_summary(df: pd.DataFrame) -> dict[str, int | float]:
    profile = detailed_profile(df)
    return {
        "rows": len(df), "columns": len(df.columns),
        "duplicate_rows": int(df.duplicated().sum()),
        "missing_cells": int(df.isna().sum().sum()),
        "outliers": int(profile["outliers_iqr"].sum()) if not profile.empty else 0,
        "invalid_values": int(profile["invalid_values"].sum()) if not profile.empty else 0,
    }


def detect_datetime_candidates(df: pd.DataFrame) -> list[str]:
    candidates = []
    for column in df.columns:
        series = df[column]
        if pd.api.types.is_datetime64_any_dtype(series):
            candidates.append(column)
            continue
        non_null = series.dropna().head(1000)
        if non_null.empty or pd.api.types.is_numeric_dtype(series):
            continue
        parsed = pd.to_datetime(non_null.astype(str), errors="coerce")
        if parsed.notna().mean() >= 0.8:
            candidates.append(column)
    return candidates


def basic_profile(df: pd.DataFrame) -> pd.DataFrame:
    return pd.DataFrame({
        "column": df.columns,
        "data_type": [str(df[c].dtype) for c in df.columns],
        "non_null": [int(df[c].notna().sum()) for c in df.columns],
        "nulls": [int(df[c].isna().sum()) for c in df.columns],
        "null_pct": [round(float(df[c].isna().mean() * 100), 2) for c in df.columns],
        "distinct": [int(df[c].nunique(dropna=True)) for c in df.columns],
    })


def classify_columns(df: pd.DataFrame) -> dict[str, list[str]]:
    result = {"numeric": [], "categorical": [], "datetime": [], "boolean": [], "empty": []}
    for column in df.columns:
        semantic = infer_semantic_type(df[column])
        if semantic in {"numerical", "numeric-like text"}:
            result["numeric"].append(column)
        elif semantic in {"datetime", "date-like text"}:
            result["datetime"].append(column)
        elif semantic == "boolean":
            result["boolean"].append(column)
        elif semantic == "empty":
            result["empty"].append(column)
        else:
            result["categorical"].append(column)
    return result


def all_column_descriptive_summary(df: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for column in df.columns:
        series = df[column]
        semantic = infer_semantic_type(series)
        non_null = series.dropna()
        row: dict[str, Any] = {
            "column": column,
            "semantic_type": semantic,
            "rows": len(series),
            "non_null": int(series.notna().sum()),
            "missing": int(series.isna().sum()),
            "unique": int(series.nunique(dropna=True)),
            "most_frequent": None,
            "frequency": 0,
            "min": None,
            "max": None,
            "mean": None,
            "median": None,
        }
        if not non_null.empty:
            counts = non_null.astype(str).value_counts()
            row["most_frequent"] = counts.index[0] if not counts.empty else None
            row["frequency"] = int(counts.iloc[0]) if not counts.empty else 0
        if semantic in {"numerical", "numeric-like text"}:
            numeric = safe_numeric_series(non_null)
            row.update({
                "min": safe_python_scalar(numeric.min()), "max": safe_python_scalar(numeric.max()),
                "mean": safe_python_scalar(numeric.mean()), "median": safe_python_scalar(numeric.median()),
            })
        elif semantic in {"datetime", "date-like text"}:
            dates = pd.to_datetime(non_null, errors="coerce")
            row["min"], row["max"] = safe_python_scalar(dates.min()), safe_python_scalar(dates.max())
        rows.append(row)
    return pd.DataFrame(rows)


def encoded_association(df: pd.DataFrame, columns: list[str], method: str = "spearman") -> pd.DataFrame:
    encoded = pd.DataFrame(index=df.index)
    for column in columns:
        semantic = infer_semantic_type(df[column])
        if semantic in {"numerical", "numeric-like text"}:
            encoded[column] = safe_numeric_series(df[column])
        elif semantic in {"datetime", "date-like text"}:
            dates = pd.to_datetime(df[column], errors="coerce")
            encoded[column] = dates.map(lambda x: x.timestamp() if pd.notna(x) else float("nan"))
        else:
            codes, _ = pd.factorize(df[column].astype("string"), sort=True)
            encoded[column] = pd.Series(codes, index=df.index, dtype="float64").replace(-1, np.nan)
    return encoded.corr(method=method)


def build_chart_data(
    df: pd.DataFrame, x_col: str, y_col: str | None, aggregation: str,
    chart_type: str, top_n: int,
) -> tuple[pd.DataFrame, str | None]:
    work = df.copy()
    if chart_type in {"Histogram", "Box", "Scatter"}:
        return work, y_col
    if aggregation == "Row count":
        result = work.groupby(x_col, dropna=False).size().rename("__value__").reset_index()
        return result.nlargest(top_n, "__value__"), "__value__"
    if y_col is None:
        return work, None
    if aggregation == "Distinct count":
        result = work.groupby(x_col, dropna=False)[y_col].nunique(dropna=True).rename("__value__").reset_index()
        return result.nlargest(top_n, "__value__"), "__value__"
    numeric = safe_numeric_series(work[y_col])
    work = work.assign(__numeric_value__=numeric)
    agg_map = {"Sum": "sum", "Average": "mean", "Median": "median", "Minimum": "min", "Maximum": "max"}
    result = work.groupby(x_col, dropna=False)["__numeric_value__"].agg(agg_map[aggregation]).rename("__value__").reset_index()
    return result.nlargest(top_n, "__value__"), "__value__"


def correlation_summary_text(matrix: pd.DataFrame) -> str:
    """Create a concise strength summary from a symmetric correlation/association matrix."""
    pairs: list[tuple[str, str, float]] = []
    cols = list(matrix.columns)
    for i, left in enumerate(cols):
        for right in cols[i + 1:]:
            value = matrix.loc[left, right]
            if pd.notna(value):
                pairs.append((str(left), str(right), float(value)))

    bands = {"High": [], "Medium": [], "Low": []}
    for left, right, value in sorted(pairs, key=lambda x: abs(x[2]), reverse=True):
        strength = abs(value)
        item = f"{left} ↔ {right} ({value:+.2f})"
        if strength >= 0.70:
            bands["High"].append(item)
        elif strength >= 0.40:
            bands["Medium"].append(item)
        elif strength >= 0.10:
            bands["Low"].append(item)

    lines = []
    for label in ("High", "Medium", "Low"):
        values = bands[label]
        if values:
            shown = "; ".join(values[:8])
            remainder = len(values) - 8
            suffix = f"; and {remainder} more" if remainder > 0 else ""
            lines.append(f"**{label} correlation:** {shown}{suffix}.")
        else:
            lines.append(f"**{label} correlation:** No feature pairs detected in this range.")
    lines.append("Positive values move in the same direction; negative values move in opposite directions. Association does not imply causation.")
    return "\n\n".join(lines)


def apply_default_data_labels(fig):
    """Apply readable value labels to Plotly charts by default."""
    try:
        for trace in fig.data:
            trace_type = getattr(trace, "type", "")
            if trace_type == "bar":
                orientation = getattr(trace, "orientation", None)
                template = "%{x:,.2f}" if orientation == "h" else "%{y:,.2f}"
                trace.update(texttemplate=template, textposition="auto", cliponaxis=False)
            elif trace_type == "pie":
                trace.update(textinfo="label+percent+value", textposition="auto")
            elif trace_type in {"scatter", "scattergl"}:
                mode = getattr(trace, "mode", "") or ""
                if "lines" in mode:
                    trace.update(mode="lines+markers+text", texttemplate="%{y:,.2f}", textposition="top center")
                else:
                    trace.update(mode="markers+text", texttemplate="%{y:,.2f}", textposition="top center")
            elif trace_type in {"histogram"}:
                trace.update(texttemplate="%{y}", textposition="auto")
    except Exception:
        pass
    return fig


def plot_chart(fig, *args, **kwargs):
    return st.plotly_chart(apply_default_data_labels(fig), *args, **kwargs)


init_state()

with st.sidebar:
    st.checkbox(
        "Expand left pane", key="wide_sidebar",
        help="Use a wider sidebar for SQL connection details and query previews."
    )
    st.header("1. Data sources")
    st.caption("Use an uploaded file or a database query for each dataset.")

    source_type_1 = st.radio(
        "Dataset 1 source", ["Upload file", "Database query"], horizontal=True, key="source_type_1"
    )
    file_1 = None
    db_raw_1 = None
    db_meta_1: dict[str, Any] = {}
    if source_type_1 == "Upload file":
        file_1 = st.file_uploader("File 1", type=["xlsx", "xlsm", "xls", "csv"], key="file_1")
    else:
        db_raw_1, db_meta_1 = render_database_source(1)

    enable_dataset_2 = st.checkbox("Add Dataset 2 for join / lookup", value=False, key="enable_dataset_2")
    source_type_2 = None
    file_2 = None
    db_raw_2 = None
    db_meta_2: dict[str, Any] = {}
    if enable_dataset_2:
        source_type_2 = st.radio(
            "Dataset 2 source", ["Upload file", "Database query"], horizontal=True, key="source_type_2"
        )
        if source_type_2 == "Upload file":
            file_2 = st.file_uploader("File 2", type=["xlsx", "xlsm", "xls", "csv"], key="file_2")
        else:
            db_raw_2, db_meta_2 = render_database_source(2)

    st.session_state.analysis_name = st.text_input("Analysis name", st.session_state.analysis_name)
    st.divider()
    st.subheader("Selected filter summary")
    filter_summary_placeholder = st.empty()
    if st.session_state.filters:
        filter_summary_placeholder.markdown("\n".join(
            f"**{i + 1}.** `{filter_summary(rule, i)}`"
            for i, rule in enumerate(st.session_state.filters)
        ))
    else:
        filter_summary_placeholder.info("No filters selected yet.")

# Resolve Dataset 1.
if source_type_1 == "Upload file" and not file_1:
    st.info("Upload Dataset 1 or choose Database query and run a query to begin.")
    st.stop()
if source_type_1 == "Database query" and db_raw_1 is None:
    st.info("Configure Dataset 1 database connection and run a query to begin.")
    st.stop()

try:
    bytes_1 = None
    bytes_2 = None
    sheet_1 = None
    sheet_2 = None

    if source_type_1 == "Upload file":
        bytes_1 = file_1.getvalue()
        sheets_1 = get_sheet_names(bytes_1, file_1.name)
        with st.sidebar:
            sheet_1 = st.selectbox("File 1 sheet", sheets_1)
        raw1 = load_table(bytes_1, file_1.name, None if sheet_1 == "CSV" else sheet_1)
        source_label_1 = file_1.name
        signature_1 = ("file", file_fingerprint(bytes_1), sheet_1)
    else:
        raw1 = db_raw_1.copy()
        source_label_1 = f"{db_meta_1.get('database_type', 'Database')} query"
        signature_1 = (
            "database", db_meta_1.get("database_type"),
            hashlib.sha256(db_meta_1.get("query", "").encode("utf-8")).hexdigest()[:16],
            len(raw1), tuple(map(str, raw1.columns)),
        )
    df1 = make_unique_columns(raw1, "File1")

    df2 = None
    source_label_2 = None
    signature_2 = None
    if enable_dataset_2:
        if source_type_2 == "Upload file":
            if file_2 is not None:
                bytes_2 = file_2.getvalue()
                sheets_2 = get_sheet_names(bytes_2, file_2.name)
                with st.sidebar:
                    sheet_2 = st.selectbox("File 2 sheet", sheets_2)
                raw2 = load_table(bytes_2, file_2.name, None if sheet_2 == "CSV" else sheet_2)
                df2 = make_unique_columns(raw2, "File2")
                source_label_2 = file_2.name
                signature_2 = ("file", file_fingerprint(bytes_2), sheet_2)
        elif db_raw_2 is not None:
            raw2 = db_raw_2.copy()
            df2 = make_unique_columns(raw2, "File2")
            source_label_2 = f"{db_meta_2.get('database_type', 'Database')} query"
            signature_2 = (
                "database", db_meta_2.get("database_type"),
                hashlib.sha256(db_meta_2.get("query", "").encode("utf-8")).hexdigest()[:16],
                len(raw2), tuple(map(str, raw2.columns)),
            )
except Exception as exc:
    st.error(f"Could not load the selected data sources: {exc}")
    st.stop()

input_signature = (signature_1, signature_2)
if st.session_state.input_signature != input_signature:
    st.session_state.input_signature = input_signature
    st.session_state.joined_data = None
    st.session_state.filtered_data = None
    st.session_state.join_config = {}
    st.session_state.last_filter_config = {}
    st.session_state.filters = []
    audit("INPUT_SOURCES_CHANGED", {
        "dataset_1": source_label_1,
        "dataset_2": source_label_2,
        "dataset_1_source_type": source_type_1,
        "dataset_2_source_type": source_type_2 if enable_dataset_2 else None,
        "single_dataset_mode": df2 is None,
    })

if df2 is None:
    m1, m2 = st.columns(2)
    m1.metric("Dataset 1 rows", f"{len(df1):,}")
    m2.metric("Dataset 1 columns", len(df1.columns))
    st.caption("Single-dataset analysis mode is active. Add Dataset 2 only when a join or lookup is required.")
else:
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Dataset 1 rows", f"{len(df1):,}")
    m2.metric("Dataset 1 columns", len(df1.columns))
    m3.metric("File 2 rows", f"{len(df2):,}")
    m4.metric("File 2 columns", len(df2.columns))

# Modern top-level navigation. Button cards avoid radio indicators and support
# programmatic navigation from actions such as the filtered-output Preview button.
NAV_ITEMS = [
    "Preview",
    "Join / Lookup",
    "Filters & Output",
    "Pivot",
    "Charts",
    "Data Profile",
    "EDA",
    "Audit",
]
if "nav_page" not in st.session_state or st.session_state.nav_page not in set(NAV_ITEMS):
    st.session_state.nav_page = "Preview"

def set_navigation(page: str) -> None:
    st.session_state.nav_page = page

def render_navigation() -> str:
    st.markdown('<div class="modern-nav-anchor"></div>', unsafe_allow_html=True)
    nav_columns = st.columns(len(NAV_ITEMS), gap="small")
    current_page = st.session_state.nav_page
    for column, page in zip(nav_columns, NAV_ITEMS):
        column.button(
            page,
            key=f"nav_button_{page.lower().replace(' ', '_').replace('/', '_').replace('&', 'and')}",
            type="primary" if current_page == page else "secondary",
            use_container_width=True,
            on_click=set_navigation,
            args=(page,),
        )
    return st.session_state.nav_page

active_page = render_navigation()

def navigate_to_preview() -> None:
    set_navigation("Preview")

if active_page == "Preview":
    st.subheader("Data preview")
    preview_sources: dict[str, pd.DataFrame] = {"Dataset 1": df1}
    if df2 is not None:
        preview_sources["Dataset 2"] = df2
    if st.session_state.joined_data is not None:
        preview_sources["Joined dataset"] = st.session_state.joined_data
    if st.session_state.filtered_data is not None:
        preview_sources["Filtered output"] = st.session_state.filtered_data

    preview_controls = st.columns([3, 1])
    preview_names = list(preview_sources.keys())
    if st.session_state.filtered_data is not None and st.session_state.get("main_preview_source") not in preview_names:
        st.session_state.main_preview_source = "Filtered output"
    preview_source_name = preview_controls[0].selectbox(
        "Preview source", preview_names, key="main_preview_source"
    )
    preview_row_limit = preview_controls[1].selectbox(
        "Preview rows", [25, 50, 100, 250, 500], index=2, key="main_preview_rows"
    )
    preview_df = preview_sources[preview_source_name]
    st.caption(
        f"Showing up to {min(preview_row_limit, len(preview_df)):,} of "
        f"{len(preview_df):,} rows and {len(preview_df.columns):,} columns."
    )
    preview_slice = preview_df.head(int(preview_row_limit)).copy()
    st.dataframe(
        preview_slice,
        use_container_width=True,
        height=min(620, max(260, 38 + 35 * min(len(preview_slice), 15))),
        hide_index=True,
    )

if active_page == "Join / Lookup":
    if df2 is None:
        st.info("Add and load Dataset 2 to enable join/lookup. All other analysis pages can use Dataset 1 directly.")
    else:
        st.subheader("Join or lookup the two datasets")
        c1, c2, c3 = st.columns(3)
        left_key = c1.selectbox("File 1 lookup key", df1.columns)
        right_key = c2.selectbox("File 2 lookup key", df2.columns)
        join_type = c3.selectbox("Join type", ["left", "inner", "right", "outer"], format_func=lambda x: {
            "left": "Left lookup (VLOOKUP style)", "inner": "Inner join",
            "right": "Right join", "outer": "Full outer join"}[x])
        c4, c5, c6 = st.columns(3)
        trim_keys = c4.checkbox("Trim spaces in keys", True)
        case_insensitive = c5.checkbox("Case-insensitive keys", True)
        add_match_status = c6.checkbox("Add match status", True)
        selected_right = st.multiselect(
            "Columns to bring from File 2", [c for c in df2.columns if c != right_key],
            default=[c for c in df2.columns if c != right_key][:10],
        )
    
        if st.button("Run join / lookup", type="primary"):
            left_work = df1.copy()
            right_work = df2[[right_key] + selected_right].copy()
            key = "__lookup_key__"
            left_work[key] = normalize_key(left_work[left_key], trim_keys, case_insensitive)
            right_work[key] = normalize_key(right_work[right_key], trim_keys, case_insensitive)
            duplicates = int(right_work[key].duplicated(keep=False).sum())
            merged = left_work.merge(
                right_work, how=join_type, on=key, suffixes=("_file1", "_file2"),
                indicator=True,
            ).drop(columns=[key])
    
            file1_key_count = int(left_work[left_key].notna().sum())
            file2_key_count = int(right_work[right_key].notna().sum())
            joined_match_count = int(merged["_merge"].eq("both").sum())
            missing_not_joined_count = int(merged["_merge"].ne("both").sum())
    
            if add_match_status:
                merged["_merge"] = merged["_merge"].astype(str).map({
                    "left_only": "Only in File 1", "right_only": "Only in File 2", "both": "Matched"})
            else:
                merged = merged.drop(columns=["_merge"])
            st.session_state.joined_data = merged
            st.session_state.filtered_data = None
            st.session_state.join_config = {
                "left_key": left_key, "right_key": right_key, "join_type": join_type,
                "trim_keys": trim_keys, "case_insensitive": case_insensitive,
                "selected_file2_columns": selected_right, "duplicate_file2_key_rows": duplicates,
            }
            st.session_state.join_config.update({
                "file1_key_record_count": file1_key_count,
                "file2_key_record_count": file2_key_count,
                "joined_match_count": joined_match_count,
                "missing_not_joined_count": missing_not_joined_count,
            })
            audit("JOIN_EXECUTED", {**st.session_state.join_config, "output_rows": len(merged)})
            st.success(
                f"Total records of file1 ({left_key} count): {file1_key_count:,} | "
                f"Total records of file2 ({right_key} count): {file2_key_count:,} | "
                f"Joined dataset count (key column match): {joined_match_count:,} | "
                f"Missing or not joined count (key column non-match): {missing_not_joined_count:,}"
            )
    
        if st.session_state.joined_data is not None:
            st.caption("Columns are prefixed with File1. or File2. so filters can clearly use fields from either source.")
            render_grid(st.session_state.joined_data, "joined_grid")
        else:
            st.info("Configure and run the join before creating cross-file filters.")
if active_page == "Filters & Output":
    st.subheader("Visible AND/OR filter builder")
    source_options = {"File 1": df1}
    if df2 is not None:
        source_options["File 2"] = df2
    if st.session_state.joined_data is not None:
        source_options = {"Joined data": st.session_state.joined_data, **source_options}
    available = list(source_options.keys())
    source_col, load_col, clear_col = st.columns([1.35, 1.35, .8], vertical_alignment="bottom")
    source_name = source_col.selectbox("Filter data source", available)
    source_df = source_options[source_name].copy()

    uploaded_filters = load_col.file_uploader("Load saved filters", type=["json"], key="filter_upload")
    if uploaded_filters and load_col.button("Import filter file", use_container_width=True):
        try:
            payload = json.loads(uploaded_filters.getvalue().decode("utf-8"))
            imported = payload.get("filters", payload)
            if not isinstance(imported, list):
                raise ValueError("The file does not contain a filter list.")
            valid = [r for r in imported if r.get("column") in source_df.columns]
            st.session_state.filters = valid
            audit("FILTER_SET_IMPORTED", {"imported": len(valid), "ignored": len(imported) - len(valid)})
            st.rerun()
        except Exception as exc:
            st.error(f"Could not import filters: {exc}")
    if clear_col.button("Clear all filters", use_container_width=True):
        count = len(st.session_state.filters)
        st.session_state.filters = []
        st.session_state.filtered_data = None
        audit("FILTERS_CLEARED", {"count": count})
        st.rerun()

    st.markdown("#### Add condition")
    a, b, c, d = st.columns([1, 2.2, 1.8, 2])
    connector = a.selectbox("Connector", ["AND", "OR"], disabled=len(st.session_state.filters) == 0)
    column = b.selectbox("Column", source_df.columns)
    operator = c.selectbox("Operator", OPERATORS)
    value_disabled = operator in {"is blank", "is not blank"}
    value = d.text_input("Value", disabled=value_disabled, help="For 'in list', use comma-separated values.")
    e, f, g = st.columns([2, 1, 1])
    value2 = e.text_input("Upper value", disabled=operator != "between")
    case_sensitive = f.checkbox("Case-sensitive", False)
    if g.button("Add filter", type="primary"):
        rule = {
            "connector": "AND" if not st.session_state.filters else connector,
            "column": column, "operator": operator, "value": value,
            "value2": value2, "case_sensitive": case_sensitive,
        }
        st.session_state.filters.append(rule)
        audit("FILTER_ADDED", rule)
        st.rerun()

    st.markdown("#### Applied filter definition")
    if not st.session_state.filters:
        st.info("No conditions added. Add conditions above; every condition remains visible here.")
    else:
        for index, rule in enumerate(st.session_state.filters):
            with st.container(border=True):
                x1, x2, x3 = st.columns([7, 1, 1])
                x1.code(filter_summary(rule, index), language=None)
                if x2.button("↑", key=f"up_{index}", disabled=index == 0):
                    rules = st.session_state.filters
                    rules[index - 1], rules[index] = rules[index], rules[index - 1]
                    audit("FILTER_REORDERED", {"from": index, "to": index - 1})
                    st.rerun()
                if x3.button("Remove", key=f"remove_{index}"):
                    removed = st.session_state.filters.pop(index)
                    audit("FILTER_REMOVED", removed)
                    st.rerun()

    csel, csort, cascn = st.columns([3, 2, 1])
    selected_columns = csel.multiselect("Output columns and order", source_df.columns, default=list(source_df.columns))
    sort_columns = csort.multiselect("Sort by", selected_columns)
    ascending = cascn.checkbox("Ascending", True)
    remove_duplicates = st.checkbox("Remove duplicate output rows")

    apply_col, save_col, preview_col = st.columns(3)
    if apply_col.button("Apply filters", type="primary", use_container_width=True):
        try:
            filtered = apply_filter_rules(source_df, st.session_state.filters)
            if selected_columns:
                filtered = filtered[selected_columns]
            if sort_columns:
                filtered = filtered.sort_values(sort_columns, ascending=ascending, na_position="last")
            if remove_duplicates:
                filtered = filtered.drop_duplicates()
            st.session_state.filtered_data = filtered
            st.session_state.last_filter_config = {
                "source": source_name, "filters": st.session_state.filters,
                "selected_columns": selected_columns, "sort_columns": sort_columns,
                "ascending": ascending, "remove_duplicates": remove_duplicates,
            }
            audit("FILTERS_APPLIED", {
                "source": source_name, "conditions": len(st.session_state.filters),
                "input_rows": len(source_df), "output_rows": len(filtered),
                "sort_columns": sort_columns, "remove_duplicates": remove_duplicates,
            })
            st.success(f"Filters returned {len(filtered):,} of {len(source_df):,} rows.")
        except Exception as exc:
            st.error(f"Could not apply filters: {exc}")

    filter_payload = {"version": 1, "source": source_name, "filters": st.session_state.filters}
    save_col.download_button(
        "Save filter definition", json_bytes(filter_payload),
        file_name=f"{st.session_state.analysis_name}_filters.json", mime="application/json",
        on_click=lambda: audit("FILTER_SET_DOWNLOADED", {"conditions": len(st.session_state.filters)}),
        use_container_width=True,
    )
    preview_col.button(
        "Preview",
        use_container_width=True,
        disabled=st.session_state.filtered_data is None,
        on_click=navigate_to_preview,
        help="Open the Preview page and display the filtered output.",
    )

    if st.session_state.filtered_data is not None:
        st.markdown("#### Filtered output")
        visible_output = render_grid(st.session_state.filtered_data, "filtered_grid")
        st.download_button(
            "Download output Excel", to_excel_bytes({"Filtered_Output": visible_output}),
            file_name=f"{st.session_state.analysis_name}_output.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            on_click=lambda: audit("OUTPUT_EXCEL_DOWNLOADED", {"rows": len(visible_output)}),
        )

if active_page == "Pivot":
    st.subheader("Pivot table")
    pivot_source = st.session_state.filtered_data if st.session_state.filtered_data is not None else (st.session_state.joined_data if st.session_state.joined_data is not None else df1)
    if pivot_source is None or pivot_source.empty:
        st.info("No analysis data is available.")
    else:
        p1, p2 = st.columns(2)
        index_columns = p1.multiselect("Rows", pivot_source.columns)
        pivot_columns = p2.multiselect("Columns", pivot_source.columns)
        numeric = list(pivot_source.select_dtypes(include="number").columns)
        values = st.multiselect("Values", pivot_source.columns, default=numeric[:1])
        aggregation = st.selectbox("Aggregation", ["sum", "mean", "count", "min", "max", "median", "nunique"])
        if st.button("Create pivot") and index_columns and values:
            pivot_df = pd.pivot_table(
                pivot_source, index=index_columns, columns=pivot_columns or None,
                values=values, aggfunc=aggregation, fill_value=0, dropna=False).reset_index()
            pivot_df.columns = [" | ".join(str(x) for x in col if str(x)) if isinstance(col, tuple) else str(col) for col in pivot_df.columns]
            st.session_state.pivot_data = pivot_df
            audit("PIVOT_CREATED", {"rows": index_columns, "columns": pivot_columns, "values": values, "aggregation": aggregation})

        pivot_df = st.session_state.get("pivot_data")
        if pivot_df is not None:
            st.caption("Column headings are automatically expanded for readability.")
            visible_pivot = render_grid(pivot_df, "pivot_grid", fit_columns=True)
            d1, d2, _pivot_spacer = st.columns([1, 1, 4])
            d1.download_button(
                "Download pivot Excel", to_excel_bytes({"Pivot_Output": visible_pivot}),
                file_name=f"{st.session_state.analysis_name}_pivot.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                on_click=lambda: audit("PIVOT_EXCEL_DOWNLOADED", {"rows": len(visible_pivot)}),
            )
            d2.download_button(
                "Download pivot CSV", visible_pivot.to_csv(index=False).encode("utf-8-sig"),
                file_name=f"{st.session_state.analysis_name}_pivot.csv", mime="text/csv",
                on_click=lambda: audit("PIVOT_CSV_DOWNLOADED", {"rows": len(visible_pivot)}),
            )

if active_page == "Charts":
    st.subheader("Interactive charts for all column types")
    chart_df = st.session_state.filtered_data if st.session_state.filtered_data is not None else (st.session_state.joined_data if st.session_state.joined_data is not None else df1)
    if chart_df is None or chart_df.empty:
        st.info("No analysis data is available.")
    else:
        chart_type = st.selectbox("Chart type", ["Bar", "Line", "Scatter", "Histogram", "Box", "Pie", "Heatmap (cross tab)"])
        columns = list(chart_df.columns)

        if chart_type == "Heatmap (cross tab)":
            h1, h2 = st.columns(2)
            row_col = h1.selectbox("Cross-tab rows", columns, key="heatmap_rows")
            col_col = h2.selectbox("Cross-tab columns", columns, index=min(1, len(columns)-1), key="heatmap_cols")
            value_cols = st.multiselect("Value columns (optional)", columns, key="heatmap_values")
            heatmap_agg = st.selectbox("Aggregation", ["Row count", "Distinct count", "Sum", "Average", "Median", "Minimum", "Maximum"], key="heatmap_agg")
            normalize = st.selectbox("Normalize", ["None", "By row (%)", "By column (%)", "Overall (%)"], key="heatmap_normalize")
            max_categories = st.slider("Maximum categories per axis", 5, 50, 20, key="heatmap_max_categories")
            if st.button("Create heatmap", type="primary"):
                try:
                    work = chart_df.copy()
                    top_rows = work[row_col].astype("string").fillna("<Missing>").value_counts().head(max_categories).index
                    top_cols = work[col_col].astype("string").fillna("<Missing>").value_counts().head(max_categories).index
                    work["__row__"] = work[row_col].astype("string").fillna("<Missing>")
                    work["__col__"] = work[col_col].astype("string").fillna("<Missing>")
                    work = work[work["__row__"].isin(top_rows) & work["__col__"].isin(top_cols)]

                    if heatmap_agg == "Row count" or not value_cols:
                        cross = pd.crosstab(work["__row__"], work["__col__"])
                    else:
                        frames = []
                        for value_col in value_cols:
                            if heatmap_agg == "Distinct count":
                                pivot = pd.pivot_table(work, index="__row__", columns="__col__", values=value_col, aggfunc=pd.Series.nunique, fill_value=0)
                            else:
                                work["__heat_value__"] = safe_numeric_series(work[value_col])
                                agg_map = {"Sum":"sum", "Average":"mean", "Median":"median", "Minimum":"min", "Maximum":"max"}
                                pivot = pd.pivot_table(work, index="__row__", columns="__col__", values="__heat_value__", aggfunc=agg_map[heatmap_agg], fill_value=0)
                            if len(value_cols) > 1:
                                pivot.columns = [f"{value_col} | {c}" for c in pivot.columns]
                            frames.append(pivot)
                        cross = pd.concat(frames, axis=1)

                    if normalize == "By row (%)":
                        cross = cross.div(cross.sum(axis=1).replace(0, np.nan), axis=0) * 100
                    elif normalize == "By column (%)":
                        cross = cross.div(cross.sum(axis=0).replace(0, np.nan), axis=1) * 100
                    elif normalize == "Overall (%)":
                        total = cross.to_numpy().sum()
                        cross = cross / total * 100 if total else cross

                    fig = px.imshow(cross, text_auto=".2f", aspect="auto", labels={"x": col_col, "y": row_col, "color": heatmap_agg}, title=f"Cross-tab heatmap: {row_col} × {col_col}")
                    plot_chart(fig, use_container_width=True)
                    st.dataframe(cross, use_container_width=True)
                    audit("HEATMAP_CREATED", {"rows": row_col, "columns": col_col, "values": value_cols, "aggregation": heatmap_agg, "normalize": normalize})
                except Exception as exc:
                    st.error(f"Could not create heatmap: {exc}")
        else:
            x_columns = st.multiselect("X axis / category columns", columns, default=[columns[0]], max_selections=3)
            y_columns = st.multiselect("Y axis / value columns", columns, default=[])
            aggregation = st.selectbox(
                "Aggregation",
                ["Row count", "Distinct count", "Sum", "Average", "Median", "Minimum", "Maximum"],
                help="Select multiple columns to generate multiple series. Row count works without a Y column.",
            )
            color_col = st.selectbox("Color / group", ["None"] + columns)
            top_n = st.slider("Maximum categories", 5, 100, 30)
            if st.button("Create chart"):
                try:
                    if not x_columns:
                        raise ValueError("Select at least one X-axis/category column.")
                    color = None if color_col == "None" else color_col
                    x_col = x_columns[0] if len(x_columns) == 1 else " | ".join(x_columns)
                    work = chart_df.copy()
                    if len(x_columns) > 1:
                        work[x_col] = work[x_columns].astype("string").fillna("<Missing>").agg(" | ".join, axis=1)

                    if chart_type in {"Scatter", "Box"} and not y_columns:
                        raise ValueError(f"Select at least one Y-axis column for a {chart_type.lower()} chart.")

                    if chart_type == "Histogram":
                        melted = work.melt(value_vars=x_columns, var_name="column", value_name="value")
                        fig = px.histogram(melted, x="value", color="column", barmode="overlay")
                    elif chart_type == "Scatter":
                        scatter_y = y_columns[:5]
                        melted = work.melt(id_vars=[x_col] + ([color] if color and color != x_col else []), value_vars=scatter_y, var_name="series", value_name="value")
                        melted["value"] = safe_numeric_series(melted["value"])
                        fig = px.scatter(melted, x=x_col, y="value", color="series", symbol=color if color and color in melted.columns else None)
                    elif chart_type == "Box":
                        melted = work.melt(id_vars=[x_col], value_vars=y_columns, var_name="series", value_name="value")
                        melted["value"] = safe_numeric_series(melted["value"])
                        fig = px.box(melted, x=x_col, y="value", color="series", points="outliers")
                    else:
                        series_cols = y_columns or [None]
                        frames = []
                        for y_col in series_cols:
                            plot_df, plot_y = build_chart_data(work, x_col, y_col, aggregation, chart_type, top_n)
                            plot_df = plot_df.copy()
                            plot_df["series"] = y_col or aggregation
                            plot_df["value"] = plot_df[plot_y]
                            frames.append(plot_df[[x_col, "series", "value"]])
                        combined = pd.concat(frames, ignore_index=True)
                        if chart_type == "Bar":
                            fig = px.bar(combined, x=x_col, y="value", color="series", barmode="group")
                        elif chart_type == "Line":
                            fig = px.line(combined, x=x_col, y="value", color="series", markers=True)
                        elif chart_type == "Pie":
                            if len(series_cols) > 1:
                                raise ValueError("Pie charts support one selected value column at a time.")
                            fig = px.pie(combined, names=x_col, values="value")
                        else:
                            raise ValueError("Unsupported chart configuration.")
                    plot_chart(fig, use_container_width=True)
                    audit("CHART_CREATED", {"type": chart_type, "x": x_columns, "y": y_columns, "aggregation": aggregation, "color": color_col})
                except Exception as exc:
                    st.error(f"Could not create chart: {exc}")

if active_page == "Data Profile":
    st.subheader("Detailed data quality profile")
    options = {"File 1": df1}
    if df2 is not None:
        options["File 2"] = df2
    if st.session_state.joined_data is not None:
        options["Joined data"] = st.session_state.joined_data
    if st.session_state.filtered_data is not None:
        options["Filtered output"] = st.session_state.filtered_data
    profile_name = st.radio("Profile source", options.keys(), horizontal=True)
    profile = options[profile_name]
    summary = quality_summary(profile)
    q1, q2, q3, q4, q5, q6 = st.columns(6)
    q1.metric("Rows", f"{summary['rows']:,}")
    q2.metric("Columns", f"{summary['columns']:,}")
    q3.metric("Duplicate rows", f"{summary['duplicate_rows']:,}")
    q4.metric("Missing cells", f"{summary['missing_cells']:,}")
    q5.metric("IQR outliers", f"{summary['outliers']:,}")
    q6.metric("Invalid values", f"{summary['invalid_values']:,}")

    profile_df = detailed_profile(profile)
    st.dataframe(profile_df, use_container_width=True, hide_index=True)
    st.caption("Invalid values identify failed conversions in columns that are predominantly numeric-like or date-like. Outliers use the 1.5×IQR rule.")

    st.subheader("Data cards")
    card_controls_1, card_controls_2 = st.columns([1, 3])
    card_view = card_controls_1.radio(
        "Card view", ["Compact", "Detailed"], horizontal=True, key="profile_card_view"
    )
    selected_card_columns = card_controls_2.multiselect(
        "Columns to display",
        list(profile.columns),
        default=list(profile.columns[:min(8, len(profile.columns))]),
        key="profile_card_columns",
        placeholder="Select one or more columns",
    )

    if not selected_card_columns:
        st.info("Select at least one column to display its data card.")
    else:
        cards_per_row = 3 if card_view == "Compact" else 2
        for start in range(0, len(selected_card_columns), cards_per_row):
            card_row = st.columns(cards_per_row)
            for position, column in enumerate(selected_card_columns[start:start + cards_per_row]):
                series = profile[column]
                row = profile_df.loc[profile_df["column"] == column].iloc[0]
                with card_row[position]:
                    with st.container(border=True):
                        st.markdown(f"**{column}**")
                        st.caption(f"{row['semantic_type']} · {row['physical_type']}")
                        m1, m2, m3 = st.columns(3)
                        m1.metric("Valid", f"{int(row['non_null']):,}")
                        m2.metric("Missing", f"{int(row['missing']):,}", f"{float(row['missing_pct']):.1f}%")
                        m3.metric("Unique", f"{int(row['unique_values']):,}")

                        if card_view == "Detailed":
                            d1, d2, d3 = st.columns(3)
                            d1.metric("Duplicates", f"{int(row['duplicate_values']):,}")
                            d2.metric("Invalid", f"{int(row['invalid_values']):,}")
                            d3.metric("Consistency", f"{float(row['type_consistency_pct']):.1f}%")

                            semantic = str(row["semantic_type"])
                            if semantic in {"numerical", "numeric-like text"}:
                                numeric = safe_numeric_series(series).dropna()
                                if not numeric.empty:
                                    stats = pd.DataFrame({
                                        "Metric": ["Mean", "Median", "Minimum", "Maximum", "Std. deviation", "IQR outliers"],
                                        "Value": [
                                            numeric.mean(), numeric.median(), numeric.min(), numeric.max(),
                                            numeric.std(), int(row["outliers_iqr"]),
                                        ],
                                    })
                                    stats["Value"] = stats["Value"].map(
                                        lambda value: f"{value:,.2f}" if isinstance(value, (int, float, np.integer, np.floating)) and not pd.isna(value) else str(value)
                                    )
                                    st.dataframe(stats, use_container_width=True, hide_index=True)
                                    plot_chart(
                                        px.histogram(numeric, nbins=20, labels={"value": column}),
                                        use_container_width=True, key=f"profile_card_hist_{start}_{position}_{column}"
                                    )
                            elif semantic in {"datetime", "date-like text"}:
                                dates = pd.to_datetime(series, errors="coerce").dropna()
                                if not dates.empty:
                                    date_stats = pd.DataFrame({
                                        "Metric": ["Earliest", "Latest", "Distinct dates"],
                                        "Value": [str(dates.min()), str(dates.max()), f"{dates.nunique():,}"],
                                    })
                                    st.dataframe(date_stats, use_container_width=True, hide_index=True)
                                    monthly = dates.dt.to_period("M").astype(str).value_counts().sort_index().tail(24).reset_index()
                                    monthly.columns = ["Period", "Count"]
                                    plot_chart(
                                        px.bar(monthly, x="Period", y="Count"),
                                        use_container_width=True, key=f"profile_card_date_{start}_{position}_{column}"
                                    )
                            else:
                                top_values = series.astype("string").fillna("<Missing>").value_counts(dropna=False).head(10).reset_index()
                                top_values.columns = ["Value", "Count"]
                                st.dataframe(top_values, use_container_width=True, hide_index=True)
                                plot_chart(
                                    px.bar(top_values, x="Count", y="Value", orientation="h"),
                                    use_container_width=True, key=f"profile_card_cat_{start}_{position}_{column}"
                                )
                        else:
                            top_values = series.astype("string").fillna("<Missing>").value_counts(dropna=False).head(3)
                            if not top_values.empty:
                                st.caption("Top values")
                                for value, count in top_values.items():
                                    label = str(value)
                                    if len(label) > 36:
                                        label = label[:33] + "..."
                                    st.write(f"{label}: **{int(count):,}**")


if active_page == "EDA":
    st.subheader("Exploratory Data Analysis on joined output")
    eda_df = st.session_state.filtered_data if st.session_state.filtered_data is not None else (st.session_state.joined_data if st.session_state.joined_data is not None else df1)
    if eda_df is None or eda_df.empty:
        st.info("Run the join first. EDA uses the filtered output when available; otherwise it uses the complete joined data.")
    else:
        groups = classify_columns(eda_df)
        all_columns = list(eda_df.columns)
        numerical_cols = groups["numeric"]
        categorical_cols = groups["categorical"] + groups["boolean"]
        datetime_cols = groups["datetime"]

        st.markdown("#### Descriptive analysis for all features")
        d1, d2, d3, d4 = st.columns(4)
        d1.metric("All features", len(all_columns))
        d2.metric("Numeric / numeric-like", len(numerical_cols))
        d3.metric("Categorical / boolean", len(categorical_cols))
        d4.metric("Date/time", len(datetime_cols))
        st.dataframe(all_column_descriptive_summary(eda_df), use_container_width=True, hide_index=True)


        st.markdown("#### Time-based analysis")
        if not datetime_cols:
            st.info("No date/time column was detected with at least 90% parseable values.")
        else:
            t1, t2, t3 = st.columns(3)
            date_col = t1.selectbox("Date column", datetime_cols, key="eda_date")
            grain = t2.selectbox("Time grain", ["Daily", "Weekly", "Monthly", "Quarterly", "Yearly"], key="eda_grain")
            measure = t3.selectbox("Measure (any column)", ["Row count"] + all_columns, key="eda_measure")
            aggregation_options = ["count", "nunique"] if measure == "Row count" or measure not in numerical_cols else ["sum", "mean", "median", "min", "max", "count", "nunique"]
            aggregation = st.selectbox("Aggregation", aggregation_options, key="eda_agg")
            temp = eda_df.copy()
            temp["__date__"] = pd.to_datetime(temp[date_col], errors="coerce")
            temp = temp[temp["__date__"].notna()]
            freq = {"Daily":"D", "Weekly":"W", "Monthly":"MS", "Quarterly":"QS", "Yearly":"YS"}[grain]
            if measure == "Row count":
                trend = temp.set_index("__date__").resample(freq).size().rename("value").reset_index()
            elif aggregation == "nunique":
                trend = temp.set_index("__date__")[measure].resample(freq).nunique().rename("value").reset_index()
            elif aggregation == "count":
                trend = temp.set_index("__date__")[measure].resample(freq).count().rename("value").reset_index()
            else:
                temp["__measure__"] = safe_numeric_series(temp[measure])
                trend = temp.set_index("__date__")["__measure__"].resample(freq).agg(aggregation).rename("value").reset_index()
            trend["period_change_pct"] = trend["value"].pct_change() * 100
            plot_chart(px.line(trend, x="__date__", y="value", markers=True, title=f"{grain} trend"), use_container_width=True)
            st.dataframe(trend.rename(columns={"__date__":"period"}), use_container_width=True, hide_index=True)

        st.markdown("#### Correlation and association analysis")
        selected_assoc = st.multiselect(
            "Select columns of any type", all_columns, default=all_columns,
            key="eda_assoc", help="All columns are selected by default. Remove columns to narrow the analysis."
        )
        selected_algorithms = st.multiselect(
            "Correlation algorithms", ["Pearson", "Spearman", "Kendall"],
            default=["Spearman"], key="eda_corr_algorithms"
        )
        if len(selected_assoc) >= 2 and selected_algorithms:
            for algorithm in selected_algorithms:
                method = algorithm.lower()
                assoc = encoded_association(eda_df, selected_assoc, method=method)
                plot_chart(
                    px.imshow(assoc, text_auto=".2f", aspect="auto", title=f"{algorithm} correlation / association across encoded columns"),
                    use_container_width=True, key=f"eda_assoc_{method}"
                )
                st.markdown(f"##### {algorithm} correlation summary")
                st.markdown(correlation_summary_text(assoc))
            st.caption("Numeric-like fields are converted, dates use timestamps, and categorical values are factor-encoded. Pearson measures linear association, Spearman rank association, and Kendall ordinal concordance.")

        st.markdown("#### Outlier and anomaly detection")
        anomaly_col = st.selectbox("Column of any type", all_columns, key="eda_anomaly_col")
        anomaly_semantic = infer_semantic_type(eda_df[anomaly_col])
        if anomaly_semantic in {"numerical", "numeric-like text"}:
            numeric_series = safe_numeric_series(eda_df[anomaly_col])
            method = st.radio("Method", ["IQR", "Z-score"], horizontal=True, key="eda_outlier_method")
            if method == "IQR":
                mask = outlier_mask_iqr(numeric_series)
                detail = "Outside Q1 − 1.5×IQR or Q3 + 1.5×IQR"
            else:
                std = numeric_series.std(ddof=0)
                z = (numeric_series - numeric_series.mean()) / std if pd.notna(std) and std != 0 else pd.Series(0, index=numeric_series.index)
                mask = z.abs() > 3
                detail = "Absolute Z-score greater than 3"
            st.metric("Outlier rows", f"{int(mask.sum()):,}")
            st.caption(detail)
            plot_chart(px.box(y=numeric_series, points="outliers", title=f"Outliers: {anomaly_col}"), use_container_width=True)
            st.dataframe(eda_df.loc[mask].head(1000), use_container_width=True, hide_index=True)
        elif anomaly_semantic in {"datetime", "date-like text"}:
            parsed = pd.to_datetime(eda_df[anomaly_col], errors="coerce")
            invalid = parsed.isna() & eda_df[anomaly_col].notna()
            st.metric("Invalid date values", f"{int(invalid.sum()):,}")
            st.dataframe(eda_df.loc[invalid].head(1000), use_container_width=True, hide_index=True)
        else:
            frequency = eda_df[anomaly_col].astype("string").fillna("<Missing>").value_counts(dropna=False)
            threshold = st.slider("Rare-value threshold", 1, 100, 5, help="Values occurring at or below this count are treated as rare anomalies.")
            rare_values = frequency[frequency <= threshold].index
            mask = eda_df[anomaly_col].astype("string").fillna("<Missing>").isin(rare_values)
            st.metric("Rare/anomalous rows", f"{int(mask.sum()):,}")
            st.dataframe(frequency.rename("count").reset_index().rename(columns={"index":"value"}), use_container_width=True, hide_index=True)
            st.dataframe(eda_df.loc[mask].head(1000), use_container_width=True, hide_index=True)

if active_page == "Audit":
    st.subheader("Audit trail and complete analysis dump")
    audit_df = pd.DataFrame(st.session_state.audit_log)
    if audit_df.empty:
        st.info("Audit entries appear after you run joins, add/apply filters, create pivots/charts, or download outputs.")
    else:
        st.dataframe(audit_df, use_container_width=True, hide_index=True)

    output_df = st.session_state.filtered_data
    if output_df is None:
        output_df = st.session_state.joined_data
    if output_df is None:
        output_df = df1

    metadata = {
        "analysis_name": st.session_state.analysis_name,
        "created_at": utc_now(),
        "dataset_1": ({
            "source_type": "upload", "name": file_1.name, "sheet": sheet_1,
            "sha256_prefix": file_fingerprint(bytes_1), "rows": len(df1),
        } if source_type_1 == "Upload file" else {
            "source_type": "database_query", "database_type": db_meta_1.get("database_type"),
            "endpoint": db_meta_1.get("host") or db_meta_1.get("server_hostname"),
            "database": db_meta_1.get("database"), "catalog": db_meta_1.get("catalog"),
            "schema": db_meta_1.get("schema"),
            "query_hash": hashlib.sha256(db_meta_1.get("query", "").encode("utf-8")).hexdigest()[:16],
            "rows": len(df1),
        }),
        "dataset_2": (({
            "source_type": "upload", "name": file_2.name, "sheet": sheet_2,
            "sha256_prefix": file_fingerprint(bytes_2), "rows": len(df2),
        } if source_type_2 == "Upload file" else {
            "source_type": "database_query", "database_type": db_meta_2.get("database_type"),
            "endpoint": db_meta_2.get("host") or db_meta_2.get("server_hostname"),
            "database": db_meta_2.get("database"), "catalog": db_meta_2.get("catalog"),
            "schema": db_meta_2.get("schema"),
            "query_hash": hashlib.sha256(db_meta_2.get("query", "").encode("utf-8")).hexdigest()[:16],
            "rows": len(df2),
        }) if df2 is not None else None),
        "join_config": st.session_state.join_config,
        "filter_config": st.session_state.last_filter_config,
        "output_rows": len(output_df),
        "output_columns": list(output_df.columns),
    }
    dump = build_dump(output_df, st.session_state.filters, metadata)
    st.download_button(
        "Download complete analysis dump (.zip)", dump,
        file_name=f"{st.session_state.analysis_name}_dump.zip", mime="application/zip",
        on_click=lambda: audit("ANALYSIS_DUMP_DOWNLOADED", {"rows": len(output_df), "audit_entries": len(st.session_state.audit_log)}),
        disabled=output_df.empty,
    )
    st.caption("The dump contains output.xlsx, output.csv, filters.json, audit_log.csv/json, and session_metadata.json.")
