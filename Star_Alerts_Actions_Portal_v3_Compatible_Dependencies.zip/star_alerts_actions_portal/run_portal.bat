@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo ============================================================
echo  Star Health Alerts ^& Actions Portal
echo ============================================================

rem Prefer standard 64-bit CPython versions with broad wheel availability.
set "PYTHON_CMD="
where py >nul 2>nul
if !errorlevel!==0 (
    py -3.12 -c "import sys,platform; assert platform.architecture()[0]=='64bit'" >nul 2>nul && set "PYTHON_CMD=py -3.12"
    if not defined PYTHON_CMD py -3.11 -c "import sys,platform; assert platform.architecture()[0]=='64bit'" >nul 2>nul && set "PYTHON_CMD=py -3.11"
    if not defined PYTHON_CMD py -3.10 -c "import sys,platform; assert platform.architecture()[0]=='64bit'" >nul 2>nul && set "PYTHON_CMD=py -3.10"
)

if not defined PYTHON_CMD (
    where python >nul 2>nul
    if !errorlevel!==0 (
        for /f "delims=" %%V in ('python -c "import sys,platform; print(f'{sys.version_info.major}.{sys.version_info.minor}|{platform.architecture()[0]}')" 2^>nul') do set "PYINFO=%%V"
        for /f "tokens=1,2 delims=|" %%A in ("!PYINFO!") do (
            set "PYVER=%%A"
            set "PYARCH=%%B"
        )
        if "!PYARCH!"=="64bit" (
            if "!PYVER!"=="3.12" set "PYTHON_CMD=python"
            if "!PYVER!"=="3.11" set "PYTHON_CMD=python"
            if "!PYVER!"=="3.10" set "PYTHON_CMD=python"
        )
    )
)

if not defined PYTHON_CMD (
    echo.
    echo ERROR: A supported 64-bit Python installation was not found.
    echo Install 64-bit CPython 3.12 from python.org and select
    echo "Add python.exe to PATH", then run this file again.
    echo.
    pause
    exit /b 1
)

echo Using: !PYTHON_CMD!

rem Validate or recreate the virtual environment.
set "RECREATE_VENV=0"
if exist .venv\Scripts\python.exe (
    .venv\Scripts\python.exe -c "import sys,platform; assert sys.version_info[:2] in [(3,10),(3,11),(3,12)] and platform.architecture()[0]=='64bit'" >nul 2>nul
    if not !errorlevel!==0 set "RECREATE_VENV=1"
)
if "!RECREATE_VENV!"=="1" (
    echo Removing incompatible virtual environment...
    rmdir /s /q .venv
)
if not exist .venv\Scripts\python.exe (
    echo Creating virtual environment...
    !PYTHON_CMD! -m venv .venv || goto :error
)

call .venv\Scripts\activate.bat || goto :error

echo Upgrading pip...
python -m pip install --upgrade pip || goto :error

rem Do not pin pandas/numpy/pyarrow directly. Streamlit will choose versions
rem compatible with this Python and with the configured package index.
echo Installing compatible binary-preferred dependencies...
python -m pip install --prefer-binary --upgrade -r requirements.txt || goto :install_error

rem Verify the exact runtime dependencies before launch.
python -c "import streamlit,pandas,plotly,numpy,pyarrow; print('Installed: Streamlit',streamlit.__version__,'| pandas',pandas.__version__)" || goto :install_error

echo.
echo Starting portal at http://localhost:8501
echo Press Ctrl+C in this window to stop it.
python -m streamlit run app.py
exit /b 0

:install_error
echo.
echo ERROR: Dependency installation failed.
echo.
echo Run the following command to see which package index pip is using:
echo   .venv\Scripts\python.exe -m pip config list

echo If your organization uses a private package repository, it must contain

echo compatible wheels for Streamlit and its dependencies. You may also run:
echo   .venv\Scripts\python.exe -m pip install --prefer-binary streamlit plotly

echo.
pause
exit /b 1

:error
echo.
echo Portal setup failed. Review the error above.
echo.
pause
exit /b 1
