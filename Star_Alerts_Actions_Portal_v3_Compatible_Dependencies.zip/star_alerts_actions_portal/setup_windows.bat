@echo off
call "%~dp0run_portal.bat"
