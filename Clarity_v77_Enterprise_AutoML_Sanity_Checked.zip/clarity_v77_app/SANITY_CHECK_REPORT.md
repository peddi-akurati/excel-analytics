# Clarity v77 Sanity Check Report

## Validation completed

- Python syntax compilation: passed
- Clarity startup validator: passed
- Navigation and widget key static scan: passed; no duplicate constant widget keys found
- Regression AutoML execution: passed
- Multiclass AutoML execution: passed
- Cross-validation and model leaderboard generation: passed
- Numeric/categorical preprocessing and missing-value handling: passed
- Clustering preprocessing matrix generation: passed
- Anomaly-detection preprocessing compatibility: passed
- Deployment ZIP structure: passed
- Standalone deployment `inference.py` execution: passed after correction
- ZIP integrity: passed

## Corrected defect

The deployment bundle stores a Clarity model artifact dictionary containing the trained pipeline and metadata. The generated inference script previously called `.predict()` directly on the dictionary. It now extracts the `pipeline`, validates required feature columns, preserves feature order, and then performs prediction/probability scoring.

## Car_sales.csv validation

Regression training completed successfully with `Price_in_thousands` as the target. The exported deployment bundle also scored a five-row CSV successfully.

`Power_perf_factor` should normally be excluded from price prediction because it appears strongly derived from or directly related to the target price and can create target leakage. Identifier-like fields such as `Manufacturer`, `Model`, and highly specific launch/date values should be evaluated carefully based on the intended prediction point.

## Runtime scope

Database connections require valid external PostgreSQL or Databricks credentials and were validated structurally rather than against a live remote database. Streamlit browser interaction was validated through source, state, widget-key, and functional component checks in the available runtime.
