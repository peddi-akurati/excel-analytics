"""Lightweight package validation that does not require database connectivity."""
from __future__ import annotations

import ast
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
APP = ROOT / "app.py"

source = APP.read_text(encoding="utf-8")
ast.parse(source, filename=str(APP))
compile(source, str(APP), "exec")

# Prevent regression of the v8 startup bug: CSS must not be embedded in an f-string.
for node in ast.walk(ast.parse(source)):
    if isinstance(node, ast.JoinedStr):
        raw = ast.get_source_segment(source, node) or ""
        if "<style>" in raw:
            raise RuntimeError("CSS was placed in an f-string; CSS braces may cause NameError at runtime.")

required = ["requirements.txt", "README.md", ".streamlit/config.toml"]
missing = [name for name in required if not (ROOT / name).exists()]
if missing:
    raise FileNotFoundError(f"Missing required package files: {missing}")

print("Clarity startup validation passed.")
